<?php

namespace addnpc
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'base/addnpc/'.$___TEMP_key; 
	
	$___PRESET_ADDNPC__VARS__npcinit=$npcinit;$___PRESET_ADDNPC__VARS__anpcinfo=$anpcinfo;
function ___pre_init() { global $___PRESET_ADDNPC__VARS__npcinit,$npcinit,$___PRESET_ADDNPC__VARS__anpcinfo,$anpcinfo;$npcinit=$___PRESET_ADDNPC__VARS__npcinit;$anpcinfo=$___PRESET_ADDNPC__VARS__anpcinfo; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_ADDNPC_PRESET_VARS','$___PRESET_ADDNPC__VARS__npcinit=$npcinit;$___PRESET_ADDNPC__VARS__anpcinfo=$anpcinfo;');
define('___LOAD_MOD_ADDNPC_PRESET_VARS','global $___PRESET_ADDNPC__VARS__npcinit,$npcinit,$___PRESET_ADDNPC__VARS__anpcinfo,$anpcinfo;$npcinit=$___PRESET_ADDNPC__VARS__npcinit;$anpcinfo=$___PRESET_ADDNPC__VARS__anpcinfo;');
define('MODULE_ADDNPC_GLOBALS_VARNAMES','npcinit,anpcinfo');
define('MOD_ADDNPC',1);
define('IMPORT_MODULE_ADDNPC_GLOBALS','global $___LOCAL_ADDNPC__VARS__npcinit,$___LOCAL_ADDNPC__VARS__anpcinfo; $npcinit=&$___LOCAL_ADDNPC__VARS__npcinit; $anpcinfo=&$___LOCAL_ADDNPC__VARS__anpcinfo; ');
define('PREFIX_MODULE_ADDNPC_GLOBALS','\'; global $___LOCAL_ADDNPC__VARS__npcinit; ${$___TEMP_PREFIX.\'npcinit\'}=&$___LOCAL_ADDNPC__VARS__npcinit; global $___LOCAL_ADDNPC__VARS__anpcinfo; ${$___TEMP_PREFIX.\'anpcinfo\'}=&$___LOCAL_ADDNPC__VARS__anpcinfo; unset($___TEMP_PREFIX); ');
define('MODULE_ADDNPC_GLOBALS','\'; global $___LOCAL_ADDNPC__VARS__npcinit; ${$___TEMP_VARNAME}[\'npcinit\']=&$___LOCAL_ADDNPC__VARS__npcinit; global $___LOCAL_ADDNPC__VARS__anpcinfo; ${$___TEMP_VARNAME}[\'anpcinfo\']=&$___LOCAL_ADDNPC__VARS__anpcinfo; unset($___TEMP_VARNAME); ');

global $___PRIVATE_ADDNPC__VARS_____PRIVATE_PFUNC,$___PRIVATE_ADDNPC__VARS_____PRIVATE_CFUNC,$___LOCAL_ADDNPC__VARS__npcinit,$___LOCAL_ADDNPC__VARS__anpcinfo;
$___PRIVATE_ADDNPC__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_ADDNPC__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_ADDNPC__VARS__npcinit=&$npcinit;$___LOCAL_ADDNPC__VARS__anpcinfo=&$anpcinfo;
unset($npcinit,$anpcinfo);
hook_register('addnpc','parse_itmuse_desc');hook_register('addnpc','addnpc');hook_register('addnpc','get_addnpclist');hook_register('addnpc','itemuse');hook_register('addnpc','parse_news');
function ___post_init() { global $___PRIVATE_ADDNPC__VARS_____PRIVATE_PFUNC,$___PRIVATE_ADDNPC__VARS_____PRIVATE_CFUNC,$___LOCAL_ADDNPC__VARS__npcinit,$___LOCAL_ADDNPC__VARS__anpcinfo;
$___LOCAL_ADDNPC__VARS__npcinit=$GLOBALS['npcinit'];$___LOCAL_ADDNPC__VARS__anpcinfo=$GLOBALS['anpcinfo'];
unset($GLOBALS['npcinit'],$GLOBALS['anpcinfo']);
}
	
}

?>