<?php

namespace scpdrink
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'base/items/scpdrink/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SCPDRINK_PRESET_VARS','');
define('___LOAD_MOD_SCPDRINK_PRESET_VARS','');
define('MODULE_SCPDRINK_GLOBALS_VARNAMES','');
define('MOD_SCPDRINK',1);
define('IMPORT_MODULE_SCPDRINK_GLOBALS','');
define('PREFIX_MODULE_SCPDRINK_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_SCPDRINK_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SCPDRINK__VARS_____PRIVATE_PFUNC,$___PRIVATE_SCPDRINK__VARS_____PRIVATE_CFUNC;
$___PRIVATE_SCPDRINK__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SCPDRINK__VARS_____PRIVATE_CFUNC=Array();

hook_register('scpdrink','itemuse');hook_register('scpdrink','parse_news');
function ___post_init() { global $___PRIVATE_SCPDRINK__VARS_____PRIVATE_PFUNC,$___PRIVATE_SCPDRINK__VARS_____PRIVATE_CFUNC;


}
	
}

?>