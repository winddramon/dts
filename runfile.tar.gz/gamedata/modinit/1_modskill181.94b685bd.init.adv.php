<?php

namespace skill181
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill181/'.$___TEMP_key; 
	
	$___PRESET_SKILL181__VARS__lvupss=$lvupss;$___PRESET_SKILL181__VARS__lvupssref=$lvupssref;$___PRESET_SKILL181__VARS__skill181_init_mss=$skill181_init_mss;$___PRESET_SKILL181__VARS__skill181_init_ss=$skill181_init_ss;
function ___pre_init() { global $___PRESET_SKILL181__VARS__lvupss,$lvupss,$___PRESET_SKILL181__VARS__lvupssref,$lvupssref,$___PRESET_SKILL181__VARS__skill181_init_mss,$skill181_init_mss,$___PRESET_SKILL181__VARS__skill181_init_ss,$skill181_init_ss;$lvupss=$___PRESET_SKILL181__VARS__lvupss;$lvupssref=$___PRESET_SKILL181__VARS__lvupssref;$skill181_init_mss=$___PRESET_SKILL181__VARS__skill181_init_mss;$skill181_init_ss=$___PRESET_SKILL181__VARS__skill181_init_ss; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL181_PRESET_VARS','$___PRESET_SKILL181__VARS__lvupss=$lvupss;$___PRESET_SKILL181__VARS__lvupssref=$lvupssref;$___PRESET_SKILL181__VARS__skill181_init_mss=$skill181_init_mss;$___PRESET_SKILL181__VARS__skill181_init_ss=$skill181_init_ss;');
define('___LOAD_MOD_SKILL181_PRESET_VARS','global $___PRESET_SKILL181__VARS__lvupss,$lvupss,$___PRESET_SKILL181__VARS__lvupssref,$lvupssref,$___PRESET_SKILL181__VARS__skill181_init_mss,$skill181_init_mss,$___PRESET_SKILL181__VARS__skill181_init_ss,$skill181_init_ss;$lvupss=$___PRESET_SKILL181__VARS__lvupss;$lvupssref=$___PRESET_SKILL181__VARS__lvupssref;$skill181_init_mss=$___PRESET_SKILL181__VARS__skill181_init_mss;$skill181_init_ss=$___PRESET_SKILL181__VARS__skill181_init_ss;');
define('MOD_SKILL181_INFO','club;hidden;');
define('MODULE_SKILL181_GLOBALS_VARNAMES','lvupss,lvupssref,skill181_init_mss,skill181_init_ss');
define('MOD_SKILL181',1);
define('IMPORT_MODULE_SKILL181_GLOBALS','global $___LOCAL_SKILL181__VARS__lvupss,$___LOCAL_SKILL181__VARS__lvupssref,$___LOCAL_SKILL181__VARS__skill181_init_mss,$___LOCAL_SKILL181__VARS__skill181_init_ss; $lvupss=&$___LOCAL_SKILL181__VARS__lvupss; $lvupssref=&$___LOCAL_SKILL181__VARS__lvupssref; $skill181_init_mss=&$___LOCAL_SKILL181__VARS__skill181_init_mss; $skill181_init_ss=&$___LOCAL_SKILL181__VARS__skill181_init_ss; ');
define('PREFIX_MODULE_SKILL181_GLOBALS','\'; global $___LOCAL_SKILL181__VARS__lvupss; ${$___TEMP_PREFIX.\'lvupss\'}=&$___LOCAL_SKILL181__VARS__lvupss; global $___LOCAL_SKILL181__VARS__lvupssref; ${$___TEMP_PREFIX.\'lvupssref\'}=&$___LOCAL_SKILL181__VARS__lvupssref; global $___LOCAL_SKILL181__VARS__skill181_init_mss; ${$___TEMP_PREFIX.\'skill181_init_mss\'}=&$___LOCAL_SKILL181__VARS__skill181_init_mss; global $___LOCAL_SKILL181__VARS__skill181_init_ss; ${$___TEMP_PREFIX.\'skill181_init_ss\'}=&$___LOCAL_SKILL181__VARS__skill181_init_ss; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL181_GLOBALS','\'; global $___LOCAL_SKILL181__VARS__lvupss; ${$___TEMP_VARNAME}[\'lvupss\']=&$___LOCAL_SKILL181__VARS__lvupss; global $___LOCAL_SKILL181__VARS__lvupssref; ${$___TEMP_VARNAME}[\'lvupssref\']=&$___LOCAL_SKILL181__VARS__lvupssref; global $___LOCAL_SKILL181__VARS__skill181_init_mss; ${$___TEMP_VARNAME}[\'skill181_init_mss\']=&$___LOCAL_SKILL181__VARS__skill181_init_mss; global $___LOCAL_SKILL181__VARS__skill181_init_ss; ${$___TEMP_VARNAME}[\'skill181_init_ss\']=&$___LOCAL_SKILL181__VARS__skill181_init_ss; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL181__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL181__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL181__VARS__lvupss,$___LOCAL_SKILL181__VARS__lvupssref,$___LOCAL_SKILL181__VARS__skill181_init_mss,$___LOCAL_SKILL181__VARS__skill181_init_ss;
$___PRIVATE_SKILL181__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL181__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_SKILL181__VARS__lvupss=&$lvupss;$___LOCAL_SKILL181__VARS__lvupssref=&$lvupssref;$___LOCAL_SKILL181__VARS__skill181_init_mss=&$skill181_init_mss;$___LOCAL_SKILL181__VARS__skill181_init_ss=&$skill181_init_ss;
unset($lvupss,$lvupssref,$skill181_init_mss,$skill181_init_ss);
hook_register('skill181','acquire181');hook_register('skill181','lost181');hook_register('skill181','lvlup');hook_register('skill181','checklvlup');
function ___post_init() { global $___PRIVATE_SKILL181__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL181__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL181__VARS__lvupss,$___LOCAL_SKILL181__VARS__lvupssref,$___LOCAL_SKILL181__VARS__skill181_init_mss,$___LOCAL_SKILL181__VARS__skill181_init_ss;
$___LOCAL_SKILL181__VARS__lvupss=$GLOBALS['lvupss'];$___LOCAL_SKILL181__VARS__lvupssref=$GLOBALS['lvupssref'];$___LOCAL_SKILL181__VARS__skill181_init_mss=$GLOBALS['skill181_init_mss'];$___LOCAL_SKILL181__VARS__skill181_init_ss=$GLOBALS['skill181_init_ss'];
unset($GLOBALS['lvupss'],$GLOBALS['lvupssref'],$GLOBALS['skill181_init_mss'],$GLOBALS['skill181_init_ss']);
}
	
}

?>