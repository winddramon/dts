<?php

namespace item_uvo_extra
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/item_extra/item_uvo_extra/'.$___TEMP_key; 
	
	$___PRESET_ITEM_UVO_EXTRA__VARS__allow_uvo_extra_gametype=$allow_uvo_extra_gametype;$___PRESET_ITEM_UVO_EXTRA__VARS__material_cards=$material_cards;
function ___pre_init() { global $___PRESET_ITEM_UVO_EXTRA__VARS__allow_uvo_extra_gametype,$allow_uvo_extra_gametype,$___PRESET_ITEM_UVO_EXTRA__VARS__material_cards,$material_cards;$allow_uvo_extra_gametype=$___PRESET_ITEM_UVO_EXTRA__VARS__allow_uvo_extra_gametype;$material_cards=$___PRESET_ITEM_UVO_EXTRA__VARS__material_cards; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_ITEM_UVO_EXTRA_PRESET_VARS','$___PRESET_ITEM_UVO_EXTRA__VARS__allow_uvo_extra_gametype=$allow_uvo_extra_gametype;$___PRESET_ITEM_UVO_EXTRA__VARS__material_cards=$material_cards;');
define('___LOAD_MOD_ITEM_UVO_EXTRA_PRESET_VARS','global $___PRESET_ITEM_UVO_EXTRA__VARS__allow_uvo_extra_gametype,$allow_uvo_extra_gametype,$___PRESET_ITEM_UVO_EXTRA__VARS__material_cards,$material_cards;$allow_uvo_extra_gametype=$___PRESET_ITEM_UVO_EXTRA__VARS__allow_uvo_extra_gametype;$material_cards=$___PRESET_ITEM_UVO_EXTRA__VARS__material_cards;');
define('MOD_ITEM_UVO_EXTRA_UVO_EXTRA_PROFILE','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\item_extra\\item_uvo_extra/uvo_extra_profile');
define('MOD_ITEM_UVO_EXTRA_UVO_EXTRA_USE','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\item_extra\\item_uvo_extra/uvo_extra_use');
define('MODULE_ITEM_UVO_EXTRA_GLOBALS_VARNAMES','allow_uvo_extra_gametype,material_cards');
define('MOD_ITEM_UVO_EXTRA',1);
define('IMPORT_MODULE_ITEM_UVO_EXTRA_GLOBALS','global $___LOCAL_ITEM_UVO_EXTRA__VARS__allow_uvo_extra_gametype,$___LOCAL_ITEM_UVO_EXTRA__VARS__material_cards; $allow_uvo_extra_gametype=&$___LOCAL_ITEM_UVO_EXTRA__VARS__allow_uvo_extra_gametype; $material_cards=&$___LOCAL_ITEM_UVO_EXTRA__VARS__material_cards; ');
define('PREFIX_MODULE_ITEM_UVO_EXTRA_GLOBALS','\'; global $___LOCAL_ITEM_UVO_EXTRA__VARS__allow_uvo_extra_gametype; ${$___TEMP_PREFIX.\'allow_uvo_extra_gametype\'}=&$___LOCAL_ITEM_UVO_EXTRA__VARS__allow_uvo_extra_gametype; global $___LOCAL_ITEM_UVO_EXTRA__VARS__material_cards; ${$___TEMP_PREFIX.\'material_cards\'}=&$___LOCAL_ITEM_UVO_EXTRA__VARS__material_cards; unset($___TEMP_PREFIX); ');
define('MODULE_ITEM_UVO_EXTRA_GLOBALS','\'; global $___LOCAL_ITEM_UVO_EXTRA__VARS__allow_uvo_extra_gametype; ${$___TEMP_VARNAME}[\'allow_uvo_extra_gametype\']=&$___LOCAL_ITEM_UVO_EXTRA__VARS__allow_uvo_extra_gametype; global $___LOCAL_ITEM_UVO_EXTRA__VARS__material_cards; ${$___TEMP_VARNAME}[\'material_cards\']=&$___LOCAL_ITEM_UVO_EXTRA__VARS__material_cards; unset($___TEMP_VARNAME); ');

global $___PRIVATE_ITEM_UVO_EXTRA__VARS_____PRIVATE_PFUNC,$___PRIVATE_ITEM_UVO_EXTRA__VARS_____PRIVATE_CFUNC,$___LOCAL_ITEM_UVO_EXTRA__VARS__allow_uvo_extra_gametype,$___LOCAL_ITEM_UVO_EXTRA__VARS__material_cards;
$___PRIVATE_ITEM_UVO_EXTRA__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_ITEM_UVO_EXTRA__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_ITEM_UVO_EXTRA__VARS__allow_uvo_extra_gametype=&$allow_uvo_extra_gametype;$___LOCAL_ITEM_UVO_EXTRA__VARS__material_cards=&$material_cards;
unset($allow_uvo_extra_gametype,$material_cards);
hook_register('item_uvo_extra','add_card_uvo_extra');hook_register('item_uvo_extra','remove_card_uvo_extra');hook_register('item_uvo_extra','get_cards_uvo_extra');hook_register('item_uvo_extra','encode_uvo_extra');hook_register('item_uvo_extra','decode_uvo_extra');hook_register('item_uvo_extra','item_uv_getcard');hook_register('item_uvo_extra','act');hook_register('item_uvo_extra','use_card_uvo_extra');hook_register('item_uvo_extra','mix_cards_uvo_extra');hook_register('item_uvo_extra','gameover_set_credits');hook_register('item_uvo_extra','player_kill_enemy');
function ___post_init() { global $___PRIVATE_ITEM_UVO_EXTRA__VARS_____PRIVATE_PFUNC,$___PRIVATE_ITEM_UVO_EXTRA__VARS_____PRIVATE_CFUNC,$___LOCAL_ITEM_UVO_EXTRA__VARS__allow_uvo_extra_gametype,$___LOCAL_ITEM_UVO_EXTRA__VARS__material_cards;
$___LOCAL_ITEM_UVO_EXTRA__VARS__allow_uvo_extra_gametype=$GLOBALS['allow_uvo_extra_gametype'];$___LOCAL_ITEM_UVO_EXTRA__VARS__material_cards=$GLOBALS['material_cards'];
unset($GLOBALS['allow_uvo_extra_gametype'],$GLOBALS['material_cards']);
}
	
}

?>