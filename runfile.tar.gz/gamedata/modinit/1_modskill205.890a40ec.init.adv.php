<?php

namespace skill205
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill205/'.$___TEMP_key; 
	
	$___PRESET_SKILL205__VARS__ragecost=$ragecost;$___PRESET_SKILL205__VARS__wep_skillkind_req=$wep_skillkind_req;$___PRESET_SKILL205__VARS__alternate_skillno205=$alternate_skillno205;$___PRESET_SKILL205__VARS__unlock_lvl205=$unlock_lvl205;
function ___pre_init() { global $___PRESET_SKILL205__VARS__ragecost,$ragecost,$___PRESET_SKILL205__VARS__wep_skillkind_req,$wep_skillkind_req,$___PRESET_SKILL205__VARS__alternate_skillno205,$alternate_skillno205,$___PRESET_SKILL205__VARS__unlock_lvl205,$unlock_lvl205;$ragecost=$___PRESET_SKILL205__VARS__ragecost;$wep_skillkind_req=$___PRESET_SKILL205__VARS__wep_skillkind_req;$alternate_skillno205=$___PRESET_SKILL205__VARS__alternate_skillno205;$unlock_lvl205=$___PRESET_SKILL205__VARS__unlock_lvl205; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL205_PRESET_VARS','$___PRESET_SKILL205__VARS__ragecost=$ragecost;$___PRESET_SKILL205__VARS__wep_skillkind_req=$wep_skillkind_req;$___PRESET_SKILL205__VARS__alternate_skillno205=$alternate_skillno205;$___PRESET_SKILL205__VARS__unlock_lvl205=$unlock_lvl205;');
define('___LOAD_MOD_SKILL205_PRESET_VARS','global $___PRESET_SKILL205__VARS__ragecost,$ragecost,$___PRESET_SKILL205__VARS__wep_skillkind_req,$wep_skillkind_req,$___PRESET_SKILL205__VARS__alternate_skillno205,$alternate_skillno205,$___PRESET_SKILL205__VARS__unlock_lvl205,$unlock_lvl205;$ragecost=$___PRESET_SKILL205__VARS__ragecost;$wep_skillkind_req=$___PRESET_SKILL205__VARS__wep_skillkind_req;$alternate_skillno205=$___PRESET_SKILL205__VARS__alternate_skillno205;$unlock_lvl205=$___PRESET_SKILL205__VARS__unlock_lvl205;');
define('MOD_SKILL205_INFO','club;battle;upgrade;');
define('MOD_SKILL205_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill205/desc');
define('MOD_SKILL205_BATTLECMD_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill205/battlecmd_desc');
define('MODULE_SKILL205_GLOBALS_VARNAMES','ragecost,wep_skillkind_req,alternate_skillno205,unlock_lvl205');
define('MOD_SKILL205',1);
define('IMPORT_MODULE_SKILL205_GLOBALS','global $___LOCAL_SKILL205__VARS__ragecost,$___LOCAL_SKILL205__VARS__wep_skillkind_req,$___LOCAL_SKILL205__VARS__alternate_skillno205,$___LOCAL_SKILL205__VARS__unlock_lvl205; $ragecost=&$___LOCAL_SKILL205__VARS__ragecost; $wep_skillkind_req=&$___LOCAL_SKILL205__VARS__wep_skillkind_req; $alternate_skillno205=&$___LOCAL_SKILL205__VARS__alternate_skillno205; $unlock_lvl205=&$___LOCAL_SKILL205__VARS__unlock_lvl205; ');
define('PREFIX_MODULE_SKILL205_GLOBALS','\'; global $___LOCAL_SKILL205__VARS__ragecost; ${$___TEMP_PREFIX.\'ragecost\'}=&$___LOCAL_SKILL205__VARS__ragecost; global $___LOCAL_SKILL205__VARS__wep_skillkind_req; ${$___TEMP_PREFIX.\'wep_skillkind_req\'}=&$___LOCAL_SKILL205__VARS__wep_skillkind_req; global $___LOCAL_SKILL205__VARS__alternate_skillno205; ${$___TEMP_PREFIX.\'alternate_skillno205\'}=&$___LOCAL_SKILL205__VARS__alternate_skillno205; global $___LOCAL_SKILL205__VARS__unlock_lvl205; ${$___TEMP_PREFIX.\'unlock_lvl205\'}=&$___LOCAL_SKILL205__VARS__unlock_lvl205; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL205_GLOBALS','\'; global $___LOCAL_SKILL205__VARS__ragecost; ${$___TEMP_VARNAME}[\'ragecost\']=&$___LOCAL_SKILL205__VARS__ragecost; global $___LOCAL_SKILL205__VARS__wep_skillkind_req; ${$___TEMP_VARNAME}[\'wep_skillkind_req\']=&$___LOCAL_SKILL205__VARS__wep_skillkind_req; global $___LOCAL_SKILL205__VARS__alternate_skillno205; ${$___TEMP_VARNAME}[\'alternate_skillno205\']=&$___LOCAL_SKILL205__VARS__alternate_skillno205; global $___LOCAL_SKILL205__VARS__unlock_lvl205; ${$___TEMP_VARNAME}[\'unlock_lvl205\']=&$___LOCAL_SKILL205__VARS__unlock_lvl205; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL205__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL205__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL205__VARS__ragecost,$___LOCAL_SKILL205__VARS__wep_skillkind_req,$___LOCAL_SKILL205__VARS__alternate_skillno205,$___LOCAL_SKILL205__VARS__unlock_lvl205;
$___PRIVATE_SKILL205__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL205__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_SKILL205__VARS__ragecost=&$ragecost;$___LOCAL_SKILL205__VARS__wep_skillkind_req=&$wep_skillkind_req;$___LOCAL_SKILL205__VARS__alternate_skillno205=&$alternate_skillno205;$___LOCAL_SKILL205__VARS__unlock_lvl205=&$unlock_lvl205;
unset($ragecost,$wep_skillkind_req,$alternate_skillno205,$unlock_lvl205);
hook_register('skill205','acquire205');hook_register('skill205','unlock205');hook_register('skill205','lost205');hook_register('skill205','check_unlocked205');hook_register('skill205','get_rage_cost205');hook_register('skill205','strike_prepare');hook_register('skill205','upgrade205');hook_register('skill205','get_physical_dmg_multiplier');hook_register('skill205','ex_attack_prepare');hook_register('skill205','calculate_ex_attack_dmg_multiplier');hook_register('skill205','calculate_weapon_wound_multiplier');hook_register('skill205','parse_news');
function ___post_init() { global $___PRIVATE_SKILL205__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL205__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL205__VARS__ragecost,$___LOCAL_SKILL205__VARS__wep_skillkind_req,$___LOCAL_SKILL205__VARS__alternate_skillno205,$___LOCAL_SKILL205__VARS__unlock_lvl205;
$___LOCAL_SKILL205__VARS__ragecost=$GLOBALS['ragecost'];$___LOCAL_SKILL205__VARS__wep_skillkind_req=$GLOBALS['wep_skillkind_req'];$___LOCAL_SKILL205__VARS__alternate_skillno205=$GLOBALS['alternate_skillno205'];$___LOCAL_SKILL205__VARS__unlock_lvl205=$GLOBALS['unlock_lvl205'];
unset($GLOBALS['ragecost'],$GLOBALS['wep_skillkind_req'],$GLOBALS['alternate_skillno205'],$GLOBALS['unlock_lvl205']);
}
	
}

?>