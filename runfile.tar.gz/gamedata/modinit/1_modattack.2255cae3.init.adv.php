<?php

namespace attack
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'base/attack/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_ATTACK_PRESET_VARS','');
define('___LOAD_MOD_ATTACK_PRESET_VARS','');
define('MODULE_ATTACK_GLOBALS_VARNAMES','');
define('MOD_ATTACK',1);
define('IMPORT_MODULE_ATTACK_GLOBALS','');
define('PREFIX_MODULE_ATTACK_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_ATTACK_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_ATTACK__VARS_____PRIVATE_PFUNC,$___PRIVATE_ATTACK__VARS_____PRIVATE_CFUNC;
$___PRIVATE_ATTACK__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_ATTACK__VARS_____PRIVATE_CFUNC=Array();

hook_register('attack','get_final_dmg_base');hook_register('attack','get_final_dmg_multiplier');hook_register('attack','apply_total_damage_modifier_invincible');hook_register('attack','apply_total_damage_modifier_special');hook_register('attack','apply_total_damage_modifier_special_set_sequence');hook_register('attack','apply_total_damage_modifier_special_check');hook_register('attack','apply_total_damage_modifier_special_core');hook_register('attack','apply_total_damage_modifier_limit');hook_register('attack','apply_total_damage_modifier_insurance');hook_register('attack','apply_total_damage_modifier_seckill');hook_register('attack','apply_damage');hook_register('attack','player_damaged_enemy');hook_register('attack','player_attack_enemy');hook_register('attack','player_kill_enemy');hook_register('attack','show_player_killwords');hook_register('attack','load_user_combat_command');hook_register('attack','load_auto_combat_command');hook_register('attack','post_player_damaged_enemy_event');hook_register('attack','attack_prepare');hook_register('attack','attack_finish');hook_register('attack','attack_wrapper');hook_register('attack','add_format');hook_register('attack','multiply_format');hook_register('attack','apply_multiplier');hook_register('attack','equalsign_format');hook_register('attack','strike_prepare');hook_register('attack','strike');hook_register('attack','strike_finish');hook_register('attack','attack');hook_register('attack','post_damage_news');hook_register('attack','parse_damage_news');hook_register('attack','parse_news');
function ___post_init() { global $___PRIVATE_ATTACK__VARS_____PRIVATE_PFUNC,$___PRIVATE_ATTACK__VARS_____PRIVATE_CFUNC;


}
	
}

?>