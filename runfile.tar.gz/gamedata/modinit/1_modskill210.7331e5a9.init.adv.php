<?php

namespace skill210
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill210/'.$___TEMP_key; 
	
	$___PRESET_SKILL210__VARS__skill210_cd=$skill210_cd;$___PRESET_SKILL210__VARS__skill210_act_time=$skill210_act_time;
function ___pre_init() { global $___PRESET_SKILL210__VARS__skill210_cd,$skill210_cd,$___PRESET_SKILL210__VARS__skill210_act_time,$skill210_act_time;$skill210_cd=$___PRESET_SKILL210__VARS__skill210_cd;$skill210_act_time=$___PRESET_SKILL210__VARS__skill210_act_time; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL210_PRESET_VARS','$___PRESET_SKILL210__VARS__skill210_cd=$skill210_cd;$___PRESET_SKILL210__VARS__skill210_act_time=$skill210_act_time;');
define('___LOAD_MOD_SKILL210_PRESET_VARS','global $___PRESET_SKILL210__VARS__skill210_cd,$skill210_cd,$___PRESET_SKILL210__VARS__skill210_act_time,$skill210_act_time;$skill210_cd=$___PRESET_SKILL210__VARS__skill210_cd;$skill210_act_time=$___PRESET_SKILL210__VARS__skill210_act_time;');
define('MOD_SKILL210_INFO','club;upgrade;buffer;');
define('MOD_SKILL210_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill210/desc');
define('MODULE_SKILL210_GLOBALS_VARNAMES','skill210_cd,skill210_act_time');
define('MOD_SKILL210',1);
define('IMPORT_MODULE_SKILL210_GLOBALS','global $___LOCAL_SKILL210__VARS__skill210_cd,$___LOCAL_SKILL210__VARS__skill210_act_time; $skill210_cd=&$___LOCAL_SKILL210__VARS__skill210_cd; $skill210_act_time=&$___LOCAL_SKILL210__VARS__skill210_act_time; ');
define('PREFIX_MODULE_SKILL210_GLOBALS','\'; global $___LOCAL_SKILL210__VARS__skill210_cd; ${$___TEMP_PREFIX.\'skill210_cd\'}=&$___LOCAL_SKILL210__VARS__skill210_cd; global $___LOCAL_SKILL210__VARS__skill210_act_time; ${$___TEMP_PREFIX.\'skill210_act_time\'}=&$___LOCAL_SKILL210__VARS__skill210_act_time; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL210_GLOBALS','\'; global $___LOCAL_SKILL210__VARS__skill210_cd; ${$___TEMP_VARNAME}[\'skill210_cd\']=&$___LOCAL_SKILL210__VARS__skill210_cd; global $___LOCAL_SKILL210__VARS__skill210_act_time; ${$___TEMP_VARNAME}[\'skill210_act_time\']=&$___LOCAL_SKILL210__VARS__skill210_act_time; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL210__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL210__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL210__VARS__skill210_cd,$___LOCAL_SKILL210__VARS__skill210_act_time;
$___PRIVATE_SKILL210__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL210__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_SKILL210__VARS__skill210_cd=&$skill210_cd;$___LOCAL_SKILL210__VARS__skill210_act_time=&$skill210_act_time;
unset($skill210_cd,$skill210_act_time);
hook_register('skill210','acquire210');hook_register('skill210','lost210');hook_register('skill210','check_unlocked210');hook_register('skill210','activate210');hook_register('skill210','check_skill210_state');hook_register('skill210','get_basic_ex_dmg');hook_register('skill210','get_physical_dmg_multiplier');hook_register('skill210','get_final_dmg_multiplier');hook_register('skill210','parse_news');
function ___post_init() { global $___PRIVATE_SKILL210__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL210__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL210__VARS__skill210_cd,$___LOCAL_SKILL210__VARS__skill210_act_time;
$___LOCAL_SKILL210__VARS__skill210_cd=$GLOBALS['skill210_cd'];$___LOCAL_SKILL210__VARS__skill210_act_time=$GLOBALS['skill210_act_time'];
unset($GLOBALS['skill210_cd'],$GLOBALS['skill210_act_time']);
}
	
}

?>