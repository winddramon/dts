<?php

namespace item_ext_armor
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/item_extra/item_ext_armor/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_ITEM_EXT_ARMOR_PRESET_VARS','');
define('___LOAD_MOD_ITEM_EXT_ARMOR_PRESET_VARS','');
define('MODULE_ITEM_EXT_ARMOR_GLOBALS_VARNAMES','');
define('MOD_ITEM_EXT_ARMOR',1);
define('IMPORT_MODULE_ITEM_EXT_ARMOR_GLOBALS','');
define('PREFIX_MODULE_ITEM_EXT_ARMOR_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_ITEM_EXT_ARMOR_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_ITEM_EXT_ARMOR__VARS_____PRIVATE_PFUNC,$___PRIVATE_ITEM_EXT_ARMOR__VARS_____PRIVATE_CFUNC;
$___PRIVATE_ITEM_EXT_ARMOR__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_ITEM_EXT_ARMOR__VARS_____PRIVATE_CFUNC=Array();

hook_register('item_ext_armor','parse_itmuse_desc');hook_register('item_ext_armor','get_itmsk_desc_single_comp_process');hook_register('item_ext_armor','use_armor');hook_register('item_ext_armor','use_armor_ext_armor_process');hook_register('item_ext_armor','armor_changename_to_ext');hook_register('item_ext_armor','armor_hurt');hook_register('item_ext_armor','suit_break');hook_register('item_ext_armor','itemoff');hook_register('item_ext_armor','getcorpse_action');hook_register('item_ext_armor','armor_get_su');hook_register('item_ext_armor','armor_put_su');hook_register('item_ext_armor','armor_remove_su');hook_register('item_ext_armor','armor_changename_from_ext');hook_register('item_ext_armor','armor_clean_suit_sk');hook_register('item_ext_armor','check_comp_itmsk_visible');hook_register('item_ext_armor','itemdrop_valid_check');hook_register('item_ext_armor','init_npcdata');
function ___post_init() { global $___PRIVATE_ITEM_EXT_ARMOR__VARS_____PRIVATE_PFUNC,$___PRIVATE_ITEM_EXT_ARMOR__VARS_____PRIVATE_CFUNC;


}
	
}

?>