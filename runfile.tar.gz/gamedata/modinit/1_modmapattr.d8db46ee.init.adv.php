<?php

namespace mapattr
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'base/mapattr/'.$___TEMP_key; 
	
	$___PRESET_MAPATTR__VARS__pls_itemfind_obbs=$pls_itemfind_obbs;$___PRESET_MAPATTR__VARS__pls_meetman_obbs=$pls_meetman_obbs;$___PRESET_MAPATTR__VARS__pls_findman_obbs=$pls_findman_obbs;
function ___pre_init() { global $___PRESET_MAPATTR__VARS__pls_itemfind_obbs,$pls_itemfind_obbs,$___PRESET_MAPATTR__VARS__pls_meetman_obbs,$pls_meetman_obbs,$___PRESET_MAPATTR__VARS__pls_findman_obbs,$pls_findman_obbs;$pls_itemfind_obbs=$___PRESET_MAPATTR__VARS__pls_itemfind_obbs;$pls_meetman_obbs=$___PRESET_MAPATTR__VARS__pls_meetman_obbs;$pls_findman_obbs=$___PRESET_MAPATTR__VARS__pls_findman_obbs; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_MAPATTR_PRESET_VARS','$___PRESET_MAPATTR__VARS__pls_itemfind_obbs=$pls_itemfind_obbs;$___PRESET_MAPATTR__VARS__pls_meetman_obbs=$pls_meetman_obbs;$___PRESET_MAPATTR__VARS__pls_findman_obbs=$pls_findman_obbs;');
define('___LOAD_MOD_MAPATTR_PRESET_VARS','global $___PRESET_MAPATTR__VARS__pls_itemfind_obbs,$pls_itemfind_obbs,$___PRESET_MAPATTR__VARS__pls_meetman_obbs,$pls_meetman_obbs,$___PRESET_MAPATTR__VARS__pls_findman_obbs,$pls_findman_obbs;$pls_itemfind_obbs=$___PRESET_MAPATTR__VARS__pls_itemfind_obbs;$pls_meetman_obbs=$___PRESET_MAPATTR__VARS__pls_meetman_obbs;$pls_findman_obbs=$___PRESET_MAPATTR__VARS__pls_findman_obbs;');
define('MODULE_MAPATTR_GLOBALS_VARNAMES','pls_itemfind_obbs,pls_meetman_obbs,pls_findman_obbs');
define('MOD_MAPATTR',1);
define('IMPORT_MODULE_MAPATTR_GLOBALS','global $___LOCAL_MAPATTR__VARS__pls_itemfind_obbs,$___LOCAL_MAPATTR__VARS__pls_meetman_obbs,$___LOCAL_MAPATTR__VARS__pls_findman_obbs; $pls_itemfind_obbs=&$___LOCAL_MAPATTR__VARS__pls_itemfind_obbs; $pls_meetman_obbs=&$___LOCAL_MAPATTR__VARS__pls_meetman_obbs; $pls_findman_obbs=&$___LOCAL_MAPATTR__VARS__pls_findman_obbs; ');
define('PREFIX_MODULE_MAPATTR_GLOBALS','\'; global $___LOCAL_MAPATTR__VARS__pls_itemfind_obbs; ${$___TEMP_PREFIX.\'pls_itemfind_obbs\'}=&$___LOCAL_MAPATTR__VARS__pls_itemfind_obbs; global $___LOCAL_MAPATTR__VARS__pls_meetman_obbs; ${$___TEMP_PREFIX.\'pls_meetman_obbs\'}=&$___LOCAL_MAPATTR__VARS__pls_meetman_obbs; global $___LOCAL_MAPATTR__VARS__pls_findman_obbs; ${$___TEMP_PREFIX.\'pls_findman_obbs\'}=&$___LOCAL_MAPATTR__VARS__pls_findman_obbs; unset($___TEMP_PREFIX); ');
define('MODULE_MAPATTR_GLOBALS','\'; global $___LOCAL_MAPATTR__VARS__pls_itemfind_obbs; ${$___TEMP_VARNAME}[\'pls_itemfind_obbs\']=&$___LOCAL_MAPATTR__VARS__pls_itemfind_obbs; global $___LOCAL_MAPATTR__VARS__pls_meetman_obbs; ${$___TEMP_VARNAME}[\'pls_meetman_obbs\']=&$___LOCAL_MAPATTR__VARS__pls_meetman_obbs; global $___LOCAL_MAPATTR__VARS__pls_findman_obbs; ${$___TEMP_VARNAME}[\'pls_findman_obbs\']=&$___LOCAL_MAPATTR__VARS__pls_findman_obbs; unset($___TEMP_VARNAME); ');

global $___PRIVATE_MAPATTR__VARS_____PRIVATE_PFUNC,$___PRIVATE_MAPATTR__VARS_____PRIVATE_CFUNC,$___LOCAL_MAPATTR__VARS__pls_itemfind_obbs,$___LOCAL_MAPATTR__VARS__pls_meetman_obbs,$___LOCAL_MAPATTR__VARS__pls_findman_obbs;
$___PRIVATE_MAPATTR__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_MAPATTR__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_MAPATTR__VARS__pls_itemfind_obbs=&$pls_itemfind_obbs;$___LOCAL_MAPATTR__VARS__pls_meetman_obbs=&$pls_meetman_obbs;$___LOCAL_MAPATTR__VARS__pls_findman_obbs=&$pls_findman_obbs;
unset($pls_itemfind_obbs,$pls_meetman_obbs,$pls_findman_obbs);
hook_register('mapattr','calculate_itemfind_obbs');hook_register('mapattr','calculate_findman_obbs');hook_register('mapattr','calculate_meetman_rate');hook_register('mapattr','calculate_real_trap_obbs');
function ___post_init() { global $___PRIVATE_MAPATTR__VARS_____PRIVATE_PFUNC,$___PRIVATE_MAPATTR__VARS_____PRIVATE_CFUNC,$___LOCAL_MAPATTR__VARS__pls_itemfind_obbs,$___LOCAL_MAPATTR__VARS__pls_meetman_obbs,$___LOCAL_MAPATTR__VARS__pls_findman_obbs;
$___LOCAL_MAPATTR__VARS__pls_itemfind_obbs=$GLOBALS['pls_itemfind_obbs'];$___LOCAL_MAPATTR__VARS__pls_meetman_obbs=$GLOBALS['pls_meetman_obbs'];$___LOCAL_MAPATTR__VARS__pls_findman_obbs=$GLOBALS['pls_findman_obbs'];
unset($GLOBALS['pls_itemfind_obbs'],$GLOBALS['pls_meetman_obbs'],$GLOBALS['pls_findman_obbs']);
}
	
}

?>