<?php

namespace instance10
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/instance/instance10_rogue/'.$___TEMP_key; 
	
	$___PRESET_INSTANCE10__VARS__npcinfo_instance10=$npcinfo_instance10;
function ___pre_init() { global $___PRESET_INSTANCE10__VARS__npcinfo_instance10,$npcinfo_instance10;$npcinfo_instance10=$___PRESET_INSTANCE10__VARS__npcinfo_instance10; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_INSTANCE10_PRESET_VARS','$___PRESET_INSTANCE10__VARS__npcinfo_instance10=$npcinfo_instance10;');
define('___LOAD_MOD_INSTANCE10_PRESET_VARS','global $___PRESET_INSTANCE10__VARS__npcinfo_instance10,$npcinfo_instance10;$npcinfo_instance10=$___PRESET_INSTANCE10__VARS__npcinfo_instance10;');
define('MODULE_INSTANCE10_GLOBALS_VARNAMES','npcinfo_instance10');
define('MOD_INSTANCE10',1);
define('IMPORT_MODULE_INSTANCE10_GLOBALS','global $___LOCAL_INSTANCE10__VARS__npcinfo_instance10; $npcinfo_instance10=&$___LOCAL_INSTANCE10__VARS__npcinfo_instance10; ');
define('PREFIX_MODULE_INSTANCE10_GLOBALS','\'; global $___LOCAL_INSTANCE10__VARS__npcinfo_instance10; ${$___TEMP_PREFIX.\'npcinfo_instance10\'}=&$___LOCAL_INSTANCE10__VARS__npcinfo_instance10; unset($___TEMP_PREFIX); ');
define('MODULE_INSTANCE10_GLOBALS','\'; global $___LOCAL_INSTANCE10__VARS__npcinfo_instance10; ${$___TEMP_VARNAME}[\'npcinfo_instance10\']=&$___LOCAL_INSTANCE10__VARS__npcinfo_instance10; unset($___TEMP_VARNAME); ');

global $___PRIVATE_INSTANCE10__VARS_____PRIVATE_PFUNC,$___PRIVATE_INSTANCE10__VARS_____PRIVATE_CFUNC,$___LOCAL_INSTANCE10__VARS__npcinfo_instance10;
$___PRIVATE_INSTANCE10__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_INSTANCE10__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_INSTANCE10__VARS__npcinfo_instance10=&$npcinfo_instance10;
unset($npcinfo_instance10);
hook_register('instance10','get_enter_battlefield_card');hook_register('instance10','card_validate_get_forbidden_cards');hook_register('instance10','card_validate_display');hook_register('instance10','init_enter_battlefield_items');hook_register('instance10','get_npclist');hook_register('instance10','get_shopconfig');hook_register('instance10','get_itemfilecont');hook_register('instance10','get_startingitemfilecont');hook_register('instance10','get_startingwepfilecont');hook_register('instance10','get_trapfilecont');hook_register('instance10','checkcombo');hook_register('instance10','rs_game');hook_register('instance10','rs_areatime');hook_register('instance10','get_area_wavenum');hook_register('instance10','check_addarea_gameover');hook_register('instance10','check_in_shop_area');hook_register('instance10','shopitem_row_data_process');hook_register('instance10','itemmix_success');hook_register('instance10','use_skcore_success');hook_register('instance10','itemuse');hook_register('instance10','uee_extra_get_hack_num');hook_register('instance10','post_enterbattlefield_events');hook_register('instance10','remove_task');hook_register('instance10','get_task_reward');hook_register('instance10','get_newtask_rank');hook_register('instance10','get_stage');hook_register('instance10','parse_news');
function ___post_init() { global $___PRIVATE_INSTANCE10__VARS_____PRIVATE_PFUNC,$___PRIVATE_INSTANCE10__VARS_____PRIVATE_CFUNC,$___LOCAL_INSTANCE10__VARS__npcinfo_instance10;
$___LOCAL_INSTANCE10__VARS__npcinfo_instance10=$GLOBALS['npcinfo_instance10'];
unset($GLOBALS['npcinfo_instance10']);
}
	
}

?>