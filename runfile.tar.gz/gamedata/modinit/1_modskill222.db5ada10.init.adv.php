<?php

namespace skill222
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill222/'.$___TEMP_key; 
	
	$___PRESET_SKILL222__VARS__ragecost=$ragecost;
function ___pre_init() { global $___PRESET_SKILL222__VARS__ragecost,$ragecost;$ragecost=$___PRESET_SKILL222__VARS__ragecost; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL222_PRESET_VARS','$___PRESET_SKILL222__VARS__ragecost=$ragecost;');
define('___LOAD_MOD_SKILL222_PRESET_VARS','global $___PRESET_SKILL222__VARS__ragecost,$ragecost;$ragecost=$___PRESET_SKILL222__VARS__ragecost;');
define('MOD_SKILL222_INFO','club;battle;');
define('MOD_SKILL222_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill222/desc');
define('MOD_SKILL222_BATTLECMD_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill222/battlecmd_desc');
define('MODULE_SKILL222_GLOBALS_VARNAMES','ragecost');
define('MOD_SKILL222',1);
define('IMPORT_MODULE_SKILL222_GLOBALS','global $___LOCAL_SKILL222__VARS__ragecost; $ragecost=&$___LOCAL_SKILL222__VARS__ragecost; ');
define('PREFIX_MODULE_SKILL222_GLOBALS','\'; global $___LOCAL_SKILL222__VARS__ragecost; ${$___TEMP_PREFIX.\'ragecost\'}=&$___LOCAL_SKILL222__VARS__ragecost; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL222_GLOBALS','\'; global $___LOCAL_SKILL222__VARS__ragecost; ${$___TEMP_VARNAME}[\'ragecost\']=&$___LOCAL_SKILL222__VARS__ragecost; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL222__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL222__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL222__VARS__ragecost;
$___PRIVATE_SKILL222__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL222__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_SKILL222__VARS__ragecost=&$ragecost;
unset($ragecost);
hook_register('skill222','acquire222');hook_register('skill222','lost222');hook_register('skill222','check_unlocked222');hook_register('skill222','get_rage_cost222');hook_register('skill222','strike_prepare');hook_register('skill222','ex_attack_prepare');hook_register('skill222','calculate_ex_single_dmg_multiple');hook_register('skill222','get_skill221_lasttime');hook_register('skill222','parse_news');
function ___post_init() { global $___PRIVATE_SKILL222__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL222__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL222__VARS__ragecost;
$___LOCAL_SKILL222__VARS__ragecost=$GLOBALS['ragecost'];
unset($GLOBALS['ragecost']);
}
	
}

?>