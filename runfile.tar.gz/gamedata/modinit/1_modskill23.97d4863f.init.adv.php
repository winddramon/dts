<?php

namespace skill23
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill23/'.$___TEMP_key; 
	
	$___PRESET_SKILL23__VARS__skill23max=$skill23max;$___PRESET_SKILL23__VARS__upgradecost=$upgradecost;$___PRESET_SKILL23__VARS__bufflist23=$bufflist23;
function ___pre_init() { global $___PRESET_SKILL23__VARS__skill23max,$skill23max,$___PRESET_SKILL23__VARS__upgradecost,$upgradecost,$___PRESET_SKILL23__VARS__bufflist23,$bufflist23;$skill23max=$___PRESET_SKILL23__VARS__skill23max;$upgradecost=$___PRESET_SKILL23__VARS__upgradecost;$bufflist23=$___PRESET_SKILL23__VARS__bufflist23; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL23_PRESET_VARS','$___PRESET_SKILL23__VARS__skill23max=$skill23max;$___PRESET_SKILL23__VARS__upgradecost=$upgradecost;$___PRESET_SKILL23__VARS__bufflist23=$bufflist23;');
define('___LOAD_MOD_SKILL23_PRESET_VARS','global $___PRESET_SKILL23__VARS__skill23max,$skill23max,$___PRESET_SKILL23__VARS__upgradecost,$upgradecost,$___PRESET_SKILL23__VARS__bufflist23,$bufflist23;$skill23max=$___PRESET_SKILL23__VARS__skill23max;$upgradecost=$___PRESET_SKILL23__VARS__upgradecost;$bufflist23=$___PRESET_SKILL23__VARS__bufflist23;');
define('MOD_SKILL23_INFO','club;active;upgrade;feature;');
define('MOD_SKILL23_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill23/desc');
define('MOD_SKILL23_PROFILECMD','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill23/profilecmd');
define('MOD_SKILL23_GEMMING','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill23/gemming');
define('MODULE_SKILL23_GLOBALS_VARNAMES','skill23max,upgradecost,bufflist23');
define('MOD_SKILL23',1);
define('IMPORT_MODULE_SKILL23_GLOBALS','global $___LOCAL_SKILL23__VARS__skill23max,$___LOCAL_SKILL23__VARS__upgradecost,$___LOCAL_SKILL23__VARS__bufflist23; $skill23max=&$___LOCAL_SKILL23__VARS__skill23max; $upgradecost=&$___LOCAL_SKILL23__VARS__upgradecost; $bufflist23=&$___LOCAL_SKILL23__VARS__bufflist23; ');
define('PREFIX_MODULE_SKILL23_GLOBALS','\'; global $___LOCAL_SKILL23__VARS__skill23max; ${$___TEMP_PREFIX.\'skill23max\'}=&$___LOCAL_SKILL23__VARS__skill23max; global $___LOCAL_SKILL23__VARS__upgradecost; ${$___TEMP_PREFIX.\'upgradecost\'}=&$___LOCAL_SKILL23__VARS__upgradecost; global $___LOCAL_SKILL23__VARS__bufflist23; ${$___TEMP_PREFIX.\'bufflist23\'}=&$___LOCAL_SKILL23__VARS__bufflist23; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL23_GLOBALS','\'; global $___LOCAL_SKILL23__VARS__skill23max; ${$___TEMP_VARNAME}[\'skill23max\']=&$___LOCAL_SKILL23__VARS__skill23max; global $___LOCAL_SKILL23__VARS__upgradecost; ${$___TEMP_VARNAME}[\'upgradecost\']=&$___LOCAL_SKILL23__VARS__upgradecost; global $___LOCAL_SKILL23__VARS__bufflist23; ${$___TEMP_VARNAME}[\'bufflist23\']=&$___LOCAL_SKILL23__VARS__bufflist23; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL23__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL23__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL23__VARS__skill23max,$___LOCAL_SKILL23__VARS__upgradecost,$___LOCAL_SKILL23__VARS__bufflist23;
$___PRIVATE_SKILL23__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL23__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_SKILL23__VARS__skill23max=&$skill23max;$___LOCAL_SKILL23__VARS__upgradecost=&$upgradecost;$___LOCAL_SKILL23__VARS__bufflist23=&$bufflist23;
unset($skill23max,$upgradecost,$bufflist23);
hook_register('skill23','acquire23');hook_register('skill23','lost23');hook_register('skill23','check_unlocked23');hook_register('skill23','gemming_itme_buff');hook_register('skill23','geming_objvalid');hook_register('skill23','gemming');hook_register('skill23','do_gemming');hook_register('skill23','upgrade23');hook_register('skill23','act');hook_register('skill23','parse_news');
function ___post_init() { global $___PRIVATE_SKILL23__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL23__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL23__VARS__skill23max,$___LOCAL_SKILL23__VARS__upgradecost,$___LOCAL_SKILL23__VARS__bufflist23;
$___LOCAL_SKILL23__VARS__skill23max=$GLOBALS['skill23max'];$___LOCAL_SKILL23__VARS__upgradecost=$GLOBALS['upgradecost'];$___LOCAL_SKILL23__VARS__bufflist23=$GLOBALS['bufflist23'];
unset($GLOBALS['skill23max'],$GLOBALS['upgradecost'],$GLOBALS['bufflist23']);
}
	
}

?>