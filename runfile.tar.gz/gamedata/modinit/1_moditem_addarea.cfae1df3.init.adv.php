<?php

namespace item_addarea
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/item_extra/item_addarea/'.$___TEMP_key; 
	
	$___PRESET_ITEM_ADDAREA__VARS__item_addarea_nlist=$item_addarea_nlist;$___PRESET_ITEM_ADDAREA__VARS__item_delayarea_nlist=$item_delayarea_nlist;
function ___pre_init() { global $___PRESET_ITEM_ADDAREA__VARS__item_addarea_nlist,$item_addarea_nlist,$___PRESET_ITEM_ADDAREA__VARS__item_delayarea_nlist,$item_delayarea_nlist;$item_addarea_nlist=$___PRESET_ITEM_ADDAREA__VARS__item_addarea_nlist;$item_delayarea_nlist=$___PRESET_ITEM_ADDAREA__VARS__item_delayarea_nlist; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_ITEM_ADDAREA_PRESET_VARS','$___PRESET_ITEM_ADDAREA__VARS__item_addarea_nlist=$item_addarea_nlist;$___PRESET_ITEM_ADDAREA__VARS__item_delayarea_nlist=$item_delayarea_nlist;');
define('___LOAD_MOD_ITEM_ADDAREA_PRESET_VARS','global $___PRESET_ITEM_ADDAREA__VARS__item_addarea_nlist,$item_addarea_nlist,$___PRESET_ITEM_ADDAREA__VARS__item_delayarea_nlist,$item_delayarea_nlist;$item_addarea_nlist=$___PRESET_ITEM_ADDAREA__VARS__item_addarea_nlist;$item_delayarea_nlist=$___PRESET_ITEM_ADDAREA__VARS__item_delayarea_nlist;');
define('MODULE_ITEM_ADDAREA_GLOBALS_VARNAMES','item_addarea_nlist,item_delayarea_nlist');
define('MOD_ITEM_ADDAREA',1);
define('IMPORT_MODULE_ITEM_ADDAREA_GLOBALS','global $___LOCAL_ITEM_ADDAREA__VARS__item_addarea_nlist,$___LOCAL_ITEM_ADDAREA__VARS__item_delayarea_nlist; $item_addarea_nlist=&$___LOCAL_ITEM_ADDAREA__VARS__item_addarea_nlist; $item_delayarea_nlist=&$___LOCAL_ITEM_ADDAREA__VARS__item_delayarea_nlist; ');
define('PREFIX_MODULE_ITEM_ADDAREA_GLOBALS','\'; global $___LOCAL_ITEM_ADDAREA__VARS__item_addarea_nlist; ${$___TEMP_PREFIX.\'item_addarea_nlist\'}=&$___LOCAL_ITEM_ADDAREA__VARS__item_addarea_nlist; global $___LOCAL_ITEM_ADDAREA__VARS__item_delayarea_nlist; ${$___TEMP_PREFIX.\'item_delayarea_nlist\'}=&$___LOCAL_ITEM_ADDAREA__VARS__item_delayarea_nlist; unset($___TEMP_PREFIX); ');
define('MODULE_ITEM_ADDAREA_GLOBALS','\'; global $___LOCAL_ITEM_ADDAREA__VARS__item_addarea_nlist; ${$___TEMP_VARNAME}[\'item_addarea_nlist\']=&$___LOCAL_ITEM_ADDAREA__VARS__item_addarea_nlist; global $___LOCAL_ITEM_ADDAREA__VARS__item_delayarea_nlist; ${$___TEMP_VARNAME}[\'item_delayarea_nlist\']=&$___LOCAL_ITEM_ADDAREA__VARS__item_delayarea_nlist; unset($___TEMP_VARNAME); ');

global $___PRIVATE_ITEM_ADDAREA__VARS_____PRIVATE_PFUNC,$___PRIVATE_ITEM_ADDAREA__VARS_____PRIVATE_CFUNC,$___LOCAL_ITEM_ADDAREA__VARS__item_addarea_nlist,$___LOCAL_ITEM_ADDAREA__VARS__item_delayarea_nlist;
$___PRIVATE_ITEM_ADDAREA__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_ITEM_ADDAREA__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_ITEM_ADDAREA__VARS__item_addarea_nlist=&$item_addarea_nlist;$___LOCAL_ITEM_ADDAREA__VARS__item_delayarea_nlist=&$item_delayarea_nlist;
unset($item_addarea_nlist,$item_delayarea_nlist);
hook_register('item_addarea','parse_itmuse_desc');hook_register('item_addarea','itemuse');hook_register('item_addarea','parse_news');
function ___post_init() { global $___PRIVATE_ITEM_ADDAREA__VARS_____PRIVATE_PFUNC,$___PRIVATE_ITEM_ADDAREA__VARS_____PRIVATE_CFUNC,$___LOCAL_ITEM_ADDAREA__VARS__item_addarea_nlist,$___LOCAL_ITEM_ADDAREA__VARS__item_delayarea_nlist;
$___LOCAL_ITEM_ADDAREA__VARS__item_addarea_nlist=$GLOBALS['item_addarea_nlist'];$___LOCAL_ITEM_ADDAREA__VARS__item_delayarea_nlist=$GLOBALS['item_delayarea_nlist'];
unset($GLOBALS['item_addarea_nlist'],$GLOBALS['item_delayarea_nlist']);
}
	
}

?>