<?php

namespace skill229
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill229/'.$___TEMP_key; 
	
	$___PRESET_SKILL229__VARS__alternate_skillno229=$alternate_skillno229;$___PRESET_SKILL229__VARS__unlock_lvl229=$unlock_lvl229;
function ___pre_init() { global $___PRESET_SKILL229__VARS__alternate_skillno229,$alternate_skillno229,$___PRESET_SKILL229__VARS__unlock_lvl229,$unlock_lvl229;$alternate_skillno229=$___PRESET_SKILL229__VARS__alternate_skillno229;$unlock_lvl229=$___PRESET_SKILL229__VARS__unlock_lvl229; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL229_PRESET_VARS','$___PRESET_SKILL229__VARS__alternate_skillno229=$alternate_skillno229;$___PRESET_SKILL229__VARS__unlock_lvl229=$unlock_lvl229;');
define('___LOAD_MOD_SKILL229_PRESET_VARS','global $___PRESET_SKILL229__VARS__alternate_skillno229,$alternate_skillno229,$___PRESET_SKILL229__VARS__unlock_lvl229,$unlock_lvl229;$alternate_skillno229=$___PRESET_SKILL229__VARS__alternate_skillno229;$unlock_lvl229=$___PRESET_SKILL229__VARS__unlock_lvl229;');
define('MOD_SKILL229_INFO','club;upgrade;');
define('MOD_SKILL229_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill229/desc');
define('MODULE_SKILL229_GLOBALS_VARNAMES','alternate_skillno229,unlock_lvl229');
define('MOD_SKILL229',1);
define('IMPORT_MODULE_SKILL229_GLOBALS','global $___LOCAL_SKILL229__VARS__alternate_skillno229,$___LOCAL_SKILL229__VARS__unlock_lvl229; $alternate_skillno229=&$___LOCAL_SKILL229__VARS__alternate_skillno229; $unlock_lvl229=&$___LOCAL_SKILL229__VARS__unlock_lvl229; ');
define('PREFIX_MODULE_SKILL229_GLOBALS','\'; global $___LOCAL_SKILL229__VARS__alternate_skillno229; ${$___TEMP_PREFIX.\'alternate_skillno229\'}=&$___LOCAL_SKILL229__VARS__alternate_skillno229; global $___LOCAL_SKILL229__VARS__unlock_lvl229; ${$___TEMP_PREFIX.\'unlock_lvl229\'}=&$___LOCAL_SKILL229__VARS__unlock_lvl229; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL229_GLOBALS','\'; global $___LOCAL_SKILL229__VARS__alternate_skillno229; ${$___TEMP_VARNAME}[\'alternate_skillno229\']=&$___LOCAL_SKILL229__VARS__alternate_skillno229; global $___LOCAL_SKILL229__VARS__unlock_lvl229; ${$___TEMP_VARNAME}[\'unlock_lvl229\']=&$___LOCAL_SKILL229__VARS__unlock_lvl229; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL229__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL229__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL229__VARS__alternate_skillno229,$___LOCAL_SKILL229__VARS__unlock_lvl229;
$___PRIVATE_SKILL229__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL229__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_SKILL229__VARS__alternate_skillno229=&$alternate_skillno229;$___LOCAL_SKILL229__VARS__unlock_lvl229=&$unlock_lvl229;
unset($alternate_skillno229,$unlock_lvl229);
hook_register('skill229','acquire229');hook_register('skill229','lost229');hook_register('skill229','check_unlocked229');hook_register('skill229','check_unlocked_state229');hook_register('skill229','upgrade229');hook_register('skill229','calculate_attack_weapon_skill_gain_base');
function ___post_init() { global $___PRIVATE_SKILL229__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL229__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL229__VARS__alternate_skillno229,$___LOCAL_SKILL229__VARS__unlock_lvl229;
$___LOCAL_SKILL229__VARS__alternate_skillno229=$GLOBALS['alternate_skillno229'];$___LOCAL_SKILL229__VARS__unlock_lvl229=$GLOBALS['unlock_lvl229'];
unset($GLOBALS['alternate_skillno229'],$GLOBALS['unlock_lvl229']);
}
	
}

?>