<?php

namespace skill103
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill103/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL103_PRESET_VARS','');
define('___LOAD_MOD_SKILL103_PRESET_VARS','');
define('MOD_SKILL103_INFO','club;active;locked;');
define('MOD_SKILL103_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill103/desc');
define('MOD_SKILL103_PROFILECMD','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill103/profilecmd');
define('MOD_SKILL103_CASTSK103','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill103/castsk103');
define('MODULE_SKILL103_GLOBALS_VARNAMES','');
define('MOD_SKILL103',1);
define('IMPORT_MODULE_SKILL103_GLOBALS','');
define('PREFIX_MODULE_SKILL103_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL103_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL103__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL103__VARS_____PRIVATE_CFUNC;
$___PRIVATE_SKILL103__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL103__VARS_____PRIVATE_CFUNC=Array();

hook_register('skill103','acquire103');hook_register('skill103','lost103');hook_register('skill103','check_unlocked103');hook_register('skill103','skill103_encode_itmarr');hook_register('skill103','skill103_decode_itmarr');hook_register('skill103','skill103_sendin');hook_register('skill103','cast_skill103');hook_register('skill103','act');hook_register('skill103','get_internal_att');hook_register('skill103','get_ex_attack_array_core');hook_register('skill103','get_ex_def_array_core');
function ___post_init() { global $___PRIVATE_SKILL103__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL103__VARS_____PRIVATE_CFUNC;


}
	
}

?>