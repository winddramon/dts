<?php

namespace skill113
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill113/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL113_PRESET_VARS','');
define('___LOAD_MOD_SKILL113_PRESET_VARS','');
define('MOD_SKILL113_INFO','club;locked;');
define('MOD_SKILL113_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill113/desc');
define('MODULE_SKILL113_GLOBALS_VARNAMES','');
define('MOD_SKILL113',1);
define('IMPORT_MODULE_SKILL113_GLOBALS','');
define('PREFIX_MODULE_SKILL113_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL113_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL113__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL113__VARS_____PRIVATE_CFUNC;
$___PRIVATE_SKILL113__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL113__VARS_____PRIVATE_CFUNC=Array();

hook_register('skill113','acquire113');hook_register('skill113','lost113');hook_register('skill113','check_unlocked113');hook_register('skill113','skill113_get_skill_count');hook_register('skill113','skill113_get_rate');hook_register('skill113','get_ex_pierce_proc_rate');hook_register('skill113','get_attr_pierce_proc_rate');hook_register('skill113','get_ex_dmg_def_proc_rate');hook_register('skill113','get_ex_phy_def_proc_rate');hook_register('skill113','get_ex_phy_nullify_proc_rate');hook_register('skill113','get_ex_dmg_nullify_proc_rate');hook_register('skill113','get_dmg_def_proc_rate');
function ___post_init() { global $___PRIVATE_SKILL113__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL113__VARS_____PRIVATE_CFUNC;


}
	
}

?>