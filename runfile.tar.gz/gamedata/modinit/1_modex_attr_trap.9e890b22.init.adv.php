<?php

namespace ex_attr_trap
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/attr/ex_attr_trap/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_EX_ATTR_TRAP_PRESET_VARS','');
define('___LOAD_MOD_EX_ATTR_TRAP_PRESET_VARS','');
define('MODULE_EX_ATTR_TRAP_GLOBALS_VARNAMES','');
define('MOD_EX_ATTR_TRAP',1);
define('IMPORT_MODULE_EX_ATTR_TRAP_GLOBALS','');
define('PREFIX_MODULE_EX_ATTR_TRAP_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_EX_ATTR_TRAP_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_EX_ATTR_TRAP__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_ATTR_TRAP__VARS_____PRIVATE_CFUNC;
$___PRIVATE_EX_ATTR_TRAP__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_EX_ATTR_TRAP__VARS_____PRIVATE_CFUNC=Array();

hook_register('ex_attr_trap','calculate_trapdetect_rate');hook_register('ex_attr_trap','get_trap_escape_rate');hook_register('ex_attr_trap','calculate_trapdef_proc_rate');hook_register('ex_attr_trap','check_trapdef_proc');hook_register('ex_attr_trap','trap_deal_damage');hook_register('ex_attr_trap','trap_miss_broken');hook_register('ex_attr_trap','trap_miss_reused');hook_register('ex_attr_trap','parse_news');
function ___post_init() { global $___PRIVATE_EX_ATTR_TRAP__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_ATTR_TRAP__VARS_____PRIVATE_CFUNC;


}
	
}

?>