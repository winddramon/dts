<?php

namespace itemnumlist
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/item_extra/itemnumlist/'.$___TEMP_key; 
	
	$___PRESET_ITEMNUMLIST__VARS__itemname_ignore=$itemname_ignore;$___PRESET_ITEMNUMLIST__VARS__itempls_ignore=$itempls_ignore;
function ___pre_init() { global $___PRESET_ITEMNUMLIST__VARS__itemname_ignore,$itemname_ignore,$___PRESET_ITEMNUMLIST__VARS__itempls_ignore,$itempls_ignore;$itemname_ignore=$___PRESET_ITEMNUMLIST__VARS__itemname_ignore;$itempls_ignore=$___PRESET_ITEMNUMLIST__VARS__itempls_ignore; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_ITEMNUMLIST_PRESET_VARS','$___PRESET_ITEMNUMLIST__VARS__itemname_ignore=$itemname_ignore;$___PRESET_ITEMNUMLIST__VARS__itempls_ignore=$itempls_ignore;');
define('___LOAD_MOD_ITEMNUMLIST_PRESET_VARS','global $___PRESET_ITEMNUMLIST__VARS__itemname_ignore,$itemname_ignore,$___PRESET_ITEMNUMLIST__VARS__itempls_ignore,$itempls_ignore;$itemname_ignore=$___PRESET_ITEMNUMLIST__VARS__itemname_ignore;$itempls_ignore=$___PRESET_ITEMNUMLIST__VARS__itempls_ignore;');
define('MODULE_ITEMNUMLIST_GLOBALS_VARNAMES','itemname_ignore,itempls_ignore');
define('MOD_ITEMNUMLIST',1);
define('IMPORT_MODULE_ITEMNUMLIST_GLOBALS','global $___LOCAL_ITEMNUMLIST__VARS__itemname_ignore,$___LOCAL_ITEMNUMLIST__VARS__itempls_ignore; $itemname_ignore=&$___LOCAL_ITEMNUMLIST__VARS__itemname_ignore; $itempls_ignore=&$___LOCAL_ITEMNUMLIST__VARS__itempls_ignore; ');
define('PREFIX_MODULE_ITEMNUMLIST_GLOBALS','\'; global $___LOCAL_ITEMNUMLIST__VARS__itemname_ignore; ${$___TEMP_PREFIX.\'itemname_ignore\'}=&$___LOCAL_ITEMNUMLIST__VARS__itemname_ignore; global $___LOCAL_ITEMNUMLIST__VARS__itempls_ignore; ${$___TEMP_PREFIX.\'itempls_ignore\'}=&$___LOCAL_ITEMNUMLIST__VARS__itempls_ignore; unset($___TEMP_PREFIX); ');
define('MODULE_ITEMNUMLIST_GLOBALS','\'; global $___LOCAL_ITEMNUMLIST__VARS__itemname_ignore; ${$___TEMP_VARNAME}[\'itemname_ignore\']=&$___LOCAL_ITEMNUMLIST__VARS__itemname_ignore; global $___LOCAL_ITEMNUMLIST__VARS__itempls_ignore; ${$___TEMP_VARNAME}[\'itempls_ignore\']=&$___LOCAL_ITEMNUMLIST__VARS__itempls_ignore; unset($___TEMP_VARNAME); ');

global $___PRIVATE_ITEMNUMLIST__VARS_____PRIVATE_PFUNC,$___PRIVATE_ITEMNUMLIST__VARS_____PRIVATE_CFUNC,$___LOCAL_ITEMNUMLIST__VARS__itemname_ignore,$___LOCAL_ITEMNUMLIST__VARS__itempls_ignore;
$___PRIVATE_ITEMNUMLIST__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_ITEMNUMLIST__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_ITEMNUMLIST__VARS__itemname_ignore=&$itemname_ignore;$___LOCAL_ITEMNUMLIST__VARS__itempls_ignore=&$itempls_ignore;
unset($itemname_ignore,$itempls_ignore);
hook_register('itemnumlist','itemnumlist_num_area_proc');hook_register('itemnumlist','itemnumlist_write');hook_register('itemnumlist','itemnumlist_create');hook_register('itemnumlist','itemnumlist_create_proc');
function ___post_init() { global $___PRIVATE_ITEMNUMLIST__VARS_____PRIVATE_PFUNC,$___PRIVATE_ITEMNUMLIST__VARS_____PRIVATE_CFUNC,$___LOCAL_ITEMNUMLIST__VARS__itemname_ignore,$___LOCAL_ITEMNUMLIST__VARS__itempls_ignore;
$___LOCAL_ITEMNUMLIST__VARS__itemname_ignore=$GLOBALS['itemname_ignore'];$___LOCAL_ITEMNUMLIST__VARS__itempls_ignore=$GLOBALS['itempls_ignore'];
unset($GLOBALS['itemname_ignore'],$GLOBALS['itempls_ignore']);
}
	
}

?>