<?php

namespace ex_phy_def
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/attr/ex_phy_def/'.$___TEMP_key; 
	
	$___PRESET_EX_PHY_DEF__VARS__def_kind=$def_kind;
function ___pre_init() { global $___PRESET_EX_PHY_DEF__VARS__def_kind,$def_kind;$def_kind=$___PRESET_EX_PHY_DEF__VARS__def_kind; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_EX_PHY_DEF_PRESET_VARS','$___PRESET_EX_PHY_DEF__VARS__def_kind=$def_kind;');
define('___LOAD_MOD_EX_PHY_DEF_PRESET_VARS','global $___PRESET_EX_PHY_DEF__VARS__def_kind,$def_kind;$def_kind=$___PRESET_EX_PHY_DEF__VARS__def_kind;');
define('MODULE_EX_PHY_DEF_GLOBALS_VARNAMES','def_kind');
define('MOD_EX_PHY_DEF',1);
define('IMPORT_MODULE_EX_PHY_DEF_GLOBALS','global $___LOCAL_EX_PHY_DEF__VARS__def_kind; $def_kind=&$___LOCAL_EX_PHY_DEF__VARS__def_kind; ');
define('PREFIX_MODULE_EX_PHY_DEF_GLOBALS','\'; global $___LOCAL_EX_PHY_DEF__VARS__def_kind; ${$___TEMP_PREFIX.\'def_kind\'}=&$___LOCAL_EX_PHY_DEF__VARS__def_kind; unset($___TEMP_PREFIX); ');
define('MODULE_EX_PHY_DEF_GLOBALS','\'; global $___LOCAL_EX_PHY_DEF__VARS__def_kind; ${$___TEMP_VARNAME}[\'def_kind\']=&$___LOCAL_EX_PHY_DEF__VARS__def_kind; unset($___TEMP_VARNAME); ');

global $___PRIVATE_EX_PHY_DEF__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_PHY_DEF__VARS_____PRIVATE_CFUNC,$___LOCAL_EX_PHY_DEF__VARS__def_kind;
$___PRIVATE_EX_PHY_DEF__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_EX_PHY_DEF__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_EX_PHY_DEF__VARS__def_kind=&$def_kind;
unset($def_kind);
hook_register('ex_phy_def','get_ex_phy_def_proc_rate');hook_register('ex_phy_def','check_ex_phy_def_proc');hook_register('ex_phy_def','check_physical_def_attr');hook_register('ex_phy_def','get_physical_dmg_multiplier');
function ___post_init() { global $___PRIVATE_EX_PHY_DEF__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_PHY_DEF__VARS_____PRIVATE_CFUNC,$___LOCAL_EX_PHY_DEF__VARS__def_kind;
$___LOCAL_EX_PHY_DEF__VARS__def_kind=$GLOBALS['def_kind'];
unset($GLOBALS['def_kind']);
}
	
}

?>