<?php

namespace news_observe
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/misc/news_observe/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_NEWS_OBSERVE_PRESET_VARS','');
define('___LOAD_MOD_NEWS_OBSERVE_PRESET_VARS','');
define('MOD_NEWS_OBSERVE_OBSERVE_SELECT','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\misc\\news_observe/observe_select');
define('MODULE_NEWS_OBSERVE_GLOBALS_VARNAMES','');
define('MOD_NEWS_OBSERVE',1);
define('IMPORT_MODULE_NEWS_OBSERVE_GLOBALS','');
define('PREFIX_MODULE_NEWS_OBSERVE_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_NEWS_OBSERVE_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_NEWS_OBSERVE__VARS_____PRIVATE_PFUNC,$___PRIVATE_NEWS_OBSERVE__VARS_____PRIVATE_CFUNC;
$___PRIVATE_NEWS_OBSERVE__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_NEWS_OBSERVE__VARS_____PRIVATE_CFUNC=Array();

hook_register('news_observe','check_observe_groomid_allowed');hook_register('news_observe','get_observe_roomlist');hook_register('news_observe','get_observe_groomid');hook_register('news_observe','set_observe_groomid');hook_register('news_observe','parse_interface_gameinfo');hook_register('news_observe','check_observe_act_allowed');hook_register('news_observe','observe_main');hook_register('news_observe','act');hook_register('news_observe','getnews');hook_register('news_observe','itemuse');
function ___post_init() { global $___PRIVATE_NEWS_OBSERVE__VARS_____PRIVATE_PFUNC,$___PRIVATE_NEWS_OBSERVE__VARS_____PRIVATE_CFUNC;


}
	
}

?>