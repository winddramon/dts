<?php

namespace gtype6
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/instance/gtype6_randomcard/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_GTYPE6_PRESET_VARS','');
define('___LOAD_MOD_GTYPE6_PRESET_VARS','');
define('MODULE_GTYPE6_GLOBALS_VARNAMES','');
define('MOD_GTYPE6',1);
define('IMPORT_MODULE_GTYPE6_GLOBALS','');
define('PREFIX_MODULE_GTYPE6_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_GTYPE6_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_GTYPE6__VARS_____PRIVATE_PFUNC,$___PRIVATE_GTYPE6__VARS_____PRIVATE_CFUNC;
$___PRIVATE_GTYPE6__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_GTYPE6__VARS_____PRIVATE_CFUNC=Array();

hook_register('gtype6','get_enter_battlefield_card');hook_register('gtype6','card_validate_get_forbidden_cards');hook_register('gtype6','card_validate_display');
function ___post_init() { global $___PRIVATE_GTYPE6__VARS_____PRIVATE_PFUNC,$___PRIVATE_GTYPE6__VARS_____PRIVATE_CFUNC;


}
	
}

?>