<?php

namespace corpse
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'base/corpse/'.$___TEMP_key; 
	
	$___PRESET_CORPSE__VARS__cannot_pick_notice=$cannot_pick_notice;$___PRESET_CORPSE__VARS__corpse_obbs=$corpse_obbs;$___PRESET_CORPSE__VARS__corpseprotect=$corpseprotect;$___PRESET_CORPSE__VARS__corpseprotect2=$corpseprotect2;$___PRESET_CORPSE__VARS__no_destroy_news_type=$no_destroy_news_type;
function ___pre_init() { global $___PRESET_CORPSE__VARS__cannot_pick_notice,$cannot_pick_notice,$___PRESET_CORPSE__VARS__corpse_obbs,$corpse_obbs,$___PRESET_CORPSE__VARS__corpseprotect,$corpseprotect,$___PRESET_CORPSE__VARS__corpseprotect2,$corpseprotect2,$___PRESET_CORPSE__VARS__no_destroy_news_type,$no_destroy_news_type;$cannot_pick_notice=$___PRESET_CORPSE__VARS__cannot_pick_notice;$corpse_obbs=$___PRESET_CORPSE__VARS__corpse_obbs;$corpseprotect=$___PRESET_CORPSE__VARS__corpseprotect;$corpseprotect2=$___PRESET_CORPSE__VARS__corpseprotect2;$no_destroy_news_type=$___PRESET_CORPSE__VARS__no_destroy_news_type; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_CORPSE_PRESET_VARS','$___PRESET_CORPSE__VARS__cannot_pick_notice=$cannot_pick_notice;$___PRESET_CORPSE__VARS__corpse_obbs=$corpse_obbs;$___PRESET_CORPSE__VARS__corpseprotect=$corpseprotect;$___PRESET_CORPSE__VARS__corpseprotect2=$corpseprotect2;$___PRESET_CORPSE__VARS__no_destroy_news_type=$no_destroy_news_type;');
define('___LOAD_MOD_CORPSE_PRESET_VARS','global $___PRESET_CORPSE__VARS__cannot_pick_notice,$cannot_pick_notice,$___PRESET_CORPSE__VARS__corpse_obbs,$corpse_obbs,$___PRESET_CORPSE__VARS__corpseprotect,$corpseprotect,$___PRESET_CORPSE__VARS__corpseprotect2,$corpseprotect2,$___PRESET_CORPSE__VARS__no_destroy_news_type,$no_destroy_news_type;$cannot_pick_notice=$___PRESET_CORPSE__VARS__cannot_pick_notice;$corpse_obbs=$___PRESET_CORPSE__VARS__corpse_obbs;$corpseprotect=$___PRESET_CORPSE__VARS__corpseprotect;$corpseprotect2=$___PRESET_CORPSE__VARS__corpseprotect2;$no_destroy_news_type=$___PRESET_CORPSE__VARS__no_destroy_news_type;');
define('MOD_CORPSE_CORPSE','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/base\\corpse/corpse');
define('MODULE_CORPSE_GLOBALS_VARNAMES','cannot_pick_notice,corpse_obbs,corpseprotect,corpseprotect2,no_destroy_news_type');
define('MOD_CORPSE',1);
define('IMPORT_MODULE_CORPSE_GLOBALS','global $___LOCAL_CORPSE__VARS__cannot_pick_notice,$___LOCAL_CORPSE__VARS__corpse_obbs,$___LOCAL_CORPSE__VARS__corpseprotect,$___LOCAL_CORPSE__VARS__corpseprotect2,$___LOCAL_CORPSE__VARS__no_destroy_news_type; $cannot_pick_notice=&$___LOCAL_CORPSE__VARS__cannot_pick_notice; $corpse_obbs=&$___LOCAL_CORPSE__VARS__corpse_obbs; $corpseprotect=&$___LOCAL_CORPSE__VARS__corpseprotect; $corpseprotect2=&$___LOCAL_CORPSE__VARS__corpseprotect2; $no_destroy_news_type=&$___LOCAL_CORPSE__VARS__no_destroy_news_type; ');
define('PREFIX_MODULE_CORPSE_GLOBALS','\'; global $___LOCAL_CORPSE__VARS__cannot_pick_notice; ${$___TEMP_PREFIX.\'cannot_pick_notice\'}=&$___LOCAL_CORPSE__VARS__cannot_pick_notice; global $___LOCAL_CORPSE__VARS__corpse_obbs; ${$___TEMP_PREFIX.\'corpse_obbs\'}=&$___LOCAL_CORPSE__VARS__corpse_obbs; global $___LOCAL_CORPSE__VARS__corpseprotect; ${$___TEMP_PREFIX.\'corpseprotect\'}=&$___LOCAL_CORPSE__VARS__corpseprotect; global $___LOCAL_CORPSE__VARS__corpseprotect2; ${$___TEMP_PREFIX.\'corpseprotect2\'}=&$___LOCAL_CORPSE__VARS__corpseprotect2; global $___LOCAL_CORPSE__VARS__no_destroy_news_type; ${$___TEMP_PREFIX.\'no_destroy_news_type\'}=&$___LOCAL_CORPSE__VARS__no_destroy_news_type; unset($___TEMP_PREFIX); ');
define('MODULE_CORPSE_GLOBALS','\'; global $___LOCAL_CORPSE__VARS__cannot_pick_notice; ${$___TEMP_VARNAME}[\'cannot_pick_notice\']=&$___LOCAL_CORPSE__VARS__cannot_pick_notice; global $___LOCAL_CORPSE__VARS__corpse_obbs; ${$___TEMP_VARNAME}[\'corpse_obbs\']=&$___LOCAL_CORPSE__VARS__corpse_obbs; global $___LOCAL_CORPSE__VARS__corpseprotect; ${$___TEMP_VARNAME}[\'corpseprotect\']=&$___LOCAL_CORPSE__VARS__corpseprotect; global $___LOCAL_CORPSE__VARS__corpseprotect2; ${$___TEMP_VARNAME}[\'corpseprotect2\']=&$___LOCAL_CORPSE__VARS__corpseprotect2; global $___LOCAL_CORPSE__VARS__no_destroy_news_type; ${$___TEMP_VARNAME}[\'no_destroy_news_type\']=&$___LOCAL_CORPSE__VARS__no_destroy_news_type; unset($___TEMP_VARNAME); ');

global $___PRIVATE_CORPSE__VARS_____PRIVATE_PFUNC,$___PRIVATE_CORPSE__VARS_____PRIVATE_CFUNC,$___LOCAL_CORPSE__VARS__cannot_pick_notice,$___LOCAL_CORPSE__VARS__corpse_obbs,$___LOCAL_CORPSE__VARS__corpseprotect,$___LOCAL_CORPSE__VARS__corpseprotect2,$___LOCAL_CORPSE__VARS__no_destroy_news_type;
$___PRIVATE_CORPSE__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_CORPSE__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_CORPSE__VARS__cannot_pick_notice=&$cannot_pick_notice;$___LOCAL_CORPSE__VARS__corpse_obbs=&$corpse_obbs;$___LOCAL_CORPSE__VARS__corpseprotect=&$corpseprotect;$___LOCAL_CORPSE__VARS__corpseprotect2=&$corpseprotect2;$___LOCAL_CORPSE__VARS__no_destroy_news_type=&$no_destroy_news_type;
unset($cannot_pick_notice,$corpse_obbs,$corpseprotect,$corpseprotect2,$no_destroy_news_type);
hook_register('corpse','check_corpse_discover');hook_register('corpse','check_corpse_discover_dice');hook_register('corpse','findcorpse');hook_register('corpse','get_corpse_filename');hook_register('corpse','meetman');hook_register('corpse','prepare_initial_response_content');hook_register('corpse','getcorpse_action');hook_register('corpse','corpsedestroy_news');hook_register('corpse','getcorpse');hook_register('corpse','post_act');hook_register('corpse','act');hook_register('corpse','check_can_destroy');hook_register('corpse','check_can_pick_money');hook_register('corpse','parse_news');
function ___post_init() { global $___PRIVATE_CORPSE__VARS_____PRIVATE_PFUNC,$___PRIVATE_CORPSE__VARS_____PRIVATE_CFUNC,$___LOCAL_CORPSE__VARS__cannot_pick_notice,$___LOCAL_CORPSE__VARS__corpse_obbs,$___LOCAL_CORPSE__VARS__corpseprotect,$___LOCAL_CORPSE__VARS__corpseprotect2,$___LOCAL_CORPSE__VARS__no_destroy_news_type;
$___LOCAL_CORPSE__VARS__cannot_pick_notice=$GLOBALS['cannot_pick_notice'];$___LOCAL_CORPSE__VARS__corpse_obbs=$GLOBALS['corpse_obbs'];$___LOCAL_CORPSE__VARS__corpseprotect=$GLOBALS['corpseprotect'];$___LOCAL_CORPSE__VARS__corpseprotect2=$GLOBALS['corpseprotect2'];$___LOCAL_CORPSE__VARS__no_destroy_news_type=$GLOBALS['no_destroy_news_type'];
unset($GLOBALS['cannot_pick_notice'],$GLOBALS['corpse_obbs'],$GLOBALS['corpseprotect'],$GLOBALS['corpseprotect2'],$GLOBALS['no_destroy_news_type']);
}
	
}

?>