<?php

namespace skill1000
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/instance/instance7_tutorial/skill1000/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL1000_PRESET_VARS','');
define('___LOAD_MOD_SKILL1000_PRESET_VARS','');
define('MOD_SKILL1000_INFO','hidden;');
define('MODULE_SKILL1000_GLOBALS_VARNAMES','');
define('MOD_SKILL1000',1);
define('IMPORT_MODULE_SKILL1000_GLOBALS','');
define('PREFIX_MODULE_SKILL1000_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL1000_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL1000__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL1000__VARS_____PRIVATE_CFUNC;
$___PRIVATE_SKILL1000__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL1000__VARS_____PRIVATE_CFUNC=Array();

hook_register('skill1000','acquire1000');hook_register('skill1000','lost1000');hook_register('skill1000','check_unlocked1000');hook_register('skill1000','check_process1000');
function ___post_init() { global $___PRIVATE_SKILL1000__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL1000__VARS_____PRIVATE_CFUNC;


}
	
}

?>