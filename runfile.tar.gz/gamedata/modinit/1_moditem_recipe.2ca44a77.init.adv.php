<?php

namespace item_recipe
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/item_extra/item_recipe/'.$___TEMP_key; 
	
	$___PRESET_ITEM_RECIPE__VARS__mix_type=$mix_type;$___PRESET_ITEM_RECIPE__VARS__recipe_mixinfo=$recipe_mixinfo;
function ___pre_init() { global $___PRESET_ITEM_RECIPE__VARS__mix_type,$mix_type,$___PRESET_ITEM_RECIPE__VARS__recipe_mixinfo,$recipe_mixinfo;$mix_type=$___PRESET_ITEM_RECIPE__VARS__mix_type;$recipe_mixinfo=$___PRESET_ITEM_RECIPE__VARS__recipe_mixinfo; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_ITEM_RECIPE_PRESET_VARS','$___PRESET_ITEM_RECIPE__VARS__mix_type=$mix_type;$___PRESET_ITEM_RECIPE__VARS__recipe_mixinfo=$recipe_mixinfo;');
define('___LOAD_MOD_ITEM_RECIPE_PRESET_VARS','global $___PRESET_ITEM_RECIPE__VARS__mix_type,$mix_type,$___PRESET_ITEM_RECIPE__VARS__recipe_mixinfo,$recipe_mixinfo;$mix_type=$___PRESET_ITEM_RECIPE__VARS__mix_type;$recipe_mixinfo=$___PRESET_ITEM_RECIPE__VARS__recipe_mixinfo;');
define('MOD_ITEM_RECIPE_RECIPE_PROFILE','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\item_extra\\item_recipe/recipe_profile');
define('MOD_ITEM_RECIPE_CHOOSE_RECIPE','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\item_extra\\item_recipe/choose_recipe');
define('MOD_ITEM_RECIPE_USE_RECIPE','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\item_extra\\item_recipe/use_recipe');
define('MOD_ITEM_RECIPE_USE_LEARNED_RECIPE','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\item_extra\\item_recipe/use_learned_recipe');
define('MODULE_ITEM_RECIPE_GLOBALS_VARNAMES','mix_type,recipe_mixinfo');
define('MOD_ITEM_RECIPE',1);
define('IMPORT_MODULE_ITEM_RECIPE_GLOBALS','global $___LOCAL_ITEM_RECIPE__VARS__mix_type,$___LOCAL_ITEM_RECIPE__VARS__recipe_mixinfo; $mix_type=&$___LOCAL_ITEM_RECIPE__VARS__mix_type; $recipe_mixinfo=&$___LOCAL_ITEM_RECIPE__VARS__recipe_mixinfo; ');
define('PREFIX_MODULE_ITEM_RECIPE_GLOBALS','\'; global $___LOCAL_ITEM_RECIPE__VARS__mix_type; ${$___TEMP_PREFIX.\'mix_type\'}=&$___LOCAL_ITEM_RECIPE__VARS__mix_type; global $___LOCAL_ITEM_RECIPE__VARS__recipe_mixinfo; ${$___TEMP_PREFIX.\'recipe_mixinfo\'}=&$___LOCAL_ITEM_RECIPE__VARS__recipe_mixinfo; unset($___TEMP_PREFIX); ');
define('MODULE_ITEM_RECIPE_GLOBALS','\'; global $___LOCAL_ITEM_RECIPE__VARS__mix_type; ${$___TEMP_VARNAME}[\'mix_type\']=&$___LOCAL_ITEM_RECIPE__VARS__mix_type; global $___LOCAL_ITEM_RECIPE__VARS__recipe_mixinfo; ${$___TEMP_VARNAME}[\'recipe_mixinfo\']=&$___LOCAL_ITEM_RECIPE__VARS__recipe_mixinfo; unset($___TEMP_VARNAME); ');

global $___PRIVATE_ITEM_RECIPE__VARS_____PRIVATE_PFUNC,$___PRIVATE_ITEM_RECIPE__VARS_____PRIVATE_CFUNC,$___LOCAL_ITEM_RECIPE__VARS__mix_type,$___LOCAL_ITEM_RECIPE__VARS__recipe_mixinfo;
$___PRIVATE_ITEM_RECIPE__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_ITEM_RECIPE__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_ITEM_RECIPE__VARS__mix_type=&$mix_type;$___LOCAL_ITEM_RECIPE__VARS__recipe_mixinfo=&$recipe_mixinfo;
unset($mix_type,$recipe_mixinfo);
hook_register('item_recipe','get_recipe_mixinfo');hook_register('item_recipe','itemuse');hook_register('item_recipe','generate_single_itemtip');hook_register('item_recipe','show_recipe');hook_register('item_recipe','check_single_item');hook_register('item_recipe','check_item_extra');hook_register('item_recipe','check_recipe_extra');hook_register('item_recipe','check_sum_possible');hook_register('item_recipe','recipe_mix_place_check');hook_register('item_recipe','act');hook_register('item_recipe','recipe_mix');hook_register('item_recipe','recipe_mix_proc');hook_register('item_recipe','get_recipe_mix_sequence');hook_register('item_recipe','recipe_mix_success');hook_register('item_recipe','get_learned_recipes');hook_register('item_recipe','learn_recipe_process');hook_register('item_recipe','parse_news');
function ___post_init() { global $___PRIVATE_ITEM_RECIPE__VARS_____PRIVATE_PFUNC,$___PRIVATE_ITEM_RECIPE__VARS_____PRIVATE_CFUNC,$___LOCAL_ITEM_RECIPE__VARS__mix_type,$___LOCAL_ITEM_RECIPE__VARS__recipe_mixinfo;
$___LOCAL_ITEM_RECIPE__VARS__mix_type=$GLOBALS['mix_type'];$___LOCAL_ITEM_RECIPE__VARS__recipe_mixinfo=$GLOBALS['recipe_mixinfo'];
unset($GLOBALS['mix_type'],$GLOBALS['recipe_mixinfo']);
}
	
}

?>