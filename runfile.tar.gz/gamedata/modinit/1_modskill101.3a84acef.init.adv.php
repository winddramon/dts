<?php

namespace skill101
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill101/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL101_PRESET_VARS','');
define('___LOAD_MOD_SKILL101_PRESET_VARS','');
define('MOD_SKILL101_INFO','club;upgrade;locked;');
define('MOD_SKILL101_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill101/desc');
define('MODULE_SKILL101_GLOBALS_VARNAMES','');
define('MOD_SKILL101',1);
define('IMPORT_MODULE_SKILL101_GLOBALS','');
define('PREFIX_MODULE_SKILL101_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL101_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL101__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL101__VARS_____PRIVATE_CFUNC;
$___PRIVATE_SKILL101__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL101__VARS_____PRIVATE_CFUNC=Array();

hook_register('skill101','acquire101');hook_register('skill101','lost101');hook_register('skill101','check_unlocked101');hook_register('skill101','upgrade101');hook_register('skill101','itemmix_success');hook_register('skill101','recipe_mix_success');hook_register('skill101','skill101_check');hook_register('skill101','skill101_proc');
function ___post_init() { global $___PRIVATE_SKILL101__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL101__VARS_____PRIVATE_CFUNC;


}
	
}

?>