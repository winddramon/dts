<?php

namespace kujibase
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/card/kujibase/'.$___TEMP_key; 
	
	$___PRESET_KUJIBASE__VARS__kujicost=$kujicost;$___PRESET_KUJIBASE__VARS__kujiobbs=$kujiobbs;$___PRESET_KUJIBASE__VARS__kujinum=$kujinum;$___PRESET_KUJIBASE__VARS__kujinum_in_pack=$kujinum_in_pack;
function ___pre_init() { global $___PRESET_KUJIBASE__VARS__kujicost,$kujicost,$___PRESET_KUJIBASE__VARS__kujiobbs,$kujiobbs,$___PRESET_KUJIBASE__VARS__kujinum,$kujinum,$___PRESET_KUJIBASE__VARS__kujinum_in_pack,$kujinum_in_pack;$kujicost=$___PRESET_KUJIBASE__VARS__kujicost;$kujiobbs=$___PRESET_KUJIBASE__VARS__kujiobbs;$kujinum=$___PRESET_KUJIBASE__VARS__kujinum;$kujinum_in_pack=$___PRESET_KUJIBASE__VARS__kujinum_in_pack; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_KUJIBASE_PRESET_VARS','$___PRESET_KUJIBASE__VARS__kujicost=$kujicost;$___PRESET_KUJIBASE__VARS__kujiobbs=$kujiobbs;$___PRESET_KUJIBASE__VARS__kujinum=$kujinum;$___PRESET_KUJIBASE__VARS__kujinum_in_pack=$kujinum_in_pack;');
define('___LOAD_MOD_KUJIBASE_PRESET_VARS','global $___PRESET_KUJIBASE__VARS__kujicost,$kujicost,$___PRESET_KUJIBASE__VARS__kujiobbs,$kujiobbs,$___PRESET_KUJIBASE__VARS__kujinum,$kujinum,$___PRESET_KUJIBASE__VARS__kujinum_in_pack,$kujinum_in_pack;$kujicost=$___PRESET_KUJIBASE__VARS__kujicost;$kujiobbs=$___PRESET_KUJIBASE__VARS__kujiobbs;$kujinum=$___PRESET_KUJIBASE__VARS__kujinum;$kujinum_in_pack=$___PRESET_KUJIBASE__VARS__kujinum_in_pack;');
define('MODULE_KUJIBASE_GLOBALS_VARNAMES','kujicost,kujiobbs,kujinum,kujinum_in_pack');
define('MOD_KUJIBASE',1);
define('IMPORT_MODULE_KUJIBASE_GLOBALS','global $___LOCAL_KUJIBASE__VARS__kujicost,$___LOCAL_KUJIBASE__VARS__kujiobbs,$___LOCAL_KUJIBASE__VARS__kujinum,$___LOCAL_KUJIBASE__VARS__kujinum_in_pack; $kujicost=&$___LOCAL_KUJIBASE__VARS__kujicost; $kujiobbs=&$___LOCAL_KUJIBASE__VARS__kujiobbs; $kujinum=&$___LOCAL_KUJIBASE__VARS__kujinum; $kujinum_in_pack=&$___LOCAL_KUJIBASE__VARS__kujinum_in_pack; ');
define('PREFIX_MODULE_KUJIBASE_GLOBALS','\'; global $___LOCAL_KUJIBASE__VARS__kujicost; ${$___TEMP_PREFIX.\'kujicost\'}=&$___LOCAL_KUJIBASE__VARS__kujicost; global $___LOCAL_KUJIBASE__VARS__kujiobbs; ${$___TEMP_PREFIX.\'kujiobbs\'}=&$___LOCAL_KUJIBASE__VARS__kujiobbs; global $___LOCAL_KUJIBASE__VARS__kujinum; ${$___TEMP_PREFIX.\'kujinum\'}=&$___LOCAL_KUJIBASE__VARS__kujinum; global $___LOCAL_KUJIBASE__VARS__kujinum_in_pack; ${$___TEMP_PREFIX.\'kujinum_in_pack\'}=&$___LOCAL_KUJIBASE__VARS__kujinum_in_pack; unset($___TEMP_PREFIX); ');
define('MODULE_KUJIBASE_GLOBALS','\'; global $___LOCAL_KUJIBASE__VARS__kujicost; ${$___TEMP_VARNAME}[\'kujicost\']=&$___LOCAL_KUJIBASE__VARS__kujicost; global $___LOCAL_KUJIBASE__VARS__kujiobbs; ${$___TEMP_VARNAME}[\'kujiobbs\']=&$___LOCAL_KUJIBASE__VARS__kujiobbs; global $___LOCAL_KUJIBASE__VARS__kujinum; ${$___TEMP_VARNAME}[\'kujinum\']=&$___LOCAL_KUJIBASE__VARS__kujinum; global $___LOCAL_KUJIBASE__VARS__kujinum_in_pack; ${$___TEMP_VARNAME}[\'kujinum_in_pack\']=&$___LOCAL_KUJIBASE__VARS__kujinum_in_pack; unset($___TEMP_VARNAME); ');

global $___PRIVATE_KUJIBASE__VARS_____PRIVATE_PFUNC,$___PRIVATE_KUJIBASE__VARS_____PRIVATE_CFUNC,$___LOCAL_KUJIBASE__VARS__kujicost,$___LOCAL_KUJIBASE__VARS__kujiobbs,$___LOCAL_KUJIBASE__VARS__kujinum,$___LOCAL_KUJIBASE__VARS__kujinum_in_pack;
$___PRIVATE_KUJIBASE__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_KUJIBASE__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_KUJIBASE__VARS__kujicost=&$kujicost;$___LOCAL_KUJIBASE__VARS__kujiobbs=&$kujiobbs;$___LOCAL_KUJIBASE__VARS__kujinum=&$kujinum;$___LOCAL_KUJIBASE__VARS__kujinum_in_pack=&$kujinum_in_pack;
unset($kujicost,$kujiobbs,$kujinum,$kujinum_in_pack);
hook_register('kujibase','kujidraw');
function ___post_init() { global $___PRIVATE_KUJIBASE__VARS_____PRIVATE_PFUNC,$___PRIVATE_KUJIBASE__VARS_____PRIVATE_CFUNC,$___LOCAL_KUJIBASE__VARS__kujicost,$___LOCAL_KUJIBASE__VARS__kujiobbs,$___LOCAL_KUJIBASE__VARS__kujinum,$___LOCAL_KUJIBASE__VARS__kujinum_in_pack;
$___LOCAL_KUJIBASE__VARS__kujicost=$GLOBALS['kujicost'];$___LOCAL_KUJIBASE__VARS__kujiobbs=$GLOBALS['kujiobbs'];$___LOCAL_KUJIBASE__VARS__kujinum=$GLOBALS['kujinum'];$___LOCAL_KUJIBASE__VARS__kujinum_in_pack=$GLOBALS['kujinum_in_pack'];
unset($GLOBALS['kujicost'],$GLOBALS['kujiobbs'],$GLOBALS['kujinum'],$GLOBALS['kujinum_in_pack']);
}
	
}

?>