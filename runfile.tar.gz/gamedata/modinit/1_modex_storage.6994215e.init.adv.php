<?php

namespace ex_storage
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/attr/ex_storage/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_EX_STORAGE_PRESET_VARS','');
define('___LOAD_MOD_EX_STORAGE_PRESET_VARS','');
define('MOD_EX_STORAGE_STORAGE_PROFILE','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\attr\\ex_storage/storage_profile');
define('MOD_EX_STORAGE_OPEN_STORAGE','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\attr\\ex_storage/open_storage');
define('MODULE_EX_STORAGE_GLOBALS_VARNAMES','');
define('MOD_EX_STORAGE',1);
define('IMPORT_MODULE_EX_STORAGE_GLOBALS','');
define('PREFIX_MODULE_EX_STORAGE_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_EX_STORAGE_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_EX_STORAGE__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_STORAGE__VARS_____PRIVATE_CFUNC;
$___PRIVATE_EX_STORAGE__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_EX_STORAGE__VARS_____PRIVATE_CFUNC=Array();

hook_register('ex_storage','storage_encode_itmarr');hook_register('ex_storage','storage_decode_itmarr');hook_register('ex_storage','get_item_storage');hook_register('ex_storage','storage_sendin');hook_register('ex_storage','get_empty_stpos');hook_register('ex_storage','storage_sendin_core');hook_register('ex_storage','storage_fetchout');hook_register('ex_storage','storage_fetchout_core');hook_register('ex_storage','use_storage');hook_register('ex_storage','act');hook_register('ex_storage','check_comp_itmsk_visible');hook_register('ex_storage','wep_b_extra_reloading_check');hook_register('ex_storage','use_armor');hook_register('ex_storage','armor_remove_su');hook_register('ex_storage','suit_break');
function ___post_init() { global $___PRIVATE_EX_STORAGE__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_STORAGE__VARS_____PRIVATE_CFUNC;


}
	
}

?>