<?php

namespace instance8
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/instance/instance8_proud/'.$___TEMP_key; 
	
	$___PRESET_INSTANCE8__VARS__npcinfo_instance8=$npcinfo_instance8;
function ___pre_init() { global $___PRESET_INSTANCE8__VARS__npcinfo_instance8,$npcinfo_instance8;$npcinfo_instance8=$___PRESET_INSTANCE8__VARS__npcinfo_instance8; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_INSTANCE8_PRESET_VARS','$___PRESET_INSTANCE8__VARS__npcinfo_instance8=$npcinfo_instance8;');
define('___LOAD_MOD_INSTANCE8_PRESET_VARS','global $___PRESET_INSTANCE8__VARS__npcinfo_instance8,$npcinfo_instance8;$npcinfo_instance8=$___PRESET_INSTANCE8__VARS__npcinfo_instance8;');
define('MODULE_INSTANCE8_GLOBALS_VARNAMES','npcinfo_instance8');
define('MOD_INSTANCE8',1);
define('IMPORT_MODULE_INSTANCE8_GLOBALS','global $___LOCAL_INSTANCE8__VARS__npcinfo_instance8; $npcinfo_instance8=&$___LOCAL_INSTANCE8__VARS__npcinfo_instance8; ');
define('PREFIX_MODULE_INSTANCE8_GLOBALS','\'; global $___LOCAL_INSTANCE8__VARS__npcinfo_instance8; ${$___TEMP_PREFIX.\'npcinfo_instance8\'}=&$___LOCAL_INSTANCE8__VARS__npcinfo_instance8; unset($___TEMP_PREFIX); ');
define('MODULE_INSTANCE8_GLOBALS','\'; global $___LOCAL_INSTANCE8__VARS__npcinfo_instance8; ${$___TEMP_VARNAME}[\'npcinfo_instance8\']=&$___LOCAL_INSTANCE8__VARS__npcinfo_instance8; unset($___TEMP_VARNAME); ');

global $___PRIVATE_INSTANCE8__VARS_____PRIVATE_PFUNC,$___PRIVATE_INSTANCE8__VARS_____PRIVATE_CFUNC,$___LOCAL_INSTANCE8__VARS__npcinfo_instance8;
$___PRIVATE_INSTANCE8__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_INSTANCE8__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_INSTANCE8__VARS__npcinfo_instance8=&$npcinfo_instance8;
unset($npcinfo_instance8);
hook_register('instance8','init_enter_battlefield_items');hook_register('instance8','get_npclist');hook_register('instance8','get_shopconfig');hook_register('instance8','get_itemfilecont');hook_register('instance8','get_startingitemfilecont');hook_register('instance8','get_startingwepfilecont');hook_register('instance8','get_trapfilecont');
function ___post_init() { global $___PRIVATE_INSTANCE8__VARS_____PRIVATE_PFUNC,$___PRIVATE_INSTANCE8__VARS_____PRIVATE_CFUNC,$___LOCAL_INSTANCE8__VARS__npcinfo_instance8;
$___LOCAL_INSTANCE8__VARS__npcinfo_instance8=$GLOBALS['npcinfo_instance8'];
unset($GLOBALS['npcinfo_instance8']);
}
	
}

?>