<?php

namespace addnpc_event
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/misc/addnpc_event/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_ADDNPC_EVENT_PRESET_VARS','');
define('___LOAD_MOD_ADDNPC_EVENT_PRESET_VARS','');
define('MODULE_ADDNPC_EVENT_GLOBALS_VARNAMES','');
define('MOD_ADDNPC_EVENT',1);
define('IMPORT_MODULE_ADDNPC_EVENT_GLOBALS','');
define('PREFIX_MODULE_ADDNPC_EVENT_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_ADDNPC_EVENT_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_ADDNPC_EVENT__VARS_____PRIVATE_PFUNC,$___PRIVATE_ADDNPC_EVENT__VARS_____PRIVATE_CFUNC;
$___PRIVATE_ADDNPC_EVENT__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_ADDNPC_EVENT__VARS_____PRIVATE_CFUNC=Array();

hook_register('addnpc_event','player_kill_enemy');hook_register('addnpc_event','addnpc_event');
function ___post_init() { global $___PRIVATE_ADDNPC_EVENT__VARS_____PRIVATE_PFUNC,$___PRIVATE_ADDNPC_EVENT__VARS_____PRIVATE_CFUNC;


}
	
}

?>