<?php

namespace dualwep
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'base/weapon/dualwep/'.$___TEMP_key; 
	
	$___PRESET_DUALWEP__VARS__dualwep_allowed_bskill=$dualwep_allowed_bskill;$___PRESET_DUALWEP__VARS__dualwep_iteminfo=$dualwep_iteminfo;
function ___pre_init() { global $___PRESET_DUALWEP__VARS__dualwep_allowed_bskill,$dualwep_allowed_bskill,$___PRESET_DUALWEP__VARS__dualwep_iteminfo,$dualwep_iteminfo;$dualwep_allowed_bskill=$___PRESET_DUALWEP__VARS__dualwep_allowed_bskill;$dualwep_iteminfo=$___PRESET_DUALWEP__VARS__dualwep_iteminfo; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_DUALWEP_PRESET_VARS','$___PRESET_DUALWEP__VARS__dualwep_allowed_bskill=$dualwep_allowed_bskill;$___PRESET_DUALWEP__VARS__dualwep_iteminfo=$dualwep_iteminfo;');
define('___LOAD_MOD_DUALWEP_PRESET_VARS','global $___PRESET_DUALWEP__VARS__dualwep_allowed_bskill,$dualwep_allowed_bskill,$___PRESET_DUALWEP__VARS__dualwep_iteminfo,$dualwep_iteminfo;$dualwep_allowed_bskill=$___PRESET_DUALWEP__VARS__dualwep_allowed_bskill;$dualwep_iteminfo=$___PRESET_DUALWEP__VARS__dualwep_iteminfo;');
define('MOD_DUALWEP_SEC_ATT_METHOD','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/base\\weapon\\dualwep/sec_att_method');
define('MOD_DUALWEP_DUALWEP_ATT_METHOD_PROFILE','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/base\\weapon\\dualwep/dualwep_att_method_profile');
define('MODULE_DUALWEP_GLOBALS_VARNAMES','dualwep_allowed_bskill,dualwep_iteminfo');
define('MOD_DUALWEP',1);
define('IMPORT_MODULE_DUALWEP_GLOBALS','global $___LOCAL_DUALWEP__VARS__dualwep_allowed_bskill,$___LOCAL_DUALWEP__VARS__dualwep_iteminfo; $dualwep_allowed_bskill=&$___LOCAL_DUALWEP__VARS__dualwep_allowed_bskill; $dualwep_iteminfo=&$___LOCAL_DUALWEP__VARS__dualwep_iteminfo; ');
define('PREFIX_MODULE_DUALWEP_GLOBALS','\'; global $___LOCAL_DUALWEP__VARS__dualwep_allowed_bskill; ${$___TEMP_PREFIX.\'dualwep_allowed_bskill\'}=&$___LOCAL_DUALWEP__VARS__dualwep_allowed_bskill; global $___LOCAL_DUALWEP__VARS__dualwep_iteminfo; ${$___TEMP_PREFIX.\'dualwep_iteminfo\'}=&$___LOCAL_DUALWEP__VARS__dualwep_iteminfo; unset($___TEMP_PREFIX); ');
define('MODULE_DUALWEP_GLOBALS','\'; global $___LOCAL_DUALWEP__VARS__dualwep_allowed_bskill; ${$___TEMP_VARNAME}[\'dualwep_allowed_bskill\']=&$___LOCAL_DUALWEP__VARS__dualwep_allowed_bskill; global $___LOCAL_DUALWEP__VARS__dualwep_iteminfo; ${$___TEMP_VARNAME}[\'dualwep_iteminfo\']=&$___LOCAL_DUALWEP__VARS__dualwep_iteminfo; unset($___TEMP_VARNAME); ');

global $___PRIVATE_DUALWEP__VARS_____PRIVATE_PFUNC,$___PRIVATE_DUALWEP__VARS_____PRIVATE_CFUNC,$___LOCAL_DUALWEP__VARS__dualwep_allowed_bskill,$___LOCAL_DUALWEP__VARS__dualwep_iteminfo;
$___PRIVATE_DUALWEP__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_DUALWEP__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_DUALWEP__VARS__dualwep_allowed_bskill=&$dualwep_allowed_bskill;$___LOCAL_DUALWEP__VARS__dualwep_iteminfo=&$dualwep_iteminfo;
unset($dualwep_allowed_bskill,$dualwep_iteminfo);
hook_register('dualwep','load_playerdata');hook_register('dualwep','parse_interface_profile');hook_register('dualwep','check_w2_valid');hook_register('dualwep','get_other_attack_method');hook_register('dualwep','get_sec_attack_method');hook_register('dualwep','check_attack_method');hook_register('dualwep','weapon_break');hook_register('dualwep','get_skill_by_kind');hook_register('dualwep','get_dualwep_imp_kind');hook_register('dualwep','get_dualwep_imp_kind_tier');hook_register('dualwep','calculate_wepimp');hook_register('dualwep','apply_weapon_imp');hook_register('dualwep','dualwep_change_am');hook_register('dualwep','act');hook_register('dualwep','get_skillkind');
function ___post_init() { global $___PRIVATE_DUALWEP__VARS_____PRIVATE_PFUNC,$___PRIVATE_DUALWEP__VARS_____PRIVATE_CFUNC,$___LOCAL_DUALWEP__VARS__dualwep_allowed_bskill,$___LOCAL_DUALWEP__VARS__dualwep_iteminfo;
$___LOCAL_DUALWEP__VARS__dualwep_allowed_bskill=$GLOBALS['dualwep_allowed_bskill'];$___LOCAL_DUALWEP__VARS__dualwep_iteminfo=$GLOBALS['dualwep_iteminfo'];
unset($GLOBALS['dualwep_allowed_bskill'],$GLOBALS['dualwep_iteminfo']);
}
	
}

?>