<?php

namespace rest
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'base/rest/'.$___TEMP_key; 
	
	$___PRESET_REST__VARS__rest_sleep_time=$rest_sleep_time;$___PRESET_REST__VARS__rest_heal_time=$rest_heal_time;$___PRESET_REST__VARS__rest_recover_time=$rest_recover_time;$___PRESET_REST__VARS__restinfo=$restinfo;$___PRESET_REST__VARS__rest_hospital_list=$rest_hospital_list;
function ___pre_init() { global $___PRESET_REST__VARS__rest_sleep_time,$rest_sleep_time,$___PRESET_REST__VARS__rest_heal_time,$rest_heal_time,$___PRESET_REST__VARS__rest_recover_time,$rest_recover_time,$___PRESET_REST__VARS__restinfo,$restinfo,$___PRESET_REST__VARS__rest_hospital_list,$rest_hospital_list;$rest_sleep_time=$___PRESET_REST__VARS__rest_sleep_time;$rest_heal_time=$___PRESET_REST__VARS__rest_heal_time;$rest_recover_time=$___PRESET_REST__VARS__rest_recover_time;$restinfo=$___PRESET_REST__VARS__restinfo;$rest_hospital_list=$___PRESET_REST__VARS__rest_hospital_list; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_REST_PRESET_VARS','$___PRESET_REST__VARS__rest_sleep_time=$rest_sleep_time;$___PRESET_REST__VARS__rest_heal_time=$rest_heal_time;$___PRESET_REST__VARS__rest_recover_time=$rest_recover_time;$___PRESET_REST__VARS__restinfo=$restinfo;$___PRESET_REST__VARS__rest_hospital_list=$rest_hospital_list;');
define('___LOAD_MOD_REST_PRESET_VARS','global $___PRESET_REST__VARS__rest_sleep_time,$rest_sleep_time,$___PRESET_REST__VARS__rest_heal_time,$rest_heal_time,$___PRESET_REST__VARS__rest_recover_time,$rest_recover_time,$___PRESET_REST__VARS__restinfo,$restinfo,$___PRESET_REST__VARS__rest_hospital_list,$rest_hospital_list;$rest_sleep_time=$___PRESET_REST__VARS__rest_sleep_time;$rest_heal_time=$___PRESET_REST__VARS__rest_heal_time;$rest_recover_time=$___PRESET_REST__VARS__rest_recover_time;$restinfo=$___PRESET_REST__VARS__restinfo;$rest_hospital_list=$___PRESET_REST__VARS__rest_hospital_list;');
define('MOD_REST_REST_CMD','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/base\\rest/rest_cmd');
define('MODULE_REST_GLOBALS_VARNAMES','rest_sleep_time,rest_heal_time,rest_recover_time,restinfo,rest_hospital_list');
define('MOD_REST',1);
define('IMPORT_MODULE_REST_GLOBALS','global $___LOCAL_REST__VARS__rest_sleep_time,$___LOCAL_REST__VARS__rest_heal_time,$___LOCAL_REST__VARS__rest_recover_time,$___LOCAL_REST__VARS__restinfo,$___LOCAL_REST__VARS__rest_hospital_list; $rest_sleep_time=&$___LOCAL_REST__VARS__rest_sleep_time; $rest_heal_time=&$___LOCAL_REST__VARS__rest_heal_time; $rest_recover_time=&$___LOCAL_REST__VARS__rest_recover_time; $restinfo=&$___LOCAL_REST__VARS__restinfo; $rest_hospital_list=&$___LOCAL_REST__VARS__rest_hospital_list; ');
define('PREFIX_MODULE_REST_GLOBALS','\'; global $___LOCAL_REST__VARS__rest_sleep_time; ${$___TEMP_PREFIX.\'rest_sleep_time\'}=&$___LOCAL_REST__VARS__rest_sleep_time; global $___LOCAL_REST__VARS__rest_heal_time; ${$___TEMP_PREFIX.\'rest_heal_time\'}=&$___LOCAL_REST__VARS__rest_heal_time; global $___LOCAL_REST__VARS__rest_recover_time; ${$___TEMP_PREFIX.\'rest_recover_time\'}=&$___LOCAL_REST__VARS__rest_recover_time; global $___LOCAL_REST__VARS__restinfo; ${$___TEMP_PREFIX.\'restinfo\'}=&$___LOCAL_REST__VARS__restinfo; global $___LOCAL_REST__VARS__rest_hospital_list; ${$___TEMP_PREFIX.\'rest_hospital_list\'}=&$___LOCAL_REST__VARS__rest_hospital_list; unset($___TEMP_PREFIX); ');
define('MODULE_REST_GLOBALS','\'; global $___LOCAL_REST__VARS__rest_sleep_time; ${$___TEMP_VARNAME}[\'rest_sleep_time\']=&$___LOCAL_REST__VARS__rest_sleep_time; global $___LOCAL_REST__VARS__rest_heal_time; ${$___TEMP_VARNAME}[\'rest_heal_time\']=&$___LOCAL_REST__VARS__rest_heal_time; global $___LOCAL_REST__VARS__rest_recover_time; ${$___TEMP_VARNAME}[\'rest_recover_time\']=&$___LOCAL_REST__VARS__rest_recover_time; global $___LOCAL_REST__VARS__restinfo; ${$___TEMP_VARNAME}[\'restinfo\']=&$___LOCAL_REST__VARS__restinfo; global $___LOCAL_REST__VARS__rest_hospital_list; ${$___TEMP_VARNAME}[\'rest_hospital_list\']=&$___LOCAL_REST__VARS__rest_hospital_list; unset($___TEMP_VARNAME); ');

global $___PRIVATE_REST__VARS_____PRIVATE_PFUNC,$___PRIVATE_REST__VARS_____PRIVATE_CFUNC,$___LOCAL_REST__VARS__rest_sleep_time,$___LOCAL_REST__VARS__rest_heal_time,$___LOCAL_REST__VARS__rest_recover_time,$___LOCAL_REST__VARS__restinfo,$___LOCAL_REST__VARS__rest_hospital_list;
$___PRIVATE_REST__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_REST__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_REST__VARS__rest_sleep_time=&$rest_sleep_time;$___LOCAL_REST__VARS__rest_heal_time=&$rest_heal_time;$___LOCAL_REST__VARS__rest_recover_time=&$rest_recover_time;$___LOCAL_REST__VARS__restinfo=&$restinfo;$___LOCAL_REST__VARS__rest_hospital_list=&$rest_hospital_list;
unset($rest_sleep_time,$rest_heal_time,$rest_recover_time,$restinfo,$rest_hospital_list);
hook_register('rest','calculate_rest_upsp');hook_register('rest','calculate_rest_uphp');hook_register('rest','get_wound_recover_time');hook_register('rest','rest');hook_register('rest','init_rest_timing');hook_register('rest','act');
function ___post_init() { global $___PRIVATE_REST__VARS_____PRIVATE_PFUNC,$___PRIVATE_REST__VARS_____PRIVATE_CFUNC,$___LOCAL_REST__VARS__rest_sleep_time,$___LOCAL_REST__VARS__rest_heal_time,$___LOCAL_REST__VARS__rest_recover_time,$___LOCAL_REST__VARS__restinfo,$___LOCAL_REST__VARS__rest_hospital_list;
$___LOCAL_REST__VARS__rest_sleep_time=$GLOBALS['rest_sleep_time'];$___LOCAL_REST__VARS__rest_heal_time=$GLOBALS['rest_heal_time'];$___LOCAL_REST__VARS__rest_recover_time=$GLOBALS['rest_recover_time'];$___LOCAL_REST__VARS__restinfo=$GLOBALS['restinfo'];$___LOCAL_REST__VARS__rest_hospital_list=$GLOBALS['rest_hospital_list'];
unset($GLOBALS['rest_sleep_time'],$GLOBALS['rest_heal_time'],$GLOBALS['rest_recover_time'],$GLOBALS['restinfo'],$GLOBALS['rest_hospital_list']);
}
	
}

?>