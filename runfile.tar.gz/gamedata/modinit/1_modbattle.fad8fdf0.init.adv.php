<?php

namespace battle
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'base/battle/'.$___TEMP_key; 
	
	$___PRESET_BATTLE__VARS__o_edata=$o_edata;
function ___pre_init() { global $___PRESET_BATTLE__VARS__o_edata,$o_edata;$o_edata=$___PRESET_BATTLE__VARS__o_edata; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_BATTLE_PRESET_VARS','$___PRESET_BATTLE__VARS__o_edata=$o_edata;');
define('___LOAD_MOD_BATTLE_PRESET_VARS','global $___PRESET_BATTLE__VARS__o_edata,$o_edata;$o_edata=$___PRESET_BATTLE__VARS__o_edata;');
define('MOD_BATTLE_BATTLERESULT','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/base\\battle/battleresult');
define('MODULE_BATTLE_GLOBALS_VARNAMES','o_edata');
define('MOD_BATTLE',1);
define('IMPORT_MODULE_BATTLE_GLOBALS','global $___LOCAL_BATTLE__VARS__o_edata; $o_edata=&$___LOCAL_BATTLE__VARS__o_edata; ');
define('PREFIX_MODULE_BATTLE_GLOBALS','\'; global $___LOCAL_BATTLE__VARS__o_edata; ${$___TEMP_PREFIX.\'o_edata\'}=&$___LOCAL_BATTLE__VARS__o_edata; unset($___TEMP_PREFIX); ');
define('MODULE_BATTLE_GLOBALS','\'; global $___LOCAL_BATTLE__VARS__o_edata; ${$___TEMP_VARNAME}[\'o_edata\']=&$___LOCAL_BATTLE__VARS__o_edata; unset($___TEMP_VARNAME); ');

global $___PRIVATE_BATTLE__VARS_____PRIVATE_PFUNC,$___PRIVATE_BATTLE__VARS_____PRIVATE_CFUNC,$___LOCAL_BATTLE__VARS__o_edata;
$___PRIVATE_BATTLE__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_BATTLE__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_BATTLE__VARS__o_edata=&$o_edata;
unset($o_edata);
hook_register('battle','battlelog_parser');hook_register('battle','check_can_counter');hook_register('battle','attack_wrapper');hook_register('battle','assault_end');hook_register('battle','counter_assault');hook_register('battle','player_cannot_counter');hook_register('battle','cannot_counter');hook_register('battle','assault_prepare');hook_register('battle','counter_assault_wrapper');hook_register('battle','assault');hook_register('battle','assault_finish');hook_register('battle','save_enemy_battlelog');hook_register('battle','send_battle_msg');hook_register('battle','battle_prepare');hook_register('battle','battle_finish');hook_register('battle','battle');hook_register('battle','battle_wrapper');hook_register('battle','get_battleresult_filename');
function ___post_init() { global $___PRIVATE_BATTLE__VARS_____PRIVATE_PFUNC,$___PRIVATE_BATTLE__VARS_____PRIVATE_CFUNC,$___LOCAL_BATTLE__VARS__o_edata;
$___LOCAL_BATTLE__VARS__o_edata=$GLOBALS['o_edata'];
unset($GLOBALS['o_edata']);
}
	
}

?>