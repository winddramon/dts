<?php

namespace ex_residue
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/attr/ex_residue/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_EX_RESIDUE_PRESET_VARS','');
define('___LOAD_MOD_EX_RESIDUE_PRESET_VARS','');
define('MODULE_EX_RESIDUE_GLOBALS_VARNAMES','');
define('MOD_EX_RESIDUE',1);
define('IMPORT_MODULE_EX_RESIDUE_GLOBALS','');
define('PREFIX_MODULE_EX_RESIDUE_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_EX_RESIDUE_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_EX_RESIDUE__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_RESIDUE__VARS_____PRIVATE_CFUNC;
$___PRIVATE_EX_RESIDUE__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_EX_RESIDUE__VARS_____PRIVATE_CFUNC=Array();

hook_register('ex_residue','get_res_itm');hook_register('ex_residue','put_res_itm');hook_register('ex_residue','itms_reduce');hook_register('ex_residue','itemmix_reduce');hook_register('ex_residue','itemuse');hook_register('ex_residue','itemmix_recipe_check');hook_register('ex_residue','weapon_break');hook_register('ex_residue','armor_break');hook_register('ex_residue','check_comp_itmsk_visible');
function ___post_init() { global $___PRIVATE_EX_RESIDUE__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_RESIDUE__VARS_____PRIVATE_CFUNC;


}
	
}

?>