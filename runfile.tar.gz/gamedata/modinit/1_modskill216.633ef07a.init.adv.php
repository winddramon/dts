<?php

namespace skill216
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill216/'.$___TEMP_key; 
	
	$___PRESET_SKILL216__VARS__wep_skillkind_req=$wep_skillkind_req;
function ___pre_init() { global $___PRESET_SKILL216__VARS__wep_skillkind_req,$wep_skillkind_req;$wep_skillkind_req=$___PRESET_SKILL216__VARS__wep_skillkind_req; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL216_PRESET_VARS','$___PRESET_SKILL216__VARS__wep_skillkind_req=$wep_skillkind_req;');
define('___LOAD_MOD_SKILL216_PRESET_VARS','global $___PRESET_SKILL216__VARS__wep_skillkind_req,$wep_skillkind_req;$wep_skillkind_req=$___PRESET_SKILL216__VARS__wep_skillkind_req;');
define('MOD_SKILL216_INFO','club;battle;limited;');
define('MOD_SKILL216_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill216/desc');
define('MOD_SKILL216_BATTLECMD_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill216/battlecmd_desc');
define('MODULE_SKILL216_GLOBALS_VARNAMES','wep_skillkind_req');
define('MOD_SKILL216',1);
define('IMPORT_MODULE_SKILL216_GLOBALS','global $___LOCAL_SKILL216__VARS__wep_skillkind_req; $wep_skillkind_req=&$___LOCAL_SKILL216__VARS__wep_skillkind_req; ');
define('PREFIX_MODULE_SKILL216_GLOBALS','\'; global $___LOCAL_SKILL216__VARS__wep_skillkind_req; ${$___TEMP_PREFIX.\'wep_skillkind_req\'}=&$___LOCAL_SKILL216__VARS__wep_skillkind_req; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL216_GLOBALS','\'; global $___LOCAL_SKILL216__VARS__wep_skillkind_req; ${$___TEMP_VARNAME}[\'wep_skillkind_req\']=&$___LOCAL_SKILL216__VARS__wep_skillkind_req; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL216__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL216__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL216__VARS__wep_skillkind_req;
$___PRIVATE_SKILL216__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL216__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_SKILL216__VARS__wep_skillkind_req=&$wep_skillkind_req;
unset($wep_skillkind_req);
hook_register('skill216','acquire216');hook_register('skill216','lost216');hook_register('skill216','check_unlocked216');hook_register('skill216','get_remaintime216');hook_register('skill216','strike_prepare');hook_register('skill216','attack');hook_register('skill216','parse_news');
function ___post_init() { global $___PRIVATE_SKILL216__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL216__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL216__VARS__wep_skillkind_req;
$___LOCAL_SKILL216__VARS__wep_skillkind_req=$GLOBALS['wep_skillkind_req'];
unset($GLOBALS['wep_skillkind_req']);
}
	
}

?>