<?php

namespace skill211
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill211/'.$___TEMP_key; 
	
	$___PRESET_SKILL211__VARS__hidegain=$hidegain;$___PRESET_SKILL211__VARS__actgain=$actgain;$___PRESET_SKILL211__VARS__upgradecost=$upgradecost;
function ___pre_init() { global $___PRESET_SKILL211__VARS__hidegain,$hidegain,$___PRESET_SKILL211__VARS__actgain,$actgain,$___PRESET_SKILL211__VARS__upgradecost,$upgradecost;$hidegain=$___PRESET_SKILL211__VARS__hidegain;$actgain=$___PRESET_SKILL211__VARS__actgain;$upgradecost=$___PRESET_SKILL211__VARS__upgradecost; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL211_PRESET_VARS','$___PRESET_SKILL211__VARS__hidegain=$hidegain;$___PRESET_SKILL211__VARS__actgain=$actgain;$___PRESET_SKILL211__VARS__upgradecost=$upgradecost;');
define('___LOAD_MOD_SKILL211_PRESET_VARS','global $___PRESET_SKILL211__VARS__hidegain,$hidegain,$___PRESET_SKILL211__VARS__actgain,$actgain,$___PRESET_SKILL211__VARS__upgradecost,$upgradecost;$hidegain=$___PRESET_SKILL211__VARS__hidegain;$actgain=$___PRESET_SKILL211__VARS__actgain;$upgradecost=$___PRESET_SKILL211__VARS__upgradecost;');
define('MOD_SKILL211_INFO','club;upgrade;');
define('MOD_SKILL211_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill211/desc');
define('MODULE_SKILL211_GLOBALS_VARNAMES','hidegain,actgain,upgradecost');
define('MOD_SKILL211',1);
define('IMPORT_MODULE_SKILL211_GLOBALS','global $___LOCAL_SKILL211__VARS__hidegain,$___LOCAL_SKILL211__VARS__actgain,$___LOCAL_SKILL211__VARS__upgradecost; $hidegain=&$___LOCAL_SKILL211__VARS__hidegain; $actgain=&$___LOCAL_SKILL211__VARS__actgain; $upgradecost=&$___LOCAL_SKILL211__VARS__upgradecost; ');
define('PREFIX_MODULE_SKILL211_GLOBALS','\'; global $___LOCAL_SKILL211__VARS__hidegain; ${$___TEMP_PREFIX.\'hidegain\'}=&$___LOCAL_SKILL211__VARS__hidegain; global $___LOCAL_SKILL211__VARS__actgain; ${$___TEMP_PREFIX.\'actgain\'}=&$___LOCAL_SKILL211__VARS__actgain; global $___LOCAL_SKILL211__VARS__upgradecost; ${$___TEMP_PREFIX.\'upgradecost\'}=&$___LOCAL_SKILL211__VARS__upgradecost; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL211_GLOBALS','\'; global $___LOCAL_SKILL211__VARS__hidegain; ${$___TEMP_VARNAME}[\'hidegain\']=&$___LOCAL_SKILL211__VARS__hidegain; global $___LOCAL_SKILL211__VARS__actgain; ${$___TEMP_VARNAME}[\'actgain\']=&$___LOCAL_SKILL211__VARS__actgain; global $___LOCAL_SKILL211__VARS__upgradecost; ${$___TEMP_VARNAME}[\'upgradecost\']=&$___LOCAL_SKILL211__VARS__upgradecost; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL211__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL211__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL211__VARS__hidegain,$___LOCAL_SKILL211__VARS__actgain,$___LOCAL_SKILL211__VARS__upgradecost;
$___PRIVATE_SKILL211__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL211__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_SKILL211__VARS__hidegain=&$hidegain;$___LOCAL_SKILL211__VARS__actgain=&$actgain;$___LOCAL_SKILL211__VARS__upgradecost=&$upgradecost;
unset($hidegain,$actgain,$upgradecost);
hook_register('skill211','acquire211');hook_register('skill211','lost211');hook_register('skill211','check_unlocked211');hook_register('skill211','upgrade211');hook_register('skill211','get_skill211_extra_hide_gain');hook_register('skill211','get_skill211_extra_act_gain');hook_register('skill211','calculate_hide_obbs');hook_register('skill211','calculate_active_obbs_multiplier');
function ___post_init() { global $___PRIVATE_SKILL211__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL211__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL211__VARS__hidegain,$___LOCAL_SKILL211__VARS__actgain,$___LOCAL_SKILL211__VARS__upgradecost;
$___LOCAL_SKILL211__VARS__hidegain=$GLOBALS['hidegain'];$___LOCAL_SKILL211__VARS__actgain=$GLOBALS['actgain'];$___LOCAL_SKILL211__VARS__upgradecost=$GLOBALS['upgradecost'];
unset($GLOBALS['hidegain'],$GLOBALS['actgain'],$GLOBALS['upgradecost']);
}
	
}

?>