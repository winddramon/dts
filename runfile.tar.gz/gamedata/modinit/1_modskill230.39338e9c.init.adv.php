<?php

namespace skill230
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill230/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL230_PRESET_VARS','');
define('___LOAD_MOD_SKILL230_PRESET_VARS','');
define('MOD_SKILL230_INFO','club;active;feature;');
define('MOD_SKILL230_PROFILECMD','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill230/profilecmd');
define('MOD_SKILL230_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill230/desc');
define('MODULE_SKILL230_GLOBALS_VARNAMES','');
define('MOD_SKILL230',1);
define('IMPORT_MODULE_SKILL230_GLOBALS','');
define('PREFIX_MODULE_SKILL230_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL230_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL230__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL230__VARS_____PRIVATE_CFUNC;
$___PRIVATE_SKILL230__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL230__VARS_____PRIVATE_CFUNC=Array();

hook_register('skill230','acquire230');hook_register('skill230','lost230');hook_register('skill230','check_unlocked230');hook_register('skill230','wele');hook_register('skill230','act');
function ___post_init() { global $___PRIVATE_SKILL230__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL230__VARS_____PRIVATE_CFUNC;


}
	
}

?>