<?php

namespace skill1010
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/gmskills/skill1010/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL1010_PRESET_VARS','');
define('___LOAD_MOD_SKILL1010_PRESET_VARS','');
define('MOD_SKILL1010_INFO','active;unique;');
define('MOD_SKILL1010_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\gmskills\\skill1010/desc');
define('MOD_SKILL1010_PROFILECMD','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\gmskills\\skill1010/profilecmd');
define('MOD_SKILL1010_MANI_PAGE','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\gmskills\\skill1010/mani_page');
define('MODULE_SKILL1010_GLOBALS_VARNAMES','');
define('MOD_SKILL1010',1);
define('IMPORT_MODULE_SKILL1010_GLOBALS','');
define('PREFIX_MODULE_SKILL1010_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL1010_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL1010__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL1010__VARS_____PRIVATE_CFUNC;
$___PRIVATE_SKILL1010__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL1010__VARS_____PRIVATE_CFUNC=Array();

hook_register('skill1010','acquire1010');hook_register('skill1010','lost1010');hook_register('skill1010','check_unlocked1010');hook_register('skill1010','skill1010_mani_load_pcs');hook_register('skill1010','skill1010_exma');hook_register('skill1010','skill1010_mani_page');hook_register('skill1010','act');hook_register('skill1010','parse_news');
function ___post_init() { global $___PRIVATE_SKILL1010__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL1010__VARS_____PRIVATE_CFUNC;


}
	
}

?>