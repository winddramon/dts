<?php

namespace ending
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'base/ending/'.$___TEMP_key; 
	
	$___PRESET_ENDING__VARS__ending_by_shootings=$ending_by_shootings;
function ___pre_init() { global $___PRESET_ENDING__VARS__ending_by_shootings,$ending_by_shootings;$ending_by_shootings=$___PRESET_ENDING__VARS__ending_by_shootings; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_ENDING_PRESET_VARS','$___PRESET_ENDING__VARS__ending_by_shootings=$ending_by_shootings;');
define('___LOAD_MOD_ENDING_PRESET_VARS','global $___PRESET_ENDING__VARS__ending_by_shootings,$ending_by_shootings;$ending_by_shootings=$___PRESET_ENDING__VARS__ending_by_shootings;');
define('MOD_ENDING_STORYBOARD','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/base\\ending/storyboard');
define('MOD_ENDING_STORYBOARD_CONTAINER','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/base\\ending/storyboard_container');
define('MOD_ENDING_NEXT_GAMETYPE','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/base\\ending/next_gametype');
define('MODULE_ENDING_GLOBALS_VARNAMES','ending_by_shootings');
define('MOD_ENDING',1);
define('IMPORT_MODULE_ENDING_GLOBALS','global $___LOCAL_ENDING__VARS__ending_by_shootings; $ending_by_shootings=&$___LOCAL_ENDING__VARS__ending_by_shootings; ');
define('PREFIX_MODULE_ENDING_GLOBALS','\'; global $___LOCAL_ENDING__VARS__ending_by_shootings; ${$___TEMP_PREFIX.\'ending_by_shootings\'}=&$___LOCAL_ENDING__VARS__ending_by_shootings; unset($___TEMP_PREFIX); ');
define('MODULE_ENDING_GLOBALS','\'; global $___LOCAL_ENDING__VARS__ending_by_shootings; ${$___TEMP_VARNAME}[\'ending_by_shootings\']=&$___LOCAL_ENDING__VARS__ending_by_shootings; unset($___TEMP_VARNAME); ');

global $___PRIVATE_ENDING__VARS_____PRIVATE_PFUNC,$___PRIVATE_ENDING__VARS_____PRIVATE_CFUNC,$___LOCAL_ENDING__VARS__ending_by_shootings;
$___PRIVATE_ENDING__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_ENDING__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_ENDING__VARS__ending_by_shootings=&$ending_by_shootings;
unset($ending_by_shootings);
hook_register('ending','ending_by_shootings_available');hook_register('ending','ending_changing_gamevars_available');hook_register('ending','get_gametype_setting_html');hook_register('ending','ending_psyche_attack_txt_parse');hook_register('ending','init_playerdata');hook_register('ending','itemmix_success');
function ___post_init() { global $___PRIVATE_ENDING__VARS_____PRIVATE_PFUNC,$___PRIVATE_ENDING__VARS_____PRIVATE_CFUNC,$___LOCAL_ENDING__VARS__ending_by_shootings;
$___LOCAL_ENDING__VARS__ending_by_shootings=$GLOBALS['ending_by_shootings'];
unset($GLOBALS['ending_by_shootings']);
}
	
}

?>