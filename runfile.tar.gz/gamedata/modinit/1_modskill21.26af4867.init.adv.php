<?php

namespace skill21
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill21/'.$___TEMP_key; 
	
	$___PRESET_SKILL21__VARS__enpcinfo=$enpcinfo;
function ___pre_init() { global $___PRESET_SKILL21__VARS__enpcinfo,$enpcinfo;$enpcinfo=$___PRESET_SKILL21__VARS__enpcinfo; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL21_PRESET_VARS','$___PRESET_SKILL21__VARS__enpcinfo=$enpcinfo;');
define('___LOAD_MOD_SKILL21_PRESET_VARS','global $___PRESET_SKILL21__VARS__enpcinfo,$enpcinfo;$enpcinfo=$___PRESET_SKILL21__VARS__enpcinfo;');
define('MOD_SKILL21_INFO','club;feature;');
define('MOD_SKILL21_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill21/desc');
define('MODULE_SKILL21_GLOBALS_VARNAMES','enpcinfo');
define('MOD_SKILL21',1);
define('IMPORT_MODULE_SKILL21_GLOBALS','global $___LOCAL_SKILL21__VARS__enpcinfo; $enpcinfo=&$___LOCAL_SKILL21__VARS__enpcinfo; ');
define('PREFIX_MODULE_SKILL21_GLOBALS','\'; global $___LOCAL_SKILL21__VARS__enpcinfo; ${$___TEMP_PREFIX.\'enpcinfo\'}=&$___LOCAL_SKILL21__VARS__enpcinfo; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL21_GLOBALS','\'; global $___LOCAL_SKILL21__VARS__enpcinfo; ${$___TEMP_VARNAME}[\'enpcinfo\']=&$___LOCAL_SKILL21__VARS__enpcinfo; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL21__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL21__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL21__VARS__enpcinfo;
$___PRIVATE_SKILL21__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL21__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_SKILL21__VARS__enpcinfo=&$enpcinfo;
unset($enpcinfo);
hook_register('skill21','acquire21');hook_register('skill21','lost21');hook_register('skill21','check_unlocked21');hook_register('skill21','get_enpcinfo');hook_register('skill21','evonpc_npcdata_process');hook_register('skill21','evonpc');hook_register('skill21','player_kill_enemy');hook_register('skill21','counter_assault_wrapper');hook_register('skill21','parse_news');
function ___post_init() { global $___PRIVATE_SKILL21__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL21__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL21__VARS__enpcinfo;
$___LOCAL_SKILL21__VARS__enpcinfo=$GLOBALS['enpcinfo'];
unset($GLOBALS['enpcinfo']);
}
	
}

?>