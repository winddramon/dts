<?php

namespace radar
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'base/items/radar/'.$___TEMP_key; 
	
	$___PRESET_RADAR__VARS__radardata=$radardata;$___PRESET_RADAR__VARS__radar_tplist=$radar_tplist;$___PRESET_RADAR__VARS__radar_fetch_type=$radar_fetch_type;$___PRESET_RADAR__VARS__radar_disp_npc_type=$radar_disp_npc_type;$___PRESET_RADAR__VARS__radar_disp_recordname_npc_type=$radar_disp_recordname_npc_type;
function ___pre_init() { global $___PRESET_RADAR__VARS__radardata,$radardata,$___PRESET_RADAR__VARS__radar_tplist,$radar_tplist,$___PRESET_RADAR__VARS__radar_fetch_type,$radar_fetch_type,$___PRESET_RADAR__VARS__radar_disp_npc_type,$radar_disp_npc_type,$___PRESET_RADAR__VARS__radar_disp_recordname_npc_type,$radar_disp_recordname_npc_type;$radardata=$___PRESET_RADAR__VARS__radardata;$radar_tplist=$___PRESET_RADAR__VARS__radar_tplist;$radar_fetch_type=$___PRESET_RADAR__VARS__radar_fetch_type;$radar_disp_npc_type=$___PRESET_RADAR__VARS__radar_disp_npc_type;$radar_disp_recordname_npc_type=$___PRESET_RADAR__VARS__radar_disp_recordname_npc_type; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_RADAR_PRESET_VARS','$___PRESET_RADAR__VARS__radardata=$radardata;$___PRESET_RADAR__VARS__radar_tplist=$radar_tplist;$___PRESET_RADAR__VARS__radar_fetch_type=$radar_fetch_type;$___PRESET_RADAR__VARS__radar_disp_npc_type=$radar_disp_npc_type;$___PRESET_RADAR__VARS__radar_disp_recordname_npc_type=$radar_disp_recordname_npc_type;');
define('___LOAD_MOD_RADAR_PRESET_VARS','global $___PRESET_RADAR__VARS__radardata,$radardata,$___PRESET_RADAR__VARS__radar_tplist,$radar_tplist,$___PRESET_RADAR__VARS__radar_fetch_type,$radar_fetch_type,$___PRESET_RADAR__VARS__radar_disp_npc_type,$radar_disp_npc_type,$___PRESET_RADAR__VARS__radar_disp_recordname_npc_type,$radar_disp_recordname_npc_type;$radardata=$___PRESET_RADAR__VARS__radardata;$radar_tplist=$___PRESET_RADAR__VARS__radar_tplist;$radar_fetch_type=$___PRESET_RADAR__VARS__radar_fetch_type;$radar_disp_npc_type=$___PRESET_RADAR__VARS__radar_disp_npc_type;$radar_disp_recordname_npc_type=$___PRESET_RADAR__VARS__radar_disp_recordname_npc_type;');
define('MOD_RADAR_RADAR','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/base\\items\\radar/radar');
define('MOD_RADAR_RADARCMD','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/base\\items\\radar/radarcmd');
define('MODULE_RADAR_GLOBALS_VARNAMES','radardata,radar_tplist,radar_fetch_type,radar_disp_npc_type,radar_disp_recordname_npc_type');
define('MOD_RADAR',1);
define('IMPORT_MODULE_RADAR_GLOBALS','global $___LOCAL_RADAR__VARS__radardata,$___LOCAL_RADAR__VARS__radar_tplist,$___LOCAL_RADAR__VARS__radar_fetch_type,$___LOCAL_RADAR__VARS__radar_disp_npc_type,$___LOCAL_RADAR__VARS__radar_disp_recordname_npc_type; $radardata=&$___LOCAL_RADAR__VARS__radardata; $radar_tplist=&$___LOCAL_RADAR__VARS__radar_tplist; $radar_fetch_type=&$___LOCAL_RADAR__VARS__radar_fetch_type; $radar_disp_npc_type=&$___LOCAL_RADAR__VARS__radar_disp_npc_type; $radar_disp_recordname_npc_type=&$___LOCAL_RADAR__VARS__radar_disp_recordname_npc_type; ');
define('PREFIX_MODULE_RADAR_GLOBALS','\'; global $___LOCAL_RADAR__VARS__radardata; ${$___TEMP_PREFIX.\'radardata\'}=&$___LOCAL_RADAR__VARS__radardata; global $___LOCAL_RADAR__VARS__radar_tplist; ${$___TEMP_PREFIX.\'radar_tplist\'}=&$___LOCAL_RADAR__VARS__radar_tplist; global $___LOCAL_RADAR__VARS__radar_fetch_type; ${$___TEMP_PREFIX.\'radar_fetch_type\'}=&$___LOCAL_RADAR__VARS__radar_fetch_type; global $___LOCAL_RADAR__VARS__radar_disp_npc_type; ${$___TEMP_PREFIX.\'radar_disp_npc_type\'}=&$___LOCAL_RADAR__VARS__radar_disp_npc_type; global $___LOCAL_RADAR__VARS__radar_disp_recordname_npc_type; ${$___TEMP_PREFIX.\'radar_disp_recordname_npc_type\'}=&$___LOCAL_RADAR__VARS__radar_disp_recordname_npc_type; unset($___TEMP_PREFIX); ');
define('MODULE_RADAR_GLOBALS','\'; global $___LOCAL_RADAR__VARS__radardata; ${$___TEMP_VARNAME}[\'radardata\']=&$___LOCAL_RADAR__VARS__radardata; global $___LOCAL_RADAR__VARS__radar_tplist; ${$___TEMP_VARNAME}[\'radar_tplist\']=&$___LOCAL_RADAR__VARS__radar_tplist; global $___LOCAL_RADAR__VARS__radar_fetch_type; ${$___TEMP_VARNAME}[\'radar_fetch_type\']=&$___LOCAL_RADAR__VARS__radar_fetch_type; global $___LOCAL_RADAR__VARS__radar_disp_npc_type; ${$___TEMP_VARNAME}[\'radar_disp_npc_type\']=&$___LOCAL_RADAR__VARS__radar_disp_npc_type; global $___LOCAL_RADAR__VARS__radar_disp_recordname_npc_type; ${$___TEMP_VARNAME}[\'radar_disp_recordname_npc_type\']=&$___LOCAL_RADAR__VARS__radar_disp_recordname_npc_type; unset($___TEMP_VARNAME); ');

global $___PRIVATE_RADAR__VARS_____PRIVATE_PFUNC,$___PRIVATE_RADAR__VARS_____PRIVATE_CFUNC,$___LOCAL_RADAR__VARS__radardata,$___LOCAL_RADAR__VARS__radar_tplist,$___LOCAL_RADAR__VARS__radar_fetch_type,$___LOCAL_RADAR__VARS__radar_disp_npc_type,$___LOCAL_RADAR__VARS__radar_disp_recordname_npc_type;
$___PRIVATE_RADAR__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_RADAR__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_RADAR__VARS__radardata=&$radardata;$___LOCAL_RADAR__VARS__radar_tplist=&$radar_tplist;$___LOCAL_RADAR__VARS__radar_fetch_type=&$radar_fetch_type;$___LOCAL_RADAR__VARS__radar_disp_npc_type=&$radar_disp_npc_type;$___LOCAL_RADAR__VARS__radar_disp_recordname_npc_type=&$radar_disp_recordname_npc_type;
unset($radardata,$radar_tplist,$radar_fetch_type,$radar_disp_npc_type,$radar_disp_recordname_npc_type);
hook_register('radar','pre_radar_event');hook_register('radar','check_radar_digit');hook_register('radar','radar_itmsk_to_digit');hook_register('radar','use_radar');hook_register('radar','check_include_radar_cmdpage');hook_register('radar','post_radar_event');hook_register('radar','radar_parse_namelist');hook_register('radar','get_radar_npc_type_list');hook_register('radar','item_radar_reduce');hook_register('radar','itemuse');
function ___post_init() { global $___PRIVATE_RADAR__VARS_____PRIVATE_PFUNC,$___PRIVATE_RADAR__VARS_____PRIVATE_CFUNC,$___LOCAL_RADAR__VARS__radardata,$___LOCAL_RADAR__VARS__radar_tplist,$___LOCAL_RADAR__VARS__radar_fetch_type,$___LOCAL_RADAR__VARS__radar_disp_npc_type,$___LOCAL_RADAR__VARS__radar_disp_recordname_npc_type;
$___LOCAL_RADAR__VARS__radardata=$GLOBALS['radardata'];$___LOCAL_RADAR__VARS__radar_tplist=$GLOBALS['radar_tplist'];$___LOCAL_RADAR__VARS__radar_fetch_type=$GLOBALS['radar_fetch_type'];$___LOCAL_RADAR__VARS__radar_disp_npc_type=$GLOBALS['radar_disp_npc_type'];$___LOCAL_RADAR__VARS__radar_disp_recordname_npc_type=$GLOBALS['radar_disp_recordname_npc_type'];
unset($GLOBALS['radardata'],$GLOBALS['radar_tplist'],$GLOBALS['radar_fetch_type'],$GLOBALS['radar_disp_npc_type'],$GLOBALS['radar_disp_recordname_npc_type']);
}
	
}

?>