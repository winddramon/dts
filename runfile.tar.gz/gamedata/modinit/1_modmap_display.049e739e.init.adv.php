<?php

namespace map_display
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'base/map_display/'.$___TEMP_key; 
	
	$___PRESET_MAP_DISPLAY__VARS__map_display_group=$map_display_group;
function ___pre_init() { global $___PRESET_MAP_DISPLAY__VARS__map_display_group,$map_display_group;$map_display_group=$___PRESET_MAP_DISPLAY__VARS__map_display_group; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_MAP_DISPLAY_PRESET_VARS','$___PRESET_MAP_DISPLAY__VARS__map_display_group=$map_display_group;');
define('___LOAD_MOD_MAP_DISPLAY_PRESET_VARS','global $___PRESET_MAP_DISPLAY__VARS__map_display_group,$map_display_group;$map_display_group=$___PRESET_MAP_DISPLAY__VARS__map_display_group;');
define('MODULE_MAP_DISPLAY_GLOBALS_VARNAMES','map_display_group');
define('MOD_MAP_DISPLAY',1);
define('IMPORT_MODULE_MAP_DISPLAY_GLOBALS','global $___LOCAL_MAP_DISPLAY__VARS__map_display_group; $map_display_group=&$___LOCAL_MAP_DISPLAY__VARS__map_display_group; ');
define('PREFIX_MODULE_MAP_DISPLAY_GLOBALS','\'; global $___LOCAL_MAP_DISPLAY__VARS__map_display_group; ${$___TEMP_PREFIX.\'map_display_group\'}=&$___LOCAL_MAP_DISPLAY__VARS__map_display_group; unset($___TEMP_PREFIX); ');
define('MODULE_MAP_DISPLAY_GLOBALS','\'; global $___LOCAL_MAP_DISPLAY__VARS__map_display_group; ${$___TEMP_VARNAME}[\'map_display_group\']=&$___LOCAL_MAP_DISPLAY__VARS__map_display_group; unset($___TEMP_VARNAME); ');

global $___PRIVATE_MAP_DISPLAY__VARS_____PRIVATE_PFUNC,$___PRIVATE_MAP_DISPLAY__VARS_____PRIVATE_CFUNC,$___LOCAL_MAP_DISPLAY__VARS__map_display_group;
$___PRIVATE_MAP_DISPLAY__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_MAP_DISPLAY__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_MAP_DISPLAY__VARS__map_display_group=&$map_display_group;
unset($map_display_group);
hook_register('map_display','get_map_display_config');hook_register('map_display','map_display_y2coor');
function ___post_init() { global $___PRIVATE_MAP_DISPLAY__VARS_____PRIVATE_PFUNC,$___PRIVATE_MAP_DISPLAY__VARS_____PRIVATE_CFUNC,$___LOCAL_MAP_DISPLAY__VARS__map_display_group;
$___LOCAL_MAP_DISPLAY__VARS__map_display_group=$GLOBALS['map_display_group'];
unset($GLOBALS['map_display_group']);
}
	
}

?>