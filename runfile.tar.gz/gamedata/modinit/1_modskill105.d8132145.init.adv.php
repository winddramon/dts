<?php

namespace skill105
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill105/'.$___TEMP_key; 
	
	$___PRESET_SKILL105__VARS__ragecost=$ragecost;
function ___pre_init() { global $___PRESET_SKILL105__VARS__ragecost,$ragecost;$ragecost=$___PRESET_SKILL105__VARS__ragecost; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL105_PRESET_VARS','$___PRESET_SKILL105__VARS__ragecost=$ragecost;');
define('___LOAD_MOD_SKILL105_PRESET_VARS','global $___PRESET_SKILL105__VARS__ragecost,$ragecost;$ragecost=$___PRESET_SKILL105__VARS__ragecost;');
define('MOD_SKILL105_INFO','club;battle;locked;');
define('MOD_SKILL105_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill105/desc');
define('MOD_SKILL105_BATTLECMD_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill105/battlecmd_desc');
define('MODULE_SKILL105_GLOBALS_VARNAMES','ragecost');
define('MOD_SKILL105',1);
define('IMPORT_MODULE_SKILL105_GLOBALS','global $___LOCAL_SKILL105__VARS__ragecost; $ragecost=&$___LOCAL_SKILL105__VARS__ragecost; ');
define('PREFIX_MODULE_SKILL105_GLOBALS','\'; global $___LOCAL_SKILL105__VARS__ragecost; ${$___TEMP_PREFIX.\'ragecost\'}=&$___LOCAL_SKILL105__VARS__ragecost; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL105_GLOBALS','\'; global $___LOCAL_SKILL105__VARS__ragecost; ${$___TEMP_VARNAME}[\'ragecost\']=&$___LOCAL_SKILL105__VARS__ragecost; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL105__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL105__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL105__VARS__ragecost;
$___PRIVATE_SKILL105__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL105__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_SKILL105__VARS__ragecost=&$ragecost;
unset($ragecost);
hook_register('skill105','acquire105');hook_register('skill105','lost105');hook_register('skill105','check_unlocked105');hook_register('skill105','get_rage_cost105');hook_register('skill105','strike_prepare');hook_register('skill105','get_skill104_actrate');hook_register('skill105','parse_news');
function ___post_init() { global $___PRIVATE_SKILL105__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL105__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL105__VARS__ragecost;
$___LOCAL_SKILL105__VARS__ragecost=$GLOBALS['ragecost'];
unset($GLOBALS['ragecost']);
}
	
}

?>