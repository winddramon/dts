<?php

namespace gameflow_antiafk
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'core/gameflow/gameflow_antiafk/'.$___TEMP_key; 
	
	$___PRESET_GAMEFLOW_ANTIAFK__VARS__antiAFKertime_normal=$antiAFKertime_normal;$___PRESET_GAMEFLOW_ANTIAFK__VARS__antiAFKertime_room=$antiAFKertime_room;
function ___pre_init() { global $___PRESET_GAMEFLOW_ANTIAFK__VARS__antiAFKertime_normal,$antiAFKertime_normal,$___PRESET_GAMEFLOW_ANTIAFK__VARS__antiAFKertime_room,$antiAFKertime_room;$antiAFKertime_normal=$___PRESET_GAMEFLOW_ANTIAFK__VARS__antiAFKertime_normal;$antiAFKertime_room=$___PRESET_GAMEFLOW_ANTIAFK__VARS__antiAFKertime_room; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_GAMEFLOW_ANTIAFK_PRESET_VARS','$___PRESET_GAMEFLOW_ANTIAFK__VARS__antiAFKertime_normal=$antiAFKertime_normal;$___PRESET_GAMEFLOW_ANTIAFK__VARS__antiAFKertime_room=$antiAFKertime_room;');
define('___LOAD_MOD_GAMEFLOW_ANTIAFK_PRESET_VARS','global $___PRESET_GAMEFLOW_ANTIAFK__VARS__antiAFKertime_normal,$antiAFKertime_normal,$___PRESET_GAMEFLOW_ANTIAFK__VARS__antiAFKertime_room,$antiAFKertime_room;$antiAFKertime_normal=$___PRESET_GAMEFLOW_ANTIAFK__VARS__antiAFKertime_normal;$antiAFKertime_room=$___PRESET_GAMEFLOW_ANTIAFK__VARS__antiAFKertime_room;');
define('MODULE_GAMEFLOW_ANTIAFK_GLOBALS_VARNAMES','antiAFKertime_normal,antiAFKertime_room');
define('MOD_GAMEFLOW_ANTIAFK',1);
define('IMPORT_MODULE_GAMEFLOW_ANTIAFK_GLOBALS','global $___LOCAL_GAMEFLOW_ANTIAFK__VARS__antiAFKertime_normal,$___LOCAL_GAMEFLOW_ANTIAFK__VARS__antiAFKertime_room; $antiAFKertime_normal=&$___LOCAL_GAMEFLOW_ANTIAFK__VARS__antiAFKertime_normal; $antiAFKertime_room=&$___LOCAL_GAMEFLOW_ANTIAFK__VARS__antiAFKertime_room; ');
define('PREFIX_MODULE_GAMEFLOW_ANTIAFK_GLOBALS','\'; global $___LOCAL_GAMEFLOW_ANTIAFK__VARS__antiAFKertime_normal; ${$___TEMP_PREFIX.\'antiAFKertime_normal\'}=&$___LOCAL_GAMEFLOW_ANTIAFK__VARS__antiAFKertime_normal; global $___LOCAL_GAMEFLOW_ANTIAFK__VARS__antiAFKertime_room; ${$___TEMP_PREFIX.\'antiAFKertime_room\'}=&$___LOCAL_GAMEFLOW_ANTIAFK__VARS__antiAFKertime_room; unset($___TEMP_PREFIX); ');
define('MODULE_GAMEFLOW_ANTIAFK_GLOBALS','\'; global $___LOCAL_GAMEFLOW_ANTIAFK__VARS__antiAFKertime_normal; ${$___TEMP_VARNAME}[\'antiAFKertime_normal\']=&$___LOCAL_GAMEFLOW_ANTIAFK__VARS__antiAFKertime_normal; global $___LOCAL_GAMEFLOW_ANTIAFK__VARS__antiAFKertime_room; ${$___TEMP_VARNAME}[\'antiAFKertime_room\']=&$___LOCAL_GAMEFLOW_ANTIAFK__VARS__antiAFKertime_room; unset($___TEMP_VARNAME); ');

global $___PRIVATE_GAMEFLOW_ANTIAFK__VARS_____PRIVATE_PFUNC,$___PRIVATE_GAMEFLOW_ANTIAFK__VARS_____PRIVATE_CFUNC,$___LOCAL_GAMEFLOW_ANTIAFK__VARS__antiAFKertime_normal,$___LOCAL_GAMEFLOW_ANTIAFK__VARS__antiAFKertime_room;
$___PRIVATE_GAMEFLOW_ANTIAFK__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_GAMEFLOW_ANTIAFK__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_GAMEFLOW_ANTIAFK__VARS__antiAFKertime_normal=&$antiAFKertime_normal;$___LOCAL_GAMEFLOW_ANTIAFK__VARS__antiAFKertime_room=&$antiAFKertime_room;
unset($antiAFKertime_normal,$antiAFKertime_room);
hook_register('gameflow_antiafk','reset_game');hook_register('gameflow_antiafk','check_triggered_antiafk');hook_register('gameflow_antiafk','get_antiafkertime');hook_register('gameflow_antiafk','gamestateupdate');hook_register('gameflow_antiafk','antiafk');hook_register('gameflow_antiafk','parse_news');
function ___post_init() { global $___PRIVATE_GAMEFLOW_ANTIAFK__VARS_____PRIVATE_PFUNC,$___PRIVATE_GAMEFLOW_ANTIAFK__VARS_____PRIVATE_CFUNC,$___LOCAL_GAMEFLOW_ANTIAFK__VARS__antiAFKertime_normal,$___LOCAL_GAMEFLOW_ANTIAFK__VARS__antiAFKertime_room;
$___LOCAL_GAMEFLOW_ANTIAFK__VARS__antiAFKertime_normal=$GLOBALS['antiAFKertime_normal'];$___LOCAL_GAMEFLOW_ANTIAFK__VARS__antiAFKertime_room=$GLOBALS['antiAFKertime_room'];
unset($GLOBALS['antiAFKertime_normal'],$GLOBALS['antiAFKertime_room']);
}
	
}

?>