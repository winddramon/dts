<?php

namespace skill231
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill231/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL231_PRESET_VARS','');
define('___LOAD_MOD_SKILL231_PRESET_VARS','');
define('MOD_SKILL231_INFO','club;hidden;');
define('MODULE_SKILL231_GLOBALS_VARNAMES','');
define('MOD_SKILL231',1);
define('IMPORT_MODULE_SKILL231_GLOBALS','');
define('PREFIX_MODULE_SKILL231_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL231_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL231__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL231__VARS_____PRIVATE_CFUNC;
$___PRIVATE_SKILL231__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL231__VARS_____PRIVATE_CFUNC=Array();

hook_register('skill231','acquire231');hook_register('skill231','lost231');hook_register('skill231','check_unlocked231');hook_register('skill231','get_ex_inf_rate_modifier');
function ___post_init() { global $___PRIVATE_SKILL231__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL231__VARS_____PRIVATE_CFUNC;


}
	
}

?>