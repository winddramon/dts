<?php

namespace opening
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'base/opening/'.$___TEMP_key; 
	
	$___PRESET_OPENING__VARS__opening_by_shootings=$opening_by_shootings;$___PRESET_OPENING__VARS__opening_by_shootings_gametype=$opening_by_shootings_gametype;
function ___pre_init() { global $___PRESET_OPENING__VARS__opening_by_shootings,$opening_by_shootings,$___PRESET_OPENING__VARS__opening_by_shootings_gametype,$opening_by_shootings_gametype;$opening_by_shootings=$___PRESET_OPENING__VARS__opening_by_shootings;$opening_by_shootings_gametype=$___PRESET_OPENING__VARS__opening_by_shootings_gametype; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_OPENING_PRESET_VARS','$___PRESET_OPENING__VARS__opening_by_shootings=$opening_by_shootings;$___PRESET_OPENING__VARS__opening_by_shootings_gametype=$opening_by_shootings_gametype;');
define('___LOAD_MOD_OPENING_PRESET_VARS','global $___PRESET_OPENING__VARS__opening_by_shootings,$opening_by_shootings,$___PRESET_OPENING__VARS__opening_by_shootings_gametype,$opening_by_shootings_gametype;$opening_by_shootings=$___PRESET_OPENING__VARS__opening_by_shootings;$opening_by_shootings_gametype=$___PRESET_OPENING__VARS__opening_by_shootings_gametype;');
define('MOD_OPENING_STORYBOARD','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/base\\opening/storyboard');
define('MOD_OPENING_STORYBOARD_CONTAINER','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/base\\opening/storyboard_container');
define('MOD_OPENING_CMD_SKIP_OP','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/base\\opening/cmd_skip_op');
define('MODULE_OPENING_GLOBALS_VARNAMES','opening_by_shootings,opening_by_shootings_gametype');
define('MOD_OPENING',1);
define('IMPORT_MODULE_OPENING_GLOBALS','global $___LOCAL_OPENING__VARS__opening_by_shootings,$___LOCAL_OPENING__VARS__opening_by_shootings_gametype; $opening_by_shootings=&$___LOCAL_OPENING__VARS__opening_by_shootings; $opening_by_shootings_gametype=&$___LOCAL_OPENING__VARS__opening_by_shootings_gametype; ');
define('PREFIX_MODULE_OPENING_GLOBALS','\'; global $___LOCAL_OPENING__VARS__opening_by_shootings; ${$___TEMP_PREFIX.\'opening_by_shootings\'}=&$___LOCAL_OPENING__VARS__opening_by_shootings; global $___LOCAL_OPENING__VARS__opening_by_shootings_gametype; ${$___TEMP_PREFIX.\'opening_by_shootings_gametype\'}=&$___LOCAL_OPENING__VARS__opening_by_shootings_gametype; unset($___TEMP_PREFIX); ');
define('MODULE_OPENING_GLOBALS','\'; global $___LOCAL_OPENING__VARS__opening_by_shootings; ${$___TEMP_VARNAME}[\'opening_by_shootings\']=&$___LOCAL_OPENING__VARS__opening_by_shootings; global $___LOCAL_OPENING__VARS__opening_by_shootings_gametype; ${$___TEMP_VARNAME}[\'opening_by_shootings_gametype\']=&$___LOCAL_OPENING__VARS__opening_by_shootings_gametype; unset($___TEMP_VARNAME); ');

global $___PRIVATE_OPENING__VARS_____PRIVATE_PFUNC,$___PRIVATE_OPENING__VARS_____PRIVATE_CFUNC,$___LOCAL_OPENING__VARS__opening_by_shootings,$___LOCAL_OPENING__VARS__opening_by_shootings_gametype;
$___PRIVATE_OPENING__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_OPENING__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_OPENING__VARS__opening_by_shootings=&$opening_by_shootings;$___LOCAL_OPENING__VARS__opening_by_shootings_gametype=&$opening_by_shootings_gametype;
unset($opening_by_shootings,$opening_by_shootings_gametype);
hook_register('opening','opening_by_shootings_available');hook_register('opening','act');hook_register('opening','show_opening');hook_register('opening','prepare_initial_response_content');hook_register('opening','prepare_response_content');
function ___post_init() { global $___PRIVATE_OPENING__VARS_____PRIVATE_PFUNC,$___PRIVATE_OPENING__VARS_____PRIVATE_CFUNC,$___LOCAL_OPENING__VARS__opening_by_shootings,$___LOCAL_OPENING__VARS__opening_by_shootings_gametype;
$___LOCAL_OPENING__VARS__opening_by_shootings=$GLOBALS['opening_by_shootings'];$___LOCAL_OPENING__VARS__opening_by_shootings_gametype=$GLOBALS['opening_by_shootings_gametype'];
unset($GLOBALS['opening_by_shootings'],$GLOBALS['opening_by_shootings_gametype']);
}
	
}

?>