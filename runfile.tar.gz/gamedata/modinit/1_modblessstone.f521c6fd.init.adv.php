<?php

namespace blessstone
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/attr/blessstone/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_BLESSSTONE_PRESET_VARS','');
define('___LOAD_MOD_BLESSSTONE_PRESET_VARS','');
define('MOD_BLESSSTONE_USE_BLESSSTONE','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\attr\\blessstone/use_blessstone');
define('MODULE_BLESSSTONE_GLOBALS_VARNAMES','');
define('MOD_BLESSSTONE',1);
define('IMPORT_MODULE_BLESSSTONE_GLOBALS','');
define('PREFIX_MODULE_BLESSSTONE_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_BLESSSTONE_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_BLESSSTONE__VARS_____PRIVATE_PFUNC,$___PRIVATE_BLESSSTONE__VARS_____PRIVATE_CFUNC;
$___PRIVATE_BLESSSTONE__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_BLESSSTONE__VARS_____PRIVATE_CFUNC=Array();

hook_register('blessstone','itemuse');hook_register('blessstone','use_blessstone');hook_register('blessstone','act');hook_register('blessstone','use_hone');hook_register('blessstone','use_sewing_kit');hook_register('blessstone','autosewingkit_finish_event');hook_register('blessstone','parse_news');
function ___post_init() { global $___PRIVATE_BLESSSTONE__VARS_____PRIVATE_PFUNC,$___PRIVATE_BLESSSTONE__VARS_____PRIVATE_CFUNC;


}
	
}

?>