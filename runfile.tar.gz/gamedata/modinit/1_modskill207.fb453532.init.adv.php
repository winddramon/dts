<?php

namespace skill207
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill207/'.$___TEMP_key; 
	
	$___PRESET_SKILL207__VARS__accgain=$accgain;$___PRESET_SKILL207__VARS__rbgain=$rbgain;$___PRESET_SKILL207__VARS__flucgain=$flucgain;$___PRESET_SKILL207__VARS__rangerate=$rangerate;$___PRESET_SKILL207__VARS__upgradecost=$upgradecost;
function ___pre_init() { global $___PRESET_SKILL207__VARS__accgain,$accgain,$___PRESET_SKILL207__VARS__rbgain,$rbgain,$___PRESET_SKILL207__VARS__flucgain,$flucgain,$___PRESET_SKILL207__VARS__rangerate,$rangerate,$___PRESET_SKILL207__VARS__upgradecost,$upgradecost;$accgain=$___PRESET_SKILL207__VARS__accgain;$rbgain=$___PRESET_SKILL207__VARS__rbgain;$flucgain=$___PRESET_SKILL207__VARS__flucgain;$rangerate=$___PRESET_SKILL207__VARS__rangerate;$upgradecost=$___PRESET_SKILL207__VARS__upgradecost; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL207_PRESET_VARS','$___PRESET_SKILL207__VARS__accgain=$accgain;$___PRESET_SKILL207__VARS__rbgain=$rbgain;$___PRESET_SKILL207__VARS__flucgain=$flucgain;$___PRESET_SKILL207__VARS__rangerate=$rangerate;$___PRESET_SKILL207__VARS__upgradecost=$upgradecost;');
define('___LOAD_MOD_SKILL207_PRESET_VARS','global $___PRESET_SKILL207__VARS__accgain,$accgain,$___PRESET_SKILL207__VARS__rbgain,$rbgain,$___PRESET_SKILL207__VARS__flucgain,$flucgain,$___PRESET_SKILL207__VARS__rangerate,$rangerate,$___PRESET_SKILL207__VARS__upgradecost,$upgradecost;$accgain=$___PRESET_SKILL207__VARS__accgain;$rbgain=$___PRESET_SKILL207__VARS__rbgain;$flucgain=$___PRESET_SKILL207__VARS__flucgain;$rangerate=$___PRESET_SKILL207__VARS__rangerate;$upgradecost=$___PRESET_SKILL207__VARS__upgradecost;');
define('MOD_SKILL207_INFO','club;upgrade;');
define('MOD_SKILL207_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill207/desc');
define('MODULE_SKILL207_GLOBALS_VARNAMES','accgain,rbgain,flucgain,rangerate,upgradecost');
define('MOD_SKILL207',1);
define('IMPORT_MODULE_SKILL207_GLOBALS','global $___LOCAL_SKILL207__VARS__accgain,$___LOCAL_SKILL207__VARS__rbgain,$___LOCAL_SKILL207__VARS__flucgain,$___LOCAL_SKILL207__VARS__rangerate,$___LOCAL_SKILL207__VARS__upgradecost; $accgain=&$___LOCAL_SKILL207__VARS__accgain; $rbgain=&$___LOCAL_SKILL207__VARS__rbgain; $flucgain=&$___LOCAL_SKILL207__VARS__flucgain; $rangerate=&$___LOCAL_SKILL207__VARS__rangerate; $upgradecost=&$___LOCAL_SKILL207__VARS__upgradecost; ');
define('PREFIX_MODULE_SKILL207_GLOBALS','\'; global $___LOCAL_SKILL207__VARS__accgain; ${$___TEMP_PREFIX.\'accgain\'}=&$___LOCAL_SKILL207__VARS__accgain; global $___LOCAL_SKILL207__VARS__rbgain; ${$___TEMP_PREFIX.\'rbgain\'}=&$___LOCAL_SKILL207__VARS__rbgain; global $___LOCAL_SKILL207__VARS__flucgain; ${$___TEMP_PREFIX.\'flucgain\'}=&$___LOCAL_SKILL207__VARS__flucgain; global $___LOCAL_SKILL207__VARS__rangerate; ${$___TEMP_PREFIX.\'rangerate\'}=&$___LOCAL_SKILL207__VARS__rangerate; global $___LOCAL_SKILL207__VARS__upgradecost; ${$___TEMP_PREFIX.\'upgradecost\'}=&$___LOCAL_SKILL207__VARS__upgradecost; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL207_GLOBALS','\'; global $___LOCAL_SKILL207__VARS__accgain; ${$___TEMP_VARNAME}[\'accgain\']=&$___LOCAL_SKILL207__VARS__accgain; global $___LOCAL_SKILL207__VARS__rbgain; ${$___TEMP_VARNAME}[\'rbgain\']=&$___LOCAL_SKILL207__VARS__rbgain; global $___LOCAL_SKILL207__VARS__flucgain; ${$___TEMP_VARNAME}[\'flucgain\']=&$___LOCAL_SKILL207__VARS__flucgain; global $___LOCAL_SKILL207__VARS__rangerate; ${$___TEMP_VARNAME}[\'rangerate\']=&$___LOCAL_SKILL207__VARS__rangerate; global $___LOCAL_SKILL207__VARS__upgradecost; ${$___TEMP_VARNAME}[\'upgradecost\']=&$___LOCAL_SKILL207__VARS__upgradecost; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL207__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL207__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL207__VARS__accgain,$___LOCAL_SKILL207__VARS__rbgain,$___LOCAL_SKILL207__VARS__flucgain,$___LOCAL_SKILL207__VARS__rangerate,$___LOCAL_SKILL207__VARS__upgradecost;
$___PRIVATE_SKILL207__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL207__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_SKILL207__VARS__accgain=&$accgain;$___LOCAL_SKILL207__VARS__rbgain=&$rbgain;$___LOCAL_SKILL207__VARS__flucgain=&$flucgain;$___LOCAL_SKILL207__VARS__rangerate=&$rangerate;$___LOCAL_SKILL207__VARS__upgradecost=&$upgradecost;
unset($accgain,$rbgain,$flucgain,$rangerate,$upgradecost);
hook_register('skill207','acquire207');hook_register('skill207','lost207');hook_register('skill207','check_unlocked207');hook_register('skill207','upgrade207');hook_register('skill207','get_skill207_extra_acc_gain');hook_register('skill207','get_skill207_extra_rb_gain');hook_register('skill207','get_rapid_accuracy_loss');hook_register('skill207','get_hitrate_multiplier');hook_register('skill207','get_skill207_fluc_bonus');hook_register('skill207','get_skill207_rangerate');hook_register('skill207','get_weapon_fluc_max_range');hook_register('skill207','check_counterable_by_weapon_range');hook_register('skill207','calculate_counter_rate_multiplier');
function ___post_init() { global $___PRIVATE_SKILL207__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL207__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL207__VARS__accgain,$___LOCAL_SKILL207__VARS__rbgain,$___LOCAL_SKILL207__VARS__flucgain,$___LOCAL_SKILL207__VARS__rangerate,$___LOCAL_SKILL207__VARS__upgradecost;
$___LOCAL_SKILL207__VARS__accgain=$GLOBALS['accgain'];$___LOCAL_SKILL207__VARS__rbgain=$GLOBALS['rbgain'];$___LOCAL_SKILL207__VARS__flucgain=$GLOBALS['flucgain'];$___LOCAL_SKILL207__VARS__rangerate=$GLOBALS['rangerate'];$___LOCAL_SKILL207__VARS__upgradecost=$GLOBALS['upgradecost'];
unset($GLOBALS['accgain'],$GLOBALS['rbgain'],$GLOBALS['flucgain'],$GLOBALS['rangerate'],$GLOBALS['upgradecost']);
}
	
}

?>