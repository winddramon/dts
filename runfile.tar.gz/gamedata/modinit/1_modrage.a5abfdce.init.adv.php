<?php

namespace rage
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/attr/rage/'.$___TEMP_key; 
	
	$___PRESET_RAGE__VARS__max_rage=$max_rage;$___PRESET_RAGE__VARS__rest_rage_time=$rest_rage_time;
function ___pre_init() { global $___PRESET_RAGE__VARS__max_rage,$max_rage,$___PRESET_RAGE__VARS__rest_rage_time,$rest_rage_time;$max_rage=$___PRESET_RAGE__VARS__max_rage;$rest_rage_time=$___PRESET_RAGE__VARS__rest_rage_time; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_RAGE_PRESET_VARS','$___PRESET_RAGE__VARS__max_rage=$max_rage;$___PRESET_RAGE__VARS__rest_rage_time=$rest_rage_time;');
define('___LOAD_MOD_RAGE_PRESET_VARS','global $___PRESET_RAGE__VARS__max_rage,$max_rage,$___PRESET_RAGE__VARS__rest_rage_time,$rest_rage_time;$max_rage=$___PRESET_RAGE__VARS__max_rage;$rest_rage_time=$___PRESET_RAGE__VARS__rest_rage_time;');
define('MODULE_RAGE_GLOBALS_VARNAMES','max_rage,rest_rage_time');
define('MOD_RAGE',1);
define('IMPORT_MODULE_RAGE_GLOBALS','global $___LOCAL_RAGE__VARS__max_rage,$___LOCAL_RAGE__VARS__rest_rage_time; $max_rage=&$___LOCAL_RAGE__VARS__max_rage; $rest_rage_time=&$___LOCAL_RAGE__VARS__rest_rage_time; ');
define('PREFIX_MODULE_RAGE_GLOBALS','\'; global $___LOCAL_RAGE__VARS__max_rage; ${$___TEMP_PREFIX.\'max_rage\'}=&$___LOCAL_RAGE__VARS__max_rage; global $___LOCAL_RAGE__VARS__rest_rage_time; ${$___TEMP_PREFIX.\'rest_rage_time\'}=&$___LOCAL_RAGE__VARS__rest_rage_time; unset($___TEMP_PREFIX); ');
define('MODULE_RAGE_GLOBALS','\'; global $___LOCAL_RAGE__VARS__max_rage; ${$___TEMP_VARNAME}[\'max_rage\']=&$___LOCAL_RAGE__VARS__max_rage; global $___LOCAL_RAGE__VARS__rest_rage_time; ${$___TEMP_VARNAME}[\'rest_rage_time\']=&$___LOCAL_RAGE__VARS__rest_rage_time; unset($___TEMP_VARNAME); ');

global $___PRIVATE_RAGE__VARS_____PRIVATE_PFUNC,$___PRIVATE_RAGE__VARS_____PRIVATE_CFUNC,$___LOCAL_RAGE__VARS__max_rage,$___LOCAL_RAGE__VARS__rest_rage_time;
$___PRIVATE_RAGE__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_RAGE__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_RAGE__VARS__max_rage=&$max_rage;$___LOCAL_RAGE__VARS__rest_rage_time=&$rest_rage_time;
unset($max_rage,$rest_rage_time);
hook_register('rage','get_max_rage');hook_register('rage','calculate_rest_rageup');hook_register('rage','rest');hook_register('rage','calculate_attack_rage_gain');hook_register('rage','calculate_attack_rage_gain_base');hook_register('rage','calculate_attack_rage_gain_multiplier');hook_register('rage','calculate_attack_rage_gain_change');hook_register('rage','get_rage');hook_register('rage','strike_finish');hook_register('rage','itemuse');hook_register('rage','attack_prepare');hook_register('rage','attack_finish');
function ___post_init() { global $___PRIVATE_RAGE__VARS_____PRIVATE_PFUNC,$___PRIVATE_RAGE__VARS_____PRIVATE_CFUNC,$___LOCAL_RAGE__VARS__max_rage,$___LOCAL_RAGE__VARS__rest_rage_time;
$___LOCAL_RAGE__VARS__max_rage=$GLOBALS['max_rage'];$___LOCAL_RAGE__VARS__rest_rage_time=$GLOBALS['rest_rage_time'];
unset($GLOBALS['max_rage'],$GLOBALS['rest_rage_time']);
}
	
}

?>