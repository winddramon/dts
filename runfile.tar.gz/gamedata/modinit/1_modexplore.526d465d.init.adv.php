<?php

namespace explore
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'base/explore/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_EXPLORE_PRESET_VARS','');
define('___LOAD_MOD_EXPLORE_PRESET_VARS','');
define('MOD_EXPLORE_EXPLORE','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/base\\explore/explore');
define('MODULE_EXPLORE_GLOBALS_VARNAMES','');
define('MOD_EXPLORE',1);
define('IMPORT_MODULE_EXPLORE_GLOBALS','');
define('PREFIX_MODULE_EXPLORE_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_EXPLORE_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_EXPLORE__VARS_____PRIVATE_PFUNC,$___PRIVATE_EXPLORE__VARS_____PRIVATE_CFUNC;
$___PRIVATE_EXPLORE__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_EXPLORE__VARS_____PRIVATE_CFUNC=Array();

hook_register('explore','calculate_move_sp_cost');hook_register('explore','move_to_area');hook_register('explore','move');hook_register('explore','calculate_search_sp_cost');hook_register('explore','search_area');hook_register('explore','allow_move_check');hook_register('explore','allow_search_check');hook_register('explore','search');hook_register('explore','discover');hook_register('explore','act');
function ___post_init() { global $___PRIVATE_EXPLORE__VARS_____PRIVATE_PFUNC,$___PRIVATE_EXPLORE__VARS_____PRIVATE_CFUNC;


}
	
}

?>