<?php

namespace ex_seckill
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/attr/ex_seckill/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_EX_SECKILL_PRESET_VARS','');
define('___LOAD_MOD_EX_SECKILL_PRESET_VARS','');
define('MODULE_EX_SECKILL_GLOBALS_VARNAMES','');
define('MOD_EX_SECKILL',1);
define('IMPORT_MODULE_EX_SECKILL_GLOBALS','');
define('PREFIX_MODULE_EX_SECKILL_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_EX_SECKILL_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_EX_SECKILL__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_SECKILL__VARS_____PRIVATE_CFUNC;
$___PRIVATE_EX_SECKILL__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_EX_SECKILL__VARS_____PRIVATE_CFUNC=Array();

hook_register('ex_seckill','get_ex_seckill_proc_rate');hook_register('ex_seckill','apply_total_damage_modifier_seckill');
function ___post_init() { global $___PRIVATE_EX_SECKILL__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_SECKILL__VARS_____PRIVATE_CFUNC;


}
	
}

?>