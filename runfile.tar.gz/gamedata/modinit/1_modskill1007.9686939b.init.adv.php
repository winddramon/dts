<?php

namespace skill1007
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/npc_action/skill1007/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL1007_PRESET_VARS','');
define('___LOAD_MOD_SKILL1007_PRESET_VARS','');
define('MOD_SKILL1007_INFO','hidden;');
define('MODULE_SKILL1007_GLOBALS_VARNAMES','');
define('MOD_SKILL1007',1);
define('IMPORT_MODULE_SKILL1007_GLOBALS','');
define('PREFIX_MODULE_SKILL1007_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL1007_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL1007__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL1007__VARS_____PRIVATE_CFUNC;
$___PRIVATE_SKILL1007__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL1007__VARS_____PRIVATE_CFUNC=Array();

hook_register('skill1007','acquire1007');hook_register('skill1007','lost1007');hook_register('skill1007','check_unlocked1007');
function ___post_init() { global $___PRIVATE_SKILL1007__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL1007__VARS_____PRIVATE_CFUNC;


}
	
}

?>