<?php

namespace ex_rapid_attr
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/attr/ex_rapid_attr/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_EX_RAPID_ATTR_PRESET_VARS','');
define('___LOAD_MOD_EX_RAPID_ATTR_PRESET_VARS','');
define('MODULE_EX_RAPID_ATTR_GLOBALS_VARNAMES','');
define('MOD_EX_RAPID_ATTR',1);
define('IMPORT_MODULE_EX_RAPID_ATTR_GLOBALS','');
define('PREFIX_MODULE_EX_RAPID_ATTR_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_EX_RAPID_ATTR_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_EX_RAPID_ATTR__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_RAPID_ATTR__VARS_____PRIVATE_CFUNC;
$___PRIVATE_EX_RAPID_ATTR__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_EX_RAPID_ATTR__VARS_____PRIVATE_CFUNC=Array();

hook_register('ex_rapid_attr','get_rapid_times');hook_register('ex_rapid_attr','get_rapid_wepimp_increase');hook_register('ex_rapid_attr','calculate_wepimp_rate');hook_register('ex_rapid_attr','get_rapid_inf_rate_loss');hook_register('ex_rapid_attr','calculate_inf_rate');hook_register('ex_rapid_attr','get_rapid_damage_modifier');hook_register('ex_rapid_attr','get_rapid_dmg_multiplier');hook_register('ex_rapid_attr','get_primary_dmg_multiplier');hook_register('ex_rapid_attr','get_rapid_accuracy_loss');hook_register('ex_rapid_attr','check_rapid');hook_register('ex_rapid_attr','weapon_strike');hook_register('ex_rapid_attr','strike_prepare');
function ___post_init() { global $___PRIVATE_EX_RAPID_ATTR__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_RAPID_ATTR__VARS_____PRIVATE_CFUNC;


}
	
}

?>