<?php

namespace item_misc
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'base/items/item_misc/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_ITEM_MISC_PRESET_VARS','');
define('___LOAD_MOD_ITEM_MISC_PRESET_VARS','');
define('MODULE_ITEM_MISC_GLOBALS_VARNAMES','');
define('MOD_ITEM_MISC',1);
define('IMPORT_MODULE_ITEM_MISC_GLOBALS','');
define('PREFIX_MODULE_ITEM_MISC_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_ITEM_MISC_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_ITEM_MISC__VARS_____PRIVATE_PFUNC,$___PRIVATE_ITEM_MISC__VARS_____PRIVATE_CFUNC;
$___PRIVATE_ITEM_MISC__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_ITEM_MISC__VARS_____PRIVATE_CFUNC=Array();

hook_register('item_misc','parse_itmuse_desc');hook_register('item_misc','itemuse');hook_register('item_misc','divining');hook_register('item_misc','divining1');hook_register('item_misc','divining2');hook_register('item_misc','deathnote');hook_register('item_misc','deathnote_process');hook_register('item_misc','deathnote_process_core');hook_register('item_misc','act');hook_register('item_misc','parse_news');
function ___post_init() { global $___PRIVATE_ITEM_MISC__VARS_____PRIVATE_PFUNC,$___PRIVATE_ITEM_MISC__VARS_____PRIVATE_CFUNC;


}
	
}

?>