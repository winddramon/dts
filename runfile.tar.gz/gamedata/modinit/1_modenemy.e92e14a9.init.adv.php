<?php

namespace enemy
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'base/enemy/'.$___TEMP_key; 
	
	$___PRESET_ENEMY__VARS__findenemy_active_words=$findenemy_active_words;$___PRESET_ENEMY__VARS__active_obbs_pc=$active_obbs_pc;$___PRESET_ENEMY__VARS__active_obbs_npc=$active_obbs_npc;$___PRESET_ENEMY__VARS__active_obbs_range=$active_obbs_range;
function ___pre_init() { global $___PRESET_ENEMY__VARS__findenemy_active_words,$findenemy_active_words,$___PRESET_ENEMY__VARS__active_obbs_pc,$active_obbs_pc,$___PRESET_ENEMY__VARS__active_obbs_npc,$active_obbs_npc,$___PRESET_ENEMY__VARS__active_obbs_range,$active_obbs_range;$findenemy_active_words=$___PRESET_ENEMY__VARS__findenemy_active_words;$active_obbs_pc=$___PRESET_ENEMY__VARS__active_obbs_pc;$active_obbs_npc=$___PRESET_ENEMY__VARS__active_obbs_npc;$active_obbs_range=$___PRESET_ENEMY__VARS__active_obbs_range; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_ENEMY_PRESET_VARS','$___PRESET_ENEMY__VARS__findenemy_active_words=$findenemy_active_words;$___PRESET_ENEMY__VARS__active_obbs_pc=$active_obbs_pc;$___PRESET_ENEMY__VARS__active_obbs_npc=$active_obbs_npc;$___PRESET_ENEMY__VARS__active_obbs_range=$active_obbs_range;');
define('___LOAD_MOD_ENEMY_PRESET_VARS','global $___PRESET_ENEMY__VARS__findenemy_active_words,$findenemy_active_words,$___PRESET_ENEMY__VARS__active_obbs_pc,$active_obbs_pc,$___PRESET_ENEMY__VARS__active_obbs_npc,$active_obbs_npc,$___PRESET_ENEMY__VARS__active_obbs_range,$active_obbs_range;$findenemy_active_words=$___PRESET_ENEMY__VARS__findenemy_active_words;$active_obbs_pc=$___PRESET_ENEMY__VARS__active_obbs_pc;$active_obbs_npc=$___PRESET_ENEMY__VARS__active_obbs_npc;$active_obbs_range=$___PRESET_ENEMY__VARS__active_obbs_range;');
define('MOD_ENEMY_BATTLECMD','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/base\\enemy/battlecmd');
define('MODULE_ENEMY_GLOBALS_VARNAMES','findenemy_active_words,active_obbs_pc,active_obbs_npc,active_obbs_range');
define('MOD_ENEMY',1);
define('IMPORT_MODULE_ENEMY_GLOBALS','global $___LOCAL_ENEMY__VARS__findenemy_active_words,$___LOCAL_ENEMY__VARS__active_obbs_pc,$___LOCAL_ENEMY__VARS__active_obbs_npc,$___LOCAL_ENEMY__VARS__active_obbs_range; $findenemy_active_words=&$___LOCAL_ENEMY__VARS__findenemy_active_words; $active_obbs_pc=&$___LOCAL_ENEMY__VARS__active_obbs_pc; $active_obbs_npc=&$___LOCAL_ENEMY__VARS__active_obbs_npc; $active_obbs_range=&$___LOCAL_ENEMY__VARS__active_obbs_range; ');
define('PREFIX_MODULE_ENEMY_GLOBALS','\'; global $___LOCAL_ENEMY__VARS__findenemy_active_words; ${$___TEMP_PREFIX.\'findenemy_active_words\'}=&$___LOCAL_ENEMY__VARS__findenemy_active_words; global $___LOCAL_ENEMY__VARS__active_obbs_pc; ${$___TEMP_PREFIX.\'active_obbs_pc\'}=&$___LOCAL_ENEMY__VARS__active_obbs_pc; global $___LOCAL_ENEMY__VARS__active_obbs_npc; ${$___TEMP_PREFIX.\'active_obbs_npc\'}=&$___LOCAL_ENEMY__VARS__active_obbs_npc; global $___LOCAL_ENEMY__VARS__active_obbs_range; ${$___TEMP_PREFIX.\'active_obbs_range\'}=&$___LOCAL_ENEMY__VARS__active_obbs_range; unset($___TEMP_PREFIX); ');
define('MODULE_ENEMY_GLOBALS','\'; global $___LOCAL_ENEMY__VARS__findenemy_active_words; ${$___TEMP_VARNAME}[\'findenemy_active_words\']=&$___LOCAL_ENEMY__VARS__findenemy_active_words; global $___LOCAL_ENEMY__VARS__active_obbs_pc; ${$___TEMP_VARNAME}[\'active_obbs_pc\']=&$___LOCAL_ENEMY__VARS__active_obbs_pc; global $___LOCAL_ENEMY__VARS__active_obbs_npc; ${$___TEMP_VARNAME}[\'active_obbs_npc\']=&$___LOCAL_ENEMY__VARS__active_obbs_npc; global $___LOCAL_ENEMY__VARS__active_obbs_range; ${$___TEMP_VARNAME}[\'active_obbs_range\']=&$___LOCAL_ENEMY__VARS__active_obbs_range; unset($___TEMP_VARNAME); ');

global $___PRIVATE_ENEMY__VARS_____PRIVATE_PFUNC,$___PRIVATE_ENEMY__VARS_____PRIVATE_CFUNC,$___LOCAL_ENEMY__VARS__findenemy_active_words,$___LOCAL_ENEMY__VARS__active_obbs_pc,$___LOCAL_ENEMY__VARS__active_obbs_npc,$___LOCAL_ENEMY__VARS__active_obbs_range;
$___PRIVATE_ENEMY__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_ENEMY__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_ENEMY__VARS__findenemy_active_words=&$findenemy_active_words;$___LOCAL_ENEMY__VARS__active_obbs_pc=&$active_obbs_pc;$___LOCAL_ENEMY__VARS__active_obbs_npc=&$active_obbs_npc;$___LOCAL_ENEMY__VARS__active_obbs_range=&$active_obbs_range;
unset($findenemy_active_words,$active_obbs_pc,$active_obbs_npc,$active_obbs_range);
hook_register('enemy','findenemy');hook_register('enemy','get_battlecmd_filename');hook_register('enemy','calculate_active_obbs');hook_register('enemy','calculate_active_obbs_multiplier');hook_register('enemy','calculate_active_obbs_change');hook_register('enemy','get_final_active_obbs');hook_register('enemy','check_enemy_meet_active');hook_register('enemy','meetman_alternative');hook_register('enemy','battle_wrapper');hook_register('enemy','post_act');hook_register('enemy','act');
function ___post_init() { global $___PRIVATE_ENEMY__VARS_____PRIVATE_PFUNC,$___PRIVATE_ENEMY__VARS_____PRIVATE_CFUNC,$___LOCAL_ENEMY__VARS__findenemy_active_words,$___LOCAL_ENEMY__VARS__active_obbs_pc,$___LOCAL_ENEMY__VARS__active_obbs_npc,$___LOCAL_ENEMY__VARS__active_obbs_range;
$___LOCAL_ENEMY__VARS__findenemy_active_words=$GLOBALS['findenemy_active_words'];$___LOCAL_ENEMY__VARS__active_obbs_pc=$GLOBALS['active_obbs_pc'];$___LOCAL_ENEMY__VARS__active_obbs_npc=$GLOBALS['active_obbs_npc'];$___LOCAL_ENEMY__VARS__active_obbs_range=$GLOBALS['active_obbs_range'];
unset($GLOBALS['findenemy_active_words'],$GLOBALS['active_obbs_pc'],$GLOBALS['active_obbs_npc'],$GLOBALS['active_obbs_range']);
}
	
}

?>