<?php

namespace skill1013
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/gmskills/skill1013/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL1013_PRESET_VARS','');
define('___LOAD_MOD_SKILL1013_PRESET_VARS','');
define('MOD_SKILL1013_INFO','active;unique;');
define('MOD_SKILL1013_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\gmskills\\skill1013/desc');
define('MOD_SKILL1013_PROFILECMD','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\gmskills\\skill1013/profilecmd');
define('MOD_SKILL1013_SUB_PAGE','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\gmskills\\skill1013/sub_page');
define('MODULE_SKILL1013_GLOBALS_VARNAMES','');
define('MOD_SKILL1013',1);
define('IMPORT_MODULE_SKILL1013_GLOBALS','');
define('PREFIX_MODULE_SKILL1013_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL1013_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL1013__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL1013__VARS_____PRIVATE_CFUNC;
$___PRIVATE_SKILL1013__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL1013__VARS_____PRIVATE_CFUNC=Array();

hook_register('skill1013','acquire1013');hook_register('skill1013','lost1013');hook_register('skill1013','check_unlocked1013');hook_register('skill1013','skill1013_sub_page');hook_register('skill1013','skill1013_acquire_skill');hook_register('skill1013','act');hook_register('skill1013','parse_news');
function ___post_init() { global $___PRIVATE_SKILL1013__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL1013__VARS_____PRIVATE_CFUNC;


}
	
}

?>