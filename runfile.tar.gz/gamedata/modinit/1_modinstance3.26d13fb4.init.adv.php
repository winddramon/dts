<?php

namespace instance3
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/instance/instance3_ascension/'.$___TEMP_key; 
	
	$___PRESET_INSTANCE3__VARS__npcinfo_instance3=$npcinfo_instance3;
function ___pre_init() { global $___PRESET_INSTANCE3__VARS__npcinfo_instance3,$npcinfo_instance3;$npcinfo_instance3=$___PRESET_INSTANCE3__VARS__npcinfo_instance3; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_INSTANCE3_PRESET_VARS','$___PRESET_INSTANCE3__VARS__npcinfo_instance3=$npcinfo_instance3;');
define('___LOAD_MOD_INSTANCE3_PRESET_VARS','global $___PRESET_INSTANCE3__VARS__npcinfo_instance3,$npcinfo_instance3;$npcinfo_instance3=$___PRESET_INSTANCE3__VARS__npcinfo_instance3;');
define('MODULE_INSTANCE3_GLOBALS_VARNAMES','npcinfo_instance3');
define('MOD_INSTANCE3',1);
define('IMPORT_MODULE_INSTANCE3_GLOBALS','global $___LOCAL_INSTANCE3__VARS__npcinfo_instance3; $npcinfo_instance3=&$___LOCAL_INSTANCE3__VARS__npcinfo_instance3; ');
define('PREFIX_MODULE_INSTANCE3_GLOBALS','\'; global $___LOCAL_INSTANCE3__VARS__npcinfo_instance3; ${$___TEMP_PREFIX.\'npcinfo_instance3\'}=&$___LOCAL_INSTANCE3__VARS__npcinfo_instance3; unset($___TEMP_PREFIX); ');
define('MODULE_INSTANCE3_GLOBALS','\'; global $___LOCAL_INSTANCE3__VARS__npcinfo_instance3; ${$___TEMP_VARNAME}[\'npcinfo_instance3\']=&$___LOCAL_INSTANCE3__VARS__npcinfo_instance3; unset($___TEMP_VARNAME); ');

global $___PRIVATE_INSTANCE3__VARS_____PRIVATE_PFUNC,$___PRIVATE_INSTANCE3__VARS_____PRIVATE_CFUNC,$___LOCAL_INSTANCE3__VARS__npcinfo_instance3;
$___PRIVATE_INSTANCE3__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_INSTANCE3__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_INSTANCE3__VARS__npcinfo_instance3=&$npcinfo_instance3;
unset($npcinfo_instance3);
hook_register('instance3','get_shopconfig');hook_register('instance3','get_itemfilecont');hook_register('instance3','get_npclist');hook_register('instance3','checkcombo');hook_register('instance3','rs_game');hook_register('instance3','rs_areatime');hook_register('instance3','check_addarea_gameover');hook_register('instance3','gameover');hook_register('instance3','init_enter_battlefield_items');hook_register('instance3','get_enter_battlefield_card');hook_register('instance3','enter_battlefield_cardproc');hook_register('instance3','instance3_add_skills');hook_register('instance3','post_enterbattlefield_events');hook_register('instance3','itemuse');hook_register('instance3','search_area');hook_register('instance3','kill');hook_register('instance3','event_core');hook_register('instance3','parse_news');hook_register('instance3','instance3_calc_qiegao_prize');hook_register('instance3','post_winnercheck_events');hook_register('instance3','init_battle');hook_register('instance3','npcchat_get_chatlog');
function ___post_init() { global $___PRIVATE_INSTANCE3__VARS_____PRIVATE_PFUNC,$___PRIVATE_INSTANCE3__VARS_____PRIVATE_CFUNC,$___LOCAL_INSTANCE3__VARS__npcinfo_instance3;
$___LOCAL_INSTANCE3__VARS__npcinfo_instance3=$GLOBALS['npcinfo_instance3'];
unset($GLOBALS['npcinfo_instance3']);
}
	
}

?>