<?php

namespace skill2
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'base/skills/skill2/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL2_PRESET_VARS','');
define('___LOAD_MOD_SKILL2_PRESET_VARS','');
define('MODULE_SKILL2_GLOBALS_VARNAMES','');
define('MOD_SKILL2',1);
define('IMPORT_MODULE_SKILL2_GLOBALS','');
define('PREFIX_MODULE_SKILL2_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL2_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL2__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL2__VARS_____PRIVATE_CFUNC;
$___PRIVATE_SKILL2__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL2__VARS_____PRIVATE_CFUNC=Array();

hook_register('skill2','acquire2');hook_register('skill2','lost2');hook_register('skill2','skill_onload_event');hook_register('skill2','skill_onsave_event');hook_register('skill2','get_hitrate_multiplier');
function ___post_init() { global $___PRIVATE_SKILL2__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL2__VARS_____PRIVATE_CFUNC;


}
	
}

?>