<?php

namespace gtype2
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/instance/gtype2/main/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_GTYPE2_PRESET_VARS','');
define('___LOAD_MOD_GTYPE2_PRESET_VARS','');
define('MODULE_GTYPE2_GLOBALS_VARNAMES','');
define('MOD_GTYPE2',1);
define('IMPORT_MODULE_GTYPE2_GLOBALS','');
define('PREFIX_MODULE_GTYPE2_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_GTYPE2_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_GTYPE2__VARS_____PRIVATE_PFUNC,$___PRIVATE_GTYPE2__VARS_____PRIVATE_CFUNC;
$___PRIVATE_GTYPE2__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_GTYPE2__VARS_____PRIVATE_CFUNC=Array();

hook_register('gtype2','prepare_new_game');hook_register('gtype2','check_player_discover');hook_register('gtype2','checkcombo');hook_register('gtype2','rs_game');hook_register('gtype2','itemuse');hook_register('gtype2','check_initnpcadd');hook_register('gtype2','get_shopconfig');hook_register('gtype2','post_enterbattlefield_events');hook_register('gtype2','check_addarea_gameover');hook_register('gtype2','parse_news');
function ___post_init() { global $___PRIVATE_GTYPE2__VARS_____PRIVATE_PFUNC,$___PRIVATE_GTYPE2__VARS_____PRIVATE_CFUNC;


}
	
}

?>