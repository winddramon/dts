<?php

namespace instance5
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/instance/instance5/'.$___TEMP_key; 
	
	$___PRESET_INSTANCE5__VARS__npcinfo_instance5=$npcinfo_instance5;
function ___pre_init() { global $___PRESET_INSTANCE5__VARS__npcinfo_instance5,$npcinfo_instance5;$npcinfo_instance5=$___PRESET_INSTANCE5__VARS__npcinfo_instance5; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_INSTANCE5_PRESET_VARS','$___PRESET_INSTANCE5__VARS__npcinfo_instance5=$npcinfo_instance5;');
define('___LOAD_MOD_INSTANCE5_PRESET_VARS','global $___PRESET_INSTANCE5__VARS__npcinfo_instance5,$npcinfo_instance5;$npcinfo_instance5=$___PRESET_INSTANCE5__VARS__npcinfo_instance5;');
define('MODULE_INSTANCE5_GLOBALS_VARNAMES','npcinfo_instance5');
define('MOD_INSTANCE5',1);
define('IMPORT_MODULE_INSTANCE5_GLOBALS','global $___LOCAL_INSTANCE5__VARS__npcinfo_instance5; $npcinfo_instance5=&$___LOCAL_INSTANCE5__VARS__npcinfo_instance5; ');
define('PREFIX_MODULE_INSTANCE5_GLOBALS','\'; global $___LOCAL_INSTANCE5__VARS__npcinfo_instance5; ${$___TEMP_PREFIX.\'npcinfo_instance5\'}=&$___LOCAL_INSTANCE5__VARS__npcinfo_instance5; unset($___TEMP_PREFIX); ');
define('MODULE_INSTANCE5_GLOBALS','\'; global $___LOCAL_INSTANCE5__VARS__npcinfo_instance5; ${$___TEMP_VARNAME}[\'npcinfo_instance5\']=&$___LOCAL_INSTANCE5__VARS__npcinfo_instance5; unset($___TEMP_VARNAME); ');

global $___PRIVATE_INSTANCE5__VARS_____PRIVATE_PFUNC,$___PRIVATE_INSTANCE5__VARS_____PRIVATE_CFUNC,$___LOCAL_INSTANCE5__VARS__npcinfo_instance5;
$___PRIVATE_INSTANCE5__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_INSTANCE5__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_INSTANCE5__VARS__npcinfo_instance5=&$npcinfo_instance5;
unset($npcinfo_instance5);
hook_register('instance5','get_shopconfig');hook_register('instance5','get_npclist');hook_register('instance5','checkcombo');hook_register('instance5','rs_game');hook_register('instance5','rs_areatime');hook_register('instance5','check_addarea_gameover');hook_register('instance5','itemuse');hook_register('instance5','get_club_choice_array');hook_register('instance5','parse_itmuse_desc');hook_register('instance5','parse_news');
function ___post_init() { global $___PRIVATE_INSTANCE5__VARS_____PRIVATE_PFUNC,$___PRIVATE_INSTANCE5__VARS_____PRIVATE_CFUNC,$___LOCAL_INSTANCE5__VARS__npcinfo_instance5;
$___LOCAL_INSTANCE5__VARS__npcinfo_instance5=$GLOBALS['npcinfo_instance5'];
unset($GLOBALS['npcinfo_instance5']);
}
	
}

?>