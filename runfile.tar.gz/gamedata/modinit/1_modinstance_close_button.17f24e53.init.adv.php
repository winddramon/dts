<?php

namespace instance_close_button
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/instance/instance_close_button/'.$___TEMP_key; 
	
	$___PRESET_INSTANCE_CLOSE_BUTTON__VARS__gametype_allow_close_button=$gametype_allow_close_button;
function ___pre_init() { global $___PRESET_INSTANCE_CLOSE_BUTTON__VARS__gametype_allow_close_button,$gametype_allow_close_button;$gametype_allow_close_button=$___PRESET_INSTANCE_CLOSE_BUTTON__VARS__gametype_allow_close_button; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_INSTANCE_CLOSE_BUTTON_PRESET_VARS','$___PRESET_INSTANCE_CLOSE_BUTTON__VARS__gametype_allow_close_button=$gametype_allow_close_button;');
define('___LOAD_MOD_INSTANCE_CLOSE_BUTTON_PRESET_VARS','global $___PRESET_INSTANCE_CLOSE_BUTTON__VARS__gametype_allow_close_button,$gametype_allow_close_button;$gametype_allow_close_button=$___PRESET_INSTANCE_CLOSE_BUTTON__VARS__gametype_allow_close_button;');
define('MOD_INSTANCE_CLOSE_BUTTON_INSTANCE_CLOSE_BUTTON','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\instance\\instance_close_button/instance_close_button');
define('MODULE_INSTANCE_CLOSE_BUTTON_GLOBALS_VARNAMES','gametype_allow_close_button');
define('MOD_INSTANCE_CLOSE_BUTTON',1);
define('IMPORT_MODULE_INSTANCE_CLOSE_BUTTON_GLOBALS','global $___LOCAL_INSTANCE_CLOSE_BUTTON__VARS__gametype_allow_close_button; $gametype_allow_close_button=&$___LOCAL_INSTANCE_CLOSE_BUTTON__VARS__gametype_allow_close_button; ');
define('PREFIX_MODULE_INSTANCE_CLOSE_BUTTON_GLOBALS','\'; global $___LOCAL_INSTANCE_CLOSE_BUTTON__VARS__gametype_allow_close_button; ${$___TEMP_PREFIX.\'gametype_allow_close_button\'}=&$___LOCAL_INSTANCE_CLOSE_BUTTON__VARS__gametype_allow_close_button; unset($___TEMP_PREFIX); ');
define('MODULE_INSTANCE_CLOSE_BUTTON_GLOBALS','\'; global $___LOCAL_INSTANCE_CLOSE_BUTTON__VARS__gametype_allow_close_button; ${$___TEMP_VARNAME}[\'gametype_allow_close_button\']=&$___LOCAL_INSTANCE_CLOSE_BUTTON__VARS__gametype_allow_close_button; unset($___TEMP_VARNAME); ');

global $___PRIVATE_INSTANCE_CLOSE_BUTTON__VARS_____PRIVATE_PFUNC,$___PRIVATE_INSTANCE_CLOSE_BUTTON__VARS_____PRIVATE_CFUNC,$___LOCAL_INSTANCE_CLOSE_BUTTON__VARS__gametype_allow_close_button;
$___PRIVATE_INSTANCE_CLOSE_BUTTON__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_INSTANCE_CLOSE_BUTTON__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_INSTANCE_CLOSE_BUTTON__VARS__gametype_allow_close_button=&$gametype_allow_close_button;
unset($gametype_allow_close_button);
hook_register('instance_close_button','check_instance_close_available');hook_register('instance_close_button','instance_close');hook_register('instance_close_button','pre_act');hook_register('instance_close_button','parse_news');
function ___post_init() { global $___PRIVATE_INSTANCE_CLOSE_BUTTON__VARS_____PRIVATE_PFUNC,$___PRIVATE_INSTANCE_CLOSE_BUTTON__VARS_____PRIVATE_CFUNC,$___LOCAL_INSTANCE_CLOSE_BUTTON__VARS__gametype_allow_close_button;
$___LOCAL_INSTANCE_CLOSE_BUTTON__VARS__gametype_allow_close_button=$GLOBALS['gametype_allow_close_button'];
unset($GLOBALS['gametype_allow_close_button']);
}
	
}

?>