<?php

namespace skill111
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill111/'.$___TEMP_key; 
	
	$___PRESET_SKILL111__VARS__skill111_tempskill_time=$skill111_tempskill_time;
function ___pre_init() { global $___PRESET_SKILL111__VARS__skill111_tempskill_time,$skill111_tempskill_time;$skill111_tempskill_time=$___PRESET_SKILL111__VARS__skill111_tempskill_time; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL111_PRESET_VARS','$___PRESET_SKILL111__VARS__skill111_tempskill_time=$skill111_tempskill_time;');
define('___LOAD_MOD_SKILL111_PRESET_VARS','global $___PRESET_SKILL111__VARS__skill111_tempskill_time,$skill111_tempskill_time;$skill111_tempskill_time=$___PRESET_SKILL111__VARS__skill111_tempskill_time;');
define('MOD_SKILL111_INFO','club;locked;');
define('MOD_SKILL111_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill111/desc');
define('MODULE_SKILL111_GLOBALS_VARNAMES','skill111_tempskill_time');
define('MOD_SKILL111',1);
define('IMPORT_MODULE_SKILL111_GLOBALS','global $___LOCAL_SKILL111__VARS__skill111_tempskill_time; $skill111_tempskill_time=&$___LOCAL_SKILL111__VARS__skill111_tempskill_time; ');
define('PREFIX_MODULE_SKILL111_GLOBALS','\'; global $___LOCAL_SKILL111__VARS__skill111_tempskill_time; ${$___TEMP_PREFIX.\'skill111_tempskill_time\'}=&$___LOCAL_SKILL111__VARS__skill111_tempskill_time; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL111_GLOBALS','\'; global $___LOCAL_SKILL111__VARS__skill111_tempskill_time; ${$___TEMP_VARNAME}[\'skill111_tempskill_time\']=&$___LOCAL_SKILL111__VARS__skill111_tempskill_time; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL111__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL111__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL111__VARS__skill111_tempskill_time;
$___PRIVATE_SKILL111__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL111__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_SKILL111__VARS__skill111_tempskill_time=&$skill111_tempskill_time;
unset($skill111_tempskill_time);
hook_register('skill111','acquire111');hook_register('skill111','lost111');hook_register('skill111','check_unlocked111');hook_register('skill111','rest');
function ___post_init() { global $___PRIVATE_SKILL111__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL111__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL111__VARS__skill111_tempskill_time;
$___LOCAL_SKILL111__VARS__skill111_tempskill_time=$GLOBALS['skill111_tempskill_time'];
unset($GLOBALS['skill111_tempskill_time']);
}
	
}

?>