<?php

namespace skill107
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill107/'.$___TEMP_key; 
	
	$___PRESET_SKILL107__VARS__skill107_actrate=$skill107_actrate;$___PRESET_SKILL107__VARS__upgradecost=$upgradecost;
function ___pre_init() { global $___PRESET_SKILL107__VARS__skill107_actrate,$skill107_actrate,$___PRESET_SKILL107__VARS__upgradecost,$upgradecost;$skill107_actrate=$___PRESET_SKILL107__VARS__skill107_actrate;$upgradecost=$___PRESET_SKILL107__VARS__upgradecost; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL107_PRESET_VARS','$___PRESET_SKILL107__VARS__skill107_actrate=$skill107_actrate;$___PRESET_SKILL107__VARS__upgradecost=$upgradecost;');
define('___LOAD_MOD_SKILL107_PRESET_VARS','global $___PRESET_SKILL107__VARS__skill107_actrate,$skill107_actrate,$___PRESET_SKILL107__VARS__upgradecost,$upgradecost;$skill107_actrate=$___PRESET_SKILL107__VARS__skill107_actrate;$upgradecost=$___PRESET_SKILL107__VARS__upgradecost;');
define('MOD_SKILL107_INFO','club;upgrade;feature;');
define('MOD_SKILL107_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill107/desc');
define('MODULE_SKILL107_GLOBALS_VARNAMES','skill107_actrate,upgradecost');
define('MOD_SKILL107',1);
define('IMPORT_MODULE_SKILL107_GLOBALS','global $___LOCAL_SKILL107__VARS__skill107_actrate,$___LOCAL_SKILL107__VARS__upgradecost; $skill107_actrate=&$___LOCAL_SKILL107__VARS__skill107_actrate; $upgradecost=&$___LOCAL_SKILL107__VARS__upgradecost; ');
define('PREFIX_MODULE_SKILL107_GLOBALS','\'; global $___LOCAL_SKILL107__VARS__skill107_actrate; ${$___TEMP_PREFIX.\'skill107_actrate\'}=&$___LOCAL_SKILL107__VARS__skill107_actrate; global $___LOCAL_SKILL107__VARS__upgradecost; ${$___TEMP_PREFIX.\'upgradecost\'}=&$___LOCAL_SKILL107__VARS__upgradecost; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL107_GLOBALS','\'; global $___LOCAL_SKILL107__VARS__skill107_actrate; ${$___TEMP_VARNAME}[\'skill107_actrate\']=&$___LOCAL_SKILL107__VARS__skill107_actrate; global $___LOCAL_SKILL107__VARS__upgradecost; ${$___TEMP_VARNAME}[\'upgradecost\']=&$___LOCAL_SKILL107__VARS__upgradecost; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL107__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL107__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL107__VARS__skill107_actrate,$___LOCAL_SKILL107__VARS__upgradecost;
$___PRIVATE_SKILL107__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL107__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_SKILL107__VARS__skill107_actrate=&$skill107_actrate;$___LOCAL_SKILL107__VARS__upgradecost=&$upgradecost;
unset($skill107_actrate,$upgradecost);
hook_register('skill107','acquire107');hook_register('skill107','lost107');hook_register('skill107','check_unlocked107');hook_register('skill107','upgrade107');hook_register('skill107','skill107_lose_sanity');hook_register('skill107','skill107_get_randskill');
function ___post_init() { global $___PRIVATE_SKILL107__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL107__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL107__VARS__skill107_actrate,$___LOCAL_SKILL107__VARS__upgradecost;
$___LOCAL_SKILL107__VARS__skill107_actrate=$GLOBALS['skill107_actrate'];$___LOCAL_SKILL107__VARS__upgradecost=$GLOBALS['upgradecost'];
unset($GLOBALS['skill107_actrate'],$GLOBALS['upgradecost']);
}
	
}

?>