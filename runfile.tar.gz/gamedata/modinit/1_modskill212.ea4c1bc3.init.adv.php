<?php

namespace skill212
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill212/'.$___TEMP_key; 
	
	$___PRESET_SKILL212__VARS__evgain=$evgain;$___PRESET_SKILL212__VARS__reugain=$reugain;$___PRESET_SKILL212__VARS__upgradecost=$upgradecost;
function ___pre_init() { global $___PRESET_SKILL212__VARS__evgain,$evgain,$___PRESET_SKILL212__VARS__reugain,$reugain,$___PRESET_SKILL212__VARS__upgradecost,$upgradecost;$evgain=$___PRESET_SKILL212__VARS__evgain;$reugain=$___PRESET_SKILL212__VARS__reugain;$upgradecost=$___PRESET_SKILL212__VARS__upgradecost; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL212_PRESET_VARS','$___PRESET_SKILL212__VARS__evgain=$evgain;$___PRESET_SKILL212__VARS__reugain=$reugain;$___PRESET_SKILL212__VARS__upgradecost=$upgradecost;');
define('___LOAD_MOD_SKILL212_PRESET_VARS','global $___PRESET_SKILL212__VARS__evgain,$evgain,$___PRESET_SKILL212__VARS__reugain,$reugain,$___PRESET_SKILL212__VARS__upgradecost,$upgradecost;$evgain=$___PRESET_SKILL212__VARS__evgain;$reugain=$___PRESET_SKILL212__VARS__reugain;$upgradecost=$___PRESET_SKILL212__VARS__upgradecost;');
define('MOD_SKILL212_INFO','club;upgrade;');
define('MOD_SKILL212_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill212/desc');
define('MODULE_SKILL212_GLOBALS_VARNAMES','evgain,reugain,upgradecost');
define('MOD_SKILL212',1);
define('IMPORT_MODULE_SKILL212_GLOBALS','global $___LOCAL_SKILL212__VARS__evgain,$___LOCAL_SKILL212__VARS__reugain,$___LOCAL_SKILL212__VARS__upgradecost; $evgain=&$___LOCAL_SKILL212__VARS__evgain; $reugain=&$___LOCAL_SKILL212__VARS__reugain; $upgradecost=&$___LOCAL_SKILL212__VARS__upgradecost; ');
define('PREFIX_MODULE_SKILL212_GLOBALS','\'; global $___LOCAL_SKILL212__VARS__evgain; ${$___TEMP_PREFIX.\'evgain\'}=&$___LOCAL_SKILL212__VARS__evgain; global $___LOCAL_SKILL212__VARS__reugain; ${$___TEMP_PREFIX.\'reugain\'}=&$___LOCAL_SKILL212__VARS__reugain; global $___LOCAL_SKILL212__VARS__upgradecost; ${$___TEMP_PREFIX.\'upgradecost\'}=&$___LOCAL_SKILL212__VARS__upgradecost; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL212_GLOBALS','\'; global $___LOCAL_SKILL212__VARS__evgain; ${$___TEMP_VARNAME}[\'evgain\']=&$___LOCAL_SKILL212__VARS__evgain; global $___LOCAL_SKILL212__VARS__reugain; ${$___TEMP_VARNAME}[\'reugain\']=&$___LOCAL_SKILL212__VARS__reugain; global $___LOCAL_SKILL212__VARS__upgradecost; ${$___TEMP_VARNAME}[\'upgradecost\']=&$___LOCAL_SKILL212__VARS__upgradecost; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL212__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL212__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL212__VARS__evgain,$___LOCAL_SKILL212__VARS__reugain,$___LOCAL_SKILL212__VARS__upgradecost;
$___PRIVATE_SKILL212__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL212__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_SKILL212__VARS__evgain=&$evgain;$___LOCAL_SKILL212__VARS__reugain=&$reugain;$___LOCAL_SKILL212__VARS__upgradecost=&$upgradecost;
unset($evgain,$reugain,$upgradecost);
hook_register('skill212','acquire212');hook_register('skill212','lost212');hook_register('skill212','check_unlocked212');hook_register('skill212','upgrade212');hook_register('skill212','get_skill212_extra_ev_gain');hook_register('skill212','get_skill212_extra_reuse_gain');hook_register('skill212','get_trap_escape_rate');hook_register('skill212','calculate_trap_reuse_rate');
function ___post_init() { global $___PRIVATE_SKILL212__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL212__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL212__VARS__evgain,$___LOCAL_SKILL212__VARS__reugain,$___LOCAL_SKILL212__VARS__upgradecost;
$___LOCAL_SKILL212__VARS__evgain=$GLOBALS['evgain'];$___LOCAL_SKILL212__VARS__reugain=$GLOBALS['reugain'];$___LOCAL_SKILL212__VARS__upgradecost=$GLOBALS['upgradecost'];
unset($GLOBALS['evgain'],$GLOBALS['reugain'],$GLOBALS['upgradecost']);
}
	
}

?>