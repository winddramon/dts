<?php

namespace itemshop
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'base/itemshop/'.$___TEMP_key; 
	
	$___PRESET_ITEMSHOP__VARS__shops=$shops;$___PRESET_ITEMSHOP__VARS__shop_tag_list=$shop_tag_list;$___PRESET_ITEMSHOP__VARS__shop_allow_input_num=$shop_allow_input_num;
function ___pre_init() { global $___PRESET_ITEMSHOP__VARS__shops,$shops,$___PRESET_ITEMSHOP__VARS__shop_tag_list,$shop_tag_list,$___PRESET_ITEMSHOP__VARS__shop_allow_input_num,$shop_allow_input_num;$shops=$___PRESET_ITEMSHOP__VARS__shops;$shop_tag_list=$___PRESET_ITEMSHOP__VARS__shop_tag_list;$shop_allow_input_num=$___PRESET_ITEMSHOP__VARS__shop_allow_input_num; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_ITEMSHOP_PRESET_VARS','$___PRESET_ITEMSHOP__VARS__shops=$shops;$___PRESET_ITEMSHOP__VARS__shop_tag_list=$shop_tag_list;$___PRESET_ITEMSHOP__VARS__shop_allow_input_num=$shop_allow_input_num;');
define('___LOAD_MOD_ITEMSHOP_PRESET_VARS','global $___PRESET_ITEMSHOP__VARS__shops,$shops,$___PRESET_ITEMSHOP__VARS__shop_tag_list,$shop_tag_list,$___PRESET_ITEMSHOP__VARS__shop_allow_input_num,$shop_allow_input_num;$shops=$___PRESET_ITEMSHOP__VARS__shops;$shop_tag_list=$___PRESET_ITEMSHOP__VARS__shop_tag_list;$shop_allow_input_num=$___PRESET_ITEMSHOP__VARS__shop_allow_input_num;');
define('MOD_ITEMSHOP_SP_SHOP','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/base\\itemshop/sp_shop');
define('MOD_ITEMSHOP_SHOP','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/base\\itemshop/shop');
define('MOD_ITEMSHOP_ITEMSHOP_CMD','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/base\\itemshop/itemshop_cmd');
define('MODULE_ITEMSHOP_GLOBALS_VARNAMES','shops,shop_tag_list,shop_allow_input_num');
define('MOD_ITEMSHOP',1);
define('IMPORT_MODULE_ITEMSHOP_GLOBALS','global $___LOCAL_ITEMSHOP__VARS__shops,$___LOCAL_ITEMSHOP__VARS__shop_tag_list,$___LOCAL_ITEMSHOP__VARS__shop_allow_input_num; $shops=&$___LOCAL_ITEMSHOP__VARS__shops; $shop_tag_list=&$___LOCAL_ITEMSHOP__VARS__shop_tag_list; $shop_allow_input_num=&$___LOCAL_ITEMSHOP__VARS__shop_allow_input_num; ');
define('PREFIX_MODULE_ITEMSHOP_GLOBALS','\'; global $___LOCAL_ITEMSHOP__VARS__shops; ${$___TEMP_PREFIX.\'shops\'}=&$___LOCAL_ITEMSHOP__VARS__shops; global $___LOCAL_ITEMSHOP__VARS__shop_tag_list; ${$___TEMP_PREFIX.\'shop_tag_list\'}=&$___LOCAL_ITEMSHOP__VARS__shop_tag_list; global $___LOCAL_ITEMSHOP__VARS__shop_allow_input_num; ${$___TEMP_PREFIX.\'shop_allow_input_num\'}=&$___LOCAL_ITEMSHOP__VARS__shop_allow_input_num; unset($___TEMP_PREFIX); ');
define('MODULE_ITEMSHOP_GLOBALS','\'; global $___LOCAL_ITEMSHOP__VARS__shops; ${$___TEMP_VARNAME}[\'shops\']=&$___LOCAL_ITEMSHOP__VARS__shops; global $___LOCAL_ITEMSHOP__VARS__shop_tag_list; ${$___TEMP_VARNAME}[\'shop_tag_list\']=&$___LOCAL_ITEMSHOP__VARS__shop_tag_list; global $___LOCAL_ITEMSHOP__VARS__shop_allow_input_num; ${$___TEMP_VARNAME}[\'shop_allow_input_num\']=&$___LOCAL_ITEMSHOP__VARS__shop_allow_input_num; unset($___TEMP_VARNAME); ');

global $___PRIVATE_ITEMSHOP__VARS_____PRIVATE_PFUNC,$___PRIVATE_ITEMSHOP__VARS_____PRIVATE_CFUNC,$___LOCAL_ITEMSHOP__VARS__shops,$___LOCAL_ITEMSHOP__VARS__shop_tag_list,$___LOCAL_ITEMSHOP__VARS__shop_allow_input_num;
$___PRIVATE_ITEMSHOP__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_ITEMSHOP__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_ITEMSHOP__VARS__shops=&$shops;$___LOCAL_ITEMSHOP__VARS__shop_tag_list=&$shop_tag_list;$___LOCAL_ITEMSHOP__VARS__shop_allow_input_num=&$shop_allow_input_num;
unset($shops,$shop_tag_list,$shop_allow_input_num);
hook_register('itemshop','get_shopconfig');hook_register('itemshop','get_shopitem_list_by_kind');hook_register('itemshop','shopitem_row_data_seperate');hook_register('itemshop','get_shopitem_list');hook_register('itemshop','rs_game');hook_register('itemshop','shopitem_row_data_process');hook_register('itemshop','prepare_shopitem');hook_register('itemshop','shoplist');hook_register('itemshop','get_itemshop_filename');hook_register('itemshop','get_sp_shop_filename');hook_register('itemshop','get_shopiteminfo');hook_register('itemshop','calculate_shop_itembuy_cost');hook_register('itemshop','get_shop_tag_list');hook_register('itemshop','itembuy');hook_register('itemshop','check_in_shop_area');hook_register('itemshop','act');hook_register('itemshop','parse_news');
function ___post_init() { global $___PRIVATE_ITEMSHOP__VARS_____PRIVATE_PFUNC,$___PRIVATE_ITEMSHOP__VARS_____PRIVATE_CFUNC,$___LOCAL_ITEMSHOP__VARS__shops,$___LOCAL_ITEMSHOP__VARS__shop_tag_list,$___LOCAL_ITEMSHOP__VARS__shop_allow_input_num;
$___LOCAL_ITEMSHOP__VARS__shops=$GLOBALS['shops'];$___LOCAL_ITEMSHOP__VARS__shop_tag_list=$GLOBALS['shop_tag_list'];$___LOCAL_ITEMSHOP__VARS__shop_allow_input_num=$GLOBALS['shop_allow_input_num'];
unset($GLOBALS['shops'],$GLOBALS['shop_tag_list'],$GLOBALS['shop_allow_input_num']);
}
	
}

?>