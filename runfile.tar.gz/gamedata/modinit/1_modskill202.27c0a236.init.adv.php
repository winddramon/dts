<?php

namespace skill202
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill202/'.$___TEMP_key; 
	
	$___PRESET_SKILL202__VARS__infrgain=$infrgain;$___PRESET_SKILL202__VARS__exthit2=$exthit2;$___PRESET_SKILL202__VARS__extrdmg=$extrdmg;$___PRESET_SKILL202__VARS__upgradecost=$upgradecost;$___PRESET_SKILL202__VARS__upgradecount=$upgradecount;
function ___pre_init() { global $___PRESET_SKILL202__VARS__infrgain,$infrgain,$___PRESET_SKILL202__VARS__exthit2,$exthit2,$___PRESET_SKILL202__VARS__extrdmg,$extrdmg,$___PRESET_SKILL202__VARS__upgradecost,$upgradecost,$___PRESET_SKILL202__VARS__upgradecount,$upgradecount;$infrgain=$___PRESET_SKILL202__VARS__infrgain;$exthit2=$___PRESET_SKILL202__VARS__exthit2;$extrdmg=$___PRESET_SKILL202__VARS__extrdmg;$upgradecost=$___PRESET_SKILL202__VARS__upgradecost;$upgradecount=$___PRESET_SKILL202__VARS__upgradecount; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL202_PRESET_VARS','$___PRESET_SKILL202__VARS__infrgain=$infrgain;$___PRESET_SKILL202__VARS__exthit2=$exthit2;$___PRESET_SKILL202__VARS__extrdmg=$extrdmg;$___PRESET_SKILL202__VARS__upgradecost=$upgradecost;$___PRESET_SKILL202__VARS__upgradecount=$upgradecount;');
define('___LOAD_MOD_SKILL202_PRESET_VARS','global $___PRESET_SKILL202__VARS__infrgain,$infrgain,$___PRESET_SKILL202__VARS__exthit2,$exthit2,$___PRESET_SKILL202__VARS__extrdmg,$extrdmg,$___PRESET_SKILL202__VARS__upgradecost,$upgradecost,$___PRESET_SKILL202__VARS__upgradecount,$upgradecount;$infrgain=$___PRESET_SKILL202__VARS__infrgain;$exthit2=$___PRESET_SKILL202__VARS__exthit2;$extrdmg=$___PRESET_SKILL202__VARS__extrdmg;$upgradecost=$___PRESET_SKILL202__VARS__upgradecost;$upgradecount=$___PRESET_SKILL202__VARS__upgradecount;');
define('MOD_SKILL202_INFO','club;upgrade;');
define('MOD_SKILL202_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill202/desc');
define('MODULE_SKILL202_GLOBALS_VARNAMES','infrgain,exthit2,extrdmg,upgradecost,upgradecount');
define('MOD_SKILL202',1);
define('IMPORT_MODULE_SKILL202_GLOBALS','global $___LOCAL_SKILL202__VARS__infrgain,$___LOCAL_SKILL202__VARS__exthit2,$___LOCAL_SKILL202__VARS__extrdmg,$___LOCAL_SKILL202__VARS__upgradecost,$___LOCAL_SKILL202__VARS__upgradecount; $infrgain=&$___LOCAL_SKILL202__VARS__infrgain; $exthit2=&$___LOCAL_SKILL202__VARS__exthit2; $extrdmg=&$___LOCAL_SKILL202__VARS__extrdmg; $upgradecost=&$___LOCAL_SKILL202__VARS__upgradecost; $upgradecount=&$___LOCAL_SKILL202__VARS__upgradecount; ');
define('PREFIX_MODULE_SKILL202_GLOBALS','\'; global $___LOCAL_SKILL202__VARS__infrgain; ${$___TEMP_PREFIX.\'infrgain\'}=&$___LOCAL_SKILL202__VARS__infrgain; global $___LOCAL_SKILL202__VARS__exthit2; ${$___TEMP_PREFIX.\'exthit2\'}=&$___LOCAL_SKILL202__VARS__exthit2; global $___LOCAL_SKILL202__VARS__extrdmg; ${$___TEMP_PREFIX.\'extrdmg\'}=&$___LOCAL_SKILL202__VARS__extrdmg; global $___LOCAL_SKILL202__VARS__upgradecost; ${$___TEMP_PREFIX.\'upgradecost\'}=&$___LOCAL_SKILL202__VARS__upgradecost; global $___LOCAL_SKILL202__VARS__upgradecount; ${$___TEMP_PREFIX.\'upgradecount\'}=&$___LOCAL_SKILL202__VARS__upgradecount; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL202_GLOBALS','\'; global $___LOCAL_SKILL202__VARS__infrgain; ${$___TEMP_VARNAME}[\'infrgain\']=&$___LOCAL_SKILL202__VARS__infrgain; global $___LOCAL_SKILL202__VARS__exthit2; ${$___TEMP_VARNAME}[\'exthit2\']=&$___LOCAL_SKILL202__VARS__exthit2; global $___LOCAL_SKILL202__VARS__extrdmg; ${$___TEMP_VARNAME}[\'extrdmg\']=&$___LOCAL_SKILL202__VARS__extrdmg; global $___LOCAL_SKILL202__VARS__upgradecost; ${$___TEMP_VARNAME}[\'upgradecost\']=&$___LOCAL_SKILL202__VARS__upgradecost; global $___LOCAL_SKILL202__VARS__upgradecount; ${$___TEMP_VARNAME}[\'upgradecount\']=&$___LOCAL_SKILL202__VARS__upgradecount; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL202__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL202__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL202__VARS__infrgain,$___LOCAL_SKILL202__VARS__exthit2,$___LOCAL_SKILL202__VARS__extrdmg,$___LOCAL_SKILL202__VARS__upgradecost,$___LOCAL_SKILL202__VARS__upgradecount;
$___PRIVATE_SKILL202__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL202__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_SKILL202__VARS__infrgain=&$infrgain;$___LOCAL_SKILL202__VARS__exthit2=&$exthit2;$___LOCAL_SKILL202__VARS__extrdmg=&$extrdmg;$___LOCAL_SKILL202__VARS__upgradecost=&$upgradecost;$___LOCAL_SKILL202__VARS__upgradecount=&$upgradecount;
unset($infrgain,$exthit2,$extrdmg,$upgradecost,$upgradecount);
hook_register('skill202','acquire202');hook_register('skill202','lost202');hook_register('skill202','check_unlocked202');hook_register('skill202','upgrade202');hook_register('skill202','get_skill202_extra_inf_rate');hook_register('skill202','calculate_inf_rate');hook_register('skill202','get_skill202_extra_wounds');hook_register('skill202','calculate_weapon_wound_multiplier');hook_register('skill202','get_skill202_extra_dmgrate');hook_register('skill202','apply_weapon_wound_real');hook_register('skill202','strike_prepare');hook_register('skill202','get_final_dmg_multiplier');
function ___post_init() { global $___PRIVATE_SKILL202__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL202__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL202__VARS__infrgain,$___LOCAL_SKILL202__VARS__exthit2,$___LOCAL_SKILL202__VARS__extrdmg,$___LOCAL_SKILL202__VARS__upgradecost,$___LOCAL_SKILL202__VARS__upgradecount;
$___LOCAL_SKILL202__VARS__infrgain=$GLOBALS['infrgain'];$___LOCAL_SKILL202__VARS__exthit2=$GLOBALS['exthit2'];$___LOCAL_SKILL202__VARS__extrdmg=$GLOBALS['extrdmg'];$___LOCAL_SKILL202__VARS__upgradecost=$GLOBALS['upgradecost'];$___LOCAL_SKILL202__VARS__upgradecount=$GLOBALS['upgradecount'];
unset($GLOBALS['infrgain'],$GLOBALS['exthit2'],$GLOBALS['extrdmg'],$GLOBALS['upgradecost'],$GLOBALS['upgradecount']);
}
	
}

?>