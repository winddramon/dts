<?php

namespace skill11
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill11/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL11_PRESET_VARS','');
define('___LOAD_MOD_SKILL11_PRESET_VARS','');
define('MOD_SKILL11_INFO','club;upgrade;locked;');
define('MOD_SKILL11_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill11/desc');
define('MODULE_SKILL11_GLOBALS_VARNAMES','');
define('MOD_SKILL11',1);
define('IMPORT_MODULE_SKILL11_GLOBALS','');
define('PREFIX_MODULE_SKILL11_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL11_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL11__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL11__VARS_____PRIVATE_CFUNC;
$___PRIVATE_SKILL11__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL11__VARS_____PRIVATE_CFUNC=Array();

hook_register('skill11','acquire11');hook_register('skill11','lost11');hook_register('skill11','check_unlocked11');hook_register('skill11','upgrade11');
function ___post_init() { global $___PRIVATE_SKILL11__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL11__VARS_____PRIVATE_CFUNC;


}
	
}

?>