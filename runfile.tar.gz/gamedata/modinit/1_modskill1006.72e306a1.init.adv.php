<?php

namespace skill1006
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill1006/'.$___TEMP_key; 
	
	$___PRESET_SKILL1006__VARS__beacon_pool=$beacon_pool;
function ___pre_init() { global $___PRESET_SKILL1006__VARS__beacon_pool,$beacon_pool;$beacon_pool=$___PRESET_SKILL1006__VARS__beacon_pool; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL1006_PRESET_VARS','$___PRESET_SKILL1006__VARS__beacon_pool=$beacon_pool;');
define('___LOAD_MOD_SKILL1006_PRESET_VARS','global $___PRESET_SKILL1006__VARS__beacon_pool,$beacon_pool;$beacon_pool=$___PRESET_SKILL1006__VARS__beacon_pool;');
define('MOD_SKILL1006_INFO','hidden;');
define('MOD_SKILL1006_BEACONLIST','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill1006/beaconlist');
define('MODULE_SKILL1006_GLOBALS_VARNAMES','beacon_pool');
define('MOD_SKILL1006',1);
define('IMPORT_MODULE_SKILL1006_GLOBALS','global $___LOCAL_SKILL1006__VARS__beacon_pool; $beacon_pool=&$___LOCAL_SKILL1006__VARS__beacon_pool; ');
define('PREFIX_MODULE_SKILL1006_GLOBALS','\'; global $___LOCAL_SKILL1006__VARS__beacon_pool; ${$___TEMP_PREFIX.\'beacon_pool\'}=&$___LOCAL_SKILL1006__VARS__beacon_pool; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL1006_GLOBALS','\'; global $___LOCAL_SKILL1006__VARS__beacon_pool; ${$___TEMP_VARNAME}[\'beacon_pool\']=&$___LOCAL_SKILL1006__VARS__beacon_pool; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL1006__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL1006__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL1006__VARS__beacon_pool;
$___PRIVATE_SKILL1006__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL1006__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_SKILL1006__VARS__beacon_pool=&$beacon_pool;
unset($beacon_pool);
hook_register('skill1006','acquire1006');hook_register('skill1006','lost1006');hook_register('skill1006','check_unlocked1006');hook_register('skill1006','post_enterbattlefield_events');hook_register('skill1006','skill1006_get_beacon_pool');hook_register('skill1006','encode_beacon');hook_register('skill1006','decode_beacon');hook_register('skill1006','add_beacon_core');hook_register('skill1006','add_beacon');hook_register('skill1006','seek_beacon_by_id');hook_register('skill1006','remove_beacon_core');hook_register('skill1006','remove_beacon');hook_register('skill1006','change_memory_unseen');hook_register('skill1006','meetman');hook_register('skill1006','beacon_discover');hook_register('skill1006','act');hook_register('skill1006','senditem_before_log_event');hook_register('skill1006','is_searchmemory_extra_displayed');hook_register('skill1006','add_beacon_from_itempool');hook_register('skill1006','add_beacon_from_edata_arr');hook_register('skill1006','multi_itemget');
function ___post_init() { global $___PRIVATE_SKILL1006__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL1006__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL1006__VARS__beacon_pool;
$___LOCAL_SKILL1006__VARS__beacon_pool=$GLOBALS['beacon_pool'];
unset($GLOBALS['beacon_pool']);
}
	
}

?>