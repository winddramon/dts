<?php

namespace skill234
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill234/'.$___TEMP_key; 
	
	$___PRESET_SKILL234__VARS__goal234=$goal234;
function ___pre_init() { global $___PRESET_SKILL234__VARS__goal234,$goal234;$goal234=$___PRESET_SKILL234__VARS__goal234; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL234_PRESET_VARS','$___PRESET_SKILL234__VARS__goal234=$goal234;');
define('___LOAD_MOD_SKILL234_PRESET_VARS','global $___PRESET_SKILL234__VARS__goal234,$goal234;$goal234=$___PRESET_SKILL234__VARS__goal234;');
define('MOD_SKILL234_INFO','club;active;locked;');
define('MOD_SKILL234_PROFILECMD','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill234/profilecmd');
define('MOD_SKILL234_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill234/desc');
define('MODULE_SKILL234_GLOBALS_VARNAMES','goal234');
define('MOD_SKILL234',1);
define('IMPORT_MODULE_SKILL234_GLOBALS','global $___LOCAL_SKILL234__VARS__goal234; $goal234=&$___LOCAL_SKILL234__VARS__goal234; ');
define('PREFIX_MODULE_SKILL234_GLOBALS','\'; global $___LOCAL_SKILL234__VARS__goal234; ${$___TEMP_PREFIX.\'goal234\'}=&$___LOCAL_SKILL234__VARS__goal234; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL234_GLOBALS','\'; global $___LOCAL_SKILL234__VARS__goal234; ${$___TEMP_VARNAME}[\'goal234\']=&$___LOCAL_SKILL234__VARS__goal234; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL234__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL234__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL234__VARS__goal234;
$___PRIVATE_SKILL234__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL234__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_SKILL234__VARS__goal234=&$goal234;
unset($goal234);
hook_register('skill234','acquire234');hook_register('skill234','lost234');hook_register('skill234','check_unlocked234');hook_register('skill234','wdecode');hook_register('skill234','act');hook_register('skill234','parse_news');
function ___post_init() { global $___PRIVATE_SKILL234__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL234__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL234__VARS__goal234;
$___LOCAL_SKILL234__VARS__goal234=$GLOBALS['goal234'];
unset($GLOBALS['goal234']);
}
	
}

?>