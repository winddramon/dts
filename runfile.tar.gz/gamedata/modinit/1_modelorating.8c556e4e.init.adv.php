<?php

namespace elorating
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/misc/elorating/'.$___TEMP_key; 
	
	$___PRESET_ELORATING__VARS__elo_servermark=$elo_servermark;
function ___pre_init() { global $___PRESET_ELORATING__VARS__elo_servermark,$elo_servermark;$elo_servermark=$___PRESET_ELORATING__VARS__elo_servermark; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_ELORATING_PRESET_VARS','$___PRESET_ELORATING__VARS__elo_servermark=$elo_servermark;');
define('___LOAD_MOD_ELORATING_PRESET_VARS','global $___PRESET_ELORATING__VARS__elo_servermark,$elo_servermark;$elo_servermark=$___PRESET_ELORATING__VARS__elo_servermark;');
define('MOD_ELORATING_ELORATING','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\misc\\elorating/elorating');
define('MODULE_ELORATING_GLOBALS_VARNAMES','elo_servermark');
define('MOD_ELORATING',1);
define('IMPORT_MODULE_ELORATING_GLOBALS','global $___LOCAL_ELORATING__VARS__elo_servermark; $elo_servermark=&$___LOCAL_ELORATING__VARS__elo_servermark; ');
define('PREFIX_MODULE_ELORATING_GLOBALS','\'; global $___LOCAL_ELORATING__VARS__elo_servermark; ${$___TEMP_PREFIX.\'elo_servermark\'}=&$___LOCAL_ELORATING__VARS__elo_servermark; unset($___TEMP_PREFIX); ');
define('MODULE_ELORATING_GLOBALS','\'; global $___LOCAL_ELORATING__VARS__elo_servermark; ${$___TEMP_VARNAME}[\'elo_servermark\']=&$___LOCAL_ELORATING__VARS__elo_servermark; unset($___TEMP_VARNAME); ');

global $___PRIVATE_ELORATING__VARS_____PRIVATE_PFUNC,$___PRIVATE_ELORATING__VARS_____PRIVATE_CFUNC,$___LOCAL_ELORATING__VARS__elo_servermark;
$___PRIVATE_ELORATING__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_ELORATING__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_ELORATING__VARS__elo_servermark=&$elo_servermark;
unset($elo_servermark);
hook_register('elorating','init_enter_battlefield_items');hook_register('elorating','get_servermark');hook_register('elorating','elorating_math_erf');hook_register('elorating','elorating_math_ierf');hook_register('elorating','elorating_math_probit');hook_register('elorating','elorating_calculate_win_probability');hook_register('elorating','elorating_stimulate_game');hook_register('elorating','elorating_calculate_update');hook_register('elorating','elorating_update');hook_register('elorating','get_gameover_udata_update_fields');hook_register('elorating','post_gameover_events');hook_register('elorating','elorating_draw_line');hook_register('elorating','elorating_get_title');hook_register('elorating','elorating_get_color');hook_register('elorating','elorating_get_graph_color');hook_register('elorating','elorating_draw_point');hook_register('elorating','elorating_draw');hook_register('elorating','elorating_show');
function ___post_init() { global $___PRIVATE_ELORATING__VARS_____PRIVATE_PFUNC,$___PRIVATE_ELORATING__VARS_____PRIVATE_CFUNC,$___LOCAL_ELORATING__VARS__elo_servermark;
$___LOCAL_ELORATING__VARS__elo_servermark=$GLOBALS['elo_servermark'];
unset($GLOBALS['elo_servermark']);
}
	
}

?>