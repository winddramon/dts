<?php

namespace itemmix_sync
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'base/itemmix/itemmix_sync/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_ITEMMIX_SYNC_PRESET_VARS','');
define('___LOAD_MOD_ITEMMIX_SYNC_PRESET_VARS','');
define('MODULE_ITEMMIX_SYNC_GLOBALS_VARNAMES','');
define('MOD_ITEMMIX_SYNC',1);
define('IMPORT_MODULE_ITEMMIX_SYNC_GLOBALS','');
define('PREFIX_MODULE_ITEMMIX_SYNC_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_ITEMMIX_SYNC_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_ITEMMIX_SYNC__VARS_____PRIVATE_PFUNC,$___PRIVATE_ITEMMIX_SYNC__VARS_____PRIVATE_CFUNC;
$___PRIVATE_ITEMMIX_SYNC__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_ITEMMIX_SYNC__VARS_____PRIVATE_CFUNC=Array();

hook_register('itemmix_sync','get_itemmix_sync_filename');hook_register('itemmix_sync','itemmix_prepare_sync');hook_register('itemmix_sync','itemmix_star_culc_sync');hook_register('itemmix_sync','itemmix_get_star');hook_register('itemmix_sync','itemmix_sync_check');hook_register('itemmix_sync','itemmix_get_result');
function ___post_init() { global $___PRIVATE_ITEMMIX_SYNC__VARS_____PRIVATE_PFUNC,$___PRIVATE_ITEMMIX_SYNC__VARS_____PRIVATE_CFUNC;


}
	
}

?>