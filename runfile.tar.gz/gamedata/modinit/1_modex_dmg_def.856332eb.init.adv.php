<?php

namespace ex_dmg_def
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/attr/ex_dmg_def/'.$___TEMP_key; 
	
	$___PRESET_EX_DMG_DEF__VARS__def_kind=$def_kind;
function ___pre_init() { global $___PRESET_EX_DMG_DEF__VARS__def_kind,$def_kind;$def_kind=$___PRESET_EX_DMG_DEF__VARS__def_kind; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_EX_DMG_DEF_PRESET_VARS','$___PRESET_EX_DMG_DEF__VARS__def_kind=$def_kind;');
define('___LOAD_MOD_EX_DMG_DEF_PRESET_VARS','global $___PRESET_EX_DMG_DEF__VARS__def_kind,$def_kind;$def_kind=$___PRESET_EX_DMG_DEF__VARS__def_kind;');
define('MODULE_EX_DMG_DEF_GLOBALS_VARNAMES','def_kind');
define('MOD_EX_DMG_DEF',1);
define('IMPORT_MODULE_EX_DMG_DEF_GLOBALS','global $___LOCAL_EX_DMG_DEF__VARS__def_kind; $def_kind=&$___LOCAL_EX_DMG_DEF__VARS__def_kind; ');
define('PREFIX_MODULE_EX_DMG_DEF_GLOBALS','\'; global $___LOCAL_EX_DMG_DEF__VARS__def_kind; ${$___TEMP_PREFIX.\'def_kind\'}=&$___LOCAL_EX_DMG_DEF__VARS__def_kind; unset($___TEMP_PREFIX); ');
define('MODULE_EX_DMG_DEF_GLOBALS','\'; global $___LOCAL_EX_DMG_DEF__VARS__def_kind; ${$___TEMP_VARNAME}[\'def_kind\']=&$___LOCAL_EX_DMG_DEF__VARS__def_kind; unset($___TEMP_VARNAME); ');

global $___PRIVATE_EX_DMG_DEF__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_DMG_DEF__VARS_____PRIVATE_CFUNC,$___LOCAL_EX_DMG_DEF__VARS__def_kind;
$___PRIVATE_EX_DMG_DEF__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_EX_DMG_DEF__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_EX_DMG_DEF__VARS__def_kind=&$def_kind;
unset($def_kind);
hook_register('ex_dmg_def','get_ex_dmg_def_proc_rate');hook_register('ex_dmg_def','check_ex_dmg_def_proc');hook_register('ex_dmg_def','check_ex_single_dmg_def_attr');hook_register('ex_dmg_def','calculate_ex_inf_multiple');hook_register('ex_dmg_def','check_ex_inf_infliction');hook_register('ex_dmg_def','calculate_ex_single_dmg_multiple');hook_register('ex_dmg_def','strike_prepare');
function ___post_init() { global $___PRIVATE_EX_DMG_DEF__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_DMG_DEF__VARS_____PRIVATE_CFUNC,$___LOCAL_EX_DMG_DEF__VARS__def_kind;
$___LOCAL_EX_DMG_DEF__VARS__def_kind=$GLOBALS['def_kind'];
unset($GLOBALS['def_kind']);
}
	
}

?>