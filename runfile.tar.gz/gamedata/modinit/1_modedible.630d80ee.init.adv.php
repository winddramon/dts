<?php

namespace edible
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'base/items/edible/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_EDIBLE_PRESET_VARS','');
define('___LOAD_MOD_EDIBLE_PRESET_VARS','');
define('MODULE_EDIBLE_GLOBALS_VARNAMES','');
define('MOD_EDIBLE',1);
define('IMPORT_MODULE_EDIBLE_GLOBALS','');
define('PREFIX_MODULE_EDIBLE_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_EDIBLE_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_EDIBLE__VARS_____PRIVATE_PFUNC,$___PRIVATE_EDIBLE__VARS_____PRIVATE_CFUNC;
$___PRIVATE_EDIBLE__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_EDIBLE__VARS_____PRIVATE_CFUNC=Array();

hook_register('edible','get_edible_spup');hook_register('edible','get_edible_hpup');hook_register('edible','edible_recover');hook_register('edible','itemuse_edible_get_msp');hook_register('edible','itemuse_edible_get_mhp');hook_register('edible','itemuse_edible');hook_register('edible','itemuse');
function ___post_init() { global $___PRIVATE_EDIBLE__VARS_____PRIVATE_PFUNC,$___PRIVATE_EDIBLE__VARS_____PRIVATE_CFUNC;


}
	
}

?>