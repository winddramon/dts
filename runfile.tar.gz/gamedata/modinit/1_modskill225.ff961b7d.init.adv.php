<?php

namespace skill225
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill225/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL225_PRESET_VARS','');
define('___LOAD_MOD_SKILL225_PRESET_VARS','');
define('MOD_SKILL225_INFO','club;feature;');
define('MOD_SKILL225_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill225/desc');
define('MODULE_SKILL225_GLOBALS_VARNAMES','');
define('MOD_SKILL225',1);
define('IMPORT_MODULE_SKILL225_GLOBALS','');
define('PREFIX_MODULE_SKILL225_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL225_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL225__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL225__VARS_____PRIVATE_CFUNC;
$___PRIVATE_SKILL225__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL225__VARS_____PRIVATE_CFUNC=Array();

hook_register('skill225','acquire225');hook_register('skill225','lost225');hook_register('skill225','check_unlocked225');hook_register('skill225','calculate_attack_weapon_skill_gain_base');hook_register('skill225','calculate_attack_exp_gain_base');
function ___post_init() { global $___PRIVATE_SKILL225__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL225__VARS_____PRIVATE_CFUNC;


}
	
}

?>