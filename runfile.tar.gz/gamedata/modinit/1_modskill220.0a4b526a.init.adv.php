<?php

namespace skill220
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill220/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL220_PRESET_VARS','');
define('___LOAD_MOD_SKILL220_PRESET_VARS','');
define('MOD_SKILL220_INFO','club;active;locked;');
define('MOD_SKILL220_PROFILECMD','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill220/profilecmd');
define('MOD_SKILL220_POISONCHECK','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill220/poisoncheck');
define('MOD_SKILL220_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill220/desc');
define('MODULE_SKILL220_GLOBALS_VARNAMES','');
define('MOD_SKILL220',1);
define('IMPORT_MODULE_SKILL220_GLOBALS','');
define('PREFIX_MODULE_SKILL220_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL220_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL220__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL220__VARS_____PRIVATE_CFUNC;
$___PRIVATE_SKILL220__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL220__VARS_____PRIVATE_CFUNC=Array();

hook_register('skill220','acquire220');hook_register('skill220','lost220');hook_register('skill220','check_unlocked220');hook_register('skill220','parse_itmk_words');hook_register('skill220','pcheck');hook_register('skill220','do_pcheck');hook_register('skill220','check_poison_factor');hook_register('skill220','act');
function ___post_init() { global $___PRIVATE_SKILL220__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL220__VARS_____PRIVATE_CFUNC;


}
	
}

?>