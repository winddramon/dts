<?php

namespace skill228
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill228/'.$___TEMP_key; 
	
	$___PRESET_SKILL228__VARS__skill228_skillpoint_req=$skill228_skillpoint_req;$___PRESET_SKILL228__VARS__stuntime228=$stuntime228;
function ___pre_init() { global $___PRESET_SKILL228__VARS__skill228_skillpoint_req,$skill228_skillpoint_req,$___PRESET_SKILL228__VARS__stuntime228,$stuntime228;$skill228_skillpoint_req=$___PRESET_SKILL228__VARS__skill228_skillpoint_req;$stuntime228=$___PRESET_SKILL228__VARS__stuntime228; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL228_PRESET_VARS','$___PRESET_SKILL228__VARS__skill228_skillpoint_req=$skill228_skillpoint_req;$___PRESET_SKILL228__VARS__stuntime228=$stuntime228;');
define('___LOAD_MOD_SKILL228_PRESET_VARS','global $___PRESET_SKILL228__VARS__skill228_skillpoint_req,$skill228_skillpoint_req,$___PRESET_SKILL228__VARS__stuntime228,$stuntime228;$skill228_skillpoint_req=$___PRESET_SKILL228__VARS__skill228_skillpoint_req;$stuntime228=$___PRESET_SKILL228__VARS__stuntime228;');
define('MOD_SKILL228_INFO','club;battle;');
define('MOD_SKILL228_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill228/desc');
define('MOD_SKILL228_BATTLECMD_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill228/battlecmd_desc');
define('MODULE_SKILL228_GLOBALS_VARNAMES','skill228_skillpoint_req,stuntime228');
define('MOD_SKILL228',1);
define('IMPORT_MODULE_SKILL228_GLOBALS','global $___LOCAL_SKILL228__VARS__skill228_skillpoint_req,$___LOCAL_SKILL228__VARS__stuntime228; $skill228_skillpoint_req=&$___LOCAL_SKILL228__VARS__skill228_skillpoint_req; $stuntime228=&$___LOCAL_SKILL228__VARS__stuntime228; ');
define('PREFIX_MODULE_SKILL228_GLOBALS','\'; global $___LOCAL_SKILL228__VARS__skill228_skillpoint_req; ${$___TEMP_PREFIX.\'skill228_skillpoint_req\'}=&$___LOCAL_SKILL228__VARS__skill228_skillpoint_req; global $___LOCAL_SKILL228__VARS__stuntime228; ${$___TEMP_PREFIX.\'stuntime228\'}=&$___LOCAL_SKILL228__VARS__stuntime228; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL228_GLOBALS','\'; global $___LOCAL_SKILL228__VARS__skill228_skillpoint_req; ${$___TEMP_VARNAME}[\'skill228_skillpoint_req\']=&$___LOCAL_SKILL228__VARS__skill228_skillpoint_req; global $___LOCAL_SKILL228__VARS__stuntime228; ${$___TEMP_VARNAME}[\'stuntime228\']=&$___LOCAL_SKILL228__VARS__stuntime228; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL228__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL228__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL228__VARS__skill228_skillpoint_req,$___LOCAL_SKILL228__VARS__stuntime228;
$___PRIVATE_SKILL228__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL228__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_SKILL228__VARS__skill228_skillpoint_req=&$skill228_skillpoint_req;$___LOCAL_SKILL228__VARS__stuntime228=&$stuntime228;
unset($skill228_skillpoint_req,$stuntime228);
hook_register('skill228','acquire228');hook_register('skill228','lost228');hook_register('skill228','check_unlocked228');hook_register('skill228','get_rage_cost228');hook_register('skill228','check_battle_skill_unactivatable');hook_register('skill228','strike_prepare');hook_register('skill228','get_final_dmg_multiplier');hook_register('skill228','parse_news');
function ___post_init() { global $___PRIVATE_SKILL228__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL228__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL228__VARS__skill228_skillpoint_req,$___LOCAL_SKILL228__VARS__stuntime228;
$___LOCAL_SKILL228__VARS__skill228_skillpoint_req=$GLOBALS['skill228_skillpoint_req'];$___LOCAL_SKILL228__VARS__stuntime228=$GLOBALS['stuntime228'];
unset($GLOBALS['skill228_skillpoint_req'],$GLOBALS['stuntime228']);
}
	
}

?>