<?php

namespace bubblebox
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/misc/bubblebox/'.$___TEMP_key; 
	
	$___PRESET_BUBBLEBOX__VARS__bubblebox_style=$bubblebox_style;
function ___pre_init() { global $___PRESET_BUBBLEBOX__VARS__bubblebox_style,$bubblebox_style;$bubblebox_style=$___PRESET_BUBBLEBOX__VARS__bubblebox_style; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_BUBBLEBOX_PRESET_VARS','$___PRESET_BUBBLEBOX__VARS__bubblebox_style=$bubblebox_style;');
define('___LOAD_MOD_BUBBLEBOX_PRESET_VARS','global $___PRESET_BUBBLEBOX__VARS__bubblebox_style,$bubblebox_style;$bubblebox_style=$___PRESET_BUBBLEBOX__VARS__bubblebox_style;');
define('MOD_BUBBLEBOX_START','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\misc\\bubblebox/start');
define('MOD_BUBBLEBOX_END','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\misc\\bubblebox/end');
define('MODULE_BUBBLEBOX_GLOBALS_VARNAMES','bubblebox_style');
define('MOD_BUBBLEBOX',1);
define('IMPORT_MODULE_BUBBLEBOX_GLOBALS','global $___LOCAL_BUBBLEBOX__VARS__bubblebox_style; $bubblebox_style=&$___LOCAL_BUBBLEBOX__VARS__bubblebox_style; ');
define('PREFIX_MODULE_BUBBLEBOX_GLOBALS','\'; global $___LOCAL_BUBBLEBOX__VARS__bubblebox_style; ${$___TEMP_PREFIX.\'bubblebox_style\'}=&$___LOCAL_BUBBLEBOX__VARS__bubblebox_style; unset($___TEMP_PREFIX); ');
define('MODULE_BUBBLEBOX_GLOBALS','\'; global $___LOCAL_BUBBLEBOX__VARS__bubblebox_style; ${$___TEMP_VARNAME}[\'bubblebox_style\']=&$___LOCAL_BUBBLEBOX__VARS__bubblebox_style; unset($___TEMP_VARNAME); ');

global $___PRIVATE_BUBBLEBOX__VARS_____PRIVATE_PFUNC,$___PRIVATE_BUBBLEBOX__VARS_____PRIVATE_CFUNC,$___LOCAL_BUBBLEBOX__VARS__bubblebox_style;
$___PRIVATE_BUBBLEBOX__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_BUBBLEBOX__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_BUBBLEBOX__VARS__bubblebox_style=&$bubblebox_style;
unset($bubblebox_style);
hook_register('bubblebox','bubblebox_delete_trailing_spaces');hook_register('bubblebox','bubblebox_set_default');hook_register('bubblebox','bubblebox_set_style');hook_register('bubblebox','bubblebox_get_style');
function ___post_init() { global $___PRIVATE_BUBBLEBOX__VARS_____PRIVATE_PFUNC,$___PRIVATE_BUBBLEBOX__VARS_____PRIVATE_CFUNC,$___LOCAL_BUBBLEBOX__VARS__bubblebox_style;
$___LOCAL_BUBBLEBOX__VARS__bubblebox_style=$GLOBALS['bubblebox_style'];
unset($GLOBALS['bubblebox_style']);
}
	
}

?>