<?php

namespace skill112
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill112/'.$___TEMP_key; 
	
	$___PRESET_SKILL112__VARS__ragecost=$ragecost;$___PRESET_SKILL112__VARS__skill112_tempskill_time=$skill112_tempskill_time;
function ___pre_init() { global $___PRESET_SKILL112__VARS__ragecost,$ragecost,$___PRESET_SKILL112__VARS__skill112_tempskill_time,$skill112_tempskill_time;$ragecost=$___PRESET_SKILL112__VARS__ragecost;$skill112_tempskill_time=$___PRESET_SKILL112__VARS__skill112_tempskill_time; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL112_PRESET_VARS','$___PRESET_SKILL112__VARS__ragecost=$ragecost;$___PRESET_SKILL112__VARS__skill112_tempskill_time=$skill112_tempskill_time;');
define('___LOAD_MOD_SKILL112_PRESET_VARS','global $___PRESET_SKILL112__VARS__ragecost,$ragecost,$___PRESET_SKILL112__VARS__skill112_tempskill_time,$skill112_tempskill_time;$ragecost=$___PRESET_SKILL112__VARS__ragecost;$skill112_tempskill_time=$___PRESET_SKILL112__VARS__skill112_tempskill_time;');
define('MOD_SKILL112_INFO','club;battle;locked;');
define('MOD_SKILL112_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill112/desc');
define('MOD_SKILL112_BATTLECMD_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill112/battlecmd_desc');
define('MODULE_SKILL112_GLOBALS_VARNAMES','ragecost,skill112_tempskill_time');
define('MOD_SKILL112',1);
define('IMPORT_MODULE_SKILL112_GLOBALS','global $___LOCAL_SKILL112__VARS__ragecost,$___LOCAL_SKILL112__VARS__skill112_tempskill_time; $ragecost=&$___LOCAL_SKILL112__VARS__ragecost; $skill112_tempskill_time=&$___LOCAL_SKILL112__VARS__skill112_tempskill_time; ');
define('PREFIX_MODULE_SKILL112_GLOBALS','\'; global $___LOCAL_SKILL112__VARS__ragecost; ${$___TEMP_PREFIX.\'ragecost\'}=&$___LOCAL_SKILL112__VARS__ragecost; global $___LOCAL_SKILL112__VARS__skill112_tempskill_time; ${$___TEMP_PREFIX.\'skill112_tempskill_time\'}=&$___LOCAL_SKILL112__VARS__skill112_tempskill_time; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL112_GLOBALS','\'; global $___LOCAL_SKILL112__VARS__ragecost; ${$___TEMP_VARNAME}[\'ragecost\']=&$___LOCAL_SKILL112__VARS__ragecost; global $___LOCAL_SKILL112__VARS__skill112_tempskill_time; ${$___TEMP_VARNAME}[\'skill112_tempskill_time\']=&$___LOCAL_SKILL112__VARS__skill112_tempskill_time; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL112__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL112__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL112__VARS__ragecost,$___LOCAL_SKILL112__VARS__skill112_tempskill_time;
$___PRIVATE_SKILL112__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL112__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_SKILL112__VARS__ragecost=&$ragecost;$___LOCAL_SKILL112__VARS__skill112_tempskill_time=&$skill112_tempskill_time;
unset($ragecost,$skill112_tempskill_time);
hook_register('skill112','acquire112');hook_register('skill112','lost112');hook_register('skill112','check_unlocked112');hook_register('skill112','get_rage_cost112');hook_register('skill112','check_battle_skill_unactivatable');hook_register('skill112','strike_prepare');hook_register('skill112','check_physical_def_attr');hook_register('skill112','check_ex_single_dmg_def_attr');hook_register('skill112','check_ex_rapid_def_exists');hook_register('skill112','get_physical_dmg_multiplier');hook_register('skill112','player_kill_enemy');hook_register('skill112','parse_news');
function ___post_init() { global $___PRIVATE_SKILL112__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL112__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL112__VARS__ragecost,$___LOCAL_SKILL112__VARS__skill112_tempskill_time;
$___LOCAL_SKILL112__VARS__ragecost=$GLOBALS['ragecost'];$___LOCAL_SKILL112__VARS__skill112_tempskill_time=$GLOBALS['skill112_tempskill_time'];
unset($GLOBALS['ragecost'],$GLOBALS['skill112_tempskill_time']);
}
	
}

?>