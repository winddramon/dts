<?php

namespace skill201
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill201/'.$___TEMP_key; 
	
	$___PRESET_SKILL201__VARS__accgain=$accgain;$___PRESET_SKILL201__VARS__rbgain=$rbgain;$___PRESET_SKILL201__VARS__upgradecost=$upgradecost;$___PRESET_SKILL201__VARS__upgradecount=$upgradecount;
function ___pre_init() { global $___PRESET_SKILL201__VARS__accgain,$accgain,$___PRESET_SKILL201__VARS__rbgain,$rbgain,$___PRESET_SKILL201__VARS__upgradecost,$upgradecost,$___PRESET_SKILL201__VARS__upgradecount,$upgradecount;$accgain=$___PRESET_SKILL201__VARS__accgain;$rbgain=$___PRESET_SKILL201__VARS__rbgain;$upgradecost=$___PRESET_SKILL201__VARS__upgradecost;$upgradecount=$___PRESET_SKILL201__VARS__upgradecount; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL201_PRESET_VARS','$___PRESET_SKILL201__VARS__accgain=$accgain;$___PRESET_SKILL201__VARS__rbgain=$rbgain;$___PRESET_SKILL201__VARS__upgradecost=$upgradecost;$___PRESET_SKILL201__VARS__upgradecount=$upgradecount;');
define('___LOAD_MOD_SKILL201_PRESET_VARS','global $___PRESET_SKILL201__VARS__accgain,$accgain,$___PRESET_SKILL201__VARS__rbgain,$rbgain,$___PRESET_SKILL201__VARS__upgradecost,$upgradecost,$___PRESET_SKILL201__VARS__upgradecount,$upgradecount;$accgain=$___PRESET_SKILL201__VARS__accgain;$rbgain=$___PRESET_SKILL201__VARS__rbgain;$upgradecost=$___PRESET_SKILL201__VARS__upgradecost;$upgradecount=$___PRESET_SKILL201__VARS__upgradecount;');
define('MOD_SKILL201_INFO','club;upgrade;');
define('MOD_SKILL201_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill201/desc');
define('MODULE_SKILL201_GLOBALS_VARNAMES','accgain,rbgain,upgradecost,upgradecount');
define('MOD_SKILL201',1);
define('IMPORT_MODULE_SKILL201_GLOBALS','global $___LOCAL_SKILL201__VARS__accgain,$___LOCAL_SKILL201__VARS__rbgain,$___LOCAL_SKILL201__VARS__upgradecost,$___LOCAL_SKILL201__VARS__upgradecount; $accgain=&$___LOCAL_SKILL201__VARS__accgain; $rbgain=&$___LOCAL_SKILL201__VARS__rbgain; $upgradecost=&$___LOCAL_SKILL201__VARS__upgradecost; $upgradecount=&$___LOCAL_SKILL201__VARS__upgradecount; ');
define('PREFIX_MODULE_SKILL201_GLOBALS','\'; global $___LOCAL_SKILL201__VARS__accgain; ${$___TEMP_PREFIX.\'accgain\'}=&$___LOCAL_SKILL201__VARS__accgain; global $___LOCAL_SKILL201__VARS__rbgain; ${$___TEMP_PREFIX.\'rbgain\'}=&$___LOCAL_SKILL201__VARS__rbgain; global $___LOCAL_SKILL201__VARS__upgradecost; ${$___TEMP_PREFIX.\'upgradecost\'}=&$___LOCAL_SKILL201__VARS__upgradecost; global $___LOCAL_SKILL201__VARS__upgradecount; ${$___TEMP_PREFIX.\'upgradecount\'}=&$___LOCAL_SKILL201__VARS__upgradecount; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL201_GLOBALS','\'; global $___LOCAL_SKILL201__VARS__accgain; ${$___TEMP_VARNAME}[\'accgain\']=&$___LOCAL_SKILL201__VARS__accgain; global $___LOCAL_SKILL201__VARS__rbgain; ${$___TEMP_VARNAME}[\'rbgain\']=&$___LOCAL_SKILL201__VARS__rbgain; global $___LOCAL_SKILL201__VARS__upgradecost; ${$___TEMP_VARNAME}[\'upgradecost\']=&$___LOCAL_SKILL201__VARS__upgradecost; global $___LOCAL_SKILL201__VARS__upgradecount; ${$___TEMP_VARNAME}[\'upgradecount\']=&$___LOCAL_SKILL201__VARS__upgradecount; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL201__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL201__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL201__VARS__accgain,$___LOCAL_SKILL201__VARS__rbgain,$___LOCAL_SKILL201__VARS__upgradecost,$___LOCAL_SKILL201__VARS__upgradecount;
$___PRIVATE_SKILL201__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL201__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_SKILL201__VARS__accgain=&$accgain;$___LOCAL_SKILL201__VARS__rbgain=&$rbgain;$___LOCAL_SKILL201__VARS__upgradecost=&$upgradecost;$___LOCAL_SKILL201__VARS__upgradecount=&$upgradecount;
unset($accgain,$rbgain,$upgradecost,$upgradecount);
hook_register('skill201','acquire201');hook_register('skill201','lost201');hook_register('skill201','check_unlocked201');hook_register('skill201','upgrade201');hook_register('skill201','get_skill201_extra_acc_gain');hook_register('skill201','get_skill201_extra_rb_gain');hook_register('skill201','get_rapid_accuracy_loss');hook_register('skill201','get_hitrate_multiplier');
function ___post_init() { global $___PRIVATE_SKILL201__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL201__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL201__VARS__accgain,$___LOCAL_SKILL201__VARS__rbgain,$___LOCAL_SKILL201__VARS__upgradecost,$___LOCAL_SKILL201__VARS__upgradecount;
$___LOCAL_SKILL201__VARS__accgain=$GLOBALS['accgain'];$___LOCAL_SKILL201__VARS__rbgain=$GLOBALS['rbgain'];$___LOCAL_SKILL201__VARS__upgradecost=$GLOBALS['upgradecost'];$___LOCAL_SKILL201__VARS__upgradecount=$GLOBALS['upgradecount'];
unset($GLOBALS['accgain'],$GLOBALS['rbgain'],$GLOBALS['upgradecost'],$GLOBALS['upgradecount']);
}
	
}

?>