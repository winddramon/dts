<?php

namespace item_uys
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/item_extra/item_uys/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_ITEM_UYS_PRESET_VARS','');
define('___LOAD_MOD_ITEM_UYS_PRESET_VARS','');
define('MOD_ITEM_UYS_USE_SEWINGKIT','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\item_extra\\item_uys/use_sewingkit');
define('MODULE_ITEM_UYS_GLOBALS_VARNAMES','');
define('MOD_ITEM_UYS',1);
define('IMPORT_MODULE_ITEM_UYS_GLOBALS','');
define('PREFIX_MODULE_ITEM_UYS_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_ITEM_UYS_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_ITEM_UYS__VARS_____PRIVATE_PFUNC,$___PRIVATE_ITEM_UYS__VARS_____PRIVATE_CFUNC;
$___PRIVATE_ITEM_UYS__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_ITEM_UYS__VARS_____PRIVATE_CFUNC=Array();

hook_register('item_uys','itemuse');hook_register('item_uys','autosewingkit');hook_register('item_uys','autosewingkit_single');hook_register('item_uys','autosewingkit_finish_event');hook_register('item_uys','act');
function ___post_init() { global $___PRIVATE_ITEM_UYS__VARS_____PRIVATE_PFUNC,$___PRIVATE_ITEM_UYS__VARS_____PRIVATE_CFUNC;


}
	
}

?>