<?php

namespace autopower
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/misc/autopower/'.$___TEMP_key; 
	
	$___PRESET_AUTOPOWER__VARS__max_autopower_num=$max_autopower_num;$___PRESET_AUTOPOWER__VARS__autopower_penalty=$autopower_penalty;
function ___pre_init() { global $___PRESET_AUTOPOWER__VARS__max_autopower_num,$max_autopower_num,$___PRESET_AUTOPOWER__VARS__autopower_penalty,$autopower_penalty;$max_autopower_num=$___PRESET_AUTOPOWER__VARS__max_autopower_num;$autopower_penalty=$___PRESET_AUTOPOWER__VARS__autopower_penalty; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_AUTOPOWER_PRESET_VARS','$___PRESET_AUTOPOWER__VARS__max_autopower_num=$max_autopower_num;$___PRESET_AUTOPOWER__VARS__autopower_penalty=$autopower_penalty;');
define('___LOAD_MOD_AUTOPOWER_PRESET_VARS','global $___PRESET_AUTOPOWER__VARS__max_autopower_num,$max_autopower_num,$___PRESET_AUTOPOWER__VARS__autopower_penalty,$autopower_penalty;$max_autopower_num=$___PRESET_AUTOPOWER__VARS__max_autopower_num;$autopower_penalty=$___PRESET_AUTOPOWER__VARS__autopower_penalty;');
define('MODULE_AUTOPOWER_GLOBALS_VARNAMES','max_autopower_num,autopower_penalty');
define('MOD_AUTOPOWER',1);
define('IMPORT_MODULE_AUTOPOWER_GLOBALS','global $___LOCAL_AUTOPOWER__VARS__max_autopower_num,$___LOCAL_AUTOPOWER__VARS__autopower_penalty; $max_autopower_num=&$___LOCAL_AUTOPOWER__VARS__max_autopower_num; $autopower_penalty=&$___LOCAL_AUTOPOWER__VARS__autopower_penalty; ');
define('PREFIX_MODULE_AUTOPOWER_GLOBALS','\'; global $___LOCAL_AUTOPOWER__VARS__max_autopower_num; ${$___TEMP_PREFIX.\'max_autopower_num\'}=&$___LOCAL_AUTOPOWER__VARS__max_autopower_num; global $___LOCAL_AUTOPOWER__VARS__autopower_penalty; ${$___TEMP_PREFIX.\'autopower_penalty\'}=&$___LOCAL_AUTOPOWER__VARS__autopower_penalty; unset($___TEMP_PREFIX); ');
define('MODULE_AUTOPOWER_GLOBALS','\'; global $___LOCAL_AUTOPOWER__VARS__max_autopower_num; ${$___TEMP_VARNAME}[\'max_autopower_num\']=&$___LOCAL_AUTOPOWER__VARS__max_autopower_num; global $___LOCAL_AUTOPOWER__VARS__autopower_penalty; ${$___TEMP_VARNAME}[\'autopower_penalty\']=&$___LOCAL_AUTOPOWER__VARS__autopower_penalty; unset($___TEMP_VARNAME); ');

global $___PRIVATE_AUTOPOWER__VARS_____PRIVATE_PFUNC,$___PRIVATE_AUTOPOWER__VARS_____PRIVATE_CFUNC,$___LOCAL_AUTOPOWER__VARS__max_autopower_num,$___LOCAL_AUTOPOWER__VARS__autopower_penalty;
$___PRIVATE_AUTOPOWER__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_AUTOPOWER__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_AUTOPOWER__VARS__max_autopower_num=&$max_autopower_num;$___LOCAL_AUTOPOWER__VARS__autopower_penalty=&$autopower_penalty;
unset($max_autopower_num,$autopower_penalty);
hook_register('autopower','itemuse');
function ___post_init() { global $___PRIVATE_AUTOPOWER__VARS_____PRIVATE_PFUNC,$___PRIVATE_AUTOPOWER__VARS_____PRIVATE_CFUNC,$___LOCAL_AUTOPOWER__VARS__max_autopower_num,$___LOCAL_AUTOPOWER__VARS__autopower_penalty;
$___LOCAL_AUTOPOWER__VARS__max_autopower_num=$GLOBALS['max_autopower_num'];$___LOCAL_AUTOPOWER__VARS__autopower_penalty=$GLOBALS['autopower_penalty'];
unset($GLOBALS['max_autopower_num'],$GLOBALS['autopower_penalty']);
}
	
}

?>