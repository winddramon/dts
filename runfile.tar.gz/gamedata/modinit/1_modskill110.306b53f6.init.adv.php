<?php

namespace skill110
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill110/'.$___TEMP_key; 
	
	$___PRESET_SKILL110__VARS__skill110_cd=$skill110_cd;
function ___pre_init() { global $___PRESET_SKILL110__VARS__skill110_cd,$skill110_cd;$skill110_cd=$___PRESET_SKILL110__VARS__skill110_cd; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL110_PRESET_VARS','$___PRESET_SKILL110__VARS__skill110_cd=$skill110_cd;');
define('___LOAD_MOD_SKILL110_PRESET_VARS','global $___PRESET_SKILL110__VARS__skill110_cd,$skill110_cd;$skill110_cd=$___PRESET_SKILL110__VARS__skill110_cd;');
define('MOD_SKILL110_INFO','club;locked;upgrade;');
define('MOD_SKILL110_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill110/desc');
define('MOD_SKILL110_CASTSK110','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill110/castsk110');
define('MODULE_SKILL110_GLOBALS_VARNAMES','skill110_cd');
define('MOD_SKILL110',1);
define('IMPORT_MODULE_SKILL110_GLOBALS','global $___LOCAL_SKILL110__VARS__skill110_cd; $skill110_cd=&$___LOCAL_SKILL110__VARS__skill110_cd; ');
define('PREFIX_MODULE_SKILL110_GLOBALS','\'; global $___LOCAL_SKILL110__VARS__skill110_cd; ${$___TEMP_PREFIX.\'skill110_cd\'}=&$___LOCAL_SKILL110__VARS__skill110_cd; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL110_GLOBALS','\'; global $___LOCAL_SKILL110__VARS__skill110_cd; ${$___TEMP_VARNAME}[\'skill110_cd\']=&$___LOCAL_SKILL110__VARS__skill110_cd; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL110__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL110__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL110__VARS__skill110_cd;
$___PRIVATE_SKILL110__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL110__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_SKILL110__VARS__skill110_cd=&$skill110_cd;
unset($skill110_cd);
hook_register('skill110','acquire110');hook_register('skill110','lost110');hook_register('skill110','check_unlocked110');hook_register('skill110','skill110_tempskill_list');hook_register('skill110','skill110_learn_tempskill');hook_register('skill110','cast_skill110');hook_register('skill110','act');
function ___post_init() { global $___PRIVATE_SKILL110__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL110__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL110__VARS__skill110_cd;
$___LOCAL_SKILL110__VARS__skill110_cd=$GLOBALS['skill110_cd'];
unset($GLOBALS['skill110_cd']);
}
	
}

?>