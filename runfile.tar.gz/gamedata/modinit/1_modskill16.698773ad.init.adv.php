<?php

namespace skill16
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill16/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL16_PRESET_VARS','');
define('___LOAD_MOD_SKILL16_PRESET_VARS','');
define('MOD_SKILL16_INFO','club;feature;');
define('MOD_SKILL16_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill16/desc');
define('MODULE_SKILL16_GLOBALS_VARNAMES','');
define('MOD_SKILL16',1);
define('IMPORT_MODULE_SKILL16_GLOBALS','');
define('PREFIX_MODULE_SKILL16_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL16_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL16__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL16__VARS_____PRIVATE_CFUNC;
$___PRIVATE_SKILL16__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL16__VARS_____PRIVATE_CFUNC=Array();

hook_register('skill16','acquire16');hook_register('skill16','lost16');hook_register('skill16','check_unlocked16');hook_register('skill16','lvlup');
function ___post_init() { global $___PRIVATE_SKILL16__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL16__VARS_____PRIVATE_CFUNC;


}
	
}

?>