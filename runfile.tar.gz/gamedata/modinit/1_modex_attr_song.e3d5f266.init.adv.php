<?php

namespace ex_attr_song
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/attr/ex_attr_song/'.$___TEMP_key; 
	
	$___PRESET_EX_ATTR_SONG__VARS__sa_factor=$sa_factor;
function ___pre_init() { global $___PRESET_EX_ATTR_SONG__VARS__sa_factor,$sa_factor;$sa_factor=$___PRESET_EX_ATTR_SONG__VARS__sa_factor; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_EX_ATTR_SONG_PRESET_VARS','$___PRESET_EX_ATTR_SONG__VARS__sa_factor=$sa_factor;');
define('___LOAD_MOD_EX_ATTR_SONG_PRESET_VARS','global $___PRESET_EX_ATTR_SONG__VARS__sa_factor,$sa_factor;$sa_factor=$___PRESET_EX_ATTR_SONG__VARS__sa_factor;');
define('MODULE_EX_ATTR_SONG_GLOBALS_VARNAMES','sa_factor');
define('MOD_EX_ATTR_SONG',1);
define('IMPORT_MODULE_EX_ATTR_SONG_GLOBALS','global $___LOCAL_EX_ATTR_SONG__VARS__sa_factor; $sa_factor=&$___LOCAL_EX_ATTR_SONG__VARS__sa_factor; ');
define('PREFIX_MODULE_EX_ATTR_SONG_GLOBALS','\'; global $___LOCAL_EX_ATTR_SONG__VARS__sa_factor; ${$___TEMP_PREFIX.\'sa_factor\'}=&$___LOCAL_EX_ATTR_SONG__VARS__sa_factor; unset($___TEMP_PREFIX); ');
define('MODULE_EX_ATTR_SONG_GLOBALS','\'; global $___LOCAL_EX_ATTR_SONG__VARS__sa_factor; ${$___TEMP_VARNAME}[\'sa_factor\']=&$___LOCAL_EX_ATTR_SONG__VARS__sa_factor; unset($___TEMP_VARNAME); ');

global $___PRIVATE_EX_ATTR_SONG__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_ATTR_SONG__VARS_____PRIVATE_CFUNC,$___LOCAL_EX_ATTR_SONG__VARS__sa_factor;
$___PRIVATE_EX_ATTR_SONG__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_EX_ATTR_SONG__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_EX_ATTR_SONG__VARS__sa_factor=&$sa_factor;
unset($sa_factor);
hook_register('ex_attr_song','get_song_effect');hook_register('ex_attr_song','ss_factor');
function ___post_init() { global $___PRIVATE_EX_ATTR_SONG__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_ATTR_SONG__VARS_____PRIVATE_CFUNC,$___LOCAL_EX_ATTR_SONG__VARS__sa_factor;
$___LOCAL_EX_ATTR_SONG__VARS__sa_factor=$GLOBALS['sa_factor'];
unset($GLOBALS['sa_factor']);
}
	
}

?>