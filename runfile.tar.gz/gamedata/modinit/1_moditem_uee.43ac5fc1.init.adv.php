<?php

namespace item_uee
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'base/items/item_uee/'.$___TEMP_key; 
	
	$___PRESET_ITEM_UEE__VARS__hack_obbs=$hack_obbs;$___PRESET_ITEM_UEE__VARS__break_obbs=$break_obbs;$___PRESET_ITEM_UEE__VARS__death_obbs=$death_obbs;
function ___pre_init() { global $___PRESET_ITEM_UEE__VARS__hack_obbs,$hack_obbs,$___PRESET_ITEM_UEE__VARS__break_obbs,$break_obbs,$___PRESET_ITEM_UEE__VARS__death_obbs,$death_obbs;$hack_obbs=$___PRESET_ITEM_UEE__VARS__hack_obbs;$break_obbs=$___PRESET_ITEM_UEE__VARS__break_obbs;$death_obbs=$___PRESET_ITEM_UEE__VARS__death_obbs; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_ITEM_UEE_PRESET_VARS','$___PRESET_ITEM_UEE__VARS__hack_obbs=$hack_obbs;$___PRESET_ITEM_UEE__VARS__break_obbs=$break_obbs;$___PRESET_ITEM_UEE__VARS__death_obbs=$death_obbs;');
define('___LOAD_MOD_ITEM_UEE_PRESET_VARS','global $___PRESET_ITEM_UEE__VARS__hack_obbs,$hack_obbs,$___PRESET_ITEM_UEE__VARS__break_obbs,$break_obbs,$___PRESET_ITEM_UEE__VARS__death_obbs,$death_obbs;$hack_obbs=$___PRESET_ITEM_UEE__VARS__hack_obbs;$break_obbs=$___PRESET_ITEM_UEE__VARS__break_obbs;$death_obbs=$___PRESET_ITEM_UEE__VARS__death_obbs;');
define('MODULE_ITEM_UEE_GLOBALS_VARNAMES','hack_obbs,break_obbs,death_obbs');
define('MOD_ITEM_UEE',1);
define('IMPORT_MODULE_ITEM_UEE_GLOBALS','global $___LOCAL_ITEM_UEE__VARS__hack_obbs,$___LOCAL_ITEM_UEE__VARS__break_obbs,$___LOCAL_ITEM_UEE__VARS__death_obbs; $hack_obbs=&$___LOCAL_ITEM_UEE__VARS__hack_obbs; $break_obbs=&$___LOCAL_ITEM_UEE__VARS__break_obbs; $death_obbs=&$___LOCAL_ITEM_UEE__VARS__death_obbs; ');
define('PREFIX_MODULE_ITEM_UEE_GLOBALS','\'; global $___LOCAL_ITEM_UEE__VARS__hack_obbs; ${$___TEMP_PREFIX.\'hack_obbs\'}=&$___LOCAL_ITEM_UEE__VARS__hack_obbs; global $___LOCAL_ITEM_UEE__VARS__break_obbs; ${$___TEMP_PREFIX.\'break_obbs\'}=&$___LOCAL_ITEM_UEE__VARS__break_obbs; global $___LOCAL_ITEM_UEE__VARS__death_obbs; ${$___TEMP_PREFIX.\'death_obbs\'}=&$___LOCAL_ITEM_UEE__VARS__death_obbs; unset($___TEMP_PREFIX); ');
define('MODULE_ITEM_UEE_GLOBALS','\'; global $___LOCAL_ITEM_UEE__VARS__hack_obbs; ${$___TEMP_VARNAME}[\'hack_obbs\']=&$___LOCAL_ITEM_UEE__VARS__hack_obbs; global $___LOCAL_ITEM_UEE__VARS__break_obbs; ${$___TEMP_VARNAME}[\'break_obbs\']=&$___LOCAL_ITEM_UEE__VARS__break_obbs; global $___LOCAL_ITEM_UEE__VARS__death_obbs; ${$___TEMP_VARNAME}[\'death_obbs\']=&$___LOCAL_ITEM_UEE__VARS__death_obbs; unset($___TEMP_VARNAME); ');

global $___PRIVATE_ITEM_UEE__VARS_____PRIVATE_PFUNC,$___PRIVATE_ITEM_UEE__VARS_____PRIVATE_CFUNC,$___LOCAL_ITEM_UEE__VARS__hack_obbs,$___LOCAL_ITEM_UEE__VARS__break_obbs,$___LOCAL_ITEM_UEE__VARS__death_obbs;
$___PRIVATE_ITEM_UEE__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_ITEM_UEE__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_ITEM_UEE__VARS__hack_obbs=&$hack_obbs;$___LOCAL_ITEM_UEE__VARS__break_obbs=&$break_obbs;$___LOCAL_ITEM_UEE__VARS__death_obbs=&$death_obbs;
unset($hack_obbs,$break_obbs,$death_obbs);
hook_register('item_uee','parse_itmuse_desc');hook_register('item_uee','calculate_hack_proc_rate');hook_register('item_uee','calculate_post_hack_proc_rate');hook_register('item_uee','get_uee_deathlog');hook_register('item_uee','post_hack_events');hook_register('item_uee','itemuse_uee');hook_register('item_uee','itemuse_uee_core');hook_register('item_uee','itemuse');hook_register('item_uee','parse_news');
function ___post_init() { global $___PRIVATE_ITEM_UEE__VARS_____PRIVATE_PFUNC,$___PRIVATE_ITEM_UEE__VARS_____PRIVATE_CFUNC,$___LOCAL_ITEM_UEE__VARS__hack_obbs,$___LOCAL_ITEM_UEE__VARS__break_obbs,$___LOCAL_ITEM_UEE__VARS__death_obbs;
$___LOCAL_ITEM_UEE__VARS__hack_obbs=$GLOBALS['hack_obbs'];$___LOCAL_ITEM_UEE__VARS__break_obbs=$GLOBALS['break_obbs'];$___LOCAL_ITEM_UEE__VARS__death_obbs=$GLOBALS['death_obbs'];
unset($GLOBALS['hack_obbs'],$GLOBALS['break_obbs'],$GLOBALS['death_obbs']);
}
	
}

?>