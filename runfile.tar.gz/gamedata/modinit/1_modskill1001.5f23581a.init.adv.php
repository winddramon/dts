<?php

namespace skill1001
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/instance/skill1001/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL1001_PRESET_VARS','');
define('___LOAD_MOD_SKILL1001_PRESET_VARS','');
define('MOD_SKILL1001_INFO','unique;');
define('MOD_SKILL1001_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\instance\\skill1001/desc');
define('MODULE_SKILL1001_GLOBALS_VARNAMES','');
define('MOD_SKILL1001',1);
define('IMPORT_MODULE_SKILL1001_GLOBALS','');
define('PREFIX_MODULE_SKILL1001_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL1001_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL1001__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL1001__VARS_____PRIVATE_CFUNC;
$___PRIVATE_SKILL1001__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL1001__VARS_____PRIVATE_CFUNC=Array();

hook_register('skill1001','acquire1001');hook_register('skill1001','lost1001');hook_register('skill1001','check_unlocked1001');hook_register('skill1001','process_1001');hook_register('skill1001','act');
function ___post_init() { global $___PRIVATE_SKILL1001__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL1001__VARS_____PRIVATE_CFUNC;


}
	
}

?>