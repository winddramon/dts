<?php

namespace skill19
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill19/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL19_PRESET_VARS','');
define('___LOAD_MOD_SKILL19_PRESET_VARS','');
define('MOD_SKILL19_INFO','club;hidden;');
define('MODULE_SKILL19_GLOBALS_VARNAMES','');
define('MOD_SKILL19',1);
define('IMPORT_MODULE_SKILL19_GLOBALS','');
define('PREFIX_MODULE_SKILL19_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL19_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL19__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL19__VARS_____PRIVATE_CFUNC;
$___PRIVATE_SKILL19__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL19__VARS_____PRIVATE_CFUNC=Array();

hook_register('skill19','acquire19');hook_register('skill19','lost19');hook_register('skill19','get_trap_escape_rate');hook_register('skill19','calculate_trap_reuse_rate');hook_register('skill19','trap_use');
function ___post_init() { global $___PRIVATE_SKILL19__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL19__VARS_____PRIVATE_CFUNC;


}
	
}

?>