<?php

namespace activity_ranking
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/activities/activity_ranking/'.$___TEMP_key; 
	
	$___PRESET_ACTIVITY_RANKING__VARS__activity_ranking_available=$activity_ranking_available;
function ___pre_init() { global $___PRESET_ACTIVITY_RANKING__VARS__activity_ranking_available,$activity_ranking_available;$activity_ranking_available=$___PRESET_ACTIVITY_RANKING__VARS__activity_ranking_available; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_ACTIVITY_RANKING_PRESET_VARS','$___PRESET_ACTIVITY_RANKING__VARS__activity_ranking_available=$activity_ranking_available;');
define('___LOAD_MOD_ACTIVITY_RANKING_PRESET_VARS','global $___PRESET_ACTIVITY_RANKING__VARS__activity_ranking_available,$activity_ranking_available;$activity_ranking_available=$___PRESET_ACTIVITY_RANKING__VARS__activity_ranking_available;');
define('MODULE_ACTIVITY_RANKING_GLOBALS_VARNAMES','activity_ranking_available');
define('MOD_ACTIVITY_RANKING',1);
define('IMPORT_MODULE_ACTIVITY_RANKING_GLOBALS','global $___LOCAL_ACTIVITY_RANKING__VARS__activity_ranking_available; $activity_ranking_available=&$___LOCAL_ACTIVITY_RANKING__VARS__activity_ranking_available; ');
define('PREFIX_MODULE_ACTIVITY_RANKING_GLOBALS','\'; global $___LOCAL_ACTIVITY_RANKING__VARS__activity_ranking_available; ${$___TEMP_PREFIX.\'activity_ranking_available\'}=&$___LOCAL_ACTIVITY_RANKING__VARS__activity_ranking_available; unset($___TEMP_PREFIX); ');
define('MODULE_ACTIVITY_RANKING_GLOBALS','\'; global $___LOCAL_ACTIVITY_RANKING__VARS__activity_ranking_available; ${$___TEMP_VARNAME}[\'activity_ranking_available\']=&$___LOCAL_ACTIVITY_RANKING__VARS__activity_ranking_available; unset($___TEMP_VARNAME); ');

global $___PRIVATE_ACTIVITY_RANKING__VARS_____PRIVATE_PFUNC,$___PRIVATE_ACTIVITY_RANKING__VARS_____PRIVATE_CFUNC,$___LOCAL_ACTIVITY_RANKING__VARS__activity_ranking_available;
$___PRIVATE_ACTIVITY_RANKING__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_ACTIVITY_RANKING__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_ACTIVITY_RANKING__VARS__activity_ranking_available=&$activity_ranking_available;
unset($activity_ranking_available);
hook_register('activity_ranking','prepare_aranking_table');hook_register('activity_ranking','aranking_send');hook_register('activity_ranking','load_aranking');hook_register('activity_ranking','save_ulist_aranking');
function ___post_init() { global $___PRIVATE_ACTIVITY_RANKING__VARS_____PRIVATE_PFUNC,$___PRIVATE_ACTIVITY_RANKING__VARS_____PRIVATE_CFUNC,$___LOCAL_ACTIVITY_RANKING__VARS__activity_ranking_available;
$___LOCAL_ACTIVITY_RANKING__VARS__activity_ranking_available=$GLOBALS['activity_ranking_available'];
unset($GLOBALS['activity_ranking_available']);
}
	
}

?>