<?php

namespace item_uee_extra
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/item_extra/item_uee_extra/'.$___TEMP_key; 
	
	$___PRESET_ITEM_UEE_EXTRA__VARS__allow_uee_extra_gametype_num=$allow_uee_extra_gametype_num;$___PRESET_ITEM_UEE_EXTRA__VARS__uee_extra_words=$uee_extra_words;$___PRESET_ITEM_UEE_EXTRA__VARS__uee_extra_buttons=$uee_extra_buttons;
function ___pre_init() { global $___PRESET_ITEM_UEE_EXTRA__VARS__allow_uee_extra_gametype_num,$allow_uee_extra_gametype_num,$___PRESET_ITEM_UEE_EXTRA__VARS__uee_extra_words,$uee_extra_words,$___PRESET_ITEM_UEE_EXTRA__VARS__uee_extra_buttons,$uee_extra_buttons;$allow_uee_extra_gametype_num=$___PRESET_ITEM_UEE_EXTRA__VARS__allow_uee_extra_gametype_num;$uee_extra_words=$___PRESET_ITEM_UEE_EXTRA__VARS__uee_extra_words;$uee_extra_buttons=$___PRESET_ITEM_UEE_EXTRA__VARS__uee_extra_buttons; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_ITEM_UEE_EXTRA_PRESET_VARS','$___PRESET_ITEM_UEE_EXTRA__VARS__allow_uee_extra_gametype_num=$allow_uee_extra_gametype_num;$___PRESET_ITEM_UEE_EXTRA__VARS__uee_extra_words=$uee_extra_words;$___PRESET_ITEM_UEE_EXTRA__VARS__uee_extra_buttons=$uee_extra_buttons;');
define('___LOAD_MOD_ITEM_UEE_EXTRA_PRESET_VARS','global $___PRESET_ITEM_UEE_EXTRA__VARS__allow_uee_extra_gametype_num,$allow_uee_extra_gametype_num,$___PRESET_ITEM_UEE_EXTRA__VARS__uee_extra_words,$uee_extra_words,$___PRESET_ITEM_UEE_EXTRA__VARS__uee_extra_buttons,$uee_extra_buttons;$allow_uee_extra_gametype_num=$___PRESET_ITEM_UEE_EXTRA__VARS__allow_uee_extra_gametype_num;$uee_extra_words=$___PRESET_ITEM_UEE_EXTRA__VARS__uee_extra_words;$uee_extra_buttons=$___PRESET_ITEM_UEE_EXTRA__VARS__uee_extra_buttons;');
define('MOD_ITEM_UEE_EXTRA_USE_UEE_CMD','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\item_extra\\item_uee_extra/use_uee_cmd');
define('MOD_ITEM_UEE_EXTRA_USE_UEE_EXTRA','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\item_extra\\item_uee_extra/use_uee_extra');
define('MODULE_ITEM_UEE_EXTRA_GLOBALS_VARNAMES','allow_uee_extra_gametype_num,uee_extra_words,uee_extra_buttons');
define('MOD_ITEM_UEE_EXTRA',1);
define('IMPORT_MODULE_ITEM_UEE_EXTRA_GLOBALS','global $___LOCAL_ITEM_UEE_EXTRA__VARS__allow_uee_extra_gametype_num,$___LOCAL_ITEM_UEE_EXTRA__VARS__uee_extra_words,$___LOCAL_ITEM_UEE_EXTRA__VARS__uee_extra_buttons; $allow_uee_extra_gametype_num=&$___LOCAL_ITEM_UEE_EXTRA__VARS__allow_uee_extra_gametype_num; $uee_extra_words=&$___LOCAL_ITEM_UEE_EXTRA__VARS__uee_extra_words; $uee_extra_buttons=&$___LOCAL_ITEM_UEE_EXTRA__VARS__uee_extra_buttons; ');
define('PREFIX_MODULE_ITEM_UEE_EXTRA_GLOBALS','\'; global $___LOCAL_ITEM_UEE_EXTRA__VARS__allow_uee_extra_gametype_num; ${$___TEMP_PREFIX.\'allow_uee_extra_gametype_num\'}=&$___LOCAL_ITEM_UEE_EXTRA__VARS__allow_uee_extra_gametype_num; global $___LOCAL_ITEM_UEE_EXTRA__VARS__uee_extra_words; ${$___TEMP_PREFIX.\'uee_extra_words\'}=&$___LOCAL_ITEM_UEE_EXTRA__VARS__uee_extra_words; global $___LOCAL_ITEM_UEE_EXTRA__VARS__uee_extra_buttons; ${$___TEMP_PREFIX.\'uee_extra_buttons\'}=&$___LOCAL_ITEM_UEE_EXTRA__VARS__uee_extra_buttons; unset($___TEMP_PREFIX); ');
define('MODULE_ITEM_UEE_EXTRA_GLOBALS','\'; global $___LOCAL_ITEM_UEE_EXTRA__VARS__allow_uee_extra_gametype_num; ${$___TEMP_VARNAME}[\'allow_uee_extra_gametype_num\']=&$___LOCAL_ITEM_UEE_EXTRA__VARS__allow_uee_extra_gametype_num; global $___LOCAL_ITEM_UEE_EXTRA__VARS__uee_extra_words; ${$___TEMP_VARNAME}[\'uee_extra_words\']=&$___LOCAL_ITEM_UEE_EXTRA__VARS__uee_extra_words; global $___LOCAL_ITEM_UEE_EXTRA__VARS__uee_extra_buttons; ${$___TEMP_VARNAME}[\'uee_extra_buttons\']=&$___LOCAL_ITEM_UEE_EXTRA__VARS__uee_extra_buttons; unset($___TEMP_VARNAME); ');

global $___PRIVATE_ITEM_UEE_EXTRA__VARS_____PRIVATE_PFUNC,$___PRIVATE_ITEM_UEE_EXTRA__VARS_____PRIVATE_CFUNC,$___LOCAL_ITEM_UEE_EXTRA__VARS__allow_uee_extra_gametype_num,$___LOCAL_ITEM_UEE_EXTRA__VARS__uee_extra_words,$___LOCAL_ITEM_UEE_EXTRA__VARS__uee_extra_buttons;
$___PRIVATE_ITEM_UEE_EXTRA__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_ITEM_UEE_EXTRA__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_ITEM_UEE_EXTRA__VARS__allow_uee_extra_gametype_num=&$allow_uee_extra_gametype_num;$___LOCAL_ITEM_UEE_EXTRA__VARS__uee_extra_words=&$uee_extra_words;$___LOCAL_ITEM_UEE_EXTRA__VARS__uee_extra_buttons=&$uee_extra_buttons;
unset($allow_uee_extra_gametype_num,$uee_extra_words,$uee_extra_buttons);
hook_register('item_uee_extra','uee_extra_get_hack_num');hook_register('item_uee_extra','itemuse_uee_core');hook_register('item_uee_extra','itemuse_uee_extra_reset');hook_register('item_uee_extra','itemuse_uee_extra');
function ___post_init() { global $___PRIVATE_ITEM_UEE_EXTRA__VARS_____PRIVATE_PFUNC,$___PRIVATE_ITEM_UEE_EXTRA__VARS_____PRIVATE_CFUNC,$___LOCAL_ITEM_UEE_EXTRA__VARS__allow_uee_extra_gametype_num,$___LOCAL_ITEM_UEE_EXTRA__VARS__uee_extra_words,$___LOCAL_ITEM_UEE_EXTRA__VARS__uee_extra_buttons;
$___LOCAL_ITEM_UEE_EXTRA__VARS__allow_uee_extra_gametype_num=$GLOBALS['allow_uee_extra_gametype_num'];$___LOCAL_ITEM_UEE_EXTRA__VARS__uee_extra_words=$GLOBALS['uee_extra_words'];$___LOCAL_ITEM_UEE_EXTRA__VARS__uee_extra_buttons=$GLOBALS['uee_extra_buttons'];
unset($GLOBALS['allow_uee_extra_gametype_num'],$GLOBALS['uee_extra_words'],$GLOBALS['uee_extra_buttons']);
}
	
}

?>