<?php

namespace skill232
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill232/'.$___TEMP_key; 
	
	$___PRESET_SKILL232__VARS__shieldgain=$shieldgain;$___PRESET_SKILL232__VARS__shieldeff=$shieldeff;$___PRESET_SKILL232__VARS__upgradecost=$upgradecost;$___PRESET_SKILL232__VARS__skill232_cd=$skill232_cd;
function ___pre_init() { global $___PRESET_SKILL232__VARS__shieldgain,$shieldgain,$___PRESET_SKILL232__VARS__shieldeff,$shieldeff,$___PRESET_SKILL232__VARS__upgradecost,$upgradecost,$___PRESET_SKILL232__VARS__skill232_cd,$skill232_cd;$shieldgain=$___PRESET_SKILL232__VARS__shieldgain;$shieldeff=$___PRESET_SKILL232__VARS__shieldeff;$upgradecost=$___PRESET_SKILL232__VARS__upgradecost;$skill232_cd=$___PRESET_SKILL232__VARS__skill232_cd; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL232_PRESET_VARS','$___PRESET_SKILL232__VARS__shieldgain=$shieldgain;$___PRESET_SKILL232__VARS__shieldeff=$shieldeff;$___PRESET_SKILL232__VARS__upgradecost=$upgradecost;$___PRESET_SKILL232__VARS__skill232_cd=$skill232_cd;');
define('___LOAD_MOD_SKILL232_PRESET_VARS','global $___PRESET_SKILL232__VARS__shieldgain,$shieldgain,$___PRESET_SKILL232__VARS__shieldeff,$shieldeff,$___PRESET_SKILL232__VARS__upgradecost,$upgradecost,$___PRESET_SKILL232__VARS__skill232_cd,$skill232_cd;$shieldgain=$___PRESET_SKILL232__VARS__shieldgain;$shieldeff=$___PRESET_SKILL232__VARS__shieldeff;$upgradecost=$___PRESET_SKILL232__VARS__upgradecost;$skill232_cd=$___PRESET_SKILL232__VARS__skill232_cd;');
define('MOD_SKILL232_INFO','club;upgrade;locked;');
define('MOD_SKILL232_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill232/desc');
define('MODULE_SKILL232_GLOBALS_VARNAMES','shieldgain,shieldeff,upgradecost,skill232_cd');
define('MOD_SKILL232',1);
define('IMPORT_MODULE_SKILL232_GLOBALS','global $___LOCAL_SKILL232__VARS__shieldgain,$___LOCAL_SKILL232__VARS__shieldeff,$___LOCAL_SKILL232__VARS__upgradecost,$___LOCAL_SKILL232__VARS__skill232_cd; $shieldgain=&$___LOCAL_SKILL232__VARS__shieldgain; $shieldeff=&$___LOCAL_SKILL232__VARS__shieldeff; $upgradecost=&$___LOCAL_SKILL232__VARS__upgradecost; $skill232_cd=&$___LOCAL_SKILL232__VARS__skill232_cd; ');
define('PREFIX_MODULE_SKILL232_GLOBALS','\'; global $___LOCAL_SKILL232__VARS__shieldgain; ${$___TEMP_PREFIX.\'shieldgain\'}=&$___LOCAL_SKILL232__VARS__shieldgain; global $___LOCAL_SKILL232__VARS__shieldeff; ${$___TEMP_PREFIX.\'shieldeff\'}=&$___LOCAL_SKILL232__VARS__shieldeff; global $___LOCAL_SKILL232__VARS__upgradecost; ${$___TEMP_PREFIX.\'upgradecost\'}=&$___LOCAL_SKILL232__VARS__upgradecost; global $___LOCAL_SKILL232__VARS__skill232_cd; ${$___TEMP_PREFIX.\'skill232_cd\'}=&$___LOCAL_SKILL232__VARS__skill232_cd; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL232_GLOBALS','\'; global $___LOCAL_SKILL232__VARS__shieldgain; ${$___TEMP_VARNAME}[\'shieldgain\']=&$___LOCAL_SKILL232__VARS__shieldgain; global $___LOCAL_SKILL232__VARS__shieldeff; ${$___TEMP_VARNAME}[\'shieldeff\']=&$___LOCAL_SKILL232__VARS__shieldeff; global $___LOCAL_SKILL232__VARS__upgradecost; ${$___TEMP_VARNAME}[\'upgradecost\']=&$___LOCAL_SKILL232__VARS__upgradecost; global $___LOCAL_SKILL232__VARS__skill232_cd; ${$___TEMP_VARNAME}[\'skill232_cd\']=&$___LOCAL_SKILL232__VARS__skill232_cd; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL232__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL232__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL232__VARS__shieldgain,$___LOCAL_SKILL232__VARS__shieldeff,$___LOCAL_SKILL232__VARS__upgradecost,$___LOCAL_SKILL232__VARS__skill232_cd;
$___PRIVATE_SKILL232__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL232__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_SKILL232__VARS__shieldgain=&$shieldgain;$___LOCAL_SKILL232__VARS__shieldeff=&$shieldeff;$___LOCAL_SKILL232__VARS__upgradecost=&$upgradecost;$___LOCAL_SKILL232__VARS__skill232_cd=&$skill232_cd;
unset($shieldgain,$shieldeff,$upgradecost,$skill232_cd);
hook_register('skill232','acquire232');hook_register('skill232','lost232');hook_register('skill232','check_unlocked232');hook_register('skill232','upgrade232');hook_register('skill232','activate232');hook_register('skill232','check_skill232_state');hook_register('skill232','check_skill232_shield_on');hook_register('skill232','get_final_dmg_base');hook_register('skill232','calculate_hp_rev_dmg');hook_register('skill232','parse_news');
function ___post_init() { global $___PRIVATE_SKILL232__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL232__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL232__VARS__shieldgain,$___LOCAL_SKILL232__VARS__shieldeff,$___LOCAL_SKILL232__VARS__upgradecost,$___LOCAL_SKILL232__VARS__skill232_cd;
$___LOCAL_SKILL232__VARS__shieldgain=$GLOBALS['shieldgain'];$___LOCAL_SKILL232__VARS__shieldeff=$GLOBALS['shieldeff'];$___LOCAL_SKILL232__VARS__upgradecost=$GLOBALS['upgradecost'];$___LOCAL_SKILL232__VARS__skill232_cd=$GLOBALS['skill232_cd'];
unset($GLOBALS['shieldgain'],$GLOBALS['shieldeff'],$GLOBALS['upgradecost'],$GLOBALS['skill232_cd']);
}
	
}

?>