<?php

namespace skill1011
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/gmskills/skill1011/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL1011_PRESET_VARS','');
define('___LOAD_MOD_SKILL1011_PRESET_VARS','');
define('MOD_SKILL1011_INFO','active;unique;');
define('MOD_SKILL1011_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\gmskills\\skill1011/desc');
define('MOD_SKILL1011_PROFILECMD','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\gmskills\\skill1011/profilecmd');
define('MOD_SKILL1011_CONS_PAGE','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\gmskills\\skill1011/cons_page');
define('MODULE_SKILL1011_GLOBALS_VARNAMES','');
define('MOD_SKILL1011',1);
define('IMPORT_MODULE_SKILL1011_GLOBALS','');
define('PREFIX_MODULE_SKILL1011_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL1011_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL1011__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL1011__VARS_____PRIVATE_CFUNC;
$___PRIVATE_SKILL1011__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL1011__VARS_____PRIVATE_CFUNC=Array();

hook_register('skill1011','acquire1011');hook_register('skill1011','lost1011');hook_register('skill1011','check_unlocked1011');hook_register('skill1011','skill1011_load_itemlist');hook_register('skill1011','skill1011_parse_itemwords');hook_register('skill1011','skill1011_cons_page');hook_register('skill1011','act');hook_register('skill1011','parse_news');
function ___post_init() { global $___PRIVATE_SKILL1011__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL1011__VARS_____PRIVATE_CFUNC;


}
	
}

?>