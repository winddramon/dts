<?php

namespace armor
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'base/armor/'.$___TEMP_key; 
	
	$___PRESET_ARMOR__VARS__nosta=$nosta;$___PRESET_ARMOR__VARS__noarb=$noarb;$___PRESET_ARMOR__VARS__armor_equip_list=$armor_equip_list;$___PRESET_ARMOR__VARS__armor_iteminfo=$armor_iteminfo;
function ___pre_init() { global $___PRESET_ARMOR__VARS__nosta,$nosta,$___PRESET_ARMOR__VARS__noarb,$noarb,$___PRESET_ARMOR__VARS__armor_equip_list,$armor_equip_list,$___PRESET_ARMOR__VARS__armor_iteminfo,$armor_iteminfo;$nosta=$___PRESET_ARMOR__VARS__nosta;$noarb=$___PRESET_ARMOR__VARS__noarb;$armor_equip_list=$___PRESET_ARMOR__VARS__armor_equip_list;$armor_iteminfo=$___PRESET_ARMOR__VARS__armor_iteminfo; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_ARMOR_PRESET_VARS','$___PRESET_ARMOR__VARS__nosta=$nosta;$___PRESET_ARMOR__VARS__noarb=$noarb;$___PRESET_ARMOR__VARS__armor_equip_list=$armor_equip_list;$___PRESET_ARMOR__VARS__armor_iteminfo=$armor_iteminfo;');
define('___LOAD_MOD_ARMOR_PRESET_VARS','global $___PRESET_ARMOR__VARS__nosta,$nosta,$___PRESET_ARMOR__VARS__noarb,$noarb,$___PRESET_ARMOR__VARS__armor_equip_list,$armor_equip_list,$___PRESET_ARMOR__VARS__armor_iteminfo,$armor_iteminfo;$nosta=$___PRESET_ARMOR__VARS__nosta;$noarb=$___PRESET_ARMOR__VARS__noarb;$armor_equip_list=$___PRESET_ARMOR__VARS__armor_equip_list;$armor_iteminfo=$___PRESET_ARMOR__VARS__armor_iteminfo;');
define('MOD_ARMOR_PROFILE_ARMOR','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/base\\armor/profile_armor');
define('MOD_ARMOR_PROFILE_ARMOR_SHORT','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/base\\armor/profile_armor_short');
define('MODULE_ARMOR_GLOBALS_VARNAMES','nosta,noarb,armor_equip_list,armor_iteminfo');
define('MOD_ARMOR',1);
define('IMPORT_MODULE_ARMOR_GLOBALS','global $___LOCAL_ARMOR__VARS__nosta,$___LOCAL_ARMOR__VARS__noarb,$___LOCAL_ARMOR__VARS__armor_equip_list,$___LOCAL_ARMOR__VARS__armor_iteminfo; $nosta=&$___LOCAL_ARMOR__VARS__nosta; $noarb=&$___LOCAL_ARMOR__VARS__noarb; $armor_equip_list=&$___LOCAL_ARMOR__VARS__armor_equip_list; $armor_iteminfo=&$___LOCAL_ARMOR__VARS__armor_iteminfo; ');
define('PREFIX_MODULE_ARMOR_GLOBALS','\'; global $___LOCAL_ARMOR__VARS__nosta; ${$___TEMP_PREFIX.\'nosta\'}=&$___LOCAL_ARMOR__VARS__nosta; global $___LOCAL_ARMOR__VARS__noarb; ${$___TEMP_PREFIX.\'noarb\'}=&$___LOCAL_ARMOR__VARS__noarb; global $___LOCAL_ARMOR__VARS__armor_equip_list; ${$___TEMP_PREFIX.\'armor_equip_list\'}=&$___LOCAL_ARMOR__VARS__armor_equip_list; global $___LOCAL_ARMOR__VARS__armor_iteminfo; ${$___TEMP_PREFIX.\'armor_iteminfo\'}=&$___LOCAL_ARMOR__VARS__armor_iteminfo; unset($___TEMP_PREFIX); ');
define('MODULE_ARMOR_GLOBALS','\'; global $___LOCAL_ARMOR__VARS__nosta; ${$___TEMP_VARNAME}[\'nosta\']=&$___LOCAL_ARMOR__VARS__nosta; global $___LOCAL_ARMOR__VARS__noarb; ${$___TEMP_VARNAME}[\'noarb\']=&$___LOCAL_ARMOR__VARS__noarb; global $___LOCAL_ARMOR__VARS__armor_equip_list; ${$___TEMP_VARNAME}[\'armor_equip_list\']=&$___LOCAL_ARMOR__VARS__armor_equip_list; global $___LOCAL_ARMOR__VARS__armor_iteminfo; ${$___TEMP_VARNAME}[\'armor_iteminfo\']=&$___LOCAL_ARMOR__VARS__armor_iteminfo; unset($___TEMP_VARNAME); ');

global $___PRIVATE_ARMOR__VARS_____PRIVATE_PFUNC,$___PRIVATE_ARMOR__VARS_____PRIVATE_CFUNC,$___LOCAL_ARMOR__VARS__nosta,$___LOCAL_ARMOR__VARS__noarb,$___LOCAL_ARMOR__VARS__armor_equip_list,$___LOCAL_ARMOR__VARS__armor_iteminfo;
$___PRIVATE_ARMOR__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_ARMOR__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_ARMOR__VARS__nosta=&$nosta;$___LOCAL_ARMOR__VARS__noarb=&$noarb;$___LOCAL_ARMOR__VARS__armor_equip_list=&$armor_equip_list;$___LOCAL_ARMOR__VARS__armor_iteminfo=&$armor_iteminfo;
unset($nosta,$noarb,$armor_equip_list,$armor_iteminfo);
hook_register('armor','get_external_def_multiplier');hook_register('armor','get_external_def');hook_register('armor','get_def_base');hook_register('armor','armor_break');hook_register('armor','armor_hurt');hook_register('armor','apply_weapon_inf');hook_register('armor','use_armor');hook_register('armor','itemuse');hook_register('armor','assault_prepare');hook_register('armor','assault_finish');
function ___post_init() { global $___PRIVATE_ARMOR__VARS_____PRIVATE_PFUNC,$___PRIVATE_ARMOR__VARS_____PRIVATE_CFUNC,$___LOCAL_ARMOR__VARS__nosta,$___LOCAL_ARMOR__VARS__noarb,$___LOCAL_ARMOR__VARS__armor_equip_list,$___LOCAL_ARMOR__VARS__armor_iteminfo;
$___LOCAL_ARMOR__VARS__nosta=$GLOBALS['nosta'];$___LOCAL_ARMOR__VARS__noarb=$GLOBALS['noarb'];$___LOCAL_ARMOR__VARS__armor_equip_list=$GLOBALS['armor_equip_list'];$___LOCAL_ARMOR__VARS__armor_iteminfo=$GLOBALS['armor_iteminfo'];
unset($GLOBALS['nosta'],$GLOBALS['noarb'],$GLOBALS['armor_equip_list'],$GLOBALS['armor_iteminfo']);
}
	
}

?>