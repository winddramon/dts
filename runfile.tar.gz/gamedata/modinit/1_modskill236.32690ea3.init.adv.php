<?php

namespace skill236
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill236/'.$___TEMP_key; 
	
	$___PRESET_SKILL236__VARS__ragecost=$ragecost;$___PRESET_SKILL236__VARS__stuntime236=$stuntime236;
function ___pre_init() { global $___PRESET_SKILL236__VARS__ragecost,$ragecost,$___PRESET_SKILL236__VARS__stuntime236,$stuntime236;$ragecost=$___PRESET_SKILL236__VARS__ragecost;$stuntime236=$___PRESET_SKILL236__VARS__stuntime236; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL236_PRESET_VARS','$___PRESET_SKILL236__VARS__ragecost=$ragecost;$___PRESET_SKILL236__VARS__stuntime236=$stuntime236;');
define('___LOAD_MOD_SKILL236_PRESET_VARS','global $___PRESET_SKILL236__VARS__ragecost,$ragecost,$___PRESET_SKILL236__VARS__stuntime236,$stuntime236;$ragecost=$___PRESET_SKILL236__VARS__ragecost;$stuntime236=$___PRESET_SKILL236__VARS__stuntime236;');
define('MOD_SKILL236_INFO','club;battle;');
define('MOD_SKILL236_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill236/desc');
define('MOD_SKILL236_BATTLECMD_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill236/battlecmd_desc');
define('MODULE_SKILL236_GLOBALS_VARNAMES','ragecost,stuntime236');
define('MOD_SKILL236',1);
define('IMPORT_MODULE_SKILL236_GLOBALS','global $___LOCAL_SKILL236__VARS__ragecost,$___LOCAL_SKILL236__VARS__stuntime236; $ragecost=&$___LOCAL_SKILL236__VARS__ragecost; $stuntime236=&$___LOCAL_SKILL236__VARS__stuntime236; ');
define('PREFIX_MODULE_SKILL236_GLOBALS','\'; global $___LOCAL_SKILL236__VARS__ragecost; ${$___TEMP_PREFIX.\'ragecost\'}=&$___LOCAL_SKILL236__VARS__ragecost; global $___LOCAL_SKILL236__VARS__stuntime236; ${$___TEMP_PREFIX.\'stuntime236\'}=&$___LOCAL_SKILL236__VARS__stuntime236; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL236_GLOBALS','\'; global $___LOCAL_SKILL236__VARS__ragecost; ${$___TEMP_VARNAME}[\'ragecost\']=&$___LOCAL_SKILL236__VARS__ragecost; global $___LOCAL_SKILL236__VARS__stuntime236; ${$___TEMP_VARNAME}[\'stuntime236\']=&$___LOCAL_SKILL236__VARS__stuntime236; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL236__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL236__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL236__VARS__ragecost,$___LOCAL_SKILL236__VARS__stuntime236;
$___PRIVATE_SKILL236__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL236__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_SKILL236__VARS__ragecost=&$ragecost;$___LOCAL_SKILL236__VARS__stuntime236=&$stuntime236;
unset($ragecost,$stuntime236);
hook_register('skill236','acquire236');hook_register('skill236','lost236');hook_register('skill236','check_unlocked236');hook_register('skill236','get_rage_cost236');hook_register('skill236','strike_prepare');hook_register('skill236','get_fixed_dmg');hook_register('skill236','parse_news');
function ___post_init() { global $___PRIVATE_SKILL236__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL236__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL236__VARS__ragecost,$___LOCAL_SKILL236__VARS__stuntime236;
$___LOCAL_SKILL236__VARS__ragecost=$GLOBALS['ragecost'];$___LOCAL_SKILL236__VARS__stuntime236=$GLOBALS['stuntime236'];
unset($GLOBALS['ragecost'],$GLOBALS['stuntime236']);
}
	
}

?>