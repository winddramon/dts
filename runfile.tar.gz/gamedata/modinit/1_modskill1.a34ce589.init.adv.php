<?php

namespace skill1
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'base/skills/skill1/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL1_PRESET_VARS','');
define('___LOAD_MOD_SKILL1_PRESET_VARS','');
define('MODULE_SKILL1_GLOBALS_VARNAMES','');
define('MOD_SKILL1',1);
define('IMPORT_MODULE_SKILL1_GLOBALS','');
define('PREFIX_MODULE_SKILL1_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL1_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL1__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL1__VARS_____PRIVATE_CFUNC;
$___PRIVATE_SKILL1__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL1__VARS_____PRIVATE_CFUNC=Array();

hook_register('skill1','acquire1');hook_register('skill1','lost1');hook_register('skill1','skill_onload_event');hook_register('skill1','skill_onsave_event');hook_register('skill1','get_def_multiplier');hook_register('skill1','calculate_rest_upsp');hook_register('skill1','calculate_rest_uphp');hook_register('skill1','get_wound_recover_time');
function ___post_init() { global $___PRIVATE_SKILL1__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL1__VARS_____PRIVATE_CFUNC;


}
	
}

?>