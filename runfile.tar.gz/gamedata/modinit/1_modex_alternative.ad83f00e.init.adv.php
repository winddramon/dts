<?php

namespace ex_alternative
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/attr/ex_alternative/'.$___TEMP_key; 
	
	$___PRESET_EX_ALTERNATIVE__VARS__tmp_ex_alternative_atype=$tmp_ex_alternative_atype;
function ___pre_init() { global $___PRESET_EX_ALTERNATIVE__VARS__tmp_ex_alternative_atype,$tmp_ex_alternative_atype;$tmp_ex_alternative_atype=$___PRESET_EX_ALTERNATIVE__VARS__tmp_ex_alternative_atype; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_EX_ALTERNATIVE_PRESET_VARS','$___PRESET_EX_ALTERNATIVE__VARS__tmp_ex_alternative_atype=$tmp_ex_alternative_atype;');
define('___LOAD_MOD_EX_ALTERNATIVE_PRESET_VARS','global $___PRESET_EX_ALTERNATIVE__VARS__tmp_ex_alternative_atype,$tmp_ex_alternative_atype;$tmp_ex_alternative_atype=$___PRESET_EX_ALTERNATIVE__VARS__tmp_ex_alternative_atype;');
define('MOD_EX_ALTERNATIVE_USE_ALTERNATIVE','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\attr\\ex_alternative/use_alternative');
define('MODULE_EX_ALTERNATIVE_GLOBALS_VARNAMES','tmp_ex_alternative_atype');
define('MOD_EX_ALTERNATIVE',1);
define('IMPORT_MODULE_EX_ALTERNATIVE_GLOBALS','global $___LOCAL_EX_ALTERNATIVE__VARS__tmp_ex_alternative_atype; $tmp_ex_alternative_atype=&$___LOCAL_EX_ALTERNATIVE__VARS__tmp_ex_alternative_atype; ');
define('PREFIX_MODULE_EX_ALTERNATIVE_GLOBALS','\'; global $___LOCAL_EX_ALTERNATIVE__VARS__tmp_ex_alternative_atype; ${$___TEMP_PREFIX.\'tmp_ex_alternative_atype\'}=&$___LOCAL_EX_ALTERNATIVE__VARS__tmp_ex_alternative_atype; unset($___TEMP_PREFIX); ');
define('MODULE_EX_ALTERNATIVE_GLOBALS','\'; global $___LOCAL_EX_ALTERNATIVE__VARS__tmp_ex_alternative_atype; ${$___TEMP_VARNAME}[\'tmp_ex_alternative_atype\']=&$___LOCAL_EX_ALTERNATIVE__VARS__tmp_ex_alternative_atype; unset($___TEMP_VARNAME); ');

global $___PRIVATE_EX_ALTERNATIVE__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_ALTERNATIVE__VARS_____PRIVATE_CFUNC,$___LOCAL_EX_ALTERNATIVE__VARS__tmp_ex_alternative_atype;
$___PRIVATE_EX_ALTERNATIVE__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_EX_ALTERNATIVE__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_EX_ALTERNATIVE__VARS__tmp_ex_alternative_atype=&$tmp_ex_alternative_atype;
unset($tmp_ex_alternative_atype);
hook_register('ex_alternative','get_altlist');hook_register('ex_alternative','alt_change');hook_register('ex_alternative','itemuse');hook_register('ex_alternative','get_altwords');hook_register('ex_alternative','get_itmsk_desc_single_comp_process');hook_register('ex_alternative','check_comp_itmsk_visible');hook_register('ex_alternative','parse_itmsk_desc');
function ___post_init() { global $___PRIVATE_EX_ALTERNATIVE__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_ALTERNATIVE__VARS_____PRIVATE_CFUNC,$___LOCAL_EX_ALTERNATIVE__VARS__tmp_ex_alternative_atype;
$___LOCAL_EX_ALTERNATIVE__VARS__tmp_ex_alternative_atype=$GLOBALS['tmp_ex_alternative_atype'];
unset($GLOBALS['tmp_ex_alternative_atype']);
}
	
}

?>