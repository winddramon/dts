<?php

namespace item_slip
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/item_extra/item_slip/'.$___TEMP_key; 
	
	$___PRESET_ITEM_SLIP__VARS__item_slip_npclist=$item_slip_npclist;$___PRESET_ITEM_SLIP__VARS__item_slip_hint=$item_slip_hint;$___PRESET_ITEM_SLIP__VARS__item_slip_npc=$item_slip_npc;$___PRESET_ITEM_SLIP__VARS__item_slip_metagame_list=$item_slip_metagame_list;
function ___pre_init() { global $___PRESET_ITEM_SLIP__VARS__item_slip_npclist,$item_slip_npclist,$___PRESET_ITEM_SLIP__VARS__item_slip_hint,$item_slip_hint,$___PRESET_ITEM_SLIP__VARS__item_slip_npc,$item_slip_npc,$___PRESET_ITEM_SLIP__VARS__item_slip_metagame_list,$item_slip_metagame_list;$item_slip_npclist=$___PRESET_ITEM_SLIP__VARS__item_slip_npclist;$item_slip_hint=$___PRESET_ITEM_SLIP__VARS__item_slip_hint;$item_slip_npc=$___PRESET_ITEM_SLIP__VARS__item_slip_npc;$item_slip_metagame_list=$___PRESET_ITEM_SLIP__VARS__item_slip_metagame_list; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_ITEM_SLIP_PRESET_VARS','$___PRESET_ITEM_SLIP__VARS__item_slip_npclist=$item_slip_npclist;$___PRESET_ITEM_SLIP__VARS__item_slip_hint=$item_slip_hint;$___PRESET_ITEM_SLIP__VARS__item_slip_npc=$item_slip_npc;$___PRESET_ITEM_SLIP__VARS__item_slip_metagame_list=$item_slip_metagame_list;');
define('___LOAD_MOD_ITEM_SLIP_PRESET_VARS','global $___PRESET_ITEM_SLIP__VARS__item_slip_npclist,$item_slip_npclist,$___PRESET_ITEM_SLIP__VARS__item_slip_hint,$item_slip_hint,$___PRESET_ITEM_SLIP__VARS__item_slip_npc,$item_slip_npc,$___PRESET_ITEM_SLIP__VARS__item_slip_metagame_list,$item_slip_metagame_list;$item_slip_npclist=$___PRESET_ITEM_SLIP__VARS__item_slip_npclist;$item_slip_hint=$___PRESET_ITEM_SLIP__VARS__item_slip_hint;$item_slip_npc=$___PRESET_ITEM_SLIP__VARS__item_slip_npc;$item_slip_metagame_list=$___PRESET_ITEM_SLIP__VARS__item_slip_metagame_list;');
define('MODULE_ITEM_SLIP_GLOBALS_VARNAMES','item_slip_npclist,item_slip_hint,item_slip_npc,item_slip_metagame_list');
define('MOD_ITEM_SLIP',1);
define('IMPORT_MODULE_ITEM_SLIP_GLOBALS','global $___LOCAL_ITEM_SLIP__VARS__item_slip_npclist,$___LOCAL_ITEM_SLIP__VARS__item_slip_hint,$___LOCAL_ITEM_SLIP__VARS__item_slip_npc,$___LOCAL_ITEM_SLIP__VARS__item_slip_metagame_list; $item_slip_npclist=&$___LOCAL_ITEM_SLIP__VARS__item_slip_npclist; $item_slip_hint=&$___LOCAL_ITEM_SLIP__VARS__item_slip_hint; $item_slip_npc=&$___LOCAL_ITEM_SLIP__VARS__item_slip_npc; $item_slip_metagame_list=&$___LOCAL_ITEM_SLIP__VARS__item_slip_metagame_list; ');
define('PREFIX_MODULE_ITEM_SLIP_GLOBALS','\'; global $___LOCAL_ITEM_SLIP__VARS__item_slip_npclist; ${$___TEMP_PREFIX.\'item_slip_npclist\'}=&$___LOCAL_ITEM_SLIP__VARS__item_slip_npclist; global $___LOCAL_ITEM_SLIP__VARS__item_slip_hint; ${$___TEMP_PREFIX.\'item_slip_hint\'}=&$___LOCAL_ITEM_SLIP__VARS__item_slip_hint; global $___LOCAL_ITEM_SLIP__VARS__item_slip_npc; ${$___TEMP_PREFIX.\'item_slip_npc\'}=&$___LOCAL_ITEM_SLIP__VARS__item_slip_npc; global $___LOCAL_ITEM_SLIP__VARS__item_slip_metagame_list; ${$___TEMP_PREFIX.\'item_slip_metagame_list\'}=&$___LOCAL_ITEM_SLIP__VARS__item_slip_metagame_list; unset($___TEMP_PREFIX); ');
define('MODULE_ITEM_SLIP_GLOBALS','\'; global $___LOCAL_ITEM_SLIP__VARS__item_slip_npclist; ${$___TEMP_VARNAME}[\'item_slip_npclist\']=&$___LOCAL_ITEM_SLIP__VARS__item_slip_npclist; global $___LOCAL_ITEM_SLIP__VARS__item_slip_hint; ${$___TEMP_VARNAME}[\'item_slip_hint\']=&$___LOCAL_ITEM_SLIP__VARS__item_slip_hint; global $___LOCAL_ITEM_SLIP__VARS__item_slip_npc; ${$___TEMP_VARNAME}[\'item_slip_npc\']=&$___LOCAL_ITEM_SLIP__VARS__item_slip_npc; global $___LOCAL_ITEM_SLIP__VARS__item_slip_metagame_list; ${$___TEMP_VARNAME}[\'item_slip_metagame_list\']=&$___LOCAL_ITEM_SLIP__VARS__item_slip_metagame_list; unset($___TEMP_VARNAME); ');

global $___PRIVATE_ITEM_SLIP__VARS_____PRIVATE_PFUNC,$___PRIVATE_ITEM_SLIP__VARS_____PRIVATE_CFUNC,$___LOCAL_ITEM_SLIP__VARS__item_slip_npclist,$___LOCAL_ITEM_SLIP__VARS__item_slip_hint,$___LOCAL_ITEM_SLIP__VARS__item_slip_npc,$___LOCAL_ITEM_SLIP__VARS__item_slip_metagame_list;
$___PRIVATE_ITEM_SLIP__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_ITEM_SLIP__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_ITEM_SLIP__VARS__item_slip_npclist=&$item_slip_npclist;$___LOCAL_ITEM_SLIP__VARS__item_slip_hint=&$item_slip_hint;$___LOCAL_ITEM_SLIP__VARS__item_slip_npc=&$item_slip_npc;$___LOCAL_ITEM_SLIP__VARS__item_slip_metagame_list=&$item_slip_metagame_list;
unset($item_slip_npclist,$item_slip_hint,$item_slip_npc,$item_slip_metagame_list);
hook_register('item_slip','parse_itmuse_desc');hook_register('item_slip','itemuse');hook_register('item_slip','mapitem_single_data_attr_process');hook_register('item_slip','item_slip_set_puzzle');hook_register('item_slip','get_mixinfo');hook_register('item_slip','item_slip_get_puzzle');hook_register('item_slip','post_gameover_events');hook_register('item_slip','evonpc_npcdata_process');
function ___post_init() { global $___PRIVATE_ITEM_SLIP__VARS_____PRIVATE_PFUNC,$___PRIVATE_ITEM_SLIP__VARS_____PRIVATE_CFUNC,$___LOCAL_ITEM_SLIP__VARS__item_slip_npclist,$___LOCAL_ITEM_SLIP__VARS__item_slip_hint,$___LOCAL_ITEM_SLIP__VARS__item_slip_npc,$___LOCAL_ITEM_SLIP__VARS__item_slip_metagame_list;
$___LOCAL_ITEM_SLIP__VARS__item_slip_npclist=$GLOBALS['item_slip_npclist'];$___LOCAL_ITEM_SLIP__VARS__item_slip_hint=$GLOBALS['item_slip_hint'];$___LOCAL_ITEM_SLIP__VARS__item_slip_npc=$GLOBALS['item_slip_npc'];$___LOCAL_ITEM_SLIP__VARS__item_slip_metagame_list=$GLOBALS['item_slip_metagame_list'];
unset($GLOBALS['item_slip_npclist'],$GLOBALS['item_slip_hint'],$GLOBALS['item_slip_npc'],$GLOBALS['item_slip_metagame_list']);
}
	
}

?>