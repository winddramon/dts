<?php

namespace skill182
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill182/'.$___TEMP_key; 
	
	$___PRESET_SKILL182__VARS__tmp_hint182=$tmp_hint182;
function ___pre_init() { global $___PRESET_SKILL182__VARS__tmp_hint182,$tmp_hint182;$tmp_hint182=$___PRESET_SKILL182__VARS__tmp_hint182; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL182_PRESET_VARS','$___PRESET_SKILL182__VARS__tmp_hint182=$tmp_hint182;');
define('___LOAD_MOD_SKILL182_PRESET_VARS','global $___PRESET_SKILL182__VARS__tmp_hint182,$tmp_hint182;$tmp_hint182=$___PRESET_SKILL182__VARS__tmp_hint182;');
define('MOD_SKILL182_INFO','club;hidden;');
define('MODULE_SKILL182_GLOBALS_VARNAMES','tmp_hint182');
define('MOD_SKILL182',1);
define('IMPORT_MODULE_SKILL182_GLOBALS','global $___LOCAL_SKILL182__VARS__tmp_hint182; $tmp_hint182=&$___LOCAL_SKILL182__VARS__tmp_hint182; ');
define('PREFIX_MODULE_SKILL182_GLOBALS','\'; global $___LOCAL_SKILL182__VARS__tmp_hint182; ${$___TEMP_PREFIX.\'tmp_hint182\'}=&$___LOCAL_SKILL182__VARS__tmp_hint182; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL182_GLOBALS','\'; global $___LOCAL_SKILL182__VARS__tmp_hint182; ${$___TEMP_VARNAME}[\'tmp_hint182\']=&$___LOCAL_SKILL182__VARS__tmp_hint182; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL182__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL182__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL182__VARS__tmp_hint182;
$___PRIVATE_SKILL182__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL182__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_SKILL182__VARS__tmp_hint182=&$tmp_hint182;
unset($tmp_hint182);
hook_register('skill182','acquire182');hook_register('skill182','lost182');hook_register('skill182','ss_record_tempbuff');hook_register('skill182','bufficons_check_buff_state');hook_register('skill182','bufficons_display_single');hook_register('skill182','show_songbuff_hint');hook_register('skill182','skill_onload_event');hook_register('skill182','act');hook_register('skill182','ss_sing');hook_register('skill182','init_songbuff_timing_process');hook_register('skill182','init_songbuff_timing');
function ___post_init() { global $___PRIVATE_SKILL182__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL182__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL182__VARS__tmp_hint182;
$___LOCAL_SKILL182__VARS__tmp_hint182=$GLOBALS['tmp_hint182'];
unset($GLOBALS['tmp_hint182']);
}
	
}

?>