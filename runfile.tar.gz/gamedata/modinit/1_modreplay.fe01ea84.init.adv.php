<?php

namespace replay
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/misc/replay/'.$___TEMP_key; 
	
	$___PRESET_REPLAY__VARS__partsize=$partsize;
function ___pre_init() { global $___PRESET_REPLAY__VARS__partsize,$partsize;$partsize=$___PRESET_REPLAY__VARS__partsize; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_REPLAY_PRESET_VARS','$___PRESET_REPLAY__VARS__partsize=$partsize;');
define('___LOAD_MOD_REPLAY_PRESET_VARS','global $___PRESET_REPLAY__VARS__partsize,$partsize;$partsize=$___PRESET_REPLAY__VARS__partsize;');
define('MOD_REPLAY_GNUM_NO_REPLAY','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\misc\\replay/gnum_no_replay');
define('MOD_REPLAY_GNUM_DATA','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\misc\\replay/gnum_data');
define('MODULE_REPLAY_GLOBALS_VARNAMES','partsize');
define('MOD_REPLAY',1);
define('IMPORT_MODULE_REPLAY_GLOBALS','global $___LOCAL_REPLAY__VARS__partsize; $partsize=&$___LOCAL_REPLAY__VARS__partsize; ');
define('PREFIX_MODULE_REPLAY_GLOBALS','\'; global $___LOCAL_REPLAY__VARS__partsize; ${$___TEMP_PREFIX.\'partsize\'}=&$___LOCAL_REPLAY__VARS__partsize; unset($___TEMP_PREFIX); ');
define('MODULE_REPLAY_GLOBALS','\'; global $___LOCAL_REPLAY__VARS__partsize; ${$___TEMP_VARNAME}[\'partsize\']=&$___LOCAL_REPLAY__VARS__partsize; unset($___TEMP_VARNAME); ');

global $___PRIVATE_REPLAY__VARS_____PRIVATE_PFUNC,$___PRIVATE_REPLAY__VARS_____PRIVATE_CFUNC,$___LOCAL_REPLAY__VARS__partsize;
$___PRIVATE_REPLAY__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_REPLAY__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_REPLAY__VARS__partsize=&$partsize;
unset($partsize);
hook_register('replay','get_html_color');hook_register('replay','get_ident_textcolor');hook_register('replay','post_gameover_events');hook_register('replay','replay_validify_record');hook_register('replay','replay_record_op');hook_register('replay','get_replay_by_gnum');hook_register('replay','get_replay_remote');
function ___post_init() { global $___PRIVATE_REPLAY__VARS_____PRIVATE_PFUNC,$___PRIVATE_REPLAY__VARS_____PRIVATE_CFUNC,$___LOCAL_REPLAY__VARS__partsize;
$___LOCAL_REPLAY__VARS__partsize=$GLOBALS['partsize'];
unset($GLOBALS['partsize']);
}
	
}

?>