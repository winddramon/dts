<?php

namespace skill214
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill214/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL214_PRESET_VARS','');
define('___LOAD_MOD_SKILL214_PRESET_VARS','');
define('MOD_SKILL214_INFO','club;upgrade;');
define('MOD_SKILL214_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill214/desc');
define('MODULE_SKILL214_GLOBALS_VARNAMES','');
define('MOD_SKILL214',1);
define('IMPORT_MODULE_SKILL214_GLOBALS','');
define('PREFIX_MODULE_SKILL214_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL214_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL214__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL214__VARS_____PRIVATE_CFUNC;
$___PRIVATE_SKILL214__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL214__VARS_____PRIVATE_CFUNC=Array();

hook_register('skill214','acquire214');hook_register('skill214','lost214');hook_register('skill214','check_unlocked214');hook_register('skill214','upgrade214');hook_register('skill214','calculate_itemfind_obbs_multiplier');hook_register('skill214','calculate_meetman_rate');
function ___post_init() { global $___PRIVATE_SKILL214__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL214__VARS_____PRIVATE_CFUNC;


}
	
}

?>