<?php

namespace gtype1
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/instance/gtype1/main/'.$___TEMP_key; 
	
	$___PRESET_GTYPE1__VARS__npcinfo_gtype1=$npcinfo_gtype1;$___PRESET_GTYPE1__VARS__enpcinfo_gtype1=$enpcinfo_gtype1;
function ___pre_init() { global $___PRESET_GTYPE1__VARS__npcinfo_gtype1,$npcinfo_gtype1,$___PRESET_GTYPE1__VARS__enpcinfo_gtype1,$enpcinfo_gtype1;$npcinfo_gtype1=$___PRESET_GTYPE1__VARS__npcinfo_gtype1;$enpcinfo_gtype1=$___PRESET_GTYPE1__VARS__enpcinfo_gtype1; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_GTYPE1_PRESET_VARS','$___PRESET_GTYPE1__VARS__npcinfo_gtype1=$npcinfo_gtype1;$___PRESET_GTYPE1__VARS__enpcinfo_gtype1=$enpcinfo_gtype1;');
define('___LOAD_MOD_GTYPE1_PRESET_VARS','global $___PRESET_GTYPE1__VARS__npcinfo_gtype1,$npcinfo_gtype1,$___PRESET_GTYPE1__VARS__enpcinfo_gtype1,$enpcinfo_gtype1;$npcinfo_gtype1=$___PRESET_GTYPE1__VARS__npcinfo_gtype1;$enpcinfo_gtype1=$___PRESET_GTYPE1__VARS__enpcinfo_gtype1;');
define('MOD_GTYPE1_SHOWHACKLEVEL','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\instance\\gtype1\\main/showhacklevel');
define('MODULE_GTYPE1_GLOBALS_VARNAMES','npcinfo_gtype1,enpcinfo_gtype1');
define('MOD_GTYPE1',1);
define('IMPORT_MODULE_GTYPE1_GLOBALS','global $___LOCAL_GTYPE1__VARS__npcinfo_gtype1,$___LOCAL_GTYPE1__VARS__enpcinfo_gtype1; $npcinfo_gtype1=&$___LOCAL_GTYPE1__VARS__npcinfo_gtype1; $enpcinfo_gtype1=&$___LOCAL_GTYPE1__VARS__enpcinfo_gtype1; ');
define('PREFIX_MODULE_GTYPE1_GLOBALS','\'; global $___LOCAL_GTYPE1__VARS__npcinfo_gtype1; ${$___TEMP_PREFIX.\'npcinfo_gtype1\'}=&$___LOCAL_GTYPE1__VARS__npcinfo_gtype1; global $___LOCAL_GTYPE1__VARS__enpcinfo_gtype1; ${$___TEMP_PREFIX.\'enpcinfo_gtype1\'}=&$___LOCAL_GTYPE1__VARS__enpcinfo_gtype1; unset($___TEMP_PREFIX); ');
define('MODULE_GTYPE1_GLOBALS','\'; global $___LOCAL_GTYPE1__VARS__npcinfo_gtype1; ${$___TEMP_VARNAME}[\'npcinfo_gtype1\']=&$___LOCAL_GTYPE1__VARS__npcinfo_gtype1; global $___LOCAL_GTYPE1__VARS__enpcinfo_gtype1; ${$___TEMP_VARNAME}[\'enpcinfo_gtype1\']=&$___LOCAL_GTYPE1__VARS__enpcinfo_gtype1; unset($___TEMP_VARNAME); ');

global $___PRIVATE_GTYPE1__VARS_____PRIVATE_PFUNC,$___PRIVATE_GTYPE1__VARS_____PRIVATE_CFUNC,$___LOCAL_GTYPE1__VARS__npcinfo_gtype1,$___LOCAL_GTYPE1__VARS__enpcinfo_gtype1;
$___PRIVATE_GTYPE1__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_GTYPE1__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_GTYPE1__VARS__npcinfo_gtype1=&$npcinfo_gtype1;$___LOCAL_GTYPE1__VARS__enpcinfo_gtype1=&$enpcinfo_gtype1;
unset($npcinfo_gtype1,$enpcinfo_gtype1);
hook_register('gtype1','get_enter_battlefield_card');hook_register('gtype1','card_validate_get_forbidden_cards');hook_register('gtype1','card_validate_display');hook_register('gtype1','prepare_new_game');hook_register('gtype1','get_uee_deathlog');hook_register('gtype1','prepare_new_game_gtype1');hook_register('gtype1','check_player_discover');hook_register('gtype1','get_npclist');hook_register('gtype1','get_enpcinfo');hook_register('gtype1','get_shopconfig');hook_register('gtype1','meetman_alternative');hook_register('gtype1','calculate_hide_obbs');hook_register('gtype1','senditem_check_teammate');hook_register('gtype1','checkcombo');hook_register('gtype1','rs_game');hook_register('gtype1','gtype1_post_rank_event');hook_register('gtype1','check_addarea_gameover');hook_register('gtype1','lvlup');hook_register('gtype1','event_available');hook_register('gtype1','parse_news');hook_register('gtype1','check_can_destroy');hook_register('gtype1','deathnote_process');
function ___post_init() { global $___PRIVATE_GTYPE1__VARS_____PRIVATE_PFUNC,$___PRIVATE_GTYPE1__VARS_____PRIVATE_CFUNC,$___LOCAL_GTYPE1__VARS__npcinfo_gtype1,$___LOCAL_GTYPE1__VARS__enpcinfo_gtype1;
$___LOCAL_GTYPE1__VARS__npcinfo_gtype1=$GLOBALS['npcinfo_gtype1'];$___LOCAL_GTYPE1__VARS__enpcinfo_gtype1=$GLOBALS['enpcinfo_gtype1'];
unset($GLOBALS['npcinfo_gtype1'],$GLOBALS['enpcinfo_gtype1']);
}
	
}

?>