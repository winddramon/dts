<?php

namespace instance11
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/instance/instance11_observe/'.$___TEMP_key; 
	
	$___PRESET_INSTANCE11__VARS__plsinfo11=$plsinfo11;$___PRESET_INSTANCE11__VARS__npcinfo_instance11=$npcinfo_instance11;$___PRESET_INSTANCE11__VARS__shops11=$shops11;$___PRESET_INSTANCE11__VARS__shop_tag_list11=$shop_tag_list11;
function ___pre_init() { global $___PRESET_INSTANCE11__VARS__plsinfo11,$plsinfo11,$___PRESET_INSTANCE11__VARS__npcinfo_instance11,$npcinfo_instance11,$___PRESET_INSTANCE11__VARS__shops11,$shops11,$___PRESET_INSTANCE11__VARS__shop_tag_list11,$shop_tag_list11;$plsinfo11=$___PRESET_INSTANCE11__VARS__plsinfo11;$npcinfo_instance11=$___PRESET_INSTANCE11__VARS__npcinfo_instance11;$shops11=$___PRESET_INSTANCE11__VARS__shops11;$shop_tag_list11=$___PRESET_INSTANCE11__VARS__shop_tag_list11; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_INSTANCE11_PRESET_VARS','$___PRESET_INSTANCE11__VARS__plsinfo11=$plsinfo11;$___PRESET_INSTANCE11__VARS__npcinfo_instance11=$npcinfo_instance11;$___PRESET_INSTANCE11__VARS__shops11=$shops11;$___PRESET_INSTANCE11__VARS__shop_tag_list11=$shop_tag_list11;');
define('___LOAD_MOD_INSTANCE11_PRESET_VARS','global $___PRESET_INSTANCE11__VARS__plsinfo11,$plsinfo11,$___PRESET_INSTANCE11__VARS__npcinfo_instance11,$npcinfo_instance11,$___PRESET_INSTANCE11__VARS__shops11,$shops11,$___PRESET_INSTANCE11__VARS__shop_tag_list11,$shop_tag_list11;$plsinfo11=$___PRESET_INSTANCE11__VARS__plsinfo11;$npcinfo_instance11=$___PRESET_INSTANCE11__VARS__npcinfo_instance11;$shops11=$___PRESET_INSTANCE11__VARS__shops11;$shop_tag_list11=$___PRESET_INSTANCE11__VARS__shop_tag_list11;');
define('MODULE_INSTANCE11_GLOBALS_VARNAMES','plsinfo11,npcinfo_instance11,shops11,shop_tag_list11');
define('MOD_INSTANCE11',1);
define('IMPORT_MODULE_INSTANCE11_GLOBALS','global $___LOCAL_INSTANCE11__VARS__plsinfo11,$___LOCAL_INSTANCE11__VARS__npcinfo_instance11,$___LOCAL_INSTANCE11__VARS__shops11,$___LOCAL_INSTANCE11__VARS__shop_tag_list11; $plsinfo11=&$___LOCAL_INSTANCE11__VARS__plsinfo11; $npcinfo_instance11=&$___LOCAL_INSTANCE11__VARS__npcinfo_instance11; $shops11=&$___LOCAL_INSTANCE11__VARS__shops11; $shop_tag_list11=&$___LOCAL_INSTANCE11__VARS__shop_tag_list11; ');
define('PREFIX_MODULE_INSTANCE11_GLOBALS','\'; global $___LOCAL_INSTANCE11__VARS__plsinfo11; ${$___TEMP_PREFIX.\'plsinfo11\'}=&$___LOCAL_INSTANCE11__VARS__plsinfo11; global $___LOCAL_INSTANCE11__VARS__npcinfo_instance11; ${$___TEMP_PREFIX.\'npcinfo_instance11\'}=&$___LOCAL_INSTANCE11__VARS__npcinfo_instance11; global $___LOCAL_INSTANCE11__VARS__shops11; ${$___TEMP_PREFIX.\'shops11\'}=&$___LOCAL_INSTANCE11__VARS__shops11; global $___LOCAL_INSTANCE11__VARS__shop_tag_list11; ${$___TEMP_PREFIX.\'shop_tag_list11\'}=&$___LOCAL_INSTANCE11__VARS__shop_tag_list11; unset($___TEMP_PREFIX); ');
define('MODULE_INSTANCE11_GLOBALS','\'; global $___LOCAL_INSTANCE11__VARS__plsinfo11; ${$___TEMP_VARNAME}[\'plsinfo11\']=&$___LOCAL_INSTANCE11__VARS__plsinfo11; global $___LOCAL_INSTANCE11__VARS__npcinfo_instance11; ${$___TEMP_VARNAME}[\'npcinfo_instance11\']=&$___LOCAL_INSTANCE11__VARS__npcinfo_instance11; global $___LOCAL_INSTANCE11__VARS__shops11; ${$___TEMP_VARNAME}[\'shops11\']=&$___LOCAL_INSTANCE11__VARS__shops11; global $___LOCAL_INSTANCE11__VARS__shop_tag_list11; ${$___TEMP_VARNAME}[\'shop_tag_list11\']=&$___LOCAL_INSTANCE11__VARS__shop_tag_list11; unset($___TEMP_VARNAME); ');

global $___PRIVATE_INSTANCE11__VARS_____PRIVATE_PFUNC,$___PRIVATE_INSTANCE11__VARS_____PRIVATE_CFUNC,$___LOCAL_INSTANCE11__VARS__plsinfo11,$___LOCAL_INSTANCE11__VARS__npcinfo_instance11,$___LOCAL_INSTANCE11__VARS__shops11,$___LOCAL_INSTANCE11__VARS__shop_tag_list11;
$___PRIVATE_INSTANCE11__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_INSTANCE11__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_INSTANCE11__VARS__plsinfo11=&$plsinfo11;$___LOCAL_INSTANCE11__VARS__npcinfo_instance11=&$npcinfo_instance11;$___LOCAL_INSTANCE11__VARS__shops11=&$shops11;$___LOCAL_INSTANCE11__VARS__shop_tag_list11=&$shop_tag_list11;
unset($plsinfo11,$npcinfo_instance11,$shops11,$shop_tag_list11);
hook_register('instance11','card_validate_get_forbidden_cards');hook_register('instance11','get_plsnum');hook_register('instance11','get_all_plsno');hook_register('instance11','init_enter_battlefield_items');hook_register('instance11','get_npclist');hook_register('instance11','get_shop_tag_list');hook_register('instance11','get_shopconfig');hook_register('instance11','check_in_shop_area');hook_register('instance11','get_itemfilecont');hook_register('instance11','get_startingitemfilecont');hook_register('instance11','get_startingwepfilecont');hook_register('instance11','get_trapfilecont');hook_register('instance11','checkcombo');hook_register('instance11','rs_game');hook_register('instance11','init_areatiming');hook_register('instance11','post_enterbattlefield_events');hook_register('instance11','check_observe_act_allowed');hook_register('instance11','itemuse');hook_register('instance11','post_act');hook_register('instance11','act');hook_register('instance11','observe_jump_to_room');hook_register('instance11','check_item_observer');hook_register('instance11','itemdrop');hook_register('instance11','itemmove');hook_register('instance11','octitem_rotate');hook_register('instance11','meetman_alternative');hook_register('instance11','senditem_check_teammate');
function ___post_init() { global $___PRIVATE_INSTANCE11__VARS_____PRIVATE_PFUNC,$___PRIVATE_INSTANCE11__VARS_____PRIVATE_CFUNC,$___LOCAL_INSTANCE11__VARS__plsinfo11,$___LOCAL_INSTANCE11__VARS__npcinfo_instance11,$___LOCAL_INSTANCE11__VARS__shops11,$___LOCAL_INSTANCE11__VARS__shop_tag_list11;
$___LOCAL_INSTANCE11__VARS__plsinfo11=$GLOBALS['plsinfo11'];$___LOCAL_INSTANCE11__VARS__npcinfo_instance11=$GLOBALS['npcinfo_instance11'];$___LOCAL_INSTANCE11__VARS__shops11=$GLOBALS['shops11'];$___LOCAL_INSTANCE11__VARS__shop_tag_list11=$GLOBALS['shop_tag_list11'];
unset($GLOBALS['plsinfo11'],$GLOBALS['npcinfo_instance11'],$GLOBALS['shops11'],$GLOBALS['shop_tag_list11']);
}
	
}

?>