<?php

namespace skill227
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill227/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL227_PRESET_VARS','');
define('___LOAD_MOD_SKILL227_PRESET_VARS','');
define('MOD_SKILL227_INFO','club;upgrade;locked;');
define('MOD_SKILL227_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill227/desc');
define('MODULE_SKILL227_GLOBALS_VARNAMES','');
define('MOD_SKILL227',1);
define('IMPORT_MODULE_SKILL227_GLOBALS','');
define('PREFIX_MODULE_SKILL227_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL227_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL227__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL227__VARS_____PRIVATE_CFUNC;
$___PRIVATE_SKILL227__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL227__VARS_____PRIVATE_CFUNC=Array();

hook_register('skill227','acquire227');hook_register('skill227','lost227');hook_register('skill227','check_unlocked227');hook_register('skill227','sklearn_checker227');hook_register('skill227','upgrade227');
function ___post_init() { global $___PRIVATE_SKILL227__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL227__VARS_____PRIVATE_CFUNC;


}
	
}

?>