<?php

namespace skill104
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill104/'.$___TEMP_key; 
	
	$___PRESET_SKILL104__VARS__upgradecost=$upgradecost;$___PRESET_SKILL104__VARS__cubemax=$cubemax;
function ___pre_init() { global $___PRESET_SKILL104__VARS__upgradecost,$upgradecost,$___PRESET_SKILL104__VARS__cubemax,$cubemax;$upgradecost=$___PRESET_SKILL104__VARS__upgradecost;$cubemax=$___PRESET_SKILL104__VARS__cubemax; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL104_PRESET_VARS','$___PRESET_SKILL104__VARS__upgradecost=$upgradecost;$___PRESET_SKILL104__VARS__cubemax=$cubemax;');
define('___LOAD_MOD_SKILL104_PRESET_VARS','global $___PRESET_SKILL104__VARS__upgradecost,$upgradecost,$___PRESET_SKILL104__VARS__cubemax,$cubemax;$upgradecost=$___PRESET_SKILL104__VARS__upgradecost;$cubemax=$___PRESET_SKILL104__VARS__cubemax;');
define('MOD_SKILL104_INFO','club;active;upgrade;locked;');
define('MOD_SKILL104_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill104/desc');
define('MOD_SKILL104_PROFILECMD','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill104/profilecmd');
define('MOD_SKILL104_CASTSK104','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill104/castsk104');
define('MODULE_SKILL104_GLOBALS_VARNAMES','upgradecost,cubemax');
define('MOD_SKILL104',1);
define('IMPORT_MODULE_SKILL104_GLOBALS','global $___LOCAL_SKILL104__VARS__upgradecost,$___LOCAL_SKILL104__VARS__cubemax; $upgradecost=&$___LOCAL_SKILL104__VARS__upgradecost; $cubemax=&$___LOCAL_SKILL104__VARS__cubemax; ');
define('PREFIX_MODULE_SKILL104_GLOBALS','\'; global $___LOCAL_SKILL104__VARS__upgradecost; ${$___TEMP_PREFIX.\'upgradecost\'}=&$___LOCAL_SKILL104__VARS__upgradecost; global $___LOCAL_SKILL104__VARS__cubemax; ${$___TEMP_PREFIX.\'cubemax\'}=&$___LOCAL_SKILL104__VARS__cubemax; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL104_GLOBALS','\'; global $___LOCAL_SKILL104__VARS__upgradecost; ${$___TEMP_VARNAME}[\'upgradecost\']=&$___LOCAL_SKILL104__VARS__upgradecost; global $___LOCAL_SKILL104__VARS__cubemax; ${$___TEMP_VARNAME}[\'cubemax\']=&$___LOCAL_SKILL104__VARS__cubemax; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL104__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL104__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL104__VARS__upgradecost,$___LOCAL_SKILL104__VARS__cubemax;
$___PRIVATE_SKILL104__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL104__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_SKILL104__VARS__upgradecost=&$upgradecost;$___LOCAL_SKILL104__VARS__cubemax=&$cubemax;
unset($upgradecost,$cubemax);
hook_register('skill104','acquire104');hook_register('skill104','lost104');hook_register('skill104','check_unlocked104');hook_register('skill104','upgrade104');hook_register('skill104','skill104_encode_itmarr');hook_register('skill104','skill104_decode_itmarr');hook_register('skill104','skill104_prepare_itmarr');hook_register('skill104','skill104_sendin');hook_register('skill104','cast_skill104');hook_register('skill104','act');hook_register('skill104','get_skill104_actrate');hook_register('skill104','get_ex_attack_array_core');
function ___post_init() { global $___PRIVATE_SKILL104__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL104__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL104__VARS__upgradecost,$___LOCAL_SKILL104__VARS__cubemax;
$___LOCAL_SKILL104__VARS__upgradecost=$GLOBALS['upgradecost'];$___LOCAL_SKILL104__VARS__cubemax=$GLOBALS['cubemax'];
unset($GLOBALS['upgradecost'],$GLOBALS['cubemax']);
}
	
}

?>