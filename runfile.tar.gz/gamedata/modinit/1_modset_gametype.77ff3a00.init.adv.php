<?php

namespace set_gametype
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/misc/set_gametype/'.$___TEMP_key; 
	
	$___PRESET_SET_GAMETYPE__VARS__set_gametype_allow_list=$set_gametype_allow_list;
function ___pre_init() { global $___PRESET_SET_GAMETYPE__VARS__set_gametype_allow_list,$set_gametype_allow_list;$set_gametype_allow_list=$___PRESET_SET_GAMETYPE__VARS__set_gametype_allow_list; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SET_GAMETYPE_PRESET_VARS','$___PRESET_SET_GAMETYPE__VARS__set_gametype_allow_list=$set_gametype_allow_list;');
define('___LOAD_MOD_SET_GAMETYPE_PRESET_VARS','global $___PRESET_SET_GAMETYPE__VARS__set_gametype_allow_list,$set_gametype_allow_list;$set_gametype_allow_list=$___PRESET_SET_GAMETYPE__VARS__set_gametype_allow_list;');
define('MOD_SET_GAMETYPE_NEXT_GAMETYPE','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\misc\\set_gametype/next_gametype');
define('MODULE_SET_GAMETYPE_GLOBALS_VARNAMES','set_gametype_allow_list');
define('MOD_SET_GAMETYPE',1);
define('IMPORT_MODULE_SET_GAMETYPE_GLOBALS','global $___LOCAL_SET_GAMETYPE__VARS__set_gametype_allow_list; $set_gametype_allow_list=&$___LOCAL_SET_GAMETYPE__VARS__set_gametype_allow_list; ');
define('PREFIX_MODULE_SET_GAMETYPE_GLOBALS','\'; global $___LOCAL_SET_GAMETYPE__VARS__set_gametype_allow_list; ${$___TEMP_PREFIX.\'set_gametype_allow_list\'}=&$___LOCAL_SET_GAMETYPE__VARS__set_gametype_allow_list; unset($___TEMP_PREFIX); ');
define('MODULE_SET_GAMETYPE_GLOBALS','\'; global $___LOCAL_SET_GAMETYPE__VARS__set_gametype_allow_list; ${$___TEMP_VARNAME}[\'set_gametype_allow_list\']=&$___LOCAL_SET_GAMETYPE__VARS__set_gametype_allow_list; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SET_GAMETYPE__VARS_____PRIVATE_PFUNC,$___PRIVATE_SET_GAMETYPE__VARS_____PRIVATE_CFUNC,$___LOCAL_SET_GAMETYPE__VARS__set_gametype_allow_list;
$___PRIVATE_SET_GAMETYPE__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SET_GAMETYPE__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_SET_GAMETYPE__VARS__set_gametype_allow_list=&$set_gametype_allow_list;
unset($set_gametype_allow_list);
hook_register('set_gametype','check_gametype_set_valid');hook_register('set_gametype','user_set_gamevars_list_init');hook_register('set_gametype','reset_gametype');hook_register('set_gametype','user_display_gamevars_setting');hook_register('set_gametype','get_gametype_setting_html');hook_register('set_gametype','user_set_gamevars_process');hook_register('set_gametype','parse_news');
function ___post_init() { global $___PRIVATE_SET_GAMETYPE__VARS_____PRIVATE_PFUNC,$___PRIVATE_SET_GAMETYPE__VARS_____PRIVATE_CFUNC,$___LOCAL_SET_GAMETYPE__VARS__set_gametype_allow_list;
$___LOCAL_SET_GAMETYPE__VARS__set_gametype_allow_list=$GLOBALS['set_gametype_allow_list'];
unset($GLOBALS['set_gametype_allow_list']);
}
	
}

?>