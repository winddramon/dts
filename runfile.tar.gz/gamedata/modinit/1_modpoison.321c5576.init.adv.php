<?php

namespace poison
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'base/items/poison/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_POISON_PRESET_VARS','');
define('___LOAD_MOD_POISON_PRESET_VARS','');
define('MOD_POISON_POISON','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/base\\items\\poison/poison');
define('MODULE_POISON_GLOBALS_VARNAMES','');
define('MOD_POISON',1);
define('IMPORT_MODULE_POISON_GLOBALS','');
define('PREFIX_MODULE_POISON_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_POISON_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_POISON__VARS_____PRIVATE_PFUNC,$___PRIVATE_POISON__VARS_____PRIVATE_CFUNC;
$___PRIVATE_POISON__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_POISON__VARS_____PRIVATE_CFUNC=Array();

hook_register('poison','parse_itmk_words');hook_register('poison','send_poison_enemylog');hook_register('poison','itemuse');hook_register('poison','poison');hook_register('poison','poison_record_pid');hook_register('poison','poison_check_pid');hook_register('poison','check_poison_factor');hook_register('poison','act');hook_register('poison','parse_news');
function ___post_init() { global $___PRIVATE_POISON__VARS_____PRIVATE_PFUNC,$___PRIVATE_POISON__VARS_____PRIVATE_CFUNC;


}
	
}

?>