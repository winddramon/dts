<?php

namespace ex_purity
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/attr/ex_purity/'.$___TEMP_key; 
	
	$___PRESET_EX_PURITY__VARS__attack_attr_purified=$attack_attr_purified;
function ___pre_init() { global $___PRESET_EX_PURITY__VARS__attack_attr_purified,$attack_attr_purified;$attack_attr_purified=$___PRESET_EX_PURITY__VARS__attack_attr_purified; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_EX_PURITY_PRESET_VARS','$___PRESET_EX_PURITY__VARS__attack_attr_purified=$attack_attr_purified;');
define('___LOAD_MOD_EX_PURITY_PRESET_VARS','global $___PRESET_EX_PURITY__VARS__attack_attr_purified,$attack_attr_purified;$attack_attr_purified=$___PRESET_EX_PURITY__VARS__attack_attr_purified;');
define('MODULE_EX_PURITY_GLOBALS_VARNAMES','attack_attr_purified');
define('MOD_EX_PURITY',1);
define('IMPORT_MODULE_EX_PURITY_GLOBALS','global $___LOCAL_EX_PURITY__VARS__attack_attr_purified; $attack_attr_purified=&$___LOCAL_EX_PURITY__VARS__attack_attr_purified; ');
define('PREFIX_MODULE_EX_PURITY_GLOBALS','\'; global $___LOCAL_EX_PURITY__VARS__attack_attr_purified; ${$___TEMP_PREFIX.\'attack_attr_purified\'}=&$___LOCAL_EX_PURITY__VARS__attack_attr_purified; unset($___TEMP_PREFIX); ');
define('MODULE_EX_PURITY_GLOBALS','\'; global $___LOCAL_EX_PURITY__VARS__attack_attr_purified; ${$___TEMP_VARNAME}[\'attack_attr_purified\']=&$___LOCAL_EX_PURITY__VARS__attack_attr_purified; unset($___TEMP_VARNAME); ');

global $___PRIVATE_EX_PURITY__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_PURITY__VARS_____PRIVATE_CFUNC,$___LOCAL_EX_PURITY__VARS__attack_attr_purified;
$___PRIVATE_EX_PURITY__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_EX_PURITY__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_EX_PURITY__VARS__attack_attr_purified=&$attack_attr_purified;
unset($attack_attr_purified);
hook_register('ex_purity','get_ex_attack_array');hook_register('ex_purity','attack_prepare');hook_register('ex_purity','check_phy_pierce_proc');hook_register('ex_purity','check_attr_pierce_proc');hook_register('ex_purity','check_ex_rapid_def_exists');hook_register('ex_purity','check_physical_def_attr');
function ___post_init() { global $___PRIVATE_EX_PURITY__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_PURITY__VARS_____PRIVATE_CFUNC,$___LOCAL_EX_PURITY__VARS__attack_attr_purified;
$___LOCAL_EX_PURITY__VARS__attack_attr_purified=$GLOBALS['attack_attr_purified'];
unset($GLOBALS['attack_attr_purified']);
}
	
}

?>