<?php

namespace attrbase
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/attr/attrbase/'.$___TEMP_key; 
	
	$___PRESET_ATTRBASE__VARS__tmp_comp_itmsk_stack=$tmp_comp_itmsk_stack;
function ___pre_init() { global $___PRESET_ATTRBASE__VARS__tmp_comp_itmsk_stack,$tmp_comp_itmsk_stack;$tmp_comp_itmsk_stack=$___PRESET_ATTRBASE__VARS__tmp_comp_itmsk_stack; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_ATTRBASE_PRESET_VARS','$___PRESET_ATTRBASE__VARS__tmp_comp_itmsk_stack=$tmp_comp_itmsk_stack;');
define('___LOAD_MOD_ATTRBASE_PRESET_VARS','global $___PRESET_ATTRBASE__VARS__tmp_comp_itmsk_stack,$tmp_comp_itmsk_stack;$tmp_comp_itmsk_stack=$___PRESET_ATTRBASE__VARS__tmp_comp_itmsk_stack;');
define('MODULE_ATTRBASE_GLOBALS_VARNAMES','tmp_comp_itmsk_stack');
define('MOD_ATTRBASE',1);
define('IMPORT_MODULE_ATTRBASE_GLOBALS','global $___LOCAL_ATTRBASE__VARS__tmp_comp_itmsk_stack; $tmp_comp_itmsk_stack=&$___LOCAL_ATTRBASE__VARS__tmp_comp_itmsk_stack; ');
define('PREFIX_MODULE_ATTRBASE_GLOBALS','\'; global $___LOCAL_ATTRBASE__VARS__tmp_comp_itmsk_stack; ${$___TEMP_PREFIX.\'tmp_comp_itmsk_stack\'}=&$___LOCAL_ATTRBASE__VARS__tmp_comp_itmsk_stack; unset($___TEMP_PREFIX); ');
define('MODULE_ATTRBASE_GLOBALS','\'; global $___LOCAL_ATTRBASE__VARS__tmp_comp_itmsk_stack; ${$___TEMP_VARNAME}[\'tmp_comp_itmsk_stack\']=&$___LOCAL_ATTRBASE__VARS__tmp_comp_itmsk_stack; unset($___TEMP_VARNAME); ');

global $___PRIVATE_ATTRBASE__VARS_____PRIVATE_PFUNC,$___PRIVATE_ATTRBASE__VARS_____PRIVATE_CFUNC,$___LOCAL_ATTRBASE__VARS__tmp_comp_itmsk_stack;
$___PRIVATE_ATTRBASE__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_ATTRBASE__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_ATTRBASE__VARS__tmp_comp_itmsk_stack=&$tmp_comp_itmsk_stack;
unset($tmp_comp_itmsk_stack);
hook_register('attrbase','get_ex_def_array');hook_register('attrbase','get_ex_def_array_core');hook_register('attrbase','get_ex_attack_array');hook_register('attrbase','get_ex_attack_array_core');hook_register('attrbase','attr_dmg_check_not_wpg');hook_register('attrbase','get_comp_itmsk_info');hook_register('attrbase','check_single_sk_head_equal');hook_register('attrbase','check_in_itmsk');hook_register('attrbase','replace_in_itmsk');hook_register('attrbase','check_itmsk');hook_register('attrbase','get_itmsk_words_single');hook_register('attrbase','get_itmsk_desc_single');hook_register('attrbase','check_comp_itmsk_visible');hook_register('attrbase','count_itmsk_num');hook_register('attrbase','get_itmsk_desc_single_comp_process');hook_register('attrbase','base64_encode_comp_itmsk');hook_register('attrbase','base64_decode_comp_itmsk');hook_register('attrbase','config_process_encode_comp_itmsk');hook_register('attrbase','config_process_encode_comp_itmsk_callback');hook_register('attrbase','config_process_encode_comp_itmsk_sepr_transfer');hook_register('attrbase','config_process_encode_comp_itmsk_sepr_transfer_callback');hook_register('attrbase','mapitem_row_data_process');hook_register('attrbase','mapitem_row_data_seperate');hook_register('attrbase','shopitem_row_data_process');hook_register('attrbase','shopitem_row_data_seperate');hook_register('attrbase','boxes_row_data_process');hook_register('attrbase','boxes_row_data_seperate');hook_register('attrbase','itemmix_success');hook_register('attrbase','init_npcdata');hook_register('attrbase','evonpc');hook_register('attrbase','enter_battlefield_cardproc_valueproc');hook_register('attrbase','startingitem_row_data_seperate');hook_register('attrbase','init_enter_battlefield_items');hook_register('attrbase','event_get_item');
function ___post_init() { global $___PRIVATE_ATTRBASE__VARS_____PRIVATE_PFUNC,$___PRIVATE_ATTRBASE__VARS_____PRIVATE_CFUNC,$___LOCAL_ATTRBASE__VARS__tmp_comp_itmsk_stack;
$___LOCAL_ATTRBASE__VARS__tmp_comp_itmsk_stack=$GLOBALS['tmp_comp_itmsk_stack'];
unset($GLOBALS['tmp_comp_itmsk_stack']);
}
	
}

?>