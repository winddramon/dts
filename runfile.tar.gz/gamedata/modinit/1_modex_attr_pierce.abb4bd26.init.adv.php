<?php

namespace ex_attr_pierce
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/attr/ex_attr_pierce/'.$___TEMP_key; 
	
	$___PRESET_EX_ATTR_PIERCE__VARS__phy_pierce_rate=$phy_pierce_rate;$___PRESET_EX_ATTR_PIERCE__VARS__attr_pierce_rate=$attr_pierce_rate;
function ___pre_init() { global $___PRESET_EX_ATTR_PIERCE__VARS__phy_pierce_rate,$phy_pierce_rate,$___PRESET_EX_ATTR_PIERCE__VARS__attr_pierce_rate,$attr_pierce_rate;$phy_pierce_rate=$___PRESET_EX_ATTR_PIERCE__VARS__phy_pierce_rate;$attr_pierce_rate=$___PRESET_EX_ATTR_PIERCE__VARS__attr_pierce_rate; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_EX_ATTR_PIERCE_PRESET_VARS','$___PRESET_EX_ATTR_PIERCE__VARS__phy_pierce_rate=$phy_pierce_rate;$___PRESET_EX_ATTR_PIERCE__VARS__attr_pierce_rate=$attr_pierce_rate;');
define('___LOAD_MOD_EX_ATTR_PIERCE_PRESET_VARS','global $___PRESET_EX_ATTR_PIERCE__VARS__phy_pierce_rate,$phy_pierce_rate,$___PRESET_EX_ATTR_PIERCE__VARS__attr_pierce_rate,$attr_pierce_rate;$phy_pierce_rate=$___PRESET_EX_ATTR_PIERCE__VARS__phy_pierce_rate;$attr_pierce_rate=$___PRESET_EX_ATTR_PIERCE__VARS__attr_pierce_rate;');
define('MODULE_EX_ATTR_PIERCE_GLOBALS_VARNAMES','phy_pierce_rate,attr_pierce_rate');
define('MOD_EX_ATTR_PIERCE',1);
define('IMPORT_MODULE_EX_ATTR_PIERCE_GLOBALS','global $___LOCAL_EX_ATTR_PIERCE__VARS__phy_pierce_rate,$___LOCAL_EX_ATTR_PIERCE__VARS__attr_pierce_rate; $phy_pierce_rate=&$___LOCAL_EX_ATTR_PIERCE__VARS__phy_pierce_rate; $attr_pierce_rate=&$___LOCAL_EX_ATTR_PIERCE__VARS__attr_pierce_rate; ');
define('PREFIX_MODULE_EX_ATTR_PIERCE_GLOBALS','\'; global $___LOCAL_EX_ATTR_PIERCE__VARS__phy_pierce_rate; ${$___TEMP_PREFIX.\'phy_pierce_rate\'}=&$___LOCAL_EX_ATTR_PIERCE__VARS__phy_pierce_rate; global $___LOCAL_EX_ATTR_PIERCE__VARS__attr_pierce_rate; ${$___TEMP_PREFIX.\'attr_pierce_rate\'}=&$___LOCAL_EX_ATTR_PIERCE__VARS__attr_pierce_rate; unset($___TEMP_PREFIX); ');
define('MODULE_EX_ATTR_PIERCE_GLOBALS','\'; global $___LOCAL_EX_ATTR_PIERCE__VARS__phy_pierce_rate; ${$___TEMP_VARNAME}[\'phy_pierce_rate\']=&$___LOCAL_EX_ATTR_PIERCE__VARS__phy_pierce_rate; global $___LOCAL_EX_ATTR_PIERCE__VARS__attr_pierce_rate; ${$___TEMP_VARNAME}[\'attr_pierce_rate\']=&$___LOCAL_EX_ATTR_PIERCE__VARS__attr_pierce_rate; unset($___TEMP_VARNAME); ');

global $___PRIVATE_EX_ATTR_PIERCE__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_ATTR_PIERCE__VARS_____PRIVATE_CFUNC,$___LOCAL_EX_ATTR_PIERCE__VARS__phy_pierce_rate,$___LOCAL_EX_ATTR_PIERCE__VARS__attr_pierce_rate;
$___PRIVATE_EX_ATTR_PIERCE__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_EX_ATTR_PIERCE__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_EX_ATTR_PIERCE__VARS__phy_pierce_rate=&$phy_pierce_rate;$___LOCAL_EX_ATTR_PIERCE__VARS__attr_pierce_rate=&$attr_pierce_rate;
unset($phy_pierce_rate,$attr_pierce_rate);
hook_register('ex_attr_pierce','get_ex_pierce_proc_rate');hook_register('ex_attr_pierce','get_attr_pierce_proc_rate');hook_register('ex_attr_pierce','check_phy_pierce_proc');hook_register('ex_attr_pierce','check_attr_pierce_proc');hook_register('ex_attr_pierce','check_ex_rapid_def_exists');hook_register('ex_attr_pierce','check_physical_def_attr');hook_register('ex_attr_pierce','check_physical_nullify');hook_register('ex_attr_pierce','check_ex_single_dmg_def_attr');hook_register('ex_attr_pierce','check_ex_dmg_nullify');hook_register('ex_attr_pierce','calculate_physical_dmg');hook_register('ex_attr_pierce','calculate_ex_attack_dmg');hook_register('ex_attr_pierce','strike_prepare');hook_register('ex_attr_pierce','check_dmg_def_attr');
function ___post_init() { global $___PRIVATE_EX_ATTR_PIERCE__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_ATTR_PIERCE__VARS_____PRIVATE_CFUNC,$___LOCAL_EX_ATTR_PIERCE__VARS__phy_pierce_rate,$___LOCAL_EX_ATTR_PIERCE__VARS__attr_pierce_rate;
$___LOCAL_EX_ATTR_PIERCE__VARS__phy_pierce_rate=$GLOBALS['phy_pierce_rate'];$___LOCAL_EX_ATTR_PIERCE__VARS__attr_pierce_rate=$GLOBALS['attr_pierce_rate'];
unset($GLOBALS['phy_pierce_rate'],$GLOBALS['attr_pierce_rate']);
}
	
}

?>