<?php

namespace npcchat
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'base/npcchat/'.$___TEMP_key; 
	
	$___PRESET_NPCCHAT__VARS__npcchaton=$npcchaton;$___PRESET_NPCCHAT__VARS__npcchat=$npcchat;
function ___pre_init() { global $___PRESET_NPCCHAT__VARS__npcchaton,$npcchaton,$___PRESET_NPCCHAT__VARS__npcchat,$npcchat;$npcchaton=$___PRESET_NPCCHAT__VARS__npcchaton;$npcchat=$___PRESET_NPCCHAT__VARS__npcchat; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_NPCCHAT_PRESET_VARS','$___PRESET_NPCCHAT__VARS__npcchaton=$npcchaton;$___PRESET_NPCCHAT__VARS__npcchat=$npcchat;');
define('___LOAD_MOD_NPCCHAT_PRESET_VARS','global $___PRESET_NPCCHAT__VARS__npcchaton,$npcchaton,$___PRESET_NPCCHAT__VARS__npcchat,$npcchat;$npcchaton=$___PRESET_NPCCHAT__VARS__npcchaton;$npcchat=$___PRESET_NPCCHAT__VARS__npcchat;');
define('MODULE_NPCCHAT_GLOBALS_VARNAMES','npcchaton,npcchat');
define('MOD_NPCCHAT',1);
define('IMPORT_MODULE_NPCCHAT_GLOBALS','global $___LOCAL_NPCCHAT__VARS__npcchaton,$___LOCAL_NPCCHAT__VARS__npcchat; $npcchaton=&$___LOCAL_NPCCHAT__VARS__npcchaton; $npcchat=&$___LOCAL_NPCCHAT__VARS__npcchat; ');
define('PREFIX_MODULE_NPCCHAT_GLOBALS','\'; global $___LOCAL_NPCCHAT__VARS__npcchaton; ${$___TEMP_PREFIX.\'npcchaton\'}=&$___LOCAL_NPCCHAT__VARS__npcchaton; global $___LOCAL_NPCCHAT__VARS__npcchat; ${$___TEMP_PREFIX.\'npcchat\'}=&$___LOCAL_NPCCHAT__VARS__npcchat; unset($___TEMP_PREFIX); ');
define('MODULE_NPCCHAT_GLOBALS','\'; global $___LOCAL_NPCCHAT__VARS__npcchaton; ${$___TEMP_VARNAME}[\'npcchaton\']=&$___LOCAL_NPCCHAT__VARS__npcchaton; global $___LOCAL_NPCCHAT__VARS__npcchat; ${$___TEMP_VARNAME}[\'npcchat\']=&$___LOCAL_NPCCHAT__VARS__npcchat; unset($___TEMP_VARNAME); ');

global $___PRIVATE_NPCCHAT__VARS_____PRIVATE_PFUNC,$___PRIVATE_NPCCHAT__VARS_____PRIVATE_CFUNC,$___LOCAL_NPCCHAT__VARS__npcchaton,$___LOCAL_NPCCHAT__VARS__npcchat;
$___PRIVATE_NPCCHAT__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_NPCCHAT__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_NPCCHAT__VARS__npcchaton=&$npcchaton;$___LOCAL_NPCCHAT__VARS__npcchat=&$npcchat;
unset($npcchaton,$npcchat);
hook_register('npcchat','npcchat');hook_register('npcchat','npcchat_print');hook_register('npcchat','npcchat_decorate');hook_register('npcchat','npcchat_get_chatlog');hook_register('npcchat','npcchat_tag_process');hook_register('npcchat','battle_prepare');hook_register('npcchat','attack_prepare');hook_register('npcchat','attack_finish');hook_register('npcchat','cannot_counter');hook_register('npcchat','player_kill_enemy');hook_register('npcchat','get_player_killmsg');hook_register('npcchat','apply_total_damage_modifier_seckill');
function ___post_init() { global $___PRIVATE_NPCCHAT__VARS_____PRIVATE_PFUNC,$___PRIVATE_NPCCHAT__VARS_____PRIVATE_CFUNC,$___LOCAL_NPCCHAT__VARS__npcchaton,$___LOCAL_NPCCHAT__VARS__npcchat;
$___LOCAL_NPCCHAT__VARS__npcchaton=$GLOBALS['npcchaton'];$___LOCAL_NPCCHAT__VARS__npcchat=$GLOBALS['npcchat'];
unset($GLOBALS['npcchaton'],$GLOBALS['npcchat']);
}
	
}

?>