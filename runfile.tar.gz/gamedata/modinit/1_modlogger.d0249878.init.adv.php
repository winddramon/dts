<?php

namespace logger
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'base/logger/'.$___TEMP_key; 
	
	$___PRESET_LOGGER__VARS__log=$log;
function ___pre_init() { global $___PRESET_LOGGER__VARS__log,$log;$log=$___PRESET_LOGGER__VARS__log; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_LOGGER_PRESET_VARS','$___PRESET_LOGGER__VARS__log=$log;');
define('___LOAD_MOD_LOGGER_PRESET_VARS','global $___PRESET_LOGGER__VARS__log,$log;$log=$___PRESET_LOGGER__VARS__log;');
define('MODULE_LOGGER_GLOBALS_VARNAMES','log');
define('MOD_LOGGER',1);
define('IMPORT_MODULE_LOGGER_GLOBALS','global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log; ');
define('PREFIX_MODULE_LOGGER_GLOBALS','\'; global $___LOCAL_LOGGER__VARS__log; ${$___TEMP_PREFIX.\'log\'}=&$___LOCAL_LOGGER__VARS__log; unset($___TEMP_PREFIX); ');
define('MODULE_LOGGER_GLOBALS','\'; global $___LOCAL_LOGGER__VARS__log; ${$___TEMP_VARNAME}[\'log\']=&$___LOCAL_LOGGER__VARS__log; unset($___TEMP_VARNAME); ');

global $___PRIVATE_LOGGER__VARS_____PRIVATE_PFUNC,$___PRIVATE_LOGGER__VARS_____PRIVATE_CFUNC,$___LOCAL_LOGGER__VARS__log;
$___PRIVATE_LOGGER__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_LOGGER__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_LOGGER__VARS__log=&$log;
unset($log);
hook_register('logger','logsave');hook_register('logger','pre_act');hook_register('logger','log_linenum_counter');
function ___post_init() { global $___PRIVATE_LOGGER__VARS_____PRIVATE_PFUNC,$___PRIVATE_LOGGER__VARS_____PRIVATE_CFUNC,$___LOCAL_LOGGER__VARS__log;
$___LOCAL_LOGGER__VARS__log=$GLOBALS['log'];
unset($GLOBALS['log']);
}
	
}

?>