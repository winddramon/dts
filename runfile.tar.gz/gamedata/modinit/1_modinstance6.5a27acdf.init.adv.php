<?php

namespace instance6
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/instance/instance6/'.$___TEMP_key; 
	
	$___PRESET_INSTANCE6__VARS__npcinfo_instance6=$npcinfo_instance6;
function ___pre_init() { global $___PRESET_INSTANCE6__VARS__npcinfo_instance6,$npcinfo_instance6;$npcinfo_instance6=$___PRESET_INSTANCE6__VARS__npcinfo_instance6; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_INSTANCE6_PRESET_VARS','$___PRESET_INSTANCE6__VARS__npcinfo_instance6=$npcinfo_instance6;');
define('___LOAD_MOD_INSTANCE6_PRESET_VARS','global $___PRESET_INSTANCE6__VARS__npcinfo_instance6,$npcinfo_instance6;$npcinfo_instance6=$___PRESET_INSTANCE6__VARS__npcinfo_instance6;');
define('MODULE_INSTANCE6_GLOBALS_VARNAMES','npcinfo_instance6');
define('MOD_INSTANCE6',1);
define('IMPORT_MODULE_INSTANCE6_GLOBALS','global $___LOCAL_INSTANCE6__VARS__npcinfo_instance6; $npcinfo_instance6=&$___LOCAL_INSTANCE6__VARS__npcinfo_instance6; ');
define('PREFIX_MODULE_INSTANCE6_GLOBALS','\'; global $___LOCAL_INSTANCE6__VARS__npcinfo_instance6; ${$___TEMP_PREFIX.\'npcinfo_instance6\'}=&$___LOCAL_INSTANCE6__VARS__npcinfo_instance6; unset($___TEMP_PREFIX); ');
define('MODULE_INSTANCE6_GLOBALS','\'; global $___LOCAL_INSTANCE6__VARS__npcinfo_instance6; ${$___TEMP_VARNAME}[\'npcinfo_instance6\']=&$___LOCAL_INSTANCE6__VARS__npcinfo_instance6; unset($___TEMP_VARNAME); ');

global $___PRIVATE_INSTANCE6__VARS_____PRIVATE_PFUNC,$___PRIVATE_INSTANCE6__VARS_____PRIVATE_CFUNC,$___LOCAL_INSTANCE6__VARS__npcinfo_instance6;
$___PRIVATE_INSTANCE6__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_INSTANCE6__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_INSTANCE6__VARS__npcinfo_instance6=&$npcinfo_instance6;
unset($npcinfo_instance6);
hook_register('instance6','get_shopconfig');hook_register('instance6','checkcombo');hook_register('instance6','get_npclist');hook_register('instance6','rs_game');hook_register('instance6','check_addarea_gameover');
function ___post_init() { global $___PRIVATE_INSTANCE6__VARS_____PRIVATE_PFUNC,$___PRIVATE_INSTANCE6__VARS_____PRIVATE_CFUNC,$___LOCAL_INSTANCE6__VARS__npcinfo_instance6;
$___LOCAL_INSTANCE6__VARS__npcinfo_instance6=$GLOBALS['npcinfo_instance6'];
unset($GLOBALS['npcinfo_instance6']);
}
	
}

?>