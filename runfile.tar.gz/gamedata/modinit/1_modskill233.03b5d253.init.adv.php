<?php

namespace skill233
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill233/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL233_PRESET_VARS','');
define('___LOAD_MOD_SKILL233_PRESET_VARS','');
define('MOD_SKILL233_INFO','club;');
define('MOD_SKILL233_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill233/desc');
define('MODULE_SKILL233_GLOBALS_VARNAMES','');
define('MOD_SKILL233',1);
define('IMPORT_MODULE_SKILL233_GLOBALS','');
define('PREFIX_MODULE_SKILL233_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL233_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL233__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL233__VARS_____PRIVATE_CFUNC;
$___PRIVATE_SKILL233__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL233__VARS_____PRIVATE_CFUNC=Array();

hook_register('skill233','acquire233');hook_register('skill233','lost233');hook_register('skill233','check_unlocked233');hook_register('skill233','calculate_hack_proc_rate');hook_register('skill233','calculate_post_hack_proc_rate');
function ___post_init() { global $___PRIVATE_SKILL233__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL233__VARS_____PRIVATE_CFUNC;


}
	
}

?>