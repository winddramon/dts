<?php

namespace skill218
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill218/'.$___TEMP_key; 
	
	$___PRESET_SKILL218__VARS__infrgain=$infrgain;$___PRESET_SKILL218__VARS__extdmg=$extdmg;$___PRESET_SKILL218__VARS__upgradecost=$upgradecost;
function ___pre_init() { global $___PRESET_SKILL218__VARS__infrgain,$infrgain,$___PRESET_SKILL218__VARS__extdmg,$extdmg,$___PRESET_SKILL218__VARS__upgradecost,$upgradecost;$infrgain=$___PRESET_SKILL218__VARS__infrgain;$extdmg=$___PRESET_SKILL218__VARS__extdmg;$upgradecost=$___PRESET_SKILL218__VARS__upgradecost; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL218_PRESET_VARS','$___PRESET_SKILL218__VARS__infrgain=$infrgain;$___PRESET_SKILL218__VARS__extdmg=$extdmg;$___PRESET_SKILL218__VARS__upgradecost=$upgradecost;');
define('___LOAD_MOD_SKILL218_PRESET_VARS','global $___PRESET_SKILL218__VARS__infrgain,$infrgain,$___PRESET_SKILL218__VARS__extdmg,$extdmg,$___PRESET_SKILL218__VARS__upgradecost,$upgradecost;$infrgain=$___PRESET_SKILL218__VARS__infrgain;$extdmg=$___PRESET_SKILL218__VARS__extdmg;$upgradecost=$___PRESET_SKILL218__VARS__upgradecost;');
define('MOD_SKILL218_INFO','club;upgrade;');
define('MOD_SKILL218_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill218/desc');
define('MODULE_SKILL218_GLOBALS_VARNAMES','infrgain,extdmg,upgradecost');
define('MOD_SKILL218',1);
define('IMPORT_MODULE_SKILL218_GLOBALS','global $___LOCAL_SKILL218__VARS__infrgain,$___LOCAL_SKILL218__VARS__extdmg,$___LOCAL_SKILL218__VARS__upgradecost; $infrgain=&$___LOCAL_SKILL218__VARS__infrgain; $extdmg=&$___LOCAL_SKILL218__VARS__extdmg; $upgradecost=&$___LOCAL_SKILL218__VARS__upgradecost; ');
define('PREFIX_MODULE_SKILL218_GLOBALS','\'; global $___LOCAL_SKILL218__VARS__infrgain; ${$___TEMP_PREFIX.\'infrgain\'}=&$___LOCAL_SKILL218__VARS__infrgain; global $___LOCAL_SKILL218__VARS__extdmg; ${$___TEMP_PREFIX.\'extdmg\'}=&$___LOCAL_SKILL218__VARS__extdmg; global $___LOCAL_SKILL218__VARS__upgradecost; ${$___TEMP_PREFIX.\'upgradecost\'}=&$___LOCAL_SKILL218__VARS__upgradecost; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL218_GLOBALS','\'; global $___LOCAL_SKILL218__VARS__infrgain; ${$___TEMP_VARNAME}[\'infrgain\']=&$___LOCAL_SKILL218__VARS__infrgain; global $___LOCAL_SKILL218__VARS__extdmg; ${$___TEMP_VARNAME}[\'extdmg\']=&$___LOCAL_SKILL218__VARS__extdmg; global $___LOCAL_SKILL218__VARS__upgradecost; ${$___TEMP_VARNAME}[\'upgradecost\']=&$___LOCAL_SKILL218__VARS__upgradecost; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL218__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL218__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL218__VARS__infrgain,$___LOCAL_SKILL218__VARS__extdmg,$___LOCAL_SKILL218__VARS__upgradecost;
$___PRIVATE_SKILL218__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL218__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_SKILL218__VARS__infrgain=&$infrgain;$___LOCAL_SKILL218__VARS__extdmg=&$extdmg;$___LOCAL_SKILL218__VARS__upgradecost=&$upgradecost;
unset($infrgain,$extdmg,$upgradecost);
hook_register('skill218','acquire218');hook_register('skill218','lost218');hook_register('skill218','check_unlocked218');hook_register('skill218','upgrade218');hook_register('skill218','get_skill218_extra_inf_rate');hook_register('skill218','calculate_ex_inf_rate');hook_register('skill218','get_skill218_extra_dmgrate');hook_register('skill218','get_final_dmg_multiplier');
function ___post_init() { global $___PRIVATE_SKILL218__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL218__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL218__VARS__infrgain,$___LOCAL_SKILL218__VARS__extdmg,$___LOCAL_SKILL218__VARS__upgradecost;
$___LOCAL_SKILL218__VARS__infrgain=$GLOBALS['infrgain'];$___LOCAL_SKILL218__VARS__extdmg=$GLOBALS['extdmg'];$___LOCAL_SKILL218__VARS__upgradecost=$GLOBALS['upgradecost'];
unset($GLOBALS['infrgain'],$GLOBALS['extdmg'],$GLOBALS['upgradecost']);
}
	
}

?>