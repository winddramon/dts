<?php

namespace randnpc
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/instance/instance10_rogue/randnpc/'.$___TEMP_key; 
	
	$___PRESET_RANDNPC__VARS__randnpc_skills=$randnpc_skills;$___PRESET_RANDNPC__VARS__randnpc_itmsk=$randnpc_itmsk;$___PRESET_RANDNPC__VARS__randnpc_item=$randnpc_item;$___PRESET_RANDNPC__VARS__randnpc_item_randname=$randnpc_item_randname;$___PRESET_RANDNPC__VARS__randnpc_presets=$randnpc_presets;
function ___pre_init() { global $___PRESET_RANDNPC__VARS__randnpc_skills,$randnpc_skills,$___PRESET_RANDNPC__VARS__randnpc_itmsk,$randnpc_itmsk,$___PRESET_RANDNPC__VARS__randnpc_item,$randnpc_item,$___PRESET_RANDNPC__VARS__randnpc_item_randname,$randnpc_item_randname,$___PRESET_RANDNPC__VARS__randnpc_presets,$randnpc_presets;$randnpc_skills=$___PRESET_RANDNPC__VARS__randnpc_skills;$randnpc_itmsk=$___PRESET_RANDNPC__VARS__randnpc_itmsk;$randnpc_item=$___PRESET_RANDNPC__VARS__randnpc_item;$randnpc_item_randname=$___PRESET_RANDNPC__VARS__randnpc_item_randname;$randnpc_presets=$___PRESET_RANDNPC__VARS__randnpc_presets; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_RANDNPC_PRESET_VARS','$___PRESET_RANDNPC__VARS__randnpc_skills=$randnpc_skills;$___PRESET_RANDNPC__VARS__randnpc_itmsk=$randnpc_itmsk;$___PRESET_RANDNPC__VARS__randnpc_item=$randnpc_item;$___PRESET_RANDNPC__VARS__randnpc_item_randname=$randnpc_item_randname;$___PRESET_RANDNPC__VARS__randnpc_presets=$randnpc_presets;');
define('___LOAD_MOD_RANDNPC_PRESET_VARS','global $___PRESET_RANDNPC__VARS__randnpc_skills,$randnpc_skills,$___PRESET_RANDNPC__VARS__randnpc_itmsk,$randnpc_itmsk,$___PRESET_RANDNPC__VARS__randnpc_item,$randnpc_item,$___PRESET_RANDNPC__VARS__randnpc_item_randname,$randnpc_item_randname,$___PRESET_RANDNPC__VARS__randnpc_presets,$randnpc_presets;$randnpc_skills=$___PRESET_RANDNPC__VARS__randnpc_skills;$randnpc_itmsk=$___PRESET_RANDNPC__VARS__randnpc_itmsk;$randnpc_item=$___PRESET_RANDNPC__VARS__randnpc_item;$randnpc_item_randname=$___PRESET_RANDNPC__VARS__randnpc_item_randname;$randnpc_presets=$___PRESET_RANDNPC__VARS__randnpc_presets;');
define('MODULE_RANDNPC_GLOBALS_VARNAMES','randnpc_skills,randnpc_itmsk,randnpc_item,randnpc_item_randname,randnpc_presets');
define('MOD_RANDNPC',1);
define('IMPORT_MODULE_RANDNPC_GLOBALS','global $___LOCAL_RANDNPC__VARS__randnpc_skills,$___LOCAL_RANDNPC__VARS__randnpc_itmsk,$___LOCAL_RANDNPC__VARS__randnpc_item,$___LOCAL_RANDNPC__VARS__randnpc_item_randname,$___LOCAL_RANDNPC__VARS__randnpc_presets; $randnpc_skills=&$___LOCAL_RANDNPC__VARS__randnpc_skills; $randnpc_itmsk=&$___LOCAL_RANDNPC__VARS__randnpc_itmsk; $randnpc_item=&$___LOCAL_RANDNPC__VARS__randnpc_item; $randnpc_item_randname=&$___LOCAL_RANDNPC__VARS__randnpc_item_randname; $randnpc_presets=&$___LOCAL_RANDNPC__VARS__randnpc_presets; ');
define('PREFIX_MODULE_RANDNPC_GLOBALS','\'; global $___LOCAL_RANDNPC__VARS__randnpc_skills; ${$___TEMP_PREFIX.\'randnpc_skills\'}=&$___LOCAL_RANDNPC__VARS__randnpc_skills; global $___LOCAL_RANDNPC__VARS__randnpc_itmsk; ${$___TEMP_PREFIX.\'randnpc_itmsk\'}=&$___LOCAL_RANDNPC__VARS__randnpc_itmsk; global $___LOCAL_RANDNPC__VARS__randnpc_item; ${$___TEMP_PREFIX.\'randnpc_item\'}=&$___LOCAL_RANDNPC__VARS__randnpc_item; global $___LOCAL_RANDNPC__VARS__randnpc_item_randname; ${$___TEMP_PREFIX.\'randnpc_item_randname\'}=&$___LOCAL_RANDNPC__VARS__randnpc_item_randname; global $___LOCAL_RANDNPC__VARS__randnpc_presets; ${$___TEMP_PREFIX.\'randnpc_presets\'}=&$___LOCAL_RANDNPC__VARS__randnpc_presets; unset($___TEMP_PREFIX); ');
define('MODULE_RANDNPC_GLOBALS','\'; global $___LOCAL_RANDNPC__VARS__randnpc_skills; ${$___TEMP_VARNAME}[\'randnpc_skills\']=&$___LOCAL_RANDNPC__VARS__randnpc_skills; global $___LOCAL_RANDNPC__VARS__randnpc_itmsk; ${$___TEMP_VARNAME}[\'randnpc_itmsk\']=&$___LOCAL_RANDNPC__VARS__randnpc_itmsk; global $___LOCAL_RANDNPC__VARS__randnpc_item; ${$___TEMP_VARNAME}[\'randnpc_item\']=&$___LOCAL_RANDNPC__VARS__randnpc_item; global $___LOCAL_RANDNPC__VARS__randnpc_item_randname; ${$___TEMP_VARNAME}[\'randnpc_item_randname\']=&$___LOCAL_RANDNPC__VARS__randnpc_item_randname; global $___LOCAL_RANDNPC__VARS__randnpc_presets; ${$___TEMP_VARNAME}[\'randnpc_presets\']=&$___LOCAL_RANDNPC__VARS__randnpc_presets; unset($___TEMP_VARNAME); ');

global $___PRIVATE_RANDNPC__VARS_____PRIVATE_PFUNC,$___PRIVATE_RANDNPC__VARS_____PRIVATE_CFUNC,$___LOCAL_RANDNPC__VARS__randnpc_skills,$___LOCAL_RANDNPC__VARS__randnpc_itmsk,$___LOCAL_RANDNPC__VARS__randnpc_item,$___LOCAL_RANDNPC__VARS__randnpc_item_randname,$___LOCAL_RANDNPC__VARS__randnpc_presets;
$___PRIVATE_RANDNPC__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_RANDNPC__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_RANDNPC__VARS__randnpc_skills=&$randnpc_skills;$___LOCAL_RANDNPC__VARS__randnpc_itmsk=&$randnpc_itmsk;$___LOCAL_RANDNPC__VARS__randnpc_item=&$randnpc_item;$___LOCAL_RANDNPC__VARS__randnpc_item_randname=&$randnpc_item_randname;$___LOCAL_RANDNPC__VARS__randnpc_presets=&$randnpc_presets;
unset($randnpc_skills,$randnpc_itmsk,$randnpc_item,$randnpc_item_randname,$randnpc_presets);
hook_register('randnpc','generate_randnpc');hook_register('randnpc','generate_single_randnpc');hook_register('randnpc','generate_randnpc_item');hook_register('randnpc','generate_randnpc_itmsk');hook_register('randnpc','generate_randnpc_skills');hook_register('randnpc','add_randnpc');hook_register('randnpc','itemuse');
function ___post_init() { global $___PRIVATE_RANDNPC__VARS_____PRIVATE_PFUNC,$___PRIVATE_RANDNPC__VARS_____PRIVATE_CFUNC,$___LOCAL_RANDNPC__VARS__randnpc_skills,$___LOCAL_RANDNPC__VARS__randnpc_itmsk,$___LOCAL_RANDNPC__VARS__randnpc_item,$___LOCAL_RANDNPC__VARS__randnpc_item_randname,$___LOCAL_RANDNPC__VARS__randnpc_presets;
$___LOCAL_RANDNPC__VARS__randnpc_skills=$GLOBALS['randnpc_skills'];$___LOCAL_RANDNPC__VARS__randnpc_itmsk=$GLOBALS['randnpc_itmsk'];$___LOCAL_RANDNPC__VARS__randnpc_item=$GLOBALS['randnpc_item'];$___LOCAL_RANDNPC__VARS__randnpc_item_randname=$GLOBALS['randnpc_item_randname'];$___LOCAL_RANDNPC__VARS__randnpc_presets=$GLOBALS['randnpc_presets'];
unset($GLOBALS['randnpc_skills'],$GLOBALS['randnpc_itmsk'],$GLOBALS['randnpc_item'],$GLOBALS['randnpc_item_randname'],$GLOBALS['randnpc_presets']);
}
	
}

?>