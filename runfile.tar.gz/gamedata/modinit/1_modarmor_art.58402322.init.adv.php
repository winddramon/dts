<?php

namespace armor_art
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'base/armor_art/'.$___TEMP_key; 
	
	$___PRESET_ARMOR_ART__VARS__armor_art_equip_list=$armor_art_equip_list;$___PRESET_ARMOR_ART__VARS__armor_art_iteminfo=$armor_art_iteminfo;
function ___pre_init() { global $___PRESET_ARMOR_ART__VARS__armor_art_equip_list,$armor_art_equip_list,$___PRESET_ARMOR_ART__VARS__armor_art_iteminfo,$armor_art_iteminfo;$armor_art_equip_list=$___PRESET_ARMOR_ART__VARS__armor_art_equip_list;$armor_art_iteminfo=$___PRESET_ARMOR_ART__VARS__armor_art_iteminfo; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_ARMOR_ART_PRESET_VARS','$___PRESET_ARMOR_ART__VARS__armor_art_equip_list=$armor_art_equip_list;$___PRESET_ARMOR_ART__VARS__armor_art_iteminfo=$armor_art_iteminfo;');
define('___LOAD_MOD_ARMOR_ART_PRESET_VARS','global $___PRESET_ARMOR_ART__VARS__armor_art_equip_list,$armor_art_equip_list,$___PRESET_ARMOR_ART__VARS__armor_art_iteminfo,$armor_art_iteminfo;$armor_art_equip_list=$___PRESET_ARMOR_ART__VARS__armor_art_equip_list;$armor_art_iteminfo=$___PRESET_ARMOR_ART__VARS__armor_art_iteminfo;');
define('MOD_ARMOR_ART_PROFILE_ARMOR_ART','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/base\\armor_art/profile_armor_art');
define('MOD_ARMOR_ART_PROFILE_ARMOR_ART_SHORT','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/base\\armor_art/profile_armor_art_short');
define('MODULE_ARMOR_ART_GLOBALS_VARNAMES','armor_art_equip_list,armor_art_iteminfo');
define('MOD_ARMOR_ART',1);
define('IMPORT_MODULE_ARMOR_ART_GLOBALS','global $___LOCAL_ARMOR_ART__VARS__armor_art_equip_list,$___LOCAL_ARMOR_ART__VARS__armor_art_iteminfo; $armor_art_equip_list=&$___LOCAL_ARMOR_ART__VARS__armor_art_equip_list; $armor_art_iteminfo=&$___LOCAL_ARMOR_ART__VARS__armor_art_iteminfo; ');
define('PREFIX_MODULE_ARMOR_ART_GLOBALS','\'; global $___LOCAL_ARMOR_ART__VARS__armor_art_equip_list; ${$___TEMP_PREFIX.\'armor_art_equip_list\'}=&$___LOCAL_ARMOR_ART__VARS__armor_art_equip_list; global $___LOCAL_ARMOR_ART__VARS__armor_art_iteminfo; ${$___TEMP_PREFIX.\'armor_art_iteminfo\'}=&$___LOCAL_ARMOR_ART__VARS__armor_art_iteminfo; unset($___TEMP_PREFIX); ');
define('MODULE_ARMOR_ART_GLOBALS','\'; global $___LOCAL_ARMOR_ART__VARS__armor_art_equip_list; ${$___TEMP_VARNAME}[\'armor_art_equip_list\']=&$___LOCAL_ARMOR_ART__VARS__armor_art_equip_list; global $___LOCAL_ARMOR_ART__VARS__armor_art_iteminfo; ${$___TEMP_VARNAME}[\'armor_art_iteminfo\']=&$___LOCAL_ARMOR_ART__VARS__armor_art_iteminfo; unset($___TEMP_VARNAME); ');

global $___PRIVATE_ARMOR_ART__VARS_____PRIVATE_PFUNC,$___PRIVATE_ARMOR_ART__VARS_____PRIVATE_CFUNC,$___LOCAL_ARMOR_ART__VARS__armor_art_equip_list,$___LOCAL_ARMOR_ART__VARS__armor_art_iteminfo;
$___PRIVATE_ARMOR_ART__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_ARMOR_ART__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_ARMOR_ART__VARS__armor_art_equip_list=&$armor_art_equip_list;$___LOCAL_ARMOR_ART__VARS__armor_art_iteminfo=&$armor_art_iteminfo;
unset($armor_art_equip_list,$armor_art_iteminfo);
hook_register('armor_art','itemuse');
function ___post_init() { global $___PRIVATE_ARMOR_ART__VARS_____PRIVATE_PFUNC,$___PRIVATE_ARMOR_ART__VARS_____PRIVATE_CFUNC,$___LOCAL_ARMOR_ART__VARS__armor_art_equip_list,$___LOCAL_ARMOR_ART__VARS__armor_art_iteminfo;
$___LOCAL_ARMOR_ART__VARS__armor_art_equip_list=$GLOBALS['armor_art_equip_list'];$___LOCAL_ARMOR_ART__VARS__armor_art_iteminfo=$GLOBALS['armor_art_iteminfo'];
unset($GLOBALS['armor_art_equip_list'],$GLOBALS['armor_art_iteminfo']);
}
	
}

?>