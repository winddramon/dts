<?php

namespace event
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'base/event/'.$___TEMP_key; 
	
	$___PRESET_EVENT__VARS__event_obbs=$event_obbs;
function ___pre_init() { global $___PRESET_EVENT__VARS__event_obbs,$event_obbs;$event_obbs=$___PRESET_EVENT__VARS__event_obbs; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_EVENT_PRESET_VARS','$___PRESET_EVENT__VARS__event_obbs=$event_obbs;');
define('___LOAD_MOD_EVENT_PRESET_VARS','global $___PRESET_EVENT__VARS__event_obbs,$event_obbs;$event_obbs=$___PRESET_EVENT__VARS__event_obbs;');
define('MODULE_EVENT_GLOBALS_VARNAMES','event_obbs');
define('MOD_EVENT',1);
define('IMPORT_MODULE_EVENT_GLOBALS','global $___LOCAL_EVENT__VARS__event_obbs; $event_obbs=&$___LOCAL_EVENT__VARS__event_obbs; ');
define('PREFIX_MODULE_EVENT_GLOBALS','\'; global $___LOCAL_EVENT__VARS__event_obbs; ${$___TEMP_PREFIX.\'event_obbs\'}=&$___LOCAL_EVENT__VARS__event_obbs; unset($___TEMP_PREFIX); ');
define('MODULE_EVENT_GLOBALS','\'; global $___LOCAL_EVENT__VARS__event_obbs; ${$___TEMP_VARNAME}[\'event_obbs\']=&$___LOCAL_EVENT__VARS__event_obbs; unset($___TEMP_VARNAME); ');

global $___PRIVATE_EVENT__VARS_____PRIVATE_PFUNC,$___PRIVATE_EVENT__VARS_____PRIVATE_CFUNC,$___LOCAL_EVENT__VARS__event_obbs;
$___PRIVATE_EVENT__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_EVENT__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_EVENT__VARS__event_obbs=&$event_obbs;
unset($event_obbs);
hook_register('event','event_available');hook_register('event','discover');hook_register('event','check_event_happen');hook_register('event','check_event_happen_special');hook_register('event','can_continue_post_event_proc');hook_register('event','event_main');hook_register('event','event_core');hook_register('event','event_death');hook_register('event','death_kagari');hook_register('event','event_suffer_inf');hook_register('event','event_suffer_dmg');hook_register('event','event_get_field');hook_register('event','event_get_item');hook_register('event','event_get_money');hook_register('event','event_get_rp');hook_register('event','event_winrate_process');hook_register('event','event_escrate_process');hook_register('event','check_pls34_enterable');hook_register('event','parse_news');
function ___post_init() { global $___PRIVATE_EVENT__VARS_____PRIVATE_PFUNC,$___PRIVATE_EVENT__VARS_____PRIVATE_CFUNC,$___LOCAL_EVENT__VARS__event_obbs;
$___LOCAL_EVENT__VARS__event_obbs=$GLOBALS['event_obbs'];
unset($GLOBALS['event_obbs']);
}
	
}

?>