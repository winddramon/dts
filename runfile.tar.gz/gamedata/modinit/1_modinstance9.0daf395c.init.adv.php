<?php

namespace instance9
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/instance/instance9_rush/'.$___TEMP_key; 
	
	$___PRESET_INSTANCE9__VARS__npcinfo_instance9=$npcinfo_instance9;
function ___pre_init() { global $___PRESET_INSTANCE9__VARS__npcinfo_instance9,$npcinfo_instance9;$npcinfo_instance9=$___PRESET_INSTANCE9__VARS__npcinfo_instance9; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_INSTANCE9_PRESET_VARS','$___PRESET_INSTANCE9__VARS__npcinfo_instance9=$npcinfo_instance9;');
define('___LOAD_MOD_INSTANCE9_PRESET_VARS','global $___PRESET_INSTANCE9__VARS__npcinfo_instance9,$npcinfo_instance9;$npcinfo_instance9=$___PRESET_INSTANCE9__VARS__npcinfo_instance9;');
define('MODULE_INSTANCE9_GLOBALS_VARNAMES','npcinfo_instance9');
define('MOD_INSTANCE9',1);
define('IMPORT_MODULE_INSTANCE9_GLOBALS','global $___LOCAL_INSTANCE9__VARS__npcinfo_instance9; $npcinfo_instance9=&$___LOCAL_INSTANCE9__VARS__npcinfo_instance9; ');
define('PREFIX_MODULE_INSTANCE9_GLOBALS','\'; global $___LOCAL_INSTANCE9__VARS__npcinfo_instance9; ${$___TEMP_PREFIX.\'npcinfo_instance9\'}=&$___LOCAL_INSTANCE9__VARS__npcinfo_instance9; unset($___TEMP_PREFIX); ');
define('MODULE_INSTANCE9_GLOBALS','\'; global $___LOCAL_INSTANCE9__VARS__npcinfo_instance9; ${$___TEMP_VARNAME}[\'npcinfo_instance9\']=&$___LOCAL_INSTANCE9__VARS__npcinfo_instance9; unset($___TEMP_VARNAME); ');

global $___PRIVATE_INSTANCE9__VARS_____PRIVATE_PFUNC,$___PRIVATE_INSTANCE9__VARS_____PRIVATE_CFUNC,$___LOCAL_INSTANCE9__VARS__npcinfo_instance9;
$___PRIVATE_INSTANCE9__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_INSTANCE9__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_INSTANCE9__VARS__npcinfo_instance9=&$npcinfo_instance9;
unset($npcinfo_instance9);
hook_register('instance9','card_validate_get_forbidden_cards');hook_register('instance9','init_enter_battlefield_items');hook_register('instance9','get_npclist');hook_register('instance9','get_shopconfig');hook_register('instance9','get_itemfilecont');hook_register('instance9','get_startingitemfilecont');hook_register('instance9','get_startingwepfilecont');hook_register('instance9','get_trapfilecont');hook_register('instance9','calculate_attack_rage_gain_multiplier');hook_register('instance9','calculate_attack_weapon_skill_gain_multiplier');hook_register('instance9','calculate_attack_exp_gain_multiplier');hook_register('instance9','rs_areatime');hook_register('instance9','mapitem_row_data_process');hook_register('instance9','shopitem_row_data_process');hook_register('instance9','event_available');hook_register('instance9','get_uee_deathlog');
function ___post_init() { global $___PRIVATE_INSTANCE9__VARS_____PRIVATE_PFUNC,$___PRIVATE_INSTANCE9__VARS_____PRIVATE_CFUNC,$___LOCAL_INSTANCE9__VARS__npcinfo_instance9;
$___LOCAL_INSTANCE9__VARS__npcinfo_instance9=$GLOBALS['npcinfo_instance9'];
unset($GLOBALS['npcinfo_instance9']);
}
	
}

?>