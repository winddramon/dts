<?php

namespace ex_cursed
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/attr/ex_cursed/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_EX_CURSED_PRESET_VARS','');
define('___LOAD_MOD_EX_CURSED_PRESET_VARS','');
define('MODULE_EX_CURSED_GLOBALS_VARNAMES','');
define('MOD_EX_CURSED',1);
define('IMPORT_MODULE_EX_CURSED_GLOBALS','');
define('PREFIX_MODULE_EX_CURSED_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_EX_CURSED_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_EX_CURSED__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_CURSED__VARS_____PRIVATE_CFUNC;
$___PRIVATE_EX_CURSED__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_EX_CURSED__VARS_____PRIVATE_CFUNC=Array();

hook_register('ex_cursed','itemdrop_valid_check');hook_register('ex_cursed','itemoff_valid_check');hook_register('ex_cursed','itemuse');hook_register('ex_cursed','senditem_check');hook_register('ex_cursed','check_enkan');hook_register('ex_cursed','geming_objvalid');
function ___post_init() { global $___PRIVATE_EX_CURSED__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_CURSED__VARS_____PRIVATE_CFUNC;


}
	
}

?>