<?php

namespace aprilfool2018
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/activities/aprilfool2018/main/'.$___TEMP_key; 
	
	$___PRESET_APRILFOOL2018__VARS__snpcinfo=$snpcinfo;
function ___pre_init() { global $___PRESET_APRILFOOL2018__VARS__snpcinfo,$snpcinfo;$snpcinfo=$___PRESET_APRILFOOL2018__VARS__snpcinfo; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_APRILFOOL2018_PRESET_VARS','$___PRESET_APRILFOOL2018__VARS__snpcinfo=$snpcinfo;');
define('___LOAD_MOD_APRILFOOL2018_PRESET_VARS','global $___PRESET_APRILFOOL2018__VARS__snpcinfo,$snpcinfo;$snpcinfo=$___PRESET_APRILFOOL2018__VARS__snpcinfo;');
define('MODULE_APRILFOOL2018_GLOBALS_VARNAMES','snpcinfo');
define('MOD_APRILFOOL2018',1);
define('IMPORT_MODULE_APRILFOOL2018_GLOBALS','global $___LOCAL_APRILFOOL2018__VARS__snpcinfo; $snpcinfo=&$___LOCAL_APRILFOOL2018__VARS__snpcinfo; ');
define('PREFIX_MODULE_APRILFOOL2018_GLOBALS','\'; global $___LOCAL_APRILFOOL2018__VARS__snpcinfo; ${$___TEMP_PREFIX.\'snpcinfo\'}=&$___LOCAL_APRILFOOL2018__VARS__snpcinfo; unset($___TEMP_PREFIX); ');
define('MODULE_APRILFOOL2018_GLOBALS','\'; global $___LOCAL_APRILFOOL2018__VARS__snpcinfo; ${$___TEMP_VARNAME}[\'snpcinfo\']=&$___LOCAL_APRILFOOL2018__VARS__snpcinfo; unset($___TEMP_VARNAME); ');

global $___PRIVATE_APRILFOOL2018__VARS_____PRIVATE_PFUNC,$___PRIVATE_APRILFOOL2018__VARS_____PRIVATE_CFUNC,$___LOCAL_APRILFOOL2018__VARS__snpcinfo;
$___PRIVATE_APRILFOOL2018__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_APRILFOOL2018__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_APRILFOOL2018__VARS__snpcinfo=&$snpcinfo;
unset($snpcinfo);
hook_register('aprilfool2018','get_npclist');hook_register('aprilfool2018','init_npcdata');hook_register('aprilfool2018','shopitem_row_data_process');
function ___post_init() { global $___PRIVATE_APRILFOOL2018__VARS_____PRIVATE_PFUNC,$___PRIVATE_APRILFOOL2018__VARS_____PRIVATE_CFUNC,$___LOCAL_APRILFOOL2018__VARS__snpcinfo;
$___LOCAL_APRILFOOL2018__VARS__snpcinfo=$GLOBALS['snpcinfo'];
unset($GLOBALS['snpcinfo']);
}
	
}

?>