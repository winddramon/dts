<?php

namespace skill217
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill217/'.$___TEMP_key; 
	
	$___PRESET_SKILL217__VARS__dmggain=$dmggain;$___PRESET_SKILL217__VARS__upgradecost=$upgradecost;
function ___pre_init() { global $___PRESET_SKILL217__VARS__dmggain,$dmggain,$___PRESET_SKILL217__VARS__upgradecost,$upgradecost;$dmggain=$___PRESET_SKILL217__VARS__dmggain;$upgradecost=$___PRESET_SKILL217__VARS__upgradecost; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL217_PRESET_VARS','$___PRESET_SKILL217__VARS__dmggain=$dmggain;$___PRESET_SKILL217__VARS__upgradecost=$upgradecost;');
define('___LOAD_MOD_SKILL217_PRESET_VARS','global $___PRESET_SKILL217__VARS__dmggain,$dmggain,$___PRESET_SKILL217__VARS__upgradecost,$upgradecost;$dmggain=$___PRESET_SKILL217__VARS__dmggain;$upgradecost=$___PRESET_SKILL217__VARS__upgradecost;');
define('MOD_SKILL217_INFO','club;upgrade;');
define('MOD_SKILL217_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill217/desc');
define('MODULE_SKILL217_GLOBALS_VARNAMES','dmggain,upgradecost');
define('MOD_SKILL217',1);
define('IMPORT_MODULE_SKILL217_GLOBALS','global $___LOCAL_SKILL217__VARS__dmggain,$___LOCAL_SKILL217__VARS__upgradecost; $dmggain=&$___LOCAL_SKILL217__VARS__dmggain; $upgradecost=&$___LOCAL_SKILL217__VARS__upgradecost; ');
define('PREFIX_MODULE_SKILL217_GLOBALS','\'; global $___LOCAL_SKILL217__VARS__dmggain; ${$___TEMP_PREFIX.\'dmggain\'}=&$___LOCAL_SKILL217__VARS__dmggain; global $___LOCAL_SKILL217__VARS__upgradecost; ${$___TEMP_PREFIX.\'upgradecost\'}=&$___LOCAL_SKILL217__VARS__upgradecost; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL217_GLOBALS','\'; global $___LOCAL_SKILL217__VARS__dmggain; ${$___TEMP_VARNAME}[\'dmggain\']=&$___LOCAL_SKILL217__VARS__dmggain; global $___LOCAL_SKILL217__VARS__upgradecost; ${$___TEMP_VARNAME}[\'upgradecost\']=&$___LOCAL_SKILL217__VARS__upgradecost; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL217__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL217__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL217__VARS__dmggain,$___LOCAL_SKILL217__VARS__upgradecost;
$___PRIVATE_SKILL217__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL217__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_SKILL217__VARS__dmggain=&$dmggain;$___LOCAL_SKILL217__VARS__upgradecost=&$upgradecost;
unset($dmggain,$upgradecost);
hook_register('skill217','acquire217');hook_register('skill217','lost217');hook_register('skill217','check_unlocked217');hook_register('skill217','upgrade217');hook_register('skill217','get_skill217_extra_dmg_gain');hook_register('skill217','calculate_ex_attack_dmg_multiplier');
function ___post_init() { global $___PRIVATE_SKILL217__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL217__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL217__VARS__dmggain,$___LOCAL_SKILL217__VARS__upgradecost;
$___LOCAL_SKILL217__VARS__dmggain=$GLOBALS['dmggain'];$___LOCAL_SKILL217__VARS__upgradecost=$GLOBALS['upgradecost'];
unset($GLOBALS['dmggain'],$GLOBALS['upgradecost']);
}
	
}

?>