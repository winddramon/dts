<?php

namespace itemmix
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'base/itemmix/itemmix/'.$___TEMP_key; 
	
	$___PRESET_ITEMMIX__VARS__mix_type=$mix_type;$___PRESET_ITEMMIX__VARS__itmname_ignore=$itmname_ignore;$___PRESET_ITEMMIX__VARS__mixinfo=$mixinfo;
function ___pre_init() { global $___PRESET_ITEMMIX__VARS__mix_type,$mix_type,$___PRESET_ITEMMIX__VARS__itmname_ignore,$itmname_ignore,$___PRESET_ITEMMIX__VARS__mixinfo,$mixinfo;$mix_type=$___PRESET_ITEMMIX__VARS__mix_type;$itmname_ignore=$___PRESET_ITEMMIX__VARS__itmname_ignore;$mixinfo=$___PRESET_ITEMMIX__VARS__mixinfo; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_ITEMMIX_PRESET_VARS','$___PRESET_ITEMMIX__VARS__mix_type=$mix_type;$___PRESET_ITEMMIX__VARS__itmname_ignore=$itmname_ignore;$___PRESET_ITEMMIX__VARS__mixinfo=$mixinfo;');
define('___LOAD_MOD_ITEMMIX_PRESET_VARS','global $___PRESET_ITEMMIX__VARS__mix_type,$mix_type,$___PRESET_ITEMMIX__VARS__itmname_ignore,$itmname_ignore,$___PRESET_ITEMMIX__VARS__mixinfo,$mixinfo;$mix_type=$___PRESET_ITEMMIX__VARS__mix_type;$itmname_ignore=$___PRESET_ITEMMIX__VARS__itmname_ignore;$mixinfo=$___PRESET_ITEMMIX__VARS__mixinfo;');
define('MOD_ITEMMIX_ITEMMIX','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/base\\itemmix\\itemmix/itemmix');
define('MOD_ITEMMIX_ITEMMIX_CMD','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/base\\itemmix\\itemmix/itemmix_cmd');
define('MOD_ITEMMIX_ITEMMIX_OPTIONS','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/base\\itemmix\\itemmix/itemmix_options');
define('MOD_ITEMMIX_ITEMMIX_OPTION_START','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/base\\itemmix\\itemmix/itemmix_option_start');
define('MOD_ITEMMIX_ITEMMIX_OPTION_END','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/base\\itemmix\\itemmix/itemmix_option_end');
define('MODULE_ITEMMIX_GLOBALS_VARNAMES','mix_type,itmname_ignore,mixinfo');
define('MOD_ITEMMIX',1);
define('IMPORT_MODULE_ITEMMIX_GLOBALS','global $___LOCAL_ITEMMIX__VARS__mix_type,$___LOCAL_ITEMMIX__VARS__itmname_ignore,$___LOCAL_ITEMMIX__VARS__mixinfo; $mix_type=&$___LOCAL_ITEMMIX__VARS__mix_type; $itmname_ignore=&$___LOCAL_ITEMMIX__VARS__itmname_ignore; $mixinfo=&$___LOCAL_ITEMMIX__VARS__mixinfo; ');
define('PREFIX_MODULE_ITEMMIX_GLOBALS','\'; global $___LOCAL_ITEMMIX__VARS__mix_type; ${$___TEMP_PREFIX.\'mix_type\'}=&$___LOCAL_ITEMMIX__VARS__mix_type; global $___LOCAL_ITEMMIX__VARS__itmname_ignore; ${$___TEMP_PREFIX.\'itmname_ignore\'}=&$___LOCAL_ITEMMIX__VARS__itmname_ignore; global $___LOCAL_ITEMMIX__VARS__mixinfo; ${$___TEMP_PREFIX.\'mixinfo\'}=&$___LOCAL_ITEMMIX__VARS__mixinfo; unset($___TEMP_PREFIX); ');
define('MODULE_ITEMMIX_GLOBALS','\'; global $___LOCAL_ITEMMIX__VARS__mix_type; ${$___TEMP_VARNAME}[\'mix_type\']=&$___LOCAL_ITEMMIX__VARS__mix_type; global $___LOCAL_ITEMMIX__VARS__itmname_ignore; ${$___TEMP_VARNAME}[\'itmname_ignore\']=&$___LOCAL_ITEMMIX__VARS__itmname_ignore; global $___LOCAL_ITEMMIX__VARS__mixinfo; ${$___TEMP_VARNAME}[\'mixinfo\']=&$___LOCAL_ITEMMIX__VARS__mixinfo; unset($___TEMP_VARNAME); ');

global $___PRIVATE_ITEMMIX__VARS_____PRIVATE_PFUNC,$___PRIVATE_ITEMMIX__VARS_____PRIVATE_CFUNC,$___LOCAL_ITEMMIX__VARS__mix_type,$___LOCAL_ITEMMIX__VARS__itmname_ignore,$___LOCAL_ITEMMIX__VARS__mixinfo;
$___PRIVATE_ITEMMIX__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_ITEMMIX__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_ITEMMIX__VARS__mix_type=&$mix_type;$___LOCAL_ITEMMIX__VARS__itmname_ignore=&$itmname_ignore;$___LOCAL_ITEMMIX__VARS__mixinfo=&$mixinfo;
unset($mix_type,$itmname_ignore,$mixinfo);
hook_register('itemmix','get_mixinfo');hook_register('itemmix','itemmix_success');hook_register('itemmix','itemmix_place_check');hook_register('itemmix','itemmix_name_proc');hook_register('itemmix','itemmix_recipe_check');hook_register('itemmix','parse_itemmix_resultshow');hook_register('itemmix','itemmix_option_show');hook_register('itemmix','calc_mixmask');hook_register('itemmix','itemmix_get_result');hook_register('itemmix','itemmix');hook_register('itemmix','itemmix_proc');hook_register('itemmix','get_itemmix_filename');hook_register('itemmix','itemmix_reduce');hook_register('itemmix','act');hook_register('itemmix','parse_news');
function ___post_init() { global $___PRIVATE_ITEMMIX__VARS_____PRIVATE_PFUNC,$___PRIVATE_ITEMMIX__VARS_____PRIVATE_CFUNC,$___LOCAL_ITEMMIX__VARS__mix_type,$___LOCAL_ITEMMIX__VARS__itmname_ignore,$___LOCAL_ITEMMIX__VARS__mixinfo;
$___LOCAL_ITEMMIX__VARS__mix_type=$GLOBALS['mix_type'];$___LOCAL_ITEMMIX__VARS__itmname_ignore=$GLOBALS['itmname_ignore'];$___LOCAL_ITEMMIX__VARS__mixinfo=$GLOBALS['mixinfo'];
unset($GLOBALS['mix_type'],$GLOBALS['itmname_ignore'],$GLOBALS['mixinfo']);
}
	
}

?>