<?php

namespace boxes
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'base/items/boxes/'.$___TEMP_key; 
	
	$___PRESET_BOXES__VARS__room_mode_can_get_card_from_boxes=$room_mode_can_get_card_from_boxes;$___PRESET_BOXES__VARS__item_boxes_list_file=$item_boxes_list_file;
function ___pre_init() { global $___PRESET_BOXES__VARS__room_mode_can_get_card_from_boxes,$room_mode_can_get_card_from_boxes,$___PRESET_BOXES__VARS__item_boxes_list_file,$item_boxes_list_file;$room_mode_can_get_card_from_boxes=$___PRESET_BOXES__VARS__room_mode_can_get_card_from_boxes;$item_boxes_list_file=$___PRESET_BOXES__VARS__item_boxes_list_file; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_BOXES_PRESET_VARS','$___PRESET_BOXES__VARS__room_mode_can_get_card_from_boxes=$room_mode_can_get_card_from_boxes;$___PRESET_BOXES__VARS__item_boxes_list_file=$item_boxes_list_file;');
define('___LOAD_MOD_BOXES_PRESET_VARS','global $___PRESET_BOXES__VARS__room_mode_can_get_card_from_boxes,$room_mode_can_get_card_from_boxes,$___PRESET_BOXES__VARS__item_boxes_list_file,$item_boxes_list_file;$room_mode_can_get_card_from_boxes=$___PRESET_BOXES__VARS__room_mode_can_get_card_from_boxes;$item_boxes_list_file=$___PRESET_BOXES__VARS__item_boxes_list_file;');
define('MODULE_BOXES_GLOBALS_VARNAMES','room_mode_can_get_card_from_boxes,item_boxes_list_file');
define('MOD_BOXES',1);
define('IMPORT_MODULE_BOXES_GLOBALS','global $___LOCAL_BOXES__VARS__room_mode_can_get_card_from_boxes,$___LOCAL_BOXES__VARS__item_boxes_list_file; $room_mode_can_get_card_from_boxes=&$___LOCAL_BOXES__VARS__room_mode_can_get_card_from_boxes; $item_boxes_list_file=&$___LOCAL_BOXES__VARS__item_boxes_list_file; ');
define('PREFIX_MODULE_BOXES_GLOBALS','\'; global $___LOCAL_BOXES__VARS__room_mode_can_get_card_from_boxes; ${$___TEMP_PREFIX.\'room_mode_can_get_card_from_boxes\'}=&$___LOCAL_BOXES__VARS__room_mode_can_get_card_from_boxes; global $___LOCAL_BOXES__VARS__item_boxes_list_file; ${$___TEMP_PREFIX.\'item_boxes_list_file\'}=&$___LOCAL_BOXES__VARS__item_boxes_list_file; unset($___TEMP_PREFIX); ');
define('MODULE_BOXES_GLOBALS','\'; global $___LOCAL_BOXES__VARS__room_mode_can_get_card_from_boxes; ${$___TEMP_VARNAME}[\'room_mode_can_get_card_from_boxes\']=&$___LOCAL_BOXES__VARS__room_mode_can_get_card_from_boxes; global $___LOCAL_BOXES__VARS__item_boxes_list_file; ${$___TEMP_VARNAME}[\'item_boxes_list_file\']=&$___LOCAL_BOXES__VARS__item_boxes_list_file; unset($___TEMP_VARNAME); ');

global $___PRIVATE_BOXES__VARS_____PRIVATE_PFUNC,$___PRIVATE_BOXES__VARS_____PRIVATE_CFUNC,$___LOCAL_BOXES__VARS__room_mode_can_get_card_from_boxes,$___LOCAL_BOXES__VARS__item_boxes_list_file;
$___PRIVATE_BOXES__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_BOXES__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_BOXES__VARS__room_mode_can_get_card_from_boxes=&$room_mode_can_get_card_from_boxes;$___LOCAL_BOXES__VARS__item_boxes_list_file=&$item_boxes_list_file;
unset($room_mode_can_get_card_from_boxes,$item_boxes_list_file);
hook_register('boxes','itemuse_boxes');hook_register('boxes','boxes_row_data_seperate');hook_register('boxes','boxes_row_data_process');hook_register('boxes','itemuse');hook_register('boxes','parse_news');
function ___post_init() { global $___PRIVATE_BOXES__VARS_____PRIVATE_PFUNC,$___PRIVATE_BOXES__VARS_____PRIVATE_CFUNC,$___LOCAL_BOXES__VARS__room_mode_can_get_card_from_boxes,$___LOCAL_BOXES__VARS__item_boxes_list_file;
$___LOCAL_BOXES__VARS__room_mode_can_get_card_from_boxes=$GLOBALS['room_mode_can_get_card_from_boxes'];$___LOCAL_BOXES__VARS__item_boxes_list_file=$GLOBALS['item_boxes_list_file'];
unset($GLOBALS['room_mode_can_get_card_from_boxes'],$GLOBALS['item_boxes_list_file']);
}
	
}

?>