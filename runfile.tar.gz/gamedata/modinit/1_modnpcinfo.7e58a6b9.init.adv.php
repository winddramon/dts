<?php

namespace npcinfo
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/misc/npcinfo/'.$___TEMP_key; 
	
	$___PRESET_NPCINFO__VARS__bubblebox_style=$bubblebox_style;
function ___pre_init() { global $___PRESET_NPCINFO__VARS__bubblebox_style,$bubblebox_style;$bubblebox_style=$___PRESET_NPCINFO__VARS__bubblebox_style; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_NPCINFO_PRESET_VARS','$___PRESET_NPCINFO__VARS__bubblebox_style=$bubblebox_style;');
define('___LOAD_MOD_NPCINFO_PRESET_VARS','global $___PRESET_NPCINFO__VARS__bubblebox_style,$bubblebox_style;$bubblebox_style=$___PRESET_NPCINFO__VARS__bubblebox_style;');
define('MOD_NPCINFO_NPCINFO','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\misc\\npcinfo/npcinfo');
define('MODULE_NPCINFO_GLOBALS_VARNAMES','bubblebox_style');
define('MOD_NPCINFO',1);
define('IMPORT_MODULE_NPCINFO_GLOBALS','global $___LOCAL_NPCINFO__VARS__bubblebox_style; $bubblebox_style=&$___LOCAL_NPCINFO__VARS__bubblebox_style; ');
define('PREFIX_MODULE_NPCINFO_GLOBALS','\'; global $___LOCAL_NPCINFO__VARS__bubblebox_style; ${$___TEMP_PREFIX.\'bubblebox_style\'}=&$___LOCAL_NPCINFO__VARS__bubblebox_style; unset($___TEMP_PREFIX); ');
define('MODULE_NPCINFO_GLOBALS','\'; global $___LOCAL_NPCINFO__VARS__bubblebox_style; ${$___TEMP_VARNAME}[\'bubblebox_style\']=&$___LOCAL_NPCINFO__VARS__bubblebox_style; unset($___TEMP_VARNAME); ');

global $___PRIVATE_NPCINFO__VARS_____PRIVATE_PFUNC,$___PRIVATE_NPCINFO__VARS_____PRIVATE_CFUNC,$___LOCAL_NPCINFO__VARS__bubblebox_style;
$___PRIVATE_NPCINFO__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_NPCINFO__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_NPCINFO__VARS__bubblebox_style=&$bubblebox_style;
unset($bubblebox_style);
hook_register('npcinfo','npcinfo_gen_item_description');hook_register('npcinfo','npcinfo_get_npc_description');hook_register('npcinfo','npcinfo_get_npc_description_all');
function ___post_init() { global $___PRIVATE_NPCINFO__VARS_____PRIVATE_PFUNC,$___PRIVATE_NPCINFO__VARS_____PRIVATE_CFUNC,$___LOCAL_NPCINFO__VARS__bubblebox_style;
$___LOCAL_NPCINFO__VARS__bubblebox_style=$GLOBALS['bubblebox_style'];
unset($GLOBALS['bubblebox_style']);
}
	
}

?>