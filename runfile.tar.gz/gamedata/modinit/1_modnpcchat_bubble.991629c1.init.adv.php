<?php

namespace npcchat_bubble
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/misc/npcchat_bubble/'.$___TEMP_key; 
	
	$___PRESET_NPCCHAT_BUBBLE__VARS__npcchat_bubble_on=$npcchat_bubble_on;$___PRESET_NPCCHAT_BUBBLE__VARS__npcchat_bubble_replace_log=$npcchat_bubble_replace_log;
function ___pre_init() { global $___PRESET_NPCCHAT_BUBBLE__VARS__npcchat_bubble_on,$npcchat_bubble_on,$___PRESET_NPCCHAT_BUBBLE__VARS__npcchat_bubble_replace_log,$npcchat_bubble_replace_log;$npcchat_bubble_on=$___PRESET_NPCCHAT_BUBBLE__VARS__npcchat_bubble_on;$npcchat_bubble_replace_log=$___PRESET_NPCCHAT_BUBBLE__VARS__npcchat_bubble_replace_log; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_NPCCHAT_BUBBLE_PRESET_VARS','$___PRESET_NPCCHAT_BUBBLE__VARS__npcchat_bubble_on=$npcchat_bubble_on;$___PRESET_NPCCHAT_BUBBLE__VARS__npcchat_bubble_replace_log=$npcchat_bubble_replace_log;');
define('___LOAD_MOD_NPCCHAT_BUBBLE_PRESET_VARS','global $___PRESET_NPCCHAT_BUBBLE__VARS__npcchat_bubble_on,$npcchat_bubble_on,$___PRESET_NPCCHAT_BUBBLE__VARS__npcchat_bubble_replace_log,$npcchat_bubble_replace_log;$npcchat_bubble_on=$___PRESET_NPCCHAT_BUBBLE__VARS__npcchat_bubble_on;$npcchat_bubble_replace_log=$___PRESET_NPCCHAT_BUBBLE__VARS__npcchat_bubble_replace_log;');
define('MOD_NPCCHAT_BUBBLE_BUBBLEPAGE','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\misc\\npcchat_bubble/bubblepage');
define('MODULE_NPCCHAT_BUBBLE_GLOBALS_VARNAMES','npcchat_bubble_on,npcchat_bubble_replace_log');
define('MOD_NPCCHAT_BUBBLE',1);
define('IMPORT_MODULE_NPCCHAT_BUBBLE_GLOBALS','global $___LOCAL_NPCCHAT_BUBBLE__VARS__npcchat_bubble_on,$___LOCAL_NPCCHAT_BUBBLE__VARS__npcchat_bubble_replace_log; $npcchat_bubble_on=&$___LOCAL_NPCCHAT_BUBBLE__VARS__npcchat_bubble_on; $npcchat_bubble_replace_log=&$___LOCAL_NPCCHAT_BUBBLE__VARS__npcchat_bubble_replace_log; ');
define('PREFIX_MODULE_NPCCHAT_BUBBLE_GLOBALS','\'; global $___LOCAL_NPCCHAT_BUBBLE__VARS__npcchat_bubble_on; ${$___TEMP_PREFIX.\'npcchat_bubble_on\'}=&$___LOCAL_NPCCHAT_BUBBLE__VARS__npcchat_bubble_on; global $___LOCAL_NPCCHAT_BUBBLE__VARS__npcchat_bubble_replace_log; ${$___TEMP_PREFIX.\'npcchat_bubble_replace_log\'}=&$___LOCAL_NPCCHAT_BUBBLE__VARS__npcchat_bubble_replace_log; unset($___TEMP_PREFIX); ');
define('MODULE_NPCCHAT_BUBBLE_GLOBALS','\'; global $___LOCAL_NPCCHAT_BUBBLE__VARS__npcchat_bubble_on; ${$___TEMP_VARNAME}[\'npcchat_bubble_on\']=&$___LOCAL_NPCCHAT_BUBBLE__VARS__npcchat_bubble_on; global $___LOCAL_NPCCHAT_BUBBLE__VARS__npcchat_bubble_replace_log; ${$___TEMP_VARNAME}[\'npcchat_bubble_replace_log\']=&$___LOCAL_NPCCHAT_BUBBLE__VARS__npcchat_bubble_replace_log; unset($___TEMP_VARNAME); ');

global $___PRIVATE_NPCCHAT_BUBBLE__VARS_____PRIVATE_PFUNC,$___PRIVATE_NPCCHAT_BUBBLE__VARS_____PRIVATE_CFUNC,$___LOCAL_NPCCHAT_BUBBLE__VARS__npcchat_bubble_on,$___LOCAL_NPCCHAT_BUBBLE__VARS__npcchat_bubble_replace_log;
$___PRIVATE_NPCCHAT_BUBBLE__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_NPCCHAT_BUBBLE__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_NPCCHAT_BUBBLE__VARS__npcchat_bubble_on=&$npcchat_bubble_on;$___LOCAL_NPCCHAT_BUBBLE__VARS__npcchat_bubble_replace_log=&$npcchat_bubble_replace_log;
unset($npcchat_bubble_on,$npcchat_bubble_replace_log);
hook_register('npcchat_bubble','npcchat_print');hook_register('npcchat_bubble','npcchat_tag_process');hook_register('npcchat_bubble','npcchat_get_chatlog');hook_register('npcchat_bubble','npcchat_bubble_cleanqm');hook_register('npcchat_bubble','player_kill_enemy');hook_register('npcchat_bubble','npcchat_bubble_show');
function ___post_init() { global $___PRIVATE_NPCCHAT_BUBBLE__VARS_____PRIVATE_PFUNC,$___PRIVATE_NPCCHAT_BUBBLE__VARS_____PRIVATE_CFUNC,$___LOCAL_NPCCHAT_BUBBLE__VARS__npcchat_bubble_on,$___LOCAL_NPCCHAT_BUBBLE__VARS__npcchat_bubble_replace_log;
$___LOCAL_NPCCHAT_BUBBLE__VARS__npcchat_bubble_on=$GLOBALS['npcchat_bubble_on'];$___LOCAL_NPCCHAT_BUBBLE__VARS__npcchat_bubble_replace_log=$GLOBALS['npcchat_bubble_replace_log'];
unset($GLOBALS['npcchat_bubble_on'],$GLOBALS['npcchat_bubble_replace_log']);
}
	
}

?>