<?php

namespace item_uu
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/item_extra/item_uu/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_ITEM_UU_PRESET_VARS','');
define('___LOAD_MOD_ITEM_UU_PRESET_VARS','');
define('MODULE_ITEM_UU_GLOBALS_VARNAMES','');
define('MOD_ITEM_UU',1);
define('IMPORT_MODULE_ITEM_UU_GLOBALS','');
define('PREFIX_MODULE_ITEM_UU_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_ITEM_UU_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_ITEM_UU__VARS_____PRIVATE_PFUNC,$___PRIVATE_ITEM_UU__VARS_____PRIVATE_CFUNC;
$___PRIVATE_ITEM_UU__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_ITEM_UU__VARS_____PRIVATE_CFUNC=Array();

hook_register('item_uu','parse_itmuse_desc');hook_register('item_uu','itemuse');hook_register('item_uu','parse_news');
function ___post_init() { global $___PRIVATE_ITEM_UU__VARS_____PRIVATE_PFUNC,$___PRIVATE_ITEM_UU__VARS_____PRIVATE_CFUNC;


}
	
}

?>