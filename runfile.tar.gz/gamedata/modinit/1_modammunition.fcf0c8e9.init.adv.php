<?php

namespace ammunition
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'base/items/ammunition/'.$___TEMP_key; 
	
	$___PRESET_AMMUNITION__VARS__ammukind=$ammukind;
function ___pre_init() { global $___PRESET_AMMUNITION__VARS__ammukind,$ammukind;$ammukind=$___PRESET_AMMUNITION__VARS__ammukind; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_AMMUNITION_PRESET_VARS','$___PRESET_AMMUNITION__VARS__ammukind=$ammukind;');
define('___LOAD_MOD_AMMUNITION_PRESET_VARS','global $___PRESET_AMMUNITION__VARS__ammukind,$ammukind;$ammukind=$___PRESET_AMMUNITION__VARS__ammukind;');
define('MODULE_AMMUNITION_GLOBALS_VARNAMES','ammukind');
define('MOD_AMMUNITION',1);
define('IMPORT_MODULE_AMMUNITION_GLOBALS','global $___LOCAL_AMMUNITION__VARS__ammukind; $ammukind=&$___LOCAL_AMMUNITION__VARS__ammukind; ');
define('PREFIX_MODULE_AMMUNITION_GLOBALS','\'; global $___LOCAL_AMMUNITION__VARS__ammukind; ${$___TEMP_PREFIX.\'ammukind\'}=&$___LOCAL_AMMUNITION__VARS__ammukind; unset($___TEMP_PREFIX); ');
define('MODULE_AMMUNITION_GLOBALS','\'; global $___LOCAL_AMMUNITION__VARS__ammukind; ${$___TEMP_VARNAME}[\'ammukind\']=&$___LOCAL_AMMUNITION__VARS__ammukind; unset($___TEMP_VARNAME); ');

global $___PRIVATE_AMMUNITION__VARS_____PRIVATE_PFUNC,$___PRIVATE_AMMUNITION__VARS_____PRIVATE_CFUNC,$___LOCAL_AMMUNITION__VARS__ammukind;
$___PRIVATE_AMMUNITION__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_AMMUNITION__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_AMMUNITION__VARS__ammukind=&$ammukind;
unset($ammukind);
hook_register('ammunition','parse_itmk_desc');hook_register('ammunition','check_ammukind');hook_register('ammunition','itemuse_ugb');hook_register('ammunition','itemuse');
function ___post_init() { global $___PRIVATE_AMMUNITION__VARS_____PRIVATE_PFUNC,$___PRIVATE_AMMUNITION__VARS_____PRIVATE_CFUNC,$___LOCAL_AMMUNITION__VARS__ammukind;
$___LOCAL_AMMUNITION__VARS__ammukind=$GLOBALS['ammukind'];
unset($GLOBALS['ammukind']);
}
	
}

?>