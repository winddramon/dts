<?php

namespace item_randskills
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/item_extra/item_randskills/'.$___TEMP_key; 
	
	$___PRESET_ITEM_RANDSKILLS__VARS__rs_allowclublist=$rs_allowclublist;$___PRESET_ITEM_RANDSKILLS__VARS__rs_banlist=$rs_banlist;$___PRESET_ITEM_RANDSKILLS__VARS__rs_feature=$rs_feature;$___PRESET_ITEM_RANDSKILLS__VARS__rs_cardskills=$rs_cardskills;
function ___pre_init() { global $___PRESET_ITEM_RANDSKILLS__VARS__rs_allowclublist,$rs_allowclublist,$___PRESET_ITEM_RANDSKILLS__VARS__rs_banlist,$rs_banlist,$___PRESET_ITEM_RANDSKILLS__VARS__rs_feature,$rs_feature,$___PRESET_ITEM_RANDSKILLS__VARS__rs_cardskills,$rs_cardskills;$rs_allowclublist=$___PRESET_ITEM_RANDSKILLS__VARS__rs_allowclublist;$rs_banlist=$___PRESET_ITEM_RANDSKILLS__VARS__rs_banlist;$rs_feature=$___PRESET_ITEM_RANDSKILLS__VARS__rs_feature;$rs_cardskills=$___PRESET_ITEM_RANDSKILLS__VARS__rs_cardskills; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_ITEM_RANDSKILLS_PRESET_VARS','$___PRESET_ITEM_RANDSKILLS__VARS__rs_allowclublist=$rs_allowclublist;$___PRESET_ITEM_RANDSKILLS__VARS__rs_banlist=$rs_banlist;$___PRESET_ITEM_RANDSKILLS__VARS__rs_feature=$rs_feature;$___PRESET_ITEM_RANDSKILLS__VARS__rs_cardskills=$rs_cardskills;');
define('___LOAD_MOD_ITEM_RANDSKILLS_PRESET_VARS','global $___PRESET_ITEM_RANDSKILLS__VARS__rs_allowclublist,$rs_allowclublist,$___PRESET_ITEM_RANDSKILLS__VARS__rs_banlist,$rs_banlist,$___PRESET_ITEM_RANDSKILLS__VARS__rs_feature,$rs_feature,$___PRESET_ITEM_RANDSKILLS__VARS__rs_cardskills,$rs_cardskills;$rs_allowclublist=$___PRESET_ITEM_RANDSKILLS__VARS__rs_allowclublist;$rs_banlist=$___PRESET_ITEM_RANDSKILLS__VARS__rs_banlist;$rs_feature=$___PRESET_ITEM_RANDSKILLS__VARS__rs_feature;$rs_cardskills=$___PRESET_ITEM_RANDSKILLS__VARS__rs_cardskills;');
define('MOD_ITEM_RANDSKILLS_USE_SKCORE','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\item_extra\\item_randskills/use_skcore');
define('MODULE_ITEM_RANDSKILLS_GLOBALS_VARNAMES','rs_allowclublist,rs_banlist,rs_feature,rs_cardskills');
define('MOD_ITEM_RANDSKILLS',1);
define('IMPORT_MODULE_ITEM_RANDSKILLS_GLOBALS','global $___LOCAL_ITEM_RANDSKILLS__VARS__rs_allowclublist,$___LOCAL_ITEM_RANDSKILLS__VARS__rs_banlist,$___LOCAL_ITEM_RANDSKILLS__VARS__rs_feature,$___LOCAL_ITEM_RANDSKILLS__VARS__rs_cardskills; $rs_allowclublist=&$___LOCAL_ITEM_RANDSKILLS__VARS__rs_allowclublist; $rs_banlist=&$___LOCAL_ITEM_RANDSKILLS__VARS__rs_banlist; $rs_feature=&$___LOCAL_ITEM_RANDSKILLS__VARS__rs_feature; $rs_cardskills=&$___LOCAL_ITEM_RANDSKILLS__VARS__rs_cardskills; ');
define('PREFIX_MODULE_ITEM_RANDSKILLS_GLOBALS','\'; global $___LOCAL_ITEM_RANDSKILLS__VARS__rs_allowclublist; ${$___TEMP_PREFIX.\'rs_allowclublist\'}=&$___LOCAL_ITEM_RANDSKILLS__VARS__rs_allowclublist; global $___LOCAL_ITEM_RANDSKILLS__VARS__rs_banlist; ${$___TEMP_PREFIX.\'rs_banlist\'}=&$___LOCAL_ITEM_RANDSKILLS__VARS__rs_banlist; global $___LOCAL_ITEM_RANDSKILLS__VARS__rs_feature; ${$___TEMP_PREFIX.\'rs_feature\'}=&$___LOCAL_ITEM_RANDSKILLS__VARS__rs_feature; global $___LOCAL_ITEM_RANDSKILLS__VARS__rs_cardskills; ${$___TEMP_PREFIX.\'rs_cardskills\'}=&$___LOCAL_ITEM_RANDSKILLS__VARS__rs_cardskills; unset($___TEMP_PREFIX); ');
define('MODULE_ITEM_RANDSKILLS_GLOBALS','\'; global $___LOCAL_ITEM_RANDSKILLS__VARS__rs_allowclublist; ${$___TEMP_VARNAME}[\'rs_allowclublist\']=&$___LOCAL_ITEM_RANDSKILLS__VARS__rs_allowclublist; global $___LOCAL_ITEM_RANDSKILLS__VARS__rs_banlist; ${$___TEMP_VARNAME}[\'rs_banlist\']=&$___LOCAL_ITEM_RANDSKILLS__VARS__rs_banlist; global $___LOCAL_ITEM_RANDSKILLS__VARS__rs_feature; ${$___TEMP_VARNAME}[\'rs_feature\']=&$___LOCAL_ITEM_RANDSKILLS__VARS__rs_feature; global $___LOCAL_ITEM_RANDSKILLS__VARS__rs_cardskills; ${$___TEMP_VARNAME}[\'rs_cardskills\']=&$___LOCAL_ITEM_RANDSKILLS__VARS__rs_cardskills; unset($___TEMP_VARNAME); ');

global $___PRIVATE_ITEM_RANDSKILLS__VARS_____PRIVATE_PFUNC,$___PRIVATE_ITEM_RANDSKILLS__VARS_____PRIVATE_CFUNC,$___LOCAL_ITEM_RANDSKILLS__VARS__rs_allowclublist,$___LOCAL_ITEM_RANDSKILLS__VARS__rs_banlist,$___LOCAL_ITEM_RANDSKILLS__VARS__rs_feature,$___LOCAL_ITEM_RANDSKILLS__VARS__rs_cardskills;
$___PRIVATE_ITEM_RANDSKILLS__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_ITEM_RANDSKILLS__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_ITEM_RANDSKILLS__VARS__rs_allowclublist=&$rs_allowclublist;$___LOCAL_ITEM_RANDSKILLS__VARS__rs_banlist=&$rs_banlist;$___LOCAL_ITEM_RANDSKILLS__VARS__rs_feature=&$rs_feature;$___LOCAL_ITEM_RANDSKILLS__VARS__rs_cardskills=&$rs_cardskills;
unset($rs_allowclublist,$rs_banlist,$rs_feature,$rs_cardskills);
hook_register('item_randskills','parse_itmuse_desc');hook_register('item_randskills','itemuse');hook_register('item_randskills','use_skcore_success');hook_register('item_randskills','get_skcore_skilllist');hook_register('item_randskills','add_skcore_choices');hook_register('item_randskills','get_rand_clubskill');hook_register('item_randskills','choose_rand_clubskill');hook_register('item_randskills','get_skilllist');hook_register('item_randskills','get_if_skilltype');hook_register('item_randskills','check_comp_itmsk_visible');
function ___post_init() { global $___PRIVATE_ITEM_RANDSKILLS__VARS_____PRIVATE_PFUNC,$___PRIVATE_ITEM_RANDSKILLS__VARS_____PRIVATE_CFUNC,$___LOCAL_ITEM_RANDSKILLS__VARS__rs_allowclublist,$___LOCAL_ITEM_RANDSKILLS__VARS__rs_banlist,$___LOCAL_ITEM_RANDSKILLS__VARS__rs_feature,$___LOCAL_ITEM_RANDSKILLS__VARS__rs_cardskills;
$___LOCAL_ITEM_RANDSKILLS__VARS__rs_allowclublist=$GLOBALS['rs_allowclublist'];$___LOCAL_ITEM_RANDSKILLS__VARS__rs_banlist=$GLOBALS['rs_banlist'];$___LOCAL_ITEM_RANDSKILLS__VARS__rs_feature=$GLOBALS['rs_feature'];$___LOCAL_ITEM_RANDSKILLS__VARS__rs_cardskills=$GLOBALS['rs_cardskills'];
unset($GLOBALS['rs_allowclublist'],$GLOBALS['rs_banlist'],$GLOBALS['rs_feature'],$GLOBALS['rs_cardskills']);
}
	
}

?>