<?php

namespace skill1003
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill1003/'.$___TEMP_key; 
	
	$___PRESET_SKILL1003__VARS__skill1003_o_money=$skill1003_o_money;
function ___pre_init() { global $___PRESET_SKILL1003__VARS__skill1003_o_money,$skill1003_o_money;$skill1003_o_money=$___PRESET_SKILL1003__VARS__skill1003_o_money; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL1003_PRESET_VARS','$___PRESET_SKILL1003__VARS__skill1003_o_money=$skill1003_o_money;');
define('___LOAD_MOD_SKILL1003_PRESET_VARS','global $___PRESET_SKILL1003__VARS__skill1003_o_money,$skill1003_o_money;$skill1003_o_money=$___PRESET_SKILL1003__VARS__skill1003_o_money;');
define('MOD_SKILL1003_INFO','hidden;');
define('MODULE_SKILL1003_GLOBALS_VARNAMES','skill1003_o_money');
define('MOD_SKILL1003',1);
define('IMPORT_MODULE_SKILL1003_GLOBALS','global $___LOCAL_SKILL1003__VARS__skill1003_o_money; $skill1003_o_money=&$___LOCAL_SKILL1003__VARS__skill1003_o_money; ');
define('PREFIX_MODULE_SKILL1003_GLOBALS','\'; global $___LOCAL_SKILL1003__VARS__skill1003_o_money; ${$___TEMP_PREFIX.\'skill1003_o_money\'}=&$___LOCAL_SKILL1003__VARS__skill1003_o_money; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL1003_GLOBALS','\'; global $___LOCAL_SKILL1003__VARS__skill1003_o_money; ${$___TEMP_VARNAME}[\'skill1003_o_money\']=&$___LOCAL_SKILL1003__VARS__skill1003_o_money; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL1003__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL1003__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL1003__VARS__skill1003_o_money;
$___PRIVATE_SKILL1003__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL1003__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_SKILL1003__VARS__skill1003_o_money=&$skill1003_o_money;
unset($skill1003_o_money);
hook_register('skill1003','acquire1003');hook_register('skill1003','lost1003');hook_register('skill1003','check_unlocked1003');hook_register('skill1003','pre_act');hook_register('skill1003','post_act');hook_register('skill1003','battle_get_qiegao_update');hook_register('skill1003','gameover_get_gold_up');hook_register('skill1003','gameover_get_credit_up');hook_register('skill1003','gameover_check_money_got');hook_register('skill1003','deathnote_process_core');hook_register('skill1003','get_dinfo');hook_register('skill1003','player_damaged_enemy');hook_register('skill1003','record_last_kill');hook_register('skill1003','player_kill_enemy');hook_register('skill1003','trap_hit');hook_register('skill1003','post_enterbattlefield_events');
function ___post_init() { global $___PRIVATE_SKILL1003__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL1003__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL1003__VARS__skill1003_o_money;
$___LOCAL_SKILL1003__VARS__skill1003_o_money=$GLOBALS['skill1003_o_money'];
unset($GLOBALS['skill1003_o_money']);
}
	
}

?>