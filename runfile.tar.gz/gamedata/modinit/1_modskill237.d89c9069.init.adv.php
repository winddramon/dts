<?php

namespace skill237
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill237/'.$___TEMP_key; 
	
	$___PRESET_SKILL237__VARS__ragecost=$ragecost;$___PRESET_SKILL237__VARS__stuntime237=$stuntime237;$___PRESET_SKILL237__VARS__cdtime237=$cdtime237;
function ___pre_init() { global $___PRESET_SKILL237__VARS__ragecost,$ragecost,$___PRESET_SKILL237__VARS__stuntime237,$stuntime237,$___PRESET_SKILL237__VARS__cdtime237,$cdtime237;$ragecost=$___PRESET_SKILL237__VARS__ragecost;$stuntime237=$___PRESET_SKILL237__VARS__stuntime237;$cdtime237=$___PRESET_SKILL237__VARS__cdtime237; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL237_PRESET_VARS','$___PRESET_SKILL237__VARS__ragecost=$ragecost;$___PRESET_SKILL237__VARS__stuntime237=$stuntime237;$___PRESET_SKILL237__VARS__cdtime237=$cdtime237;');
define('___LOAD_MOD_SKILL237_PRESET_VARS','global $___PRESET_SKILL237__VARS__ragecost,$ragecost,$___PRESET_SKILL237__VARS__stuntime237,$stuntime237,$___PRESET_SKILL237__VARS__cdtime237,$cdtime237;$ragecost=$___PRESET_SKILL237__VARS__ragecost;$stuntime237=$___PRESET_SKILL237__VARS__stuntime237;$cdtime237=$___PRESET_SKILL237__VARS__cdtime237;');
define('MOD_SKILL237_INFO','club;battle;');
define('MOD_SKILL237_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill237/desc');
define('MOD_SKILL237_BATTLECMD_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill237/battlecmd_desc');
define('MODULE_SKILL237_GLOBALS_VARNAMES','ragecost,stuntime237,cdtime237');
define('MOD_SKILL237',1);
define('IMPORT_MODULE_SKILL237_GLOBALS','global $___LOCAL_SKILL237__VARS__ragecost,$___LOCAL_SKILL237__VARS__stuntime237,$___LOCAL_SKILL237__VARS__cdtime237; $ragecost=&$___LOCAL_SKILL237__VARS__ragecost; $stuntime237=&$___LOCAL_SKILL237__VARS__stuntime237; $cdtime237=&$___LOCAL_SKILL237__VARS__cdtime237; ');
define('PREFIX_MODULE_SKILL237_GLOBALS','\'; global $___LOCAL_SKILL237__VARS__ragecost; ${$___TEMP_PREFIX.\'ragecost\'}=&$___LOCAL_SKILL237__VARS__ragecost; global $___LOCAL_SKILL237__VARS__stuntime237; ${$___TEMP_PREFIX.\'stuntime237\'}=&$___LOCAL_SKILL237__VARS__stuntime237; global $___LOCAL_SKILL237__VARS__cdtime237; ${$___TEMP_PREFIX.\'cdtime237\'}=&$___LOCAL_SKILL237__VARS__cdtime237; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL237_GLOBALS','\'; global $___LOCAL_SKILL237__VARS__ragecost; ${$___TEMP_VARNAME}[\'ragecost\']=&$___LOCAL_SKILL237__VARS__ragecost; global $___LOCAL_SKILL237__VARS__stuntime237; ${$___TEMP_VARNAME}[\'stuntime237\']=&$___LOCAL_SKILL237__VARS__stuntime237; global $___LOCAL_SKILL237__VARS__cdtime237; ${$___TEMP_VARNAME}[\'cdtime237\']=&$___LOCAL_SKILL237__VARS__cdtime237; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL237__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL237__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL237__VARS__ragecost,$___LOCAL_SKILL237__VARS__stuntime237,$___LOCAL_SKILL237__VARS__cdtime237;
$___PRIVATE_SKILL237__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL237__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_SKILL237__VARS__ragecost=&$ragecost;$___LOCAL_SKILL237__VARS__stuntime237=&$stuntime237;$___LOCAL_SKILL237__VARS__cdtime237=&$cdtime237;
unset($ragecost,$stuntime237,$cdtime237);
hook_register('skill237','acquire237');hook_register('skill237','lost237');hook_register('skill237','check_unlocked237');hook_register('skill237','get_rage_cost237');hook_register('skill237','strike_prepare');hook_register('skill237','get_physical_dmg_change');hook_register('skill237','strike_finish');hook_register('skill237','parse_news');
function ___post_init() { global $___PRIVATE_SKILL237__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL237__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL237__VARS__ragecost,$___LOCAL_SKILL237__VARS__stuntime237,$___LOCAL_SKILL237__VARS__cdtime237;
$___LOCAL_SKILL237__VARS__ragecost=$GLOBALS['ragecost'];$___LOCAL_SKILL237__VARS__stuntime237=$GLOBALS['stuntime237'];$___LOCAL_SKILL237__VARS__cdtime237=$GLOBALS['cdtime237'];
unset($GLOBALS['ragecost'],$GLOBALS['stuntime237'],$GLOBALS['cdtime237']);
}
	
}

?>