<?php

namespace skill208
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill208/'.$___TEMP_key; 
	
	$___PRESET_SKILL208__VARS__ragecost=$ragecost;$___PRESET_SKILL208__VARS__wep_skillkind_req=$wep_skillkind_req;
function ___pre_init() { global $___PRESET_SKILL208__VARS__ragecost,$ragecost,$___PRESET_SKILL208__VARS__wep_skillkind_req,$wep_skillkind_req;$ragecost=$___PRESET_SKILL208__VARS__ragecost;$wep_skillkind_req=$___PRESET_SKILL208__VARS__wep_skillkind_req; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL208_PRESET_VARS','$___PRESET_SKILL208__VARS__ragecost=$ragecost;$___PRESET_SKILL208__VARS__wep_skillkind_req=$wep_skillkind_req;');
define('___LOAD_MOD_SKILL208_PRESET_VARS','global $___PRESET_SKILL208__VARS__ragecost,$ragecost,$___PRESET_SKILL208__VARS__wep_skillkind_req,$wep_skillkind_req;$ragecost=$___PRESET_SKILL208__VARS__ragecost;$wep_skillkind_req=$___PRESET_SKILL208__VARS__wep_skillkind_req;');
define('MOD_SKILL208_INFO','club;battle;');
define('MOD_SKILL208_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill208/desc');
define('MOD_SKILL208_BATTLECMD_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill208/battlecmd_desc');
define('MODULE_SKILL208_GLOBALS_VARNAMES','ragecost,wep_skillkind_req');
define('MOD_SKILL208',1);
define('IMPORT_MODULE_SKILL208_GLOBALS','global $___LOCAL_SKILL208__VARS__ragecost,$___LOCAL_SKILL208__VARS__wep_skillkind_req; $ragecost=&$___LOCAL_SKILL208__VARS__ragecost; $wep_skillkind_req=&$___LOCAL_SKILL208__VARS__wep_skillkind_req; ');
define('PREFIX_MODULE_SKILL208_GLOBALS','\'; global $___LOCAL_SKILL208__VARS__ragecost; ${$___TEMP_PREFIX.\'ragecost\'}=&$___LOCAL_SKILL208__VARS__ragecost; global $___LOCAL_SKILL208__VARS__wep_skillkind_req; ${$___TEMP_PREFIX.\'wep_skillkind_req\'}=&$___LOCAL_SKILL208__VARS__wep_skillkind_req; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL208_GLOBALS','\'; global $___LOCAL_SKILL208__VARS__ragecost; ${$___TEMP_VARNAME}[\'ragecost\']=&$___LOCAL_SKILL208__VARS__ragecost; global $___LOCAL_SKILL208__VARS__wep_skillkind_req; ${$___TEMP_VARNAME}[\'wep_skillkind_req\']=&$___LOCAL_SKILL208__VARS__wep_skillkind_req; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL208__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL208__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL208__VARS__ragecost,$___LOCAL_SKILL208__VARS__wep_skillkind_req;
$___PRIVATE_SKILL208__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL208__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_SKILL208__VARS__ragecost=&$ragecost;$___LOCAL_SKILL208__VARS__wep_skillkind_req=&$wep_skillkind_req;
unset($ragecost,$wep_skillkind_req);
hook_register('skill208','acquire208');hook_register('skill208','lost208');hook_register('skill208','check_unlocked208');hook_register('skill208','get_rage_cost208');hook_register('skill208','strike_prepare');hook_register('skill208','check_ex_rapid_def_exists');hook_register('skill208','check_physical_def_attr');hook_register('skill208','check_ex_single_dmg_def_attr');hook_register('skill208','get_final_dmg_multiplier');hook_register('skill208','parse_news');
function ___post_init() { global $___PRIVATE_SKILL208__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL208__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL208__VARS__ragecost,$___LOCAL_SKILL208__VARS__wep_skillkind_req;
$___LOCAL_SKILL208__VARS__ragecost=$GLOBALS['ragecost'];$___LOCAL_SKILL208__VARS__wep_skillkind_req=$GLOBALS['wep_skillkind_req'];
unset($GLOBALS['ragecost'],$GLOBALS['wep_skillkind_req']);
}
	
}

?>