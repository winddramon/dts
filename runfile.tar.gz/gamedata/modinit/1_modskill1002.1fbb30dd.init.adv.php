<?php

namespace skill1002
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/instance/skill1002/'.$___TEMP_key; 
	
	$___PRESET_SKILL1002__VARS__skill1002_act_time=$skill1002_act_time;$___PRESET_SKILL1002__VARS__skill1002_no_effect_array=$skill1002_no_effect_array;
function ___pre_init() { global $___PRESET_SKILL1002__VARS__skill1002_act_time,$skill1002_act_time,$___PRESET_SKILL1002__VARS__skill1002_no_effect_array,$skill1002_no_effect_array;$skill1002_act_time=$___PRESET_SKILL1002__VARS__skill1002_act_time;$skill1002_no_effect_array=$___PRESET_SKILL1002__VARS__skill1002_no_effect_array; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL1002_PRESET_VARS','$___PRESET_SKILL1002__VARS__skill1002_act_time=$skill1002_act_time;$___PRESET_SKILL1002__VARS__skill1002_no_effect_array=$skill1002_no_effect_array;');
define('___LOAD_MOD_SKILL1002_PRESET_VARS','global $___PRESET_SKILL1002__VARS__skill1002_act_time,$skill1002_act_time,$___PRESET_SKILL1002__VARS__skill1002_no_effect_array,$skill1002_no_effect_array;$skill1002_act_time=$___PRESET_SKILL1002__VARS__skill1002_act_time;$skill1002_no_effect_array=$___PRESET_SKILL1002__VARS__skill1002_no_effect_array;');
define('MOD_SKILL1002_INFO','card;locked;buffer;');
define('MOD_SKILL1002_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\instance\\skill1002/desc');
define('MODULE_SKILL1002_GLOBALS_VARNAMES','skill1002_act_time,skill1002_no_effect_array');
define('MOD_SKILL1002',1);
define('IMPORT_MODULE_SKILL1002_GLOBALS','global $___LOCAL_SKILL1002__VARS__skill1002_act_time,$___LOCAL_SKILL1002__VARS__skill1002_no_effect_array; $skill1002_act_time=&$___LOCAL_SKILL1002__VARS__skill1002_act_time; $skill1002_no_effect_array=&$___LOCAL_SKILL1002__VARS__skill1002_no_effect_array; ');
define('PREFIX_MODULE_SKILL1002_GLOBALS','\'; global $___LOCAL_SKILL1002__VARS__skill1002_act_time; ${$___TEMP_PREFIX.\'skill1002_act_time\'}=&$___LOCAL_SKILL1002__VARS__skill1002_act_time; global $___LOCAL_SKILL1002__VARS__skill1002_no_effect_array; ${$___TEMP_PREFIX.\'skill1002_no_effect_array\'}=&$___LOCAL_SKILL1002__VARS__skill1002_no_effect_array; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL1002_GLOBALS','\'; global $___LOCAL_SKILL1002__VARS__skill1002_act_time; ${$___TEMP_VARNAME}[\'skill1002_act_time\']=&$___LOCAL_SKILL1002__VARS__skill1002_act_time; global $___LOCAL_SKILL1002__VARS__skill1002_no_effect_array; ${$___TEMP_VARNAME}[\'skill1002_no_effect_array\']=&$___LOCAL_SKILL1002__VARS__skill1002_no_effect_array; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL1002__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL1002__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL1002__VARS__skill1002_act_time,$___LOCAL_SKILL1002__VARS__skill1002_no_effect_array;
$___PRIVATE_SKILL1002__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL1002__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_SKILL1002__VARS__skill1002_act_time=&$skill1002_act_time;$___LOCAL_SKILL1002__VARS__skill1002_no_effect_array=&$skill1002_no_effect_array;
unset($skill1002_act_time,$skill1002_no_effect_array);
hook_register('skill1002','acquire1002');hook_register('skill1002','lost1002');hook_register('skill1002','check_unlocked1002');hook_register('skill1002','check_available1002');hook_register('skill1002','check_corpse_discover');hook_register('skill1002','apply_total_damage_modifier_invincible');hook_register('skill1002','kill');hook_register('skill1002','get_trap_final_damage_modifier_down');
function ___post_init() { global $___PRIVATE_SKILL1002__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL1002__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL1002__VARS__skill1002_act_time,$___LOCAL_SKILL1002__VARS__skill1002_no_effect_array;
$___LOCAL_SKILL1002__VARS__skill1002_act_time=$GLOBALS['skill1002_act_time'];$___LOCAL_SKILL1002__VARS__skill1002_no_effect_array=$GLOBALS['skill1002_no_effect_array'];
unset($GLOBALS['skill1002_act_time'],$GLOBALS['skill1002_no_effect_array']);
}
	
}

?>