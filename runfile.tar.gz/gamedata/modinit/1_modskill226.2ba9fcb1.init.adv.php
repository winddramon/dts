<?php

namespace skill226
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill226/'.$___TEMP_key; 
	
	$___PRESET_SKILL226__VARS__alternate_skillno226=$alternate_skillno226;$___PRESET_SKILL226__VARS__unlock_lvl226=$unlock_lvl226;
function ___pre_init() { global $___PRESET_SKILL226__VARS__alternate_skillno226,$alternate_skillno226,$___PRESET_SKILL226__VARS__unlock_lvl226,$unlock_lvl226;$alternate_skillno226=$___PRESET_SKILL226__VARS__alternate_skillno226;$unlock_lvl226=$___PRESET_SKILL226__VARS__unlock_lvl226; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL226_PRESET_VARS','$___PRESET_SKILL226__VARS__alternate_skillno226=$alternate_skillno226;$___PRESET_SKILL226__VARS__unlock_lvl226=$unlock_lvl226;');
define('___LOAD_MOD_SKILL226_PRESET_VARS','global $___PRESET_SKILL226__VARS__alternate_skillno226,$alternate_skillno226,$___PRESET_SKILL226__VARS__unlock_lvl226,$unlock_lvl226;$alternate_skillno226=$___PRESET_SKILL226__VARS__alternate_skillno226;$unlock_lvl226=$___PRESET_SKILL226__VARS__unlock_lvl226;');
define('MOD_SKILL226_INFO','club;upgrade;');
define('MOD_SKILL226_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill226/desc');
define('MODULE_SKILL226_GLOBALS_VARNAMES','alternate_skillno226,unlock_lvl226');
define('MOD_SKILL226',1);
define('IMPORT_MODULE_SKILL226_GLOBALS','global $___LOCAL_SKILL226__VARS__alternate_skillno226,$___LOCAL_SKILL226__VARS__unlock_lvl226; $alternate_skillno226=&$___LOCAL_SKILL226__VARS__alternate_skillno226; $unlock_lvl226=&$___LOCAL_SKILL226__VARS__unlock_lvl226; ');
define('PREFIX_MODULE_SKILL226_GLOBALS','\'; global $___LOCAL_SKILL226__VARS__alternate_skillno226; ${$___TEMP_PREFIX.\'alternate_skillno226\'}=&$___LOCAL_SKILL226__VARS__alternate_skillno226; global $___LOCAL_SKILL226__VARS__unlock_lvl226; ${$___TEMP_PREFIX.\'unlock_lvl226\'}=&$___LOCAL_SKILL226__VARS__unlock_lvl226; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL226_GLOBALS','\'; global $___LOCAL_SKILL226__VARS__alternate_skillno226; ${$___TEMP_VARNAME}[\'alternate_skillno226\']=&$___LOCAL_SKILL226__VARS__alternate_skillno226; global $___LOCAL_SKILL226__VARS__unlock_lvl226; ${$___TEMP_VARNAME}[\'unlock_lvl226\']=&$___LOCAL_SKILL226__VARS__unlock_lvl226; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL226__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL226__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL226__VARS__alternate_skillno226,$___LOCAL_SKILL226__VARS__unlock_lvl226;
$___PRIVATE_SKILL226__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL226__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_SKILL226__VARS__alternate_skillno226=&$alternate_skillno226;$___LOCAL_SKILL226__VARS__unlock_lvl226=&$unlock_lvl226;
unset($alternate_skillno226,$unlock_lvl226);
hook_register('skill226','acquire226');hook_register('skill226','lost226');hook_register('skill226','check_unlocked226');hook_register('skill226','check_unlocked_state226');hook_register('skill226','upgrade226');hook_register('skill226','calculate_attack_exp_gain_base');
function ___post_init() { global $___PRIVATE_SKILL226__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL226__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL226__VARS__alternate_skillno226,$___LOCAL_SKILL226__VARS__unlock_lvl226;
$___LOCAL_SKILL226__VARS__alternate_skillno226=$GLOBALS['alternate_skillno226'];$___LOCAL_SKILL226__VARS__unlock_lvl226=$GLOBALS['unlock_lvl226'];
unset($GLOBALS['alternate_skillno226'],$GLOBALS['unlock_lvl226']);
}
	
}

?>