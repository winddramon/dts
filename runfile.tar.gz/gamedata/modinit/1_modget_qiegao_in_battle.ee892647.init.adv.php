<?php

namespace get_qiegao_in_battle
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/misc/get_qiegao_in_battle/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_GET_QIEGAO_IN_BATTLE_PRESET_VARS','');
define('___LOAD_MOD_GET_QIEGAO_IN_BATTLE_PRESET_VARS','');
define('MODULE_GET_QIEGAO_IN_BATTLE_GLOBALS_VARNAMES','');
define('MOD_GET_QIEGAO_IN_BATTLE',1);
define('IMPORT_MODULE_GET_QIEGAO_IN_BATTLE_GLOBALS','');
define('PREFIX_MODULE_GET_QIEGAO_IN_BATTLE_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_GET_QIEGAO_IN_BATTLE_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_GET_QIEGAO_IN_BATTLE__VARS_____PRIVATE_PFUNC,$___PRIVATE_GET_QIEGAO_IN_BATTLE__VARS_____PRIVATE_CFUNC;
$___PRIVATE_GET_QIEGAO_IN_BATTLE__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_GET_QIEGAO_IN_BATTLE__VARS_____PRIVATE_CFUNC=Array();

hook_register('get_qiegao_in_battle','calc_qiegao_drop');hook_register('get_qiegao_in_battle','player_kill_enemy');hook_register('get_qiegao_in_battle','battle_get_qiegao');hook_register('get_qiegao_in_battle','battle_get_qiegao_update');
function ___post_init() { global $___PRIVATE_GET_QIEGAO_IN_BATTLE__VARS_____PRIVATE_PFUNC,$___PRIVATE_GET_QIEGAO_IN_BATTLE__VARS_____PRIVATE_CFUNC;


}
	
}

?>