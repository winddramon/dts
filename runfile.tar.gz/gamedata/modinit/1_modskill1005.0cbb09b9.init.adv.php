<?php

namespace skill1005
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/instance/gtype5/skill1005/'.$___TEMP_key; 
	
	$___PRESET_SKILL1005__VARS__goal1005=$goal1005;
function ___pre_init() { global $___PRESET_SKILL1005__VARS__goal1005,$goal1005;$goal1005=$___PRESET_SKILL1005__VARS__goal1005; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL1005_PRESET_VARS','$___PRESET_SKILL1005__VARS__goal1005=$goal1005;');
define('___LOAD_MOD_SKILL1005_PRESET_VARS','global $___PRESET_SKILL1005__VARS__goal1005,$goal1005;$goal1005=$___PRESET_SKILL1005__VARS__goal1005;');
define('MOD_SKILL1005_INFO','card;unique;active;locked;');
define('MOD_SKILL1005_PROFILECMD','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\instance\\gtype5\\skill1005/profilecmd');
define('MOD_SKILL1005_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\instance\\gtype5\\skill1005/desc');
define('MODULE_SKILL1005_GLOBALS_VARNAMES','goal1005');
define('MOD_SKILL1005',1);
define('IMPORT_MODULE_SKILL1005_GLOBALS','global $___LOCAL_SKILL1005__VARS__goal1005; $goal1005=&$___LOCAL_SKILL1005__VARS__goal1005; ');
define('PREFIX_MODULE_SKILL1005_GLOBALS','\'; global $___LOCAL_SKILL1005__VARS__goal1005; ${$___TEMP_PREFIX.\'goal1005\'}=&$___LOCAL_SKILL1005__VARS__goal1005; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL1005_GLOBALS','\'; global $___LOCAL_SKILL1005__VARS__goal1005; ${$___TEMP_VARNAME}[\'goal1005\']=&$___LOCAL_SKILL1005__VARS__goal1005; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL1005__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL1005__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL1005__VARS__goal1005;
$___PRIVATE_SKILL1005__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL1005__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_SKILL1005__VARS__goal1005=&$goal1005;
unset($goal1005);
hook_register('skill1005','acquire1005');hook_register('skill1005','lost1005');hook_register('skill1005','check_unlocked1005');hook_register('skill1005','wdebug_check1005');hook_register('skill1005','wdebug_reset1005');hook_register('skill1005','wdebug_showreq1005');hook_register('skill1005','wdebug1005');hook_register('skill1005','act');hook_register('skill1005','parse_news');
function ___post_init() { global $___PRIVATE_SKILL1005__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL1005__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL1005__VARS__goal1005;
$___LOCAL_SKILL1005__VARS__goal1005=$GLOBALS['goal1005'];
unset($GLOBALS['goal1005']);
}
	
}

?>