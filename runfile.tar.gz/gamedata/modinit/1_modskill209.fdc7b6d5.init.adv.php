<?php

namespace skill209
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill209/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL209_PRESET_VARS','');
define('___LOAD_MOD_SKILL209_PRESET_VARS','');
define('MOD_SKILL209_INFO','club;');
define('MOD_SKILL209_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill209/desc');
define('MODULE_SKILL209_GLOBALS_VARNAMES','');
define('MOD_SKILL209',1);
define('IMPORT_MODULE_SKILL209_GLOBALS','');
define('PREFIX_MODULE_SKILL209_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL209_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL209__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL209__VARS_____PRIVATE_CFUNC;
$___PRIVATE_SKILL209__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL209__VARS_____PRIVATE_CFUNC=Array();

hook_register('skill209','acquire209');hook_register('skill209','lost209');hook_register('skill209','check_unlocked209');hook_register('skill209','get_weapon_fluc_percentage');hook_register('skill209','calculate_weapon_wound_multiplier');
function ___post_init() { global $___PRIVATE_SKILL209__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL209__VARS_____PRIVATE_CFUNC;


}
	
}

?>