<?php

namespace skill102
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill102/'.$___TEMP_key; 
	
	$___PRESET_SKILL102__VARS__ragecost=$ragecost;
function ___pre_init() { global $___PRESET_SKILL102__VARS__ragecost,$ragecost;$ragecost=$___PRESET_SKILL102__VARS__ragecost; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL102_PRESET_VARS','$___PRESET_SKILL102__VARS__ragecost=$ragecost;');
define('___LOAD_MOD_SKILL102_PRESET_VARS','global $___PRESET_SKILL102__VARS__ragecost,$ragecost;$ragecost=$___PRESET_SKILL102__VARS__ragecost;');
define('MOD_SKILL102_INFO','club;battle;');
define('MOD_SKILL102_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill102/desc');
define('MOD_SKILL102_BATTLECMD_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill102/battlecmd_desc');
define('MODULE_SKILL102_GLOBALS_VARNAMES','ragecost');
define('MOD_SKILL102',1);
define('IMPORT_MODULE_SKILL102_GLOBALS','global $___LOCAL_SKILL102__VARS__ragecost; $ragecost=&$___LOCAL_SKILL102__VARS__ragecost; ');
define('PREFIX_MODULE_SKILL102_GLOBALS','\'; global $___LOCAL_SKILL102__VARS__ragecost; ${$___TEMP_PREFIX.\'ragecost\'}=&$___LOCAL_SKILL102__VARS__ragecost; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL102_GLOBALS','\'; global $___LOCAL_SKILL102__VARS__ragecost; ${$___TEMP_VARNAME}[\'ragecost\']=&$___LOCAL_SKILL102__VARS__ragecost; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL102__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL102__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL102__VARS__ragecost;
$___PRIVATE_SKILL102__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL102__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_SKILL102__VARS__ragecost=&$ragecost;
unset($ragecost);
hook_register('skill102','acquire102');hook_register('skill102','lost102');hook_register('skill102','check_unlocked102');hook_register('skill102','get_rage_cost102');hook_register('skill102','strike_prepare');hook_register('skill102','get_internal_att');hook_register('skill102','get_ex_attack_array_core');hook_register('skill102','parse_news');
function ___post_init() { global $___PRIVATE_SKILL102__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL102__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL102__VARS__ragecost;
$___LOCAL_SKILL102__VARS__ragecost=$GLOBALS['ragecost'];
unset($GLOBALS['ragecost']);
}
	
}

?>