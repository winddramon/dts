<?php

namespace ex_dmg_nullify
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/attr/ex_dmg_nullify/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_EX_DMG_NULLIFY_PRESET_VARS','');
define('___LOAD_MOD_EX_DMG_NULLIFY_PRESET_VARS','');
define('MODULE_EX_DMG_NULLIFY_GLOBALS_VARNAMES','');
define('MOD_EX_DMG_NULLIFY',1);
define('IMPORT_MODULE_EX_DMG_NULLIFY_GLOBALS','');
define('PREFIX_MODULE_EX_DMG_NULLIFY_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_EX_DMG_NULLIFY_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_EX_DMG_NULLIFY__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_DMG_NULLIFY__VARS_____PRIVATE_CFUNC;
$___PRIVATE_EX_DMG_NULLIFY__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_EX_DMG_NULLIFY__VARS_____PRIVATE_CFUNC=Array();

hook_register('ex_dmg_nullify','get_ex_dmg_nullify_proc_rate');hook_register('ex_dmg_nullify','check_ex_dmg_nullify');hook_register('ex_dmg_nullify','check_ex_attack_available');hook_register('ex_dmg_nullify','strike_prepare');
function ___post_init() { global $___PRIVATE_EX_DMG_NULLIFY__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_DMG_NULLIFY__VARS_____PRIVATE_CFUNC;


}
	
}

?>