<?php

namespace item_ub
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'base/items/item_ub/'.$___TEMP_key; 
	
	$___PRESET_ITEM_UB__VARS__elec_cap=$elec_cap;
function ___pre_init() { global $___PRESET_ITEM_UB__VARS__elec_cap,$elec_cap;$elec_cap=$___PRESET_ITEM_UB__VARS__elec_cap; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_ITEM_UB_PRESET_VARS','$___PRESET_ITEM_UB__VARS__elec_cap=$elec_cap;');
define('___LOAD_MOD_ITEM_UB_PRESET_VARS','global $___PRESET_ITEM_UB__VARS__elec_cap,$elec_cap;$elec_cap=$___PRESET_ITEM_UB__VARS__elec_cap;');
define('MODULE_ITEM_UB_GLOBALS_VARNAMES','elec_cap');
define('MOD_ITEM_UB',1);
define('IMPORT_MODULE_ITEM_UB_GLOBALS','global $___LOCAL_ITEM_UB__VARS__elec_cap; $elec_cap=&$___LOCAL_ITEM_UB__VARS__elec_cap; ');
define('PREFIX_MODULE_ITEM_UB_GLOBALS','\'; global $___LOCAL_ITEM_UB__VARS__elec_cap; ${$___TEMP_PREFIX.\'elec_cap\'}=&$___LOCAL_ITEM_UB__VARS__elec_cap; unset($___TEMP_PREFIX); ');
define('MODULE_ITEM_UB_GLOBALS','\'; global $___LOCAL_ITEM_UB__VARS__elec_cap; ${$___TEMP_VARNAME}[\'elec_cap\']=&$___LOCAL_ITEM_UB__VARS__elec_cap; unset($___TEMP_VARNAME); ');

global $___PRIVATE_ITEM_UB__VARS_____PRIVATE_PFUNC,$___PRIVATE_ITEM_UB__VARS_____PRIVATE_CFUNC,$___LOCAL_ITEM_UB__VARS__elec_cap;
$___PRIVATE_ITEM_UB__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_ITEM_UB__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_ITEM_UB__VARS__elec_cap=&$elec_cap;
unset($elec_cap);
hook_register('item_ub','itemuse_ub');hook_register('item_ub','ub_check');hook_register('item_ub','itemuse');
function ___post_init() { global $___PRIVATE_ITEM_UB__VARS_____PRIVATE_PFUNC,$___PRIVATE_ITEM_UB__VARS_____PRIVATE_CFUNC,$___LOCAL_ITEM_UB__VARS__elec_cap;
$___LOCAL_ITEM_UB__VARS__elec_cap=$GLOBALS['elec_cap'];
unset($GLOBALS['elec_cap']);
}
	
}

?>