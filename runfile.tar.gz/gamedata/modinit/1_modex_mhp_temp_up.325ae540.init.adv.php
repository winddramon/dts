<?php

namespace ex_mhp_temp_up
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/attr/ex_mhp_temp_up/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_EX_MHP_TEMP_UP_PRESET_VARS','');
define('___LOAD_MOD_EX_MHP_TEMP_UP_PRESET_VARS','');
define('MODULE_EX_MHP_TEMP_UP_GLOBALS_VARNAMES','');
define('MOD_EX_MHP_TEMP_UP',1);
define('IMPORT_MODULE_EX_MHP_TEMP_UP_GLOBALS','');
define('PREFIX_MODULE_EX_MHP_TEMP_UP_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_EX_MHP_TEMP_UP_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_EX_MHP_TEMP_UP__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_MHP_TEMP_UP__VARS_____PRIVATE_CFUNC;
$___PRIVATE_EX_MHP_TEMP_UP__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_EX_MHP_TEMP_UP__VARS_____PRIVATE_CFUNC=Array();

hook_register('ex_mhp_temp_up','itemuse_edible_get_mhp');hook_register('ex_mhp_temp_up','ex_mhp_temp_lose');hook_register('ex_mhp_temp_up','itemdrop_valid_check');hook_register('ex_mhp_temp_up','itemoff_valid_check');hook_register('ex_mhp_temp_up','itemuse');hook_register('ex_mhp_temp_up','act');hook_register('ex_mhp_temp_up','upgrade28');
function ___post_init() { global $___PRIVATE_EX_MHP_TEMP_UP__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_MHP_TEMP_UP__VARS_____PRIVATE_CFUNC;


}
	
}

?>