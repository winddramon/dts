<?php

namespace bufficons
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/misc/bufficons/'.$___TEMP_key; 
	
	$___PRESET_BUFFICONS__VARS__bufficons_list=$bufficons_list;$___PRESET_BUFFICONS__VARS__tmp_totsec=$tmp_totsec;$___PRESET_BUFFICONS__VARS__tmp_nowsec=$tmp_nowsec;
function ___pre_init() { global $___PRESET_BUFFICONS__VARS__bufficons_list,$bufficons_list,$___PRESET_BUFFICONS__VARS__tmp_totsec,$tmp_totsec,$___PRESET_BUFFICONS__VARS__tmp_nowsec,$tmp_nowsec;$bufficons_list=$___PRESET_BUFFICONS__VARS__bufficons_list;$tmp_totsec=$___PRESET_BUFFICONS__VARS__tmp_totsec;$tmp_nowsec=$___PRESET_BUFFICONS__VARS__tmp_nowsec; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_BUFFICONS_PRESET_VARS','$___PRESET_BUFFICONS__VARS__bufficons_list=$bufficons_list;$___PRESET_BUFFICONS__VARS__tmp_totsec=$tmp_totsec;$___PRESET_BUFFICONS__VARS__tmp_nowsec=$tmp_nowsec;');
define('___LOAD_MOD_BUFFICONS_PRESET_VARS','global $___PRESET_BUFFICONS__VARS__bufficons_list,$bufficons_list,$___PRESET_BUFFICONS__VARS__tmp_totsec,$tmp_totsec,$___PRESET_BUFFICONS__VARS__tmp_nowsec,$tmp_nowsec;$bufficons_list=$___PRESET_BUFFICONS__VARS__bufficons_list;$tmp_totsec=$___PRESET_BUFFICONS__VARS__tmp_totsec;$tmp_nowsec=$___PRESET_BUFFICONS__VARS__tmp_nowsec;');
define('MOD_BUFFICONS_ICON_STYLE_1','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\misc\\bufficons/icon_style_1');
define('MOD_BUFFICONS_ICON_STYLE_2','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\misc\\bufficons/icon_style_2');
define('MOD_BUFFICONS_ICON_STYLE_3','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\misc\\bufficons/icon_style_3');
define('MOD_BUFFICONS_PROFILE','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\misc\\bufficons/profile');
define('MOD_BUFFICONS_CORNER_TEXT','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\misc\\bufficons/corner_text');
define('MODULE_BUFFICONS_GLOBALS_VARNAMES','bufficons_list,tmp_totsec,tmp_nowsec');
define('MOD_BUFFICONS',1);
define('IMPORT_MODULE_BUFFICONS_GLOBALS','global $___LOCAL_BUFFICONS__VARS__bufficons_list,$___LOCAL_BUFFICONS__VARS__tmp_totsec,$___LOCAL_BUFFICONS__VARS__tmp_nowsec; $bufficons_list=&$___LOCAL_BUFFICONS__VARS__bufficons_list; $tmp_totsec=&$___LOCAL_BUFFICONS__VARS__tmp_totsec; $tmp_nowsec=&$___LOCAL_BUFFICONS__VARS__tmp_nowsec; ');
define('PREFIX_MODULE_BUFFICONS_GLOBALS','\'; global $___LOCAL_BUFFICONS__VARS__bufficons_list; ${$___TEMP_PREFIX.\'bufficons_list\'}=&$___LOCAL_BUFFICONS__VARS__bufficons_list; global $___LOCAL_BUFFICONS__VARS__tmp_totsec; ${$___TEMP_PREFIX.\'tmp_totsec\'}=&$___LOCAL_BUFFICONS__VARS__tmp_totsec; global $___LOCAL_BUFFICONS__VARS__tmp_nowsec; ${$___TEMP_PREFIX.\'tmp_nowsec\'}=&$___LOCAL_BUFFICONS__VARS__tmp_nowsec; unset($___TEMP_PREFIX); ');
define('MODULE_BUFFICONS_GLOBALS','\'; global $___LOCAL_BUFFICONS__VARS__bufficons_list; ${$___TEMP_VARNAME}[\'bufficons_list\']=&$___LOCAL_BUFFICONS__VARS__bufficons_list; global $___LOCAL_BUFFICONS__VARS__tmp_totsec; ${$___TEMP_VARNAME}[\'tmp_totsec\']=&$___LOCAL_BUFFICONS__VARS__tmp_totsec; global $___LOCAL_BUFFICONS__VARS__tmp_nowsec; ${$___TEMP_VARNAME}[\'tmp_nowsec\']=&$___LOCAL_BUFFICONS__VARS__tmp_nowsec; unset($___TEMP_VARNAME); ');

global $___PRIVATE_BUFFICONS__VARS_____PRIVATE_PFUNC,$___PRIVATE_BUFFICONS__VARS_____PRIVATE_CFUNC,$___LOCAL_BUFFICONS__VARS__bufficons_list,$___LOCAL_BUFFICONS__VARS__tmp_totsec,$___LOCAL_BUFFICONS__VARS__tmp_nowsec;
$___PRIVATE_BUFFICONS__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_BUFFICONS__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_BUFFICONS__VARS__bufficons_list=&$bufficons_list;$___LOCAL_BUFFICONS__VARS__tmp_totsec=&$tmp_totsec;$___LOCAL_BUFFICONS__VARS__tmp_nowsec=&$tmp_nowsec;
unset($bufficons_list,$tmp_totsec,$tmp_nowsec);
hook_register('bufficons','bufficon_show');hook_register('bufficons','bufficons_display');hook_register('bufficons','bufficons_display_single');hook_register('bufficons','bufficons_set_timestamp');hook_register('bufficons','bufficons_check_buff_state');hook_register('bufficons','bufficons_check_buff_state_shell');hook_register('bufficons','bufficons_activate_buff');hook_register('bufficons','bufficons_impose_buff');
function ___post_init() { global $___PRIVATE_BUFFICONS__VARS_____PRIVATE_PFUNC,$___PRIVATE_BUFFICONS__VARS_____PRIVATE_CFUNC,$___LOCAL_BUFFICONS__VARS__bufficons_list,$___LOCAL_BUFFICONS__VARS__tmp_totsec,$___LOCAL_BUFFICONS__VARS__tmp_nowsec;
$___LOCAL_BUFFICONS__VARS__bufficons_list=$GLOBALS['bufficons_list'];$___LOCAL_BUFFICONS__VARS__tmp_totsec=$GLOBALS['tmp_totsec'];$___LOCAL_BUFFICONS__VARS__tmp_nowsec=$GLOBALS['tmp_nowsec'];
unset($GLOBALS['bufficons_list'],$GLOBALS['tmp_totsec'],$GLOBALS['tmp_nowsec']);
}
	
}

?>