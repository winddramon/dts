<?php

namespace apm
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'base/apm/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_APM_PRESET_VARS','');
define('___LOAD_MOD_APM_PRESET_VARS','');
define('MOD_APM_PROFILE','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/base\\apm/profile');
define('MODULE_APM_GLOBALS_VARNAMES','');
define('MOD_APM',1);
define('IMPORT_MODULE_APM_GLOBALS','');
define('PREFIX_MODULE_APM_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_APM_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_APM__VARS_____PRIVATE_PFUNC,$___PRIVATE_APM__VARS_____PRIVATE_CFUNC;
$___PRIVATE_APM__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_APM__VARS_____PRIVATE_CFUNC=Array();

hook_register('apm','add_a_actionnum');hook_register('apm','add_v_actionnum');hook_register('apm','discover');hook_register('apm','itemuse');hook_register('apm','calc_apm');hook_register('apm','calc_winner_apm');hook_register('apm','act');
function ___post_init() { global $___PRIVATE_APM__VARS_____PRIVATE_PFUNC,$___PRIVATE_APM__VARS_____PRIVATE_CFUNC;


}
	
}

?>