<?php

namespace npc_action
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/npc_action/'.$___TEMP_key; 
	
	$___PRESET_NPC_ACTION__VARS__npc_action_tmp_paras=$npc_action_tmp_paras;$___PRESET_NPC_ACTION__VARS__npc_action_gametype=$npc_action_gametype;$___PRESET_NPC_ACTION__VARS__npc_action_min_intv=$npc_action_min_intv;$___PRESET_NPC_ACTION__VARS__npc_action_data=$npc_action_data;
function ___pre_init() { global $___PRESET_NPC_ACTION__VARS__npc_action_tmp_paras,$npc_action_tmp_paras,$___PRESET_NPC_ACTION__VARS__npc_action_gametype,$npc_action_gametype,$___PRESET_NPC_ACTION__VARS__npc_action_min_intv,$npc_action_min_intv,$___PRESET_NPC_ACTION__VARS__npc_action_data,$npc_action_data;$npc_action_tmp_paras=$___PRESET_NPC_ACTION__VARS__npc_action_tmp_paras;$npc_action_gametype=$___PRESET_NPC_ACTION__VARS__npc_action_gametype;$npc_action_min_intv=$___PRESET_NPC_ACTION__VARS__npc_action_min_intv;$npc_action_data=$___PRESET_NPC_ACTION__VARS__npc_action_data; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_NPC_ACTION_PRESET_VARS','$___PRESET_NPC_ACTION__VARS__npc_action_tmp_paras=$npc_action_tmp_paras;$___PRESET_NPC_ACTION__VARS__npc_action_gametype=$npc_action_gametype;$___PRESET_NPC_ACTION__VARS__npc_action_min_intv=$npc_action_min_intv;$___PRESET_NPC_ACTION__VARS__npc_action_data=$npc_action_data;');
define('___LOAD_MOD_NPC_ACTION_PRESET_VARS','global $___PRESET_NPC_ACTION__VARS__npc_action_tmp_paras,$npc_action_tmp_paras,$___PRESET_NPC_ACTION__VARS__npc_action_gametype,$npc_action_gametype,$___PRESET_NPC_ACTION__VARS__npc_action_min_intv,$npc_action_min_intv,$___PRESET_NPC_ACTION__VARS__npc_action_data,$npc_action_data;$npc_action_tmp_paras=$___PRESET_NPC_ACTION__VARS__npc_action_tmp_paras;$npc_action_gametype=$___PRESET_NPC_ACTION__VARS__npc_action_gametype;$npc_action_min_intv=$___PRESET_NPC_ACTION__VARS__npc_action_min_intv;$npc_action_data=$___PRESET_NPC_ACTION__VARS__npc_action_data;');
define('MODULE_NPC_ACTION_GLOBALS_VARNAMES','npc_action_tmp_paras,npc_action_gametype,npc_action_min_intv,npc_action_data');
define('MOD_NPC_ACTION',1);
define('IMPORT_MODULE_NPC_ACTION_GLOBALS','global $___LOCAL_NPC_ACTION__VARS__npc_action_tmp_paras,$___LOCAL_NPC_ACTION__VARS__npc_action_gametype,$___LOCAL_NPC_ACTION__VARS__npc_action_min_intv,$___LOCAL_NPC_ACTION__VARS__npc_action_data; $npc_action_tmp_paras=&$___LOCAL_NPC_ACTION__VARS__npc_action_tmp_paras; $npc_action_gametype=&$___LOCAL_NPC_ACTION__VARS__npc_action_gametype; $npc_action_min_intv=&$___LOCAL_NPC_ACTION__VARS__npc_action_min_intv; $npc_action_data=&$___LOCAL_NPC_ACTION__VARS__npc_action_data; ');
define('PREFIX_MODULE_NPC_ACTION_GLOBALS','\'; global $___LOCAL_NPC_ACTION__VARS__npc_action_tmp_paras; ${$___TEMP_PREFIX.\'npc_action_tmp_paras\'}=&$___LOCAL_NPC_ACTION__VARS__npc_action_tmp_paras; global $___LOCAL_NPC_ACTION__VARS__npc_action_gametype; ${$___TEMP_PREFIX.\'npc_action_gametype\'}=&$___LOCAL_NPC_ACTION__VARS__npc_action_gametype; global $___LOCAL_NPC_ACTION__VARS__npc_action_min_intv; ${$___TEMP_PREFIX.\'npc_action_min_intv\'}=&$___LOCAL_NPC_ACTION__VARS__npc_action_min_intv; global $___LOCAL_NPC_ACTION__VARS__npc_action_data; ${$___TEMP_PREFIX.\'npc_action_data\'}=&$___LOCAL_NPC_ACTION__VARS__npc_action_data; unset($___TEMP_PREFIX); ');
define('MODULE_NPC_ACTION_GLOBALS','\'; global $___LOCAL_NPC_ACTION__VARS__npc_action_tmp_paras; ${$___TEMP_VARNAME}[\'npc_action_tmp_paras\']=&$___LOCAL_NPC_ACTION__VARS__npc_action_tmp_paras; global $___LOCAL_NPC_ACTION__VARS__npc_action_gametype; ${$___TEMP_VARNAME}[\'npc_action_gametype\']=&$___LOCAL_NPC_ACTION__VARS__npc_action_gametype; global $___LOCAL_NPC_ACTION__VARS__npc_action_min_intv; ${$___TEMP_VARNAME}[\'npc_action_min_intv\']=&$___LOCAL_NPC_ACTION__VARS__npc_action_min_intv; global $___LOCAL_NPC_ACTION__VARS__npc_action_data; ${$___TEMP_VARNAME}[\'npc_action_data\']=&$___LOCAL_NPC_ACTION__VARS__npc_action_data; unset($___TEMP_VARNAME); ');

global $___PRIVATE_NPC_ACTION__VARS_____PRIVATE_PFUNC,$___PRIVATE_NPC_ACTION__VARS_____PRIVATE_CFUNC,$___LOCAL_NPC_ACTION__VARS__npc_action_tmp_paras,$___LOCAL_NPC_ACTION__VARS__npc_action_gametype,$___LOCAL_NPC_ACTION__VARS__npc_action_min_intv,$___LOCAL_NPC_ACTION__VARS__npc_action_data;
$___PRIVATE_NPC_ACTION__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_NPC_ACTION__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_NPC_ACTION__VARS__npc_action_tmp_paras=&$npc_action_tmp_paras;$___LOCAL_NPC_ACTION__VARS__npc_action_gametype=&$npc_action_gametype;$___LOCAL_NPC_ACTION__VARS__npc_action_min_intv=&$npc_action_min_intv;$___LOCAL_NPC_ACTION__VARS__npc_action_data=&$npc_action_data;
unset($npc_action_tmp_paras,$npc_action_gametype,$npc_action_min_intv,$npc_action_data);
hook_register('npc_action','is_npc_action_allowed');hook_register('npc_action','get_npc_action_list');hook_register('npc_action','npc_action_main');hook_register('npc_action','npc_action_single');hook_register('npc_action','npc_action_single_core');hook_register('npc_action','post_npc_action_single');hook_register('npc_action','get_npc_action_list_chosen');hook_register('npc_action','npc_action_checknpc');hook_register('npc_action','npc_action_loadnpc');hook_register('npc_action','calculate_active_obbs');hook_register('npc_action','post_act');hook_register('npc_action','bot_action');hook_register('npc_action','evonpc');
function ___post_init() { global $___PRIVATE_NPC_ACTION__VARS_____PRIVATE_PFUNC,$___PRIVATE_NPC_ACTION__VARS_____PRIVATE_CFUNC,$___LOCAL_NPC_ACTION__VARS__npc_action_tmp_paras,$___LOCAL_NPC_ACTION__VARS__npc_action_gametype,$___LOCAL_NPC_ACTION__VARS__npc_action_min_intv,$___LOCAL_NPC_ACTION__VARS__npc_action_data;
$___LOCAL_NPC_ACTION__VARS__npc_action_tmp_paras=$GLOBALS['npc_action_tmp_paras'];$___LOCAL_NPC_ACTION__VARS__npc_action_gametype=$GLOBALS['npc_action_gametype'];$___LOCAL_NPC_ACTION__VARS__npc_action_min_intv=$GLOBALS['npc_action_min_intv'];$___LOCAL_NPC_ACTION__VARS__npc_action_data=$GLOBALS['npc_action_data'];
unset($GLOBALS['npc_action_tmp_paras'],$GLOBALS['npc_action_gametype'],$GLOBALS['npc_action_min_intv'],$GLOBALS['npc_action_data']);
}
	
}

?>