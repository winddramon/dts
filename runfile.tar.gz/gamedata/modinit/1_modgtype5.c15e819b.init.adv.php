<?php

namespace gtype5
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/instance/gtype5/main/'.$___TEMP_key; 
	
	$___PRESET_GTYPE5__VARS__npcinfo_gtype5=$npcinfo_gtype5;$___PRESET_GTYPE5__VARS__enpcinfo_gtype5=$enpcinfo_gtype5;
function ___pre_init() { global $___PRESET_GTYPE5__VARS__npcinfo_gtype5,$npcinfo_gtype5,$___PRESET_GTYPE5__VARS__enpcinfo_gtype5,$enpcinfo_gtype5;$npcinfo_gtype5=$___PRESET_GTYPE5__VARS__npcinfo_gtype5;$enpcinfo_gtype5=$___PRESET_GTYPE5__VARS__enpcinfo_gtype5; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_GTYPE5_PRESET_VARS','$___PRESET_GTYPE5__VARS__npcinfo_gtype5=$npcinfo_gtype5;$___PRESET_GTYPE5__VARS__enpcinfo_gtype5=$enpcinfo_gtype5;');
define('___LOAD_MOD_GTYPE5_PRESET_VARS','global $___PRESET_GTYPE5__VARS__npcinfo_gtype5,$npcinfo_gtype5,$___PRESET_GTYPE5__VARS__enpcinfo_gtype5,$enpcinfo_gtype5;$npcinfo_gtype5=$___PRESET_GTYPE5__VARS__npcinfo_gtype5;$enpcinfo_gtype5=$___PRESET_GTYPE5__VARS__enpcinfo_gtype5;');
define('MODULE_GTYPE5_GLOBALS_VARNAMES','npcinfo_gtype5,enpcinfo_gtype5');
define('MOD_GTYPE5',1);
define('IMPORT_MODULE_GTYPE5_GLOBALS','global $___LOCAL_GTYPE5__VARS__npcinfo_gtype5,$___LOCAL_GTYPE5__VARS__enpcinfo_gtype5; $npcinfo_gtype5=&$___LOCAL_GTYPE5__VARS__npcinfo_gtype5; $enpcinfo_gtype5=&$___LOCAL_GTYPE5__VARS__enpcinfo_gtype5; ');
define('PREFIX_MODULE_GTYPE5_GLOBALS','\'; global $___LOCAL_GTYPE5__VARS__npcinfo_gtype5; ${$___TEMP_PREFIX.\'npcinfo_gtype5\'}=&$___LOCAL_GTYPE5__VARS__npcinfo_gtype5; global $___LOCAL_GTYPE5__VARS__enpcinfo_gtype5; ${$___TEMP_PREFIX.\'enpcinfo_gtype5\'}=&$___LOCAL_GTYPE5__VARS__enpcinfo_gtype5; unset($___TEMP_PREFIX); ');
define('MODULE_GTYPE5_GLOBALS','\'; global $___LOCAL_GTYPE5__VARS__npcinfo_gtype5; ${$___TEMP_VARNAME}[\'npcinfo_gtype5\']=&$___LOCAL_GTYPE5__VARS__npcinfo_gtype5; global $___LOCAL_GTYPE5__VARS__enpcinfo_gtype5; ${$___TEMP_VARNAME}[\'enpcinfo_gtype5\']=&$___LOCAL_GTYPE5__VARS__enpcinfo_gtype5; unset($___TEMP_VARNAME); ');

global $___PRIVATE_GTYPE5__VARS_____PRIVATE_PFUNC,$___PRIVATE_GTYPE5__VARS_____PRIVATE_CFUNC,$___LOCAL_GTYPE5__VARS__npcinfo_gtype5,$___LOCAL_GTYPE5__VARS__enpcinfo_gtype5;
$___PRIVATE_GTYPE5__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_GTYPE5__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_GTYPE5__VARS__npcinfo_gtype5=&$npcinfo_gtype5;$___LOCAL_GTYPE5__VARS__enpcinfo_gtype5=&$enpcinfo_gtype5;
unset($npcinfo_gtype5,$enpcinfo_gtype5);
hook_register('gtype5','get_npclist');hook_register('gtype5','get_enpcinfo');hook_register('gtype5','get_shopconfig');hook_register('gtype5','get_itemfilecont');hook_register('gtype5','get_trapfilecont');hook_register('gtype5','get_startingitemfilecont');hook_register('gtype5','get_startingwepfilecont');
function ___post_init() { global $___PRIVATE_GTYPE5__VARS_____PRIVATE_PFUNC,$___PRIVATE_GTYPE5__VARS_____PRIVATE_CFUNC,$___LOCAL_GTYPE5__VARS__npcinfo_gtype5,$___LOCAL_GTYPE5__VARS__enpcinfo_gtype5;
$___LOCAL_GTYPE5__VARS__npcinfo_gtype5=$GLOBALS['npcinfo_gtype5'];$___LOCAL_GTYPE5__VARS__enpcinfo_gtype5=$GLOBALS['enpcinfo_gtype5'];
unset($GLOBALS['npcinfo_gtype5'],$GLOBALS['enpcinfo_gtype5']);
}
	
}

?>