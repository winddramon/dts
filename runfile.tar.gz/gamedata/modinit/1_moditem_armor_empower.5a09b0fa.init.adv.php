<?php

namespace item_armor_empower
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/item_extra/item_armor_empower/'.$___TEMP_key; 
	
	$___PRESET_ITEM_ARMOR_EMPOWER__VARS__ea_itmsk=$ea_itmsk;
function ___pre_init() { global $___PRESET_ITEM_ARMOR_EMPOWER__VARS__ea_itmsk,$ea_itmsk;$ea_itmsk=$___PRESET_ITEM_ARMOR_EMPOWER__VARS__ea_itmsk; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_ITEM_ARMOR_EMPOWER_PRESET_VARS','$___PRESET_ITEM_ARMOR_EMPOWER__VARS__ea_itmsk=$ea_itmsk;');
define('___LOAD_MOD_ITEM_ARMOR_EMPOWER_PRESET_VARS','global $___PRESET_ITEM_ARMOR_EMPOWER__VARS__ea_itmsk,$ea_itmsk;$ea_itmsk=$___PRESET_ITEM_ARMOR_EMPOWER__VARS__ea_itmsk;');
define('MOD_ITEM_ARMOR_EMPOWER_USE_ARMOR_EMPOWER','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\item_extra\\item_armor_empower/use_armor_empower');
define('MODULE_ITEM_ARMOR_EMPOWER_GLOBALS_VARNAMES','ea_itmsk');
define('MOD_ITEM_ARMOR_EMPOWER',1);
define('IMPORT_MODULE_ITEM_ARMOR_EMPOWER_GLOBALS','global $___LOCAL_ITEM_ARMOR_EMPOWER__VARS__ea_itmsk; $ea_itmsk=&$___LOCAL_ITEM_ARMOR_EMPOWER__VARS__ea_itmsk; ');
define('PREFIX_MODULE_ITEM_ARMOR_EMPOWER_GLOBALS','\'; global $___LOCAL_ITEM_ARMOR_EMPOWER__VARS__ea_itmsk; ${$___TEMP_PREFIX.\'ea_itmsk\'}=&$___LOCAL_ITEM_ARMOR_EMPOWER__VARS__ea_itmsk; unset($___TEMP_PREFIX); ');
define('MODULE_ITEM_ARMOR_EMPOWER_GLOBALS','\'; global $___LOCAL_ITEM_ARMOR_EMPOWER__VARS__ea_itmsk; ${$___TEMP_VARNAME}[\'ea_itmsk\']=&$___LOCAL_ITEM_ARMOR_EMPOWER__VARS__ea_itmsk; unset($___TEMP_VARNAME); ');

global $___PRIVATE_ITEM_ARMOR_EMPOWER__VARS_____PRIVATE_PFUNC,$___PRIVATE_ITEM_ARMOR_EMPOWER__VARS_____PRIVATE_CFUNC,$___LOCAL_ITEM_ARMOR_EMPOWER__VARS__ea_itmsk;
$___PRIVATE_ITEM_ARMOR_EMPOWER__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_ITEM_ARMOR_EMPOWER__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_ITEM_ARMOR_EMPOWER__VARS__ea_itmsk=&$ea_itmsk;
unset($ea_itmsk);
hook_register('item_armor_empower','parse_itmuse_desc');hook_register('item_armor_empower','use_armor_empower');hook_register('item_armor_empower','armor_empower');hook_register('item_armor_empower','itemuse');hook_register('item_armor_empower','act');hook_register('item_armor_empower','parse_news');
function ___post_init() { global $___PRIVATE_ITEM_ARMOR_EMPOWER__VARS_____PRIVATE_PFUNC,$___PRIVATE_ITEM_ARMOR_EMPOWER__VARS_____PRIVATE_CFUNC,$___LOCAL_ITEM_ARMOR_EMPOWER__VARS__ea_itmsk;
$___LOCAL_ITEM_ARMOR_EMPOWER__VARS__ea_itmsk=$GLOBALS['ea_itmsk'];
unset($GLOBALS['ea_itmsk']);
}
	
}

?>