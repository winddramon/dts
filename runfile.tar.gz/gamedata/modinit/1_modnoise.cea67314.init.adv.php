<?php

namespace noise
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'base/noise/'.$___TEMP_key; 
	
	$___PRESET_NOISE__VARS__noiseinfo=$noiseinfo;$___PRESET_NOISE__VARS__noiselimit=$noiselimit;
function ___pre_init() { global $___PRESET_NOISE__VARS__noiseinfo,$noiseinfo,$___PRESET_NOISE__VARS__noiselimit,$noiselimit;$noiseinfo=$___PRESET_NOISE__VARS__noiseinfo;$noiselimit=$___PRESET_NOISE__VARS__noiselimit; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_NOISE_PRESET_VARS','$___PRESET_NOISE__VARS__noiseinfo=$noiseinfo;$___PRESET_NOISE__VARS__noiselimit=$noiselimit;');
define('___LOAD_MOD_NOISE_PRESET_VARS','global $___PRESET_NOISE__VARS__noiseinfo,$noiseinfo,$___PRESET_NOISE__VARS__noiselimit,$noiselimit;$noiseinfo=$___PRESET_NOISE__VARS__noiseinfo;$noiselimit=$___PRESET_NOISE__VARS__noiselimit;');
define('MODULE_NOISE_GLOBALS_VARNAMES','noiseinfo,noiselimit,noisetime,noisepls,noiseid,noiseid2,noisemode');
define('MOD_NOISE',1);
define('IMPORT_MODULE_NOISE_GLOBALS','global $___LOCAL_NOISE__VARS__noiseinfo,$___LOCAL_NOISE__VARS__noiselimit,$___LOCAL_NOISE__VARS__noisetime,$___LOCAL_NOISE__VARS__noisepls,$___LOCAL_NOISE__VARS__noiseid,$___LOCAL_NOISE__VARS__noiseid2,$___LOCAL_NOISE__VARS__noisemode; $noiseinfo=&$___LOCAL_NOISE__VARS__noiseinfo; $noiselimit=&$___LOCAL_NOISE__VARS__noiselimit; $noisetime=&$___LOCAL_NOISE__VARS__noisetime; $noisepls=&$___LOCAL_NOISE__VARS__noisepls; $noiseid=&$___LOCAL_NOISE__VARS__noiseid; $noiseid2=&$___LOCAL_NOISE__VARS__noiseid2; $noisemode=&$___LOCAL_NOISE__VARS__noisemode; ');
define('PREFIX_MODULE_NOISE_GLOBALS','\'; global $___LOCAL_NOISE__VARS__noiseinfo; ${$___TEMP_PREFIX.\'noiseinfo\'}=&$___LOCAL_NOISE__VARS__noiseinfo; global $___LOCAL_NOISE__VARS__noiselimit; ${$___TEMP_PREFIX.\'noiselimit\'}=&$___LOCAL_NOISE__VARS__noiselimit; global $___LOCAL_NOISE__VARS__noisetime; ${$___TEMP_PREFIX.\'noisetime\'}=&$___LOCAL_NOISE__VARS__noisetime; global $___LOCAL_NOISE__VARS__noisepls; ${$___TEMP_PREFIX.\'noisepls\'}=&$___LOCAL_NOISE__VARS__noisepls; global $___LOCAL_NOISE__VARS__noiseid; ${$___TEMP_PREFIX.\'noiseid\'}=&$___LOCAL_NOISE__VARS__noiseid; global $___LOCAL_NOISE__VARS__noiseid2; ${$___TEMP_PREFIX.\'noiseid2\'}=&$___LOCAL_NOISE__VARS__noiseid2; global $___LOCAL_NOISE__VARS__noisemode; ${$___TEMP_PREFIX.\'noisemode\'}=&$___LOCAL_NOISE__VARS__noisemode; unset($___TEMP_PREFIX); ');
define('MODULE_NOISE_GLOBALS','\'; global $___LOCAL_NOISE__VARS__noiseinfo; ${$___TEMP_VARNAME}[\'noiseinfo\']=&$___LOCAL_NOISE__VARS__noiseinfo; global $___LOCAL_NOISE__VARS__noiselimit; ${$___TEMP_VARNAME}[\'noiselimit\']=&$___LOCAL_NOISE__VARS__noiselimit; global $___LOCAL_NOISE__VARS__noisetime; ${$___TEMP_VARNAME}[\'noisetime\']=&$___LOCAL_NOISE__VARS__noisetime; global $___LOCAL_NOISE__VARS__noisepls; ${$___TEMP_VARNAME}[\'noisepls\']=&$___LOCAL_NOISE__VARS__noisepls; global $___LOCAL_NOISE__VARS__noiseid; ${$___TEMP_VARNAME}[\'noiseid\']=&$___LOCAL_NOISE__VARS__noiseid; global $___LOCAL_NOISE__VARS__noiseid2; ${$___TEMP_VARNAME}[\'noiseid2\']=&$___LOCAL_NOISE__VARS__noiseid2; global $___LOCAL_NOISE__VARS__noisemode; ${$___TEMP_VARNAME}[\'noisemode\']=&$___LOCAL_NOISE__VARS__noisemode; unset($___TEMP_VARNAME); ');

global $___PRIVATE_NOISE__VARS_____PRIVATE_PFUNC,$___PRIVATE_NOISE__VARS_____PRIVATE_CFUNC,$___LOCAL_NOISE__VARS__noiseinfo,$___LOCAL_NOISE__VARS__noiselimit,$___LOCAL_NOISE__VARS__noisetime,$___LOCAL_NOISE__VARS__noisepls,$___LOCAL_NOISE__VARS__noiseid,$___LOCAL_NOISE__VARS__noiseid2,$___LOCAL_NOISE__VARS__noisemode;
$___PRIVATE_NOISE__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_NOISE__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_NOISE__VARS__noiseinfo=&$noiseinfo;$___LOCAL_NOISE__VARS__noiselimit=&$noiselimit;$___LOCAL_NOISE__VARS__noisetime=&$noisetime;$___LOCAL_NOISE__VARS__noisepls=&$noisepls;$___LOCAL_NOISE__VARS__noiseid=&$noiseid;$___LOCAL_NOISE__VARS__noiseid2=&$noiseid2;$___LOCAL_NOISE__VARS__noisemode=&$noisemode;
unset($noiseinfo,$noiselimit,$noisetime,$noisepls,$noiseid,$noiseid2,$noisemode);
hook_register('noise','pre_act');hook_register('noise','addnoise');hook_register('noise','load_gameinfo_post_work_core_extra');hook_register('noise','gameinfo_audit');hook_register('noise','reset_game');hook_register('noise','save_gameinfo_prepare_work');
function ___post_init() { global $___PRIVATE_NOISE__VARS_____PRIVATE_PFUNC,$___PRIVATE_NOISE__VARS_____PRIVATE_CFUNC,$___LOCAL_NOISE__VARS__noiseinfo,$___LOCAL_NOISE__VARS__noiselimit,$___LOCAL_NOISE__VARS__noisetime,$___LOCAL_NOISE__VARS__noisepls,$___LOCAL_NOISE__VARS__noiseid,$___LOCAL_NOISE__VARS__noiseid2,$___LOCAL_NOISE__VARS__noisemode;
$___LOCAL_NOISE__VARS__noiseinfo=$GLOBALS['noiseinfo'];$___LOCAL_NOISE__VARS__noiselimit=$GLOBALS['noiselimit'];$___LOCAL_NOISE__VARS__noisetime=$GLOBALS['noisetime'];$___LOCAL_NOISE__VARS__noisepls=$GLOBALS['noisepls'];$___LOCAL_NOISE__VARS__noiseid=$GLOBALS['noiseid'];$___LOCAL_NOISE__VARS__noiseid2=$GLOBALS['noiseid2'];$___LOCAL_NOISE__VARS__noisemode=$GLOBALS['noisemode'];
unset($GLOBALS['noiseinfo'],$GLOBALS['noiselimit'],$GLOBALS['noisetime'],$GLOBALS['noisepls'],$GLOBALS['noiseid'],$GLOBALS['noiseid2'],$GLOBALS['noisemode']);
}
	
}

?>