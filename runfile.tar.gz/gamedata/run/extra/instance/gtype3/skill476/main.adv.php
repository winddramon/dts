<?php

namespace skill476
{
	
	function init() 
	{
		define('MOD_SKILL476_INFO','club;locked;');
		do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;   } while (0);
		$clubskillname[476] = '尊严';
	}
	
	function acquire476(&$pa)
	{
		
	}
	
	function lost476(&$pa)
	{
		
	}
	
	function check_unlocked476(&$pa)
	{
		
		return 1;
	}

	function get_final_dmg_multiplier(&$pa, &$pd, $active)
	{
		return \skill507\get_final_dmg_multiplier($pa,$pd,$active);
	}
}

?>
