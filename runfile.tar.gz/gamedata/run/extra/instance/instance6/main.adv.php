<?php

namespace instance6
{
	function init() {}
	
	function get_shopconfig(){
		return \instance10\get_shopconfig();
	}
	
	function checkcombo($time){
		return \instance10\checkcombo($time);
	}
	
	function get_npclist(){
		return \instance10\get_npclist();
	}
	
	function rs_game($xmode = 0) 	
	{
		return \instance10\rs_game($xmode);
	}
	
	function check_addarea_gameover($atime){
		return \instance10\check_addarea_gameover($atime);
	}
}

?>