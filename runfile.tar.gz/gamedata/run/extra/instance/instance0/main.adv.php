<?php

namespace instance0
{
	function init() {}
	
	function checkcombo($time){
		return \instance10\checkcombo($time);
	}
}

?>