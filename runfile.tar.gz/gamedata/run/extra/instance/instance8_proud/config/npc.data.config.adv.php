<?php

namespace instance8
{
	$npcinfo_instance8 = array
	( 
		1 => array
		(
			'mode' => 3,
			'num' => 1,
			'pass' => 'bra',
			'club' => 0,
			'bid' => 0,
			'inf' => '',
			'rage' => 0,
			'pose'=> 2,
			'skills'=>array('401'=>'3','400'=>'6','459'=>'0','461'=>'0','462'=>'0'),
			'tactic' => 3,
			'killnum' => 0,
			'teamID' => '',
			'teamPass' => '',
			'gd' => 'f',
			'pls' => 0,
			'mhp' => 7500,
			'msp' => 4000,
			'att' => 750,
			'def' => 750,
			'lvl' => 75,
			'skill' => 1111,
			'money' => 9999,
			'arb' => '红灰色定制西装',
			'arbk' => 'DB',
			'arbe' => 150,
			'arbs' => 150,
			'arbsk' => 'c',
			'arh' => '奥术战甲H - 炎',
			'arhk' => 'DHS',
			'arhe' => 1500,
			'arhs' => 3000,
			'arf' => '商务谈判用黑色丝袜',
			'arfk' => 'DF',
			'arfe' => 100,
			'arfs' => 100,
			'ara' => '奥术战甲A - 炎',
			'arak' => 'DAS',
			'arae' => 1500,
			'aras' => 3000,
			'arask' => '',
			'art' => '龙虎旗帜',
			'artk' => 'A',
			'arte' => 1000,
			'arts' => 1000,
			'artsk' => 'H',
			'sub' => array
			(
				0 => array
				(
					'name' => '红暮',
					'icon' => 7,
					'wep' => '燃素加农炮『爆炎』MK-II',
					'wepk' => 'WG',
					'wepe' => 1280,
					'weps' => 999,
					'wepsk' => 'rfn',
					'itm1' => '挑战者之印',
					'itmk1' => 'Y',
					'itme1' => 1,
					'itms1' => 1,
					'itm2' => '黑色碎片',
					'itmk2' => 'WK',
					'itme2' => 10,
					'itms2' => '∞',
					'itmsk2' => 'j',
					'itm3' => '不要按这个按钮',
					'itmk3' => 'Y',
					'itme3' => 1,
					'itms3' => 1,
					
					'ext_armor' => array(
						'arb' => '奥术战甲B - 炎',
						'arbk' => 'DBS',
						'arbe' => 3000,
						'arbs' => 3000,
						'arbsk' => 'Ab',
						'arf' => '奥术战甲F - 炎',
						'arfk' => 'DFS',
						'arfe' => 1500,
						'arfs' => 3000,
					),
					'description' => '红杀将军 红暮，坐镇于无月之影的BOSS，达成锁定解除结局所必须击杀的NPC。 <span class="linen b">"红暮真可爱呀！"</span>',
				),
			),
		),
		
		2 => array
		(
			'mode' => 2,
			'num' => 24,
			'pass' => 'bra',
			'club' => 0,
			'bid' => 0,
			'inf' => '',
			'rage' => 0,
			'pose'=> 0,
			'tactic' => 0,
			'killnum' => 0,
			'teamID' => '',
			'teampass' => '',
			'pls' => 99,
			'mhp' => 2800,
			'msp' => 200,
			'att' => 250,
			'def' => 350,
			'lvl' => 25,
			'skill' => 135,
			'money' => 1600,
			'arb' => '全息幻象的虚拟制服',
			'arbk' => 'DB',
			'arbe' => 150,
			'arbs' => 100,
			'arh' => '全息幻象的虚拟头带',
			'arhk' => 'DH',
			'arhe' => 75,
			'arhs' => 100,
			'arf' => '全息幻象的虚拟鞋子',
			'arfk' => 'DF',
			'arfe' => 75,
			'arfs' => 100,
			'ara' => '全息幻象的虚拟手套',
			'arak' => 'DA',
			'arae' => 75,
			'aras' => 100,
			'art' => '全息幻象的自律回路',
			'artk' => 'A',
			'arte' => 20,
			'arts' => 10,
			'artsk' => 'c',
			'itm6' => '提示纸条AA',
			'itmk6' => 'Y',
			'itme6' => 1,
			'itms6' => 1,
			'itmsk6' => '',
			'sub' => array
			(
				0 => array
				(
					'name' => '熵魔法传人 Howling',
					'icon' => 'avatar_kh/howling_fk.jpg',
					'skills' => array('512'=>array('type' => '46', 'sub' => '0')),
					'gd' => 'f',
					'mss' => 50,
					'wep' => '爪拳 Haab',
					'wepk' => 'WP',
					'wepe' => 75,
					'weps' => 200,
					'itm1' => '幻爪拳 Tonalpo',
					'itmk1' => 'WP',
					'itme1' => 260,
					'itms1' => 200,
					'itmsk1' => 'NwZ',
					'itm2' => '异世界调味品',
					'itmk2' => 'HB',
					'itme2' => 222,
					'itms2' => 22,
					'ara' => '附魔之爪 Wayeb',
					'arask' => 'N',
					'description' => '全息幻象 熵魔法传人 Howling，于西之国漫雄公司畅销漫画《银月哨兵团》中登场的兽人少女，使用爪和魔法进行复合攻击。掉落优秀的殴系武器和命体回复品。',
				),
				1 => array
				(
					'name' => '幻影斗将神 S.A.S',
					'icon' => 'avatar_kh/SAS_fk.jpg',
					'skills' => array('512'=>array('type' => '46', 'sub' => '1')),
					'gd' => 'f',
					'mss' => 50,
					'wep' => '破魔镰·断月',
					'wepk' => 'WK',
					'wepe' => 75,
					'weps' => 200,
					'itm1' => '斩神镰·噬日',
					'itmk1' => 'WK',
					'itme1' => 280,
					'itms1' => 100,
					'itmsk1' => 'ikj',
					
					'ext_armor' => array(
						'arb' => '暗红色的外套',
						'arbk' => 'DBS',
						'arbe' => 120,
						'arbs' => 30,
						'arbsk' => '^st1^vol4',
					),
					'description' => '全息幻象 幻影斗将神 S.A.S，本名叫做『Salina』，东之国著名角色扮演游戏《重生之地》的女主角之一，使用符合设定的巨大镰刀进行攻击。掉落优秀的斩系武器（可变为DN刀）。',
				),
				2 => array
				(
					'name' => '银白愿天使 Annabelle',
					'icon' => 'avatar_kh/annabelle_fk.jpg',
					'skills' => array('512'=>array('type' => '46', 'sub' => '2')),
					'gd' => 'f',
					'mss' => 50,
					'wep' => '『雷米尔之冲击』',
					'wepk' => 'WC',
					'wepe' => 75,
					'weps' => 200,
					'arf' => '神启之羽翼',
					'arfk' => 'DF',
					'arfe' => 100,
					'arfs' => 100,
					'arfsk' => 'MH',
					'itm1' => '☆开完变30元的卡牌包☆',
					'itmk1' => 'ygo2',
					'itme1' => 1,
					'itms1' => 7,
					'itm2' => '赛路尔之磨刀石',
					'itmk2' => 'Y',
					'itme2' => 45,
					'itms2' => 8,			
					'description' => '全息幻象 银白愿天使 Annabelle，东之国出品的以卡牌游戏《时空乱斗》为基础的卡牌角色兼可使用角色，使用各种卡牌作为飞行道具进行战斗。掉落（游戏王）卡牌包、强效的磨刀石以及带HP制御属性的腿部防具。',
				),
				3 => array
				(
					'name' => '通灵冒险家 星海',
					'icon' => 'avatar_kh/xinghai_fk.jpg',
					'skills' => array('512'=>array('type' => '46', 'sub' => '3')),
					'gd' => 'f',
					'mss' => 50,
					'wep' => '5.45mm 无声手枪',
					'wepk' => 'WG',
					'wepe' => 75,
					'weps' => 200,
					'wepsk' => 'S',
					'itm1' => '『不可见的协助者』',
					'itmk1' => 'WF',
					'itme1' => 290,
					'itms1' => 300,
					'itmsk1' => 'i',
					'itm3' => '潜意识信息播放器',
					'itmk3' => 'HM',
					'itme3' => 30,
					'itms3' => 1,
					'description' => '全息幻象 通灵冒险家 星海，东之国被改编成动画的科幻冒险网文《我，通灵者》的主角，以防身用的迷你手枪作为武器。掉落优秀的灵力兵器以及歌魂增加道具。',
				),
				4 => array
				(
					'name' => '麻烦妖精 Sophia',
					'icon' => 'avatar_kh/sophia_fk.jpg',
					'skills' => array('512'=>array('type' => '46', 'sub' => '4')),
					'gd' => 'f',
					'mss' => 50,
					'pose'=> 4,
					'wep' => '空想爆弹 ~ 出乎意料',
					'wepk' => 'WD',
					'wepe' => 75,
					'weps' => 200,
					'itm1' => '妖精的羽翼',
					'itmk1' => 'A',
					'itme1' => 1,
					'itms1' => 1,
					'itmsk1' => 'q',
					'itm2' => '空想魔炮 ~ 七零八落',
					'itmk2' => 'WD',
					'itme2' => 270,
					'itms2' => 300,
					'itmsk2' => 'id',
					'description' => '全息幻象 麻烦妖精 Sophia，从700余份有效投稿竞选中胜出的人设，有趣的妖精魔法少女，使用利用魔杖具现出的各种武器灵活地打击敌人。掉落优秀的爆系武器以及具有补给净化功能的饰品。',
				),
				5 => array
				(
					'name' => '思念体-触手众',
					'icon' => 14,
					'gd' => 'm',
					'pose'=> 4,
					'mhp' => 3500,
					'money' => 2400,
					'wep' => '触手的力量',
					'wepk' => 'WF',
					'wepe' => 75,
					'weps' => 200,
					'itm1' => '触手的怨念',
					'itmk1' => 'PR2',
					'itme1' => 50,
					'itms1' => 5,
					'itm2' => '艾莲娜的圣钉',
					'itmk2' => 'Y',
					'itme2' => 40,
					'itms2' => 10,
					'description' => '全息幻象 思念体-触手众，用参与历次大逃杀的触手玩家的意识碎片拼成的角色。掉落怒气增加道具、强效的钉子以及额外的金钱。',
				),
			),
		),
	
		
		
		
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
			5 => array
			(
			'mode' => 2,
			'num' => 2,
			'pass' => 'bra',
			'bid' => 0,
			'inf' => '',
			'rage' => 20,
			'pose'=> 1,
			'tactic' => 3,
			'killnum' => 0,
			
			
			'teamID' => '',
			'teamPass' => '',
			'pls' => 99,
			'mhp' => 3333,
			'msp' => 333,
			'att' => 333,
			'def' => 333,
			'lvl' => 33,
			'skill' => 233,
			'money' => 3333,
			'arb' => '杏仁豆腐模样的以太结晶',
			'arbk' => 'DB',
			'arbe' => 333,
			'arbs' => 333,
			'arbsk' => 'A',
			'arh' => '杏仁豆腐模样的狙击镜片',
			'arhk' => 'DH',
			'arhe' => 333,
			'arhs' => 333,
			'arhsk' => 'cW',
			'arf' => '杏仁豆腐模样的长筒靴',
			'arfk' => 'DF',
			'arfe' => 333,
			'arfs' => 333,
			'arfsk' => 'qE',
			'ara' => '杏仁豆腐模样的童话伪翼',
			'arak' => 'DA',
			'arae' => 333,
			'aras' => 333,
			'arask' => 'UI',
			'art' => '杏仁豆腐模样的HP制御系统',
			'artk' => 'A',
			'arte' => 333,
			'arts' => 333,
			'artsk' => 'H',
			'itm1' => '杏仁豆腐的ID卡',
			'itmk1' => 'Z',
			'itme1' => 1,
			'itms1' => 1,
	
	
	
	
			
			'sub' => array
			(
				0 => array
				(
					'name' => '冴月 麟',
					'icon' => 3,
					'gd' => 'f',
					'club' => 9,
					'mss' => 30,
					'skills'=>array('460'=>'0','65'=>'2'),
					'wep' => '简称为UCW的杏仁豆腐',
					'wepk' => 'WK',
					'wepe' => 133,
					'weps' => 333,
					'wepsk' => 'dr',
					'itm2' => '《红魔乡设定废案》',
					'itmk2' => 'VS',
					'itme2' => 1,
					'itms2' => 1,
					'itmsk2' => '246',
					'itm3' => '《ぼくのフレンド》',
					'itmk3' => 'ss',
					'itme3' => 110,
					'itms3' => 1,
					'itmsk3' => '',
					'description' => '杏仁豆腐 冴月 麟，对玩家有较大威胁，掉落启动死斗模式的钥匙和一本隐形技能书。',
				),
				1 => array
				(
					'name' => '某四面',
					'icon' => 4,
					'gd' => 'm',
					'club' => 8,
					'skills'=>array('460'=>'0','217'=>'2'),
					'wep' => '深生态杏仁豆腐',
					'wepk' => 'WD',
					'wepe' => 100,
					'weps' => 333,
					'wepsk' => 'drp',
					'itm2' => '安雅人体冰雕',
					'itmk2' => 'Y',
					'itme2' => 1,
					'itms2' => 1,
					'itmsk2' => '',
					'itm3' => '四面骰',
					'itmk3' => 'Y',
					'itme3' => 4,
					'itms3' => 1,
					'itmsk3' => '',
					'description' => '杏仁豆腐 某四面，对玩家有较大威胁，掉落启动死斗模式的钥匙和武器师安雅的奖赏的素材。',
				),
			),
		),
		
		6 => array
		(
			'mode' => 2,
			'num' => 1,
			'pass' => 'bra',
			'club' => 0,
			'bid' => 0,
			'inf' => '',
			'rage' => 0,
			'pose'=> 4,
			'tactic' => 3,
			'skills'=>array('461'=>'1'),
			'killnum' => 0,
			'teamID' => '',
			'teamPass' => '',
			'gd' => 'r',
			'pls' => 99,
			'mhp' => 8888,
			'msp' => 400,
			'att' => 400,
			'def' => 777,
			'lvl' => 45,
			'skill' => 477,
			'money' => 17777,
			'arb' => '【属性防御装甲】',
			'arbk' => 'DB',
			'arbe' => 480,
			'arbs' => 200,
			'arbsk' => 'a',
			'arh' => '【冲击防御头盔】',
			'arhk' => 'DH',
			'arhe' => 360,
			'arhs' => 200,
			'arhsk' => 'A',
			'arf' => '【数据护膝】',
			'arfk' => 'DF',
			'arfe' => 360,
			'arfs' => 200,
			'arfsk' => 'R',
			'ara' => '【陷阱拦截护盾】',
			'arak' => 'DA',
			'arae' => 360,
			'aras' => 200,
			'arask' => 'm',
			'art' => '【ACFUN的荣耀】',
			'artk' => 'Ag',
			'arte' => 5000,
			'arts' => 500,
			'artsk' => 'H',
	
	
	
	
			'sub' => array
			(
				0 => array
				(
					'name' => 'Acg_Xilin',
					'icon' => 'avatar_rek/xilin.png',
					'mss' => 100,
					'wep' => '【全屏幕弹幕发射】',
					'wepk' => 'WG',
					'wepe' => 360,
					'weps' => 600,
					'wepsk' => 'rew',
					'itm1' => '■DeathNote■',
					'itmk1' => 'Y',
					'itme1' => 1,
					'itms1' => 1,
					'itm2' => 'TDG压片猴',
					'itmk2' => 'Y',
					'itme2' => 1,
					'itms2' => 1,
					'description' => '黑幕 Acg_Xilin，对玩家具有很大威胁，如果防御值没有达到2000最好不要惹他（她）。掉落可以杀死任意一名玩家的道具“死亡笔记”，和大量的金钱。',
				),
			),
		),
		
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
		
		
		
		9 => array
		(
			'mode' => 3,
			'num' => 1,
			'pass' => 'bra',
			'club' => 17,
			'bid' => 0,
			'inf' => '',
			'rage' => 0,
			'pose'=> 1,
			'tactic' => 3,
			'killnum' => 99,
			'teamID' => '',
			'teamPass' => '',
			'gd' => 'f',
			'pls' => 26,
			'mhp' => 10000000,
			'msp' => 4000,
			'att' => 200000,
			'def' => 4000,
			'lvl' => 97,
			'skill' => 2400,
			'money' => 1,
			'arb' => '蓝色睡衣',
			'arbk' => 'DB',
			'arbe' => 60,
			'arbs' => 15,
			'arh' => '奥术战甲H - 霜',
			'arhk' => 'DHS',
			'arhe' => 4000,
			'arhs' => 300,
			'arf' => '泡泡拖鞋',
			'arfk' => 'DF',
			'arfe' => 40,
			'arfs' => 15,
			'ara' => '奥术战甲A - 霜',
			'arak' => 'DAS',
			'arae' => 4000,
			'aras' => 300,
			'art' => '龙虎徽标',
			'artk' => 'A',
			'arte' => 200,
			'arts' => 300,
			'artsk' => 'Hc',
			'sub' => array
			(
				0 => array
				(
					'name' => '蓝凝',
					'mss' => 40,
					'skills' => array('406'=>'0','432'=>'0','459'=>'0','461'=>'0'),
					'icon' => 52,
					'wep' => '『AZURE RONDO』',
					'wepk' => 'WKF',
					'wepe' => 2000,
					'weps' => 360,
					'wepsk' => 'rkd',
					'itm1' => '挑战者之证',
					'itmk1' => 'Y',
					'itme1' => 1,
					'itms1' => 1,
					'itm2' => '琉璃血',
					'itmk2' => 'Y',
					'itme2' => 1,
					'itms2' => 1,
					'itm3' => '好想按这个按钮',
					'itmk3' => 'Y',
					'itme3' => 1,
					'itms3' => 1,
					'ext_armor' => array(
						'arb' => '奥术战甲B - 霜',
						'arbk' => 'DBS',
						'arbe' => 6000,
						'arbs' => 400,
						'arbsk' => 'Aa',
						'arf' => '奥术战甲F - 霜',
						'arfk' => 'DFS',
						'arfe' => 4000,
						'arfs' => 300,
						'arfsk' => 'Aa',
					),
					'description' => '坐镇于冰封墓场的NPC，几乎无敌的存在。<span class="yellow b">没事还是不要惹她好了……</span>',
				),
			),
		),
		
		
		
		11 => array
		(
			'mode' => 1,
			'num' => 7,
			'pass' => 'bra',
			'club' => 0,
			'bid' => 0,
			'inf' => '',
			'rage' => 0,
			'pose'=> 1,
			'tactic' => 3,
			'killnum' => 0,
			'teamID' => '',
			'teamPass' => '',
			'gd' => 'r',
			'pls' => 99,
			'mhp' => 2888,
			'msp' => 888,
			'att' => 88,
			'def' => 88,
			'lvl' => 30,
			'skill' => 100,
			'money' => 888,
			'arb' => '职人的佩服',
			'arbk' => 'DB',
			'arbe' => 888,
			'arbs' => 888,
			'arbsk' => 'a',
			'arh' => '职人的搞头',
			'arhk' => 'DH',
			'arhe' => 888,
			'arhs' => 888,
			'arhsk' => 'DF',
			'arf' => '职人的满足',
			'arfk' => 'DF',
			'arfe' => 888,
			'arfs' => 888,
			'ara' => '职人的拿手',
			'arak' => 'DA',
			'arae' => 888,
			'aras' => 888,
			'arask' => 'H',
			'art' => '职人的荣耀',
			'artk' => 'A',
			'arte' => 888,
			'arts' => 888,
			'artsk' => 'c',
			'itm6' => '提示纸条AB',
			'itmk6' => 'Y',
			'itme6' => 1,
			'itms6' => 1,
			'itmsk6' => '',
			'sub' => array
			(
				0 => array
				(
					'name' => 'Hank',
					'icon' => 91,
					'mss' => 100,
					'wep' => '『性感玉米』',
					'wepk' => 'WD',
					'wepe' => 88,
					'weps' => 888,
					'wepsk' => 'ewuip',
					'itm1' => '我打败HANK了！',
					'itmk1' => 'Z',
					'itme1' => 1,
					'itms1' => 1,
					'description' => '真职人 Hank，使用带有全属性的爆系武器，掉落极优秀的防具。',
				),
				
				1 => array
				(
					'name' => '爱情上甘岭',
					'icon' => 92,
					'mss' => 100,
					'wep' => '『阿里嘎头哦～』',
					'wepk' => 'WK',
					'wepe' => 88,
					'weps' => 888,
					'wepsk' => 'ewuip',
					'itm1' => '我成功TDGSGL了！',
					'itmk1' => 'Z',
					'itme1' => 1,
					'itms1' => 1,
					'description' => '真职人 爱情上甘岭，使用带有全属性的斩系武器，掉落极优秀的防具。',
				),
				
				2 => array
				(
					'name' => '221',
					'icon' => 94,
					'mss' => 100,
					'wep' => '『和谐你全家』',
					'wepk' => 'WP',
					'wepe' => 88,
					'weps' => 888,
					'wepsk' => 'uiewp',
					'arb' => '神之装束',
					'arbk' => 'DB',
					'arbe' => 888,
					'arbs' => 888,
					'arbsk' => 'a',
					'arh' => '神之远见',
					'arhk' => 'DH',
					'arhe' => 888,
					'arhs' => 888,
					'arhsk' => 'DF',
					'arf' => '神之步伐',
					'arfk' => 'DF',
					'arfe' => 888,
					'arfs' => 888,
					'ara' => '神之操控',
					'arak' => 'DA',
					'arae' => 888,
					'aras' => 888,
					'arask' => 'H',
					'art' => '神之荣耀',
					'artk' => 'A',
					'arte' => 888,
					'arts' => 888,
					'artsk' => 'c',
					'itm1' => '荼荼丸的茶',
					'itmk1' => 'Z',
					'itme1' => 1,
					'itms1' => 1,
					'description' => '真职人 221，使用带有全属性的殴系武器，掉落极优秀的防具。',
				
				),
				3 => array
				(
					'name' => 'Erul Tron',
					'icon' => 93,
					'club' => 0,
					'mss' => 70,
					'wep' => '『罗德不列颠号』',
					'wepk' => 'WC',
					'wepe' => 88,
					'weps' => 888,
					'wepsk' => 'uiewp',
					'arb' => '少女的泳衣',
					'arbk' => 'DB',
					'arbe' => 888,
					'arbs' => 888,
					'arbsk' => 'a',
					'arh' => '少女的单马尾',
					'arhk' => 'DH',
					'arhe' => 888,
					'arhs' => 888,
					'arhsk' => 'DF',
					'arf' => '少女的高筒靴',
					'arfk' => 'DF',
					'arfe' => 888,
					'arfs' => 888,
					'ara' => '少女的绒边手套',
					'arak' => 'DA',
					'arae' => 888,
					'aras' => 888,
					'arask' => 'H',
					'art' => '少女的星星眼',
					'artk' => 'A',
					'arte' => 888,
					'arts' => 888,
					'artsk' => 'c',
					'itm1' => '罗德不列颠号舰长钥匙',
					'itmk1' => 'Z',
					'itme1' => 1,
					'itms1' => 1,
					'description' => '真职人 Erul Tron，使用带有全属性的射系武器，掉落极优秀的防具。',
				),
				
				4 => array
				(
					'name' => '亚玛丽欧·维拉蒂安',
					'icon' => 95,
					'club' => 0,
					'mss' => 50,
					'wep' => '负人气的光环',
					'wepk' => 'WP',
					'wepe' => 88,
					'weps' => 888,
					'wepsk' => 'uiewp',
					'arb' => '阿婆主的点击量',
					'arbk' => 'DB',
					'arbe' => 888,
					'arbs' => 888,
					'arbsk' => 'a',
					'arh' => '阿婆主的点击量',
					'arhk' => 'DH',
					'arhe' => 888,
					'arhs' => 888,
					'arhsk' => 'DF',
					'arf' => '阿婆主的点击量',
					'arfk' => 'DF',
					'arfe' => 888,
					'arfs' => 888,
					'ara' => '阿婆主的点击量',
					'arak' => 'DA',
					'arae' => 888,
					'aras' => 888,
					'arask' => 'H',
					'art' => '阿婆主的点击量',
					'artk' => 'A',
					'arte' => 888,
					'arts' => 888,
					'artsk' => 'c',
					'itm1' => '点击量终于爆表了！',
					'itmk1' => 'Z',
					'itme1' => 1,
					'itms1' => 1,
					'itm2' => '负人品的结界',
					'itmk2' => 'WG',
					'itme2' => 88,
					'itms2' => 88,
					'itmsk2' => 'kN',
					'description' => '真职人 亚玛丽欧·维拉蒂安，使用带有全属性的殴系武器，掉落极优秀的防具。',
				),
				
				5 => array
				(
					'name' => '便当盒',
					'icon' => 100,
					'gd' => 'f',
					'club' => 17,
					'lvl' => 1,
					'mhp' => 8888888,
					'skills'=>array('401'=>'5','461'=>'1'),
					'skill' => 20,
					'def' => 88888,
					'wep' => '灭罪「正直者の死」',
					'wepk' => 'WF',
					'wepe' => 8,
					'weps' => 888,
					'wepsk' => 'r',
					'arb' => '吉祥物',
					'arbk' => 'DB',
					'arbe' => 1,
					'arbs' => 10000,
					'arbsk' => 'Aa',
					'arh' => '吉祥物',
					'arhk' => 'DH',
					'arhe' => 1,
					'arhs' => 10000,
					'arhsk' => '',
					'arf' => '吉祥物',
					'arfk' => 'DF',
					'arfe' => 1,
					'arfs' => 10000,
					'ara' => '吉祥物',
					'arak' => 'DA',
					'arae' => 1,
					'aras' => 10000,
					'arask' => '',
					'art' => '姬露瑞希的爱心便当',
					'artk' => 'A',
					'arte' => 1,
					'arts' => 1,
					'artsk' => 'Bb^st_<:comp_itmsk:>{适者生存的豪华便当,MB,1,1,^mbid401^mblvl5^mbtime900,}1^vol1',
					'itm6' => '',
					'itmk6' => '',
					'itme6' => 0,
					'itms6' => 0,
					'itmsk6' => '',
					'description' => '真职人 便当盒，ACFUN大逃杀吉祥物，卖萌的存在，拥有888万点HP和双抹消饰品，几乎无法杀死。',
				),
				
				6 => array
				(
					'name' => 'KHIBIKI《黑曲》',
					'mode'=>'3',
					'gd' => 'f',
					'icon' => 113,
					'mss' => 30,
					'club' => 17,
					'lvl' => 1,
					'mhp' => 6666666,
					'skills'=>array('415'=>'1','461'=>'1'),
					'skill' => 20,
					'def' => 20,
					'wep' => '武裝幻想『DAYDREAM』',
					'wepk' => 'WG',
					'wepe' => 8,
					'weps' => 888,
					'wepsk' => 'r',
					'arb' => '【純黑色的連帽型外套】',
					'arbk' => 'DB',
					'arbe' => 1,
					'arbs' => 10000,
					'arbsk' => 'Aa',
					'arh' => '【純黑色的耳罩式耳機】',
					'arhk' => 'DH',
					'arhe' => 1,
					'arhs' => 10000,
					'arhsk' => '',
					'arf' => '【純黑色的皮製型長靴】',
					'arfk' => 'DF',
					'arfe' => 1,
					'arfs' => 10000,
					'ara' => '【純黑色的電子式繪筆】',
					'arak' => 'DA',
					'arae' => 1,
					'aras' => 10000,
					'arask' => '',
					'art' => '黑色終曲『HONOUR』',
					'artk' => 'A',
					'arte' => 1,
					'arts' => 1,
					'artsk' => 'Zz',
					'itm6' => '★宛如天体运行的卡牌包★',
					'itmk6' => 'VO4',
					'itme6' => 1,
					'itms6' => 1,
					'itmsk6' => '65',
					'description' => '真职人 黑色夺魂曲，ACFUN大逃杀吉祥物，卖萌的存在，似乎很难对其造成伤害。',
				),
			),
		),
		
		
		
		13 => array
		(
			'mode' => 1,
			'num' => 0,
			'pass' => 'bra',
			'club' => 98,
			'bid' => 0,
			'inf' => '',
			'rage' => 174,
			'pose'=> 4,
			'tactic' => 3,
			'killnum' => 99,
			'teamID' => '循环',
			'teamPass' => 'L1g2t2D2k',
			'gd' => 'f',
			'pls' => 26,
			'mhp' => 28800,
			'msp' => 400,
			'att' => 1600,
			'def' => 600,
			'lvl' => 60,
			'skill' => 625,
			'money' => 8000,
			'arb' => '希-玻粒子固化装甲',
			'arbk' => 'DB',
			'arbe' => 10,
			'arbs' => 500,
			'arbsk' => 'B',
			'arh' => '知觉增幅设备',
			'arhk' => 'DH',
			'arhe' => 64,
			'arhs' => 500,
			'arhsk' => 'Hc',
			'arf' => '空间扰动场',
			'arfk' => 'DF',
			'arfe' => 1500,
			'arfs' => 500,
			'arfsk' => 'a',
			'ara' => '破旧的长袍',
			'arak' => 'DA',
			'arae' => 4,
			'aras' => 800,
			'art' => '循环的预示',
			'artk' => 'A',
			'arte' => 1,
			'arts' => 1,
			'artsk' => 'M',
			'sub' => array
			(
				0 => array
				(
					'name' => '卡玛·克莱因',
					'icon' => 9,
					'wep' => '巴鲁康宁MK-III',
					'wepk' => 'WG',
					'wepe' => 1600,
					'weps' => 5000,
					'wepsk' => 'rdo',
					'itm1' => '凛剑·银槲之剑',
					'itmk1' => 'WK',
					'itme1' => 2800,
					'itms1' => 180,
					'itmsk1' => 'k',
					'itm2' => '焰剑·永恒终焉',
					'itmk2' => 'WK',
					'itme2' => 2800,
					'itms2' => 180,
					'itmsk2' => 'f',
					'itm3' => '奇怪的按钮',
					'itmk3' => 'Y',
					'itme3' => 1,
					'itms3' => 1,
				),
			),
		),
		
		14 => array
		(
			'mode' => 1,
			'num' => 3,
			'pass' => 'bra',
			'club' => 99,
			'bid' => 0,
			'inf' => '',
			'state' => 1,
			'rage' => 5,
			'pose'=> 0,
			'tactic' => 0,
			'killnum' => 0,
			'teamID' => '',
			'teamPass' => '',
			'gd' => 'f',
			'pls' => 99,
			'mhp' => 2800,
			'msp' => 400,
			'att' => 75,
			'def' => 75,
			'lvl' => 20,
			'skill' => 25,
			'money' => 3,
			'sub' => array
			(
				0 => array
				(
					'name' => '讲解员 梦美',
					'icon' => 61,
					'mss' => 50,
					'wep' => '垃圾花束',
					'wepk' => 'WP',
					'wepe' => 175,
					'weps' => 36,
					'wepsk' => 'c',
					'arb' => '接待员制服',
					'arbk' => 'DB',
					'arbe' => 75,
					'arbs' => 50,
					'arbsk' => 'a',
					'arh' => '橙色信号缎带',
					'arhk' => 'DH',
					'arhe' => 640,
					'arhs' => 50,
					'arf' => '蓝色信号缎带',
					'arfk' => 'DF',
					'arfe' => 640,
					'arfs' => 50,
					'ara' => '绿色信号缎带',
					'arak' => 'DA',
					'arae' => 640,
					'aras' => 50,
					'art' => '星空之愿',
					'artk' => 'A',
					'arte' => 1,
					'arts' => 1,
					'artsk' => 'H',
					'description' => '数据碎片 讲解员 梦美，<span class="yellow b">被击杀后会变身为攻击力极强的NPC</span>。',
				),
				1 => array
				(
					'name' => '喧哗少女 叶留佳',
					'icon' => 63,
					'mss' => 50,
					'wep' => '七色玻璃珠',
					'wepk' => 'WK',
					'wepe' => 160,
					'weps' => 36,
					'wepsk' => 'ec',
					'arb' => 'RF高校校服',
					'arbk' => 'DB',
					'arbe' => 75,
					'arbs' => 50,
					'arbsk' => 'a',
					'arh' => '粉红双球发饰',
					'arhk' => 'DH',
					'arhe' => 640,
					'arhs' => 50,
					'arf' => '女式皮鞋',
					'arfk' => 'DF',
					'arfe' => 640,
					'arfs' => 50,
					'ara' => '奇怪的袋子',
					'arak' => 'DA',
					'arae' => 640,
					'aras' => 50,
					'art' => '友情之愿',
					'artk' => 'A',
					'arte' => 1,
					'arts' => 1,
					'artsk' => 'H',
					'description' => '数据碎片 喧哗少女 叶留佳，<span class="yellow b">被击杀后会变身为攻击力极强的NPC</span>。',
				),
				2 => array
				(
					'name' => '风纪委员 静流',
					'icon' => 65,
					'mss' => 50,
					'wep' => '银白口哨',
					'wepk' => 'WF',
					'wepe' => 175,
					'weps' => 200,
					'wepsk' => 'c',
					'arb' => '风祭学院校服',
					'arbk' => 'DB',
					'arbe' => 75,
					'arbs' => 50,
					'arbsk' => '',
					'arh' => '白色眼罩',
					'arhk' => 'DH',
					'arhe' => 640,
					'arhs' => 50,
					'arf' => '女式运动鞋',
					'arfk' => 'DF',
					'arfe' => 640,
					'arfs' => 50,
					'ara' => 'Mp3播放器',
					'arak' => 'DA',
					'arae' => 640,
					'aras' => 50,
					'art' => '平和之愿',
					'artk' => 'A',
					'arte' => 1,
					'arts' => 1,
					'artsk' => 'H',
					'description' => '数据碎片 风纪委员 静流，<span class="yellow b">被击杀后会变身为攻击力极强的NPC</span>。',
				),
			),
		), 
	
		20 => array
		(
			'mode' => 2,
			'num' => 10,
			'pass' => 'gbauibg2',
			'club' => 0,
			'bid' => 0,
			'inf' => '',
			'rage' => 88,
			'pose'=> 1,
			'tactic' => 3,
			'killnum' => 0,
			'teamID' => '',
			'teamPass' => '',
			'gd' => 'r',
			'pls' => 34,
			'mhp' => 3000,
			'msp' => 400,
			'att' => 200,
			'def' => 200,
			'lvl' => 40,
			'skill' => 300,
			'money' => 800,
			'arb' => '英雄战甲B',
			'arbk' => 'DB',
			'arbe' => 1000,
			'arbs' => 300,
			'arbsk' => 'A',
			'arh' => '英雄战甲H',
			'arhk' => 'DH',
			'arhe' => 600,
			'arhs' => 300,
			'arhsk' => 'DF',
			'arf' => '英雄战甲F',
			'arfk' => 'DF',
			'arfe' => 500,
			'arfs' => 300,
			'arfsk' => 'a',
			'ara' => '英雄战甲A',
			'arak' => 'DA',
			'arae' => 600,
			'aras' => 300,
			'arask' => 'H',
			'art' => '英雄之力',
			'artk' => 'A',
			'arte' => 9,
			'arts' => 9,
			'artsk' => 'c',
			'sub' => array
			(
				0 => array
				(
					'name' => '霜火协奏曲',
					'icon' => 0,
					'club' => 6,
					'wep' => '『看吧，你的死兆星正在天上闪耀！』',
					'wepk' => 'WC',
					'wepe' => 333,
					'weps' => 600,
					'wepsk' => 'w',
				),
				1 => array
				(
					'name' => '脸骑士-菜包',
					'club' => 98,
					'icon' => 0,
					'wep' => '脸',
					'wepk' => 'WP',
					'wepe' => 300,
					'weps' => 600,
					'wepsk' => 'N',
				),
				2 => array
				(
					'name' => '枪毙的某神',
					'icon' => 0,
					'club' => 3,
					'wep' => '《小黄的时间球》',
					'wepk' => 'WC',
					'wepe' => 180,
					'weps' => 600,
					'wepsk' => 'r',
				),
				3 => array
				(
					'name' => '我是高达',
					'icon' => 0,
					'club' => 8,
					'wep' => '毒性凸眼鱼',
					'wepk' => 'WF',
					'wepe' => 200,
					'weps' => 600,
					'wepsk' => 'pd',
				),
				4 => array
				(
					'name' => '一旦接受这种设定',
					'icon' => 0,
					'club' => 10,
					'wep' => '『一瞬千击』',
					'wepk' => 'WP',
					'wepe' => 190,
					'weps' => 600,
					'wepsk' => 'r',
				),
				5 => array
				(
					'name' => '一方通行',
					'icon' => 0,
					'club' => 9,
					'wep' => '【矢量操作】',
					'wepk' => 'WG',
					'wepe' => 300,
					'weps' => 600,
					'wepsk' => 'N',
				),
				6 => array
				(
					'name' => '晓魂之歌',
					'icon' => 0,
					'club' => 2,
					'wep' => '锋利的电气毒性晓魂之歌-改[+4]',
					'wepk' => 'WK',
					'wepe' => 300,
					'weps' => 600,
					'wepsk' => 'pew',
				),
				7 => array
				(
					'name' => '卡',
					'icon' => 0,
					'club' => 13,
					'wep' => '【不屈的意志】',
					'wepk' => 'WF',
					'wepe' => 140,
					'weps' => 600,
					'wepsk' => 'r',
				),
				8 => array
				(
					'name' => 'Exocet',
					'icon' => 0,
					'club' => 9,
					'wep' => '『微型火箭加速噴射單輪車』',
					'wepk' => 'WP',
					'wepe' => 110,
					'weps' => 600,
					'wepsk' => 'ru',
				),
				9 => array
				(
					'name' => '中西醫',
					'icon' => 0,
					'club' => 1,
					'wep' => '《衷中參西錄》',
					'wepk' => 'WP',
					'wepe' => 250,
					'weps' => 600,
					'wepsk' => 'p',
				),
				10 => array
				(
					'name' => '黑猫',
					'icon' => 0,
					'club' => 6,
					'wep' => '阔剑地雷吸附器',
					'wepk' => 'WP',
					'wepe' => 400,
					'weps' => 600,
					'wepsk' => 'Mm',
				),
				11 => array
				(
					'name' => '水羊',
					'icon' => 0,
					'club' => 2,
					'wep' => '■Darthnote■',
					'wepk' => 'WK',
					'wepe' => 400,
					'weps' => 600,
					'wepsk' => 'c',
				),
				12 => array
				(
					'name' => '上帝的左手',
					'icon' => 0,
					'club' => 2,
					'wep' => '胡来的左手',
					'wepk' => 'WK',
					'wepe' => 270,
					'weps' => 600,
					'wepsk' => 'd',
				),
				13 => array
				(
					'name' => '半人半灵半吊子',
					'icon' => 0,
					'club' => 98,
					'wep' => '楼观剑',
					'wepk' => 'WK',
					'wepe' => 200,
					'weps' => 600,
					'wepsk' => 'd',
					'itm1' => '白楼剑',
					'itmk1' => 'WK',
					'itme1' => 130,
					'itms1' => 600,
					'itmsk1' => 'r',
				),
				14 => array
				(
					'name' => '死亡荆棘',
					'icon' => 0,
					'club' => 7,
					'wep' => '【荆棘式电子地雷】',
					'wepk' => 'WK',
					'wepe' => 210,
					'weps' => 600,
					'wepsk' => 'd',
				),
				15 => array
				(
					'name' => '超魔理沙-电子',
					'icon' => 0,
					'club' => 14,
					'wep' => '【荆棘式电子地雷】',
					'wepk' => 'WP',
					'wepe' => 240,
					'weps' => 600,
					'wepsk' => 'd',
				),
				16 => array
				(
					'name' => '东方地雷殿',
					'icon' => 0,
					'club' => 7,
					'wep' => '【荆棘式电子地雷】',
					'wepk' => 'WD',
					'wepe' => 210,
					'weps' => 600,
					'wepsk' => 'd',
				),
				17 => array
				(
					'name' => 'fossil',
					'icon' => 0,
					'club' => 1,
					'wep' => '大钉棍棒',
					'wepk' => 'WP',
					'wepe' => 250,
					'weps' => 600,
					'wepsk' => 'Nn',
				),
				18 => array
				(
					'name' => '流风之念',
					'icon' => 0,
					'club' => 4,
					'wep' => '连击烧输尿管~☆',
					'wepk' => 'WG',
					'wepe' => 150,
					'weps' => 600,
					'wepsk' => 'ru',
				),
				19 => array
				(
					'name' => 'MESSIAH',
					'icon' => 0,
					'club' => 4,
					'wep' => '本格的嘴炮',
					'wepk' => 'WG',
					'wepe' => 240,
					'weps' => 600,
					'wepsk' => 'd',
				),
				20 => array
				(
					'name' => '帕秋莉诺蕾姬',
					'icon' => 0,
					'club' => 9,
					'wep' => '水&火符「Phlogistic Rain」',
					'wepk' => 'WF',
					'wepe' => 260,
					'weps' => 600,
					'wepsk' => 'ui',
				),
				21 => array
				(
					'name' => '坂田铜时',
					'icon' => 0,
					'club' => 1,
					'wep' => '无毁的受王拳',
					'wepk' => 'WP',
					'wepe' => 380,
					'weps' => 600,
				),
				22 => array
				(
					'name' => '耶和华',
					'icon' => 0,
					'club' => 15,
					'wep' => 'L5爆发！',
					'wepk' => 'WF',
					'wepe' => 250,
					'weps' => 600,
					'wepsk' => 'd',
				),
				23 => array
				(
					'name' => '闹球肾',
					'icon' => 0,
					'club' => 1,
					'wep' => '一个半角符号',
					'wepk' => 'WF',
					'wepe' => 150,
					'weps' => 600,
					'wepsk' => 'rd',
				),
				24 => array
				(
					'name' => '初音ミク',
					'icon' => 0,
					'club' => 4,
					'wep' => '「Falchion Rider」模样的杏仁豆腐',
					'wepk' => 'WG',
					'wepe' => 190,
					'weps' => 600,
					'wepsk' => 'r',
					'arb' => '英雄战甲B模样的杏仁豆腐',
					'arh' => '英雄战甲H模样的杏仁豆腐',
					'arf' => '英雄战甲F模样的杏仁豆腐',
					'ara' => '英雄战甲A模样的杏仁豆腐',
					'art' => '英雄之力模样的杏仁豆腐',
				),
				25 => array
				(
					'name' => 'Abyss混沌',
					'icon' => 0,
					'club' => 1,
					'wep' => '混乱邪恶之塔',
					'wepk' => 'WF',
					'wepe' => 1,
					'weps' => 1,
					'wepsk' => 'r',
				),
				26 => array
				(
					'name' => '飞雪大大',
					'icon' => 0,
					'club' => 9,
					'wep' => '魔王の剑',
					'wepk' => 'WK',
					'wepe' => 300,
					'weps' => 300,
					'wepsk' => 'u',
				),
				27 => array
				(
					'name' => '微笑的疯子',
					'icon' => 0,
					'club' => 1,
					'wep' => '把妹の手',
					'wepk' => 'WP',
					'wepe' => 100,
					'weps' => 600,
					'wepsk' => 'Nnr',
				),
				28 => array
				(
					'name' => '挂机中的灰尘',
					'icon' => 0,
					'club' => 9,
					'wep' => '★挂机の萌力★',
					'wepk' => 'WF',
					'wepe' => 250,
					'weps' => 600,
					'wepsk' => 'ni',
				),
				29 => array
				(
					'name' => '西园寺世界酱',
					'icon' => 0,
					'club' => 5,
					'wep' => '节操炸弹G',
					'wepk' => 'WD',
					'wepe' => 300,
					'weps' => 600,
					'wepsk' => 'id',
				),
				30 => array
				(
					'name' => '索非亚小傻鸟',
					'icon' => 0,
					'club' => 8,
					'wep' => 'COCO☆酱',
					'wepk' => 'WC',
					'wepe' => 280,
					'weps' => 600,
					'wepsk' => 'lu',
				),
				31 => array
				(
					'name' => '浮云_小坏',
					'icon' => 0,
					'club' => 9,
					'wep' => '向日葵妖精',
					'wepk' => 'WG',
					'wepe' => 251,
					'weps' => 600,
					'wepsk' => 'ud',
					'itm1' => 'YES♂SIR',
					'itmk1' => 'Z',
					'itme1' => 1,
					'itms1' => 1,
				),
				32 => array
				(
					'name' => '人形蚂蚁α',
					'icon' => 0,
					'club' => 9,
					'wep' => '纸条■■■■',
					'wepk' => 'WC',
					'wepe' => 280,
					'weps' => 600,
					'wepsk' => 'Ne',
				),
				33 => array
				(
					'name' => 'tabris',
					'icon' => 0,
					'club' => 13,
					'wep' => '十二试炼',
					'wepk' => 'WC',
					'wepe' => 400,
					'weps' => 600,
					'wepsk' => 'r',
				),
				34 => array
				(
					'name' => '吔姐蕉',
					'icon' => 0,
					'club' => 1,
					'wep' => '无毁的受王拳',
					'wepk' => 'WP',
					'wepe' => 410,
					'weps' => 600,
				),
				35 => array
				(
					'name' => 'ad53123426',
					'icon' => 0,
					'club' => 9,
					'wep' => '无毁的受王拳',
					'wepk' => 'WP',
					'wepe' => 530,
					'weps' => 600,
				),
			),
		),
	
		21 => array
			(
			'mode' => 2,
			'num' => 7,
			'pass' => 'wei42bg',
			'club' => 0,
			'bid' => 0,
			'inf' => '',
			'rage' => 250,
			'pose'=> 2,
			'tactic' => 3,
			'killnum' => 0,
			'teamID' => '',
			'teamPass' => '',
			'gd' => 'r',
			'pls' => 34,
			'mhp' => 12900,
			'msp' => 800,
			'att' => 4000,
			'def' => 4000,
			'lvl' => 65,
			'skill' => 800,
			'money' => 40000,
			'arb' => '武神战甲B',
			'arbk' => 'DB',
			'arbe' => 3000,
			'arbs' => 300,
			'arbsk' => 'A',
			'arh' => '武神战甲H',
			'arhk' => 'DH',
			'arhe' => 2000,
			'arhs' => 300,
			'arhsk' => 'b',
			'arf' => '武神战甲F',
			'arfk' => 'DF',
			'arfe' => 2000,
			'arfs' => 300,
			'arfsk' => 'a',
			'ara' => '武神战甲A',
			'arak' => 'DA',
			'arae' => 2000,
			'aras' => 300,
			'arask' => 'H',
			'art' => '武神之魂',
			'artk' => 'A',
			'arte' => 9,
			'arts' => 9,
			'artsk' => 'ch',
	
	
	
	
			'sub' => array
			(
				0 => array
				(
					'name' => '黑熊',
					'gd' => 'm',
					'icon' => 210,
					'club' => 18,
					'mhp' => 8932,
					'att' => 5120,
					'skill' => 1919,
					'skills' => array('400'=>'5','401'=>'5','402'=>'1','403'=>'5','461'=>'1','422'=>'0'),
					'wep' => 'Solidarity',
					'wepk' => 'WG',
					'wepe' => 3000,
					'weps' => 3000,
					'wepsk' => 'Nnrd',
					'arb' => 'NATO',
					'arbk' => 'DB',
					'arbe' => 2333,
					'arbs' => 300,
					'arbsk' => 'ZA',
					'arh' => 'Voice of America',
					'arhk' => 'DH',
					'arhe' => 2333,
					'arhs' => 300,
					'arhsk' => 'ZB',
					'arf' => 'One small step',
					'arfk' => 'DF',
					'arfe' => 2333,
					'arfs' => 300,
					'arfsk' => 'Za',
					'ara' => 'Tear down this WALL',
					'arak' => 'DA',
					'arae' => 2333,
					'aras' => 300,
					'arask' => 'ZH',
					'art' => 'Bear Trap',
					'artk' => 'A',
					'arte' => 1,
					'arts' => 1,
					'artsk' => 'Zch',
					'itm1' => '『黑熊刀』',
					'itmk1' => 'WK',
					'itme1' => 90,
					'itms1' => 350,
					'itmsk1' => 'Nnrd',
					'itm2' => '超重型黑熊列车 古斯塔夫最大炮',
					'itmk2' => 'WG',
					'itme2' => 3000,
					'itms2' => 3000,
					'itmsk2' => 'Nnrd',
					'itm3' => '《黑熊语录》',
					'itmk3' => 'VV',
					'itme3' => 153,
					'itms3' => 1,
					'itmsk3' => 'Z',
					'itm4' => '这个是什么按钮',
					'itmk4' => 'Y',
					'itme4' => 1,
					'itms4' => 1,
					'description' => '武神 黑熊，<span class="yellow b">旧英灵四天王之首，被称为英灵殿唯一的良心。（咦？）<br>附带很不要脸的<span class="red b">【直死1】</span>和<span class="red b">【暴风】</span>技能</span>',
				),
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
				2 => array
				(
					'name' => '水月',
					'gd' => 'f',
					'icon' => 99,
					'club' => 9,
					'mode' => 2,
					'mhp' => 14000,
					'skill' => 1200,
					'skills' => array('81'=>'0', '461'=>'0'),
					'wep' => '「饭纲权现降临」',
					'wepk' => 'WC',
					'wepe' => 1,
					'weps' => 9999,
					'wepsk' => 'Bbx',
					'arb' => 'Reality marble',
					'arbk' => 'DB',
					'arbe' => 3000,
					'arbs' => 500,
					'arbsk' => 'Ax',
					'arh' => 'Torah',
					'arhk' => 'DH',
					'arhe' => 3000,
					'arhs' => 300,
					'arhsk' => 'bx',
					'arf' => 'Nevi’im',
					'arfk' => 'DF',
					'arfe' => 3000,
					'arfs' => 300,
					'arfsk' => 'ax',
					'ara' => 'Fantasm',
					'arak' => 'DA',
					'arae' => 3000,
					'aras' => 300,
					'arask' => 'Hx',
					'art' => '《Dead Sea Scrolls》',
					'artk' => 'Ah',
					'arte' => 3000,
					'arts' => 233,
					'artsk' => 'cx',
					'itm1' => 'EX火&金符『St. Elmo Pillar』',
					'itmk1' => 'WF',
					'itme1' => 800,
					'itms1' => '∞',
					'itmsk1' => 'nrdf',
					'itm2' => 'Barrett M95',
					'itmk2' => 'WG',
					'itme2' => 1500,
					'itms2' => 500,
					'itmsk2' => 'rnfS',
					'itm3' => '圣光啊!你有看到那个敌人吗！',
					'itmk3' => 'Z',
					'itme3' => 1,
					'itms3' => 1,
					'description' => '武神 水月，<span class="yellow b">旧英灵四天王之一。</span>身上的火金符对玩家威胁很大，称号为换装迷宫，台词来源于圣经。初始武器自带双抹，但威力不足。',
				),
				3 => array
				(
					'name' => '芬里爾《黑曲》',
					'gd' => 'f',
					'mode' => 3,
					'icon' => 104,
					'club' => 99,
					'mhp' => 10000,
					'att' => 100,
					'def' => 400,
					'rage' => 10,
					'lvl' => 20, 
					'skill' => 100,
					'skills' => array('461'=>'1'),
					'wep' => '超⑨武神斩',
					'wepk' => 'WK',
					'wepe' => 200,
					'weps' => 100,
					'wepsk' => 'z',
					'arb' => '黑曲装备B',
					'arbk' => 'DB',
					'arbe' => 400,
					'arbs' => 300,
					'arbsk' => 'zh',
					'arh' => '黑曲装备H',
					'arhk' => 'DH',
					'arhe' => 233,
					'arhs' => 300,
					'arhsk' => 'z',
					'arf' => '黑曲装备F',
					'arfk' => 'DF',
					'arfe' => 233,
					'arfs' => 300,
					'arfsk' => 'z',
					'ara' => '黑曲装备A',
					'arak' => 'DA',
					'arae' => 233,
					'aras' => 300,
					'arask' => 'z',
					'art' => '黑曲装备T',
					'artk' => 'Ah',
					'arte' => 233,
					'arts' => 233,
					'artsk' => 'z',
					'description' => '武神 黑色奪魂曲，<span class="yellow b">英灵殿吉祥物。</span>攻击力低，二形态血量为1000W，自带双抹，同时武器拥有贯穿属性，具有一定威胁。',
				),
				4 => array
				(
					'name' => '北京推倒你',
					'gd' => 'm',
					'icon' => 102,
					'club' => 14,
					'skill' => 6000,
					'skills' => array('461'=>'0'),
					'wep' => '拳头',
					'wepk' => 'WN',
					'wepe' => 400,
					'weps' => 998,
					'wepsk' => 'hrden',
					'arb' => 'Microsoft Visual Studio 2010',
					'arbk' => 'DB',
					'arbe' => 2333,
					'arbs' => 300,
					'arbsk' => 'A',
					'arh' => 'GoldWave',
					'arhk' => 'DH',
					'arhe' => 2333,
					'arhs' => 300,
					'arhsk' => 'b',
					'arf' => 'MeGUI',
					'arfk' => 'DF',
					'arfe' => 2333,
					'arfs' => 300,
					'arfsk' => 'a',
					'ara' => 'Micorsoft AppLocale',
					'arak' => 'DA',
					'arae' => 2333,
					'aras' => 300,
					'arask' => 'H',
					'itm1' => '肉○器“北京”型',
					'itmk1' => 'WP',
					'itme1' => 4000,
					'itms1' => '∞',
					'itmsk1' => 'g',
					'description' => '武神 北京推倒你，<span class="yellow b">曾经被誉为最弱武神，经过BUFF后变的丧心病狂起来。</span>武器为空手，但拥有6000点的基础熟练，隐隐有成为小黑熊的架势。',
				),
				5 => array
				(
					'name' => 'BorisX',
					'gd' => 'm',
					'icon' => 105,
					'hp' => 9400,
					'club' => 4,
					'skill' => 1150,
					'skills' => array('461'=>'1'),
					'wep' => 'AKM改二',
					'wepk' => 'WJ',
					'wepe' => 2600,
					'weps' => 4000,
					'wepsk' => 'n',
					'description' => '武神 BorisX，<span class="yellow b">旧英灵四天王之一，经过BUFF后变的更加丧心病狂。</span>武器为重枪，同时具有1150点的基础熟练，而且血量也有所提升，大家看见之后绕着走就行了。',
				),
				6 => array
				(
					'name' => 'Renamon',
					'gd' => 'f',
					'mhp' => 14000,
					'icon' => 98,
					'club' => 2,
					'skill' => 1100,
					'skills' => array('461'=>'0'),
					'wep' => '画(ping)笔(ru)',
					'wepk' => 'WK',
					'wepe' => 1900,
					'weps' => 999,
					'wepsk' => 'rdn',
					'description' => '武神 Renamon，<span class="yellow b">旧时代毫无存在感的武神之一，被BUFF能拯救她阿卡林的命运吗？</span>血量为武神中最高，同时武器基础效和全熟在被BUFF后隐隐有与当年黄鸡寻星比肩的势头。',
				),
				7 => array
				(
					'name' => 'beijuzhu',
					'gd' => 'm',
					'icon' => 0,
					'club' => 7,
					'skill' => 3000,
					'skills' => array('461'=>'0'),
					'wep' => '破解的PSP-3000',
					'wepk' => 'WP',
					'wepe' => 2100,
					'weps' => 999,
					'wepsk' => 'rne',
					'description' => '武神 beijuzhu，<span class="yellow b">旧时代毫无存在感的武神之一，被BUFF能拯救他阿卡林的命运吗？</span>虽然和小狐一样，武器基础效得到了BUFF，但看起来还是很弱小。',
				),
				8 => array
				(
					'name' => '捂脸姬',
					'gd' => 'f',
					'pose' => 4,
					'att' => 4000,
					'icon' => 0,
					'club' => 8,
					'skill' => 850,
					'skills' => array('461'=>'0'),
					'wep' => '超级☆无敌辰音LILY',
					'wepk' => 'WD',
					'wepe' => 10000,
					'weps' => 999,
					'wepsk' => 'cdn',
					'description' => '武神 捂脸姬，<span class="yellow b">旧时代毫无存在感的武神之一，被BUFF能拯救她阿卡林的命运吗？</span>少数没有强袭姿态的武神之一，但是武器基础效直接被提高了十倍，看起来很危险的样子。',
				),
				9 => array
				(
					'name' => 'Yoshiko-G',
					'gd' => 'f',
					'def' => 30250,
					'icon' => 4,
					'club' => 18,
					'skill' => 900,
					'skills' => array('461'=>'0'),
					'wep' => '光翼型近接支援残酷戦闘機銃',
					'wepk' => 'WG',
					'wepe' => 2000,
					'weps' => 999,
					'wepsk' => 'nre',
					'description' => '武神 Yoshiko-G，<span class="yellow b">四面衍生物，特征是毒舌与傲娇。</span>武神中基础防御力仅低于lemon，在得到BUFF后翻身农奴把歌唱，自带迅疾和静息技能，同时称号变为天赋，要被耀西子教做人了吗！？',
				),
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
			),
		),
		
		22 => array
		(
			'mode' => 1,
			'num' => 4,
			'club' => 0,
			'bid' => 0,
			'inf' => '',
			'rage' => 255,
			'pose'=> 4,
			'tactic' => 3,
			'killnum' => 99,
			'teamID' => '',
			'teamPass' => '',
			'pls' => 34,
			'mhp' => 23333,
			'msp' => 2333,
			'def' => 2333,
			'lvl' => 97,
			'skill' => 444,
			'money' => 100000,
			'arb' => '天神的威光',
			'arbk' => 'DB',
			'arbe' => 6000,
			'arbs' => 400,
			'arbsk' => 'ab',
			'arh' => '天神的极光',
			'arhk' => 'DH',
			'arhe' => 4000,
			'arhs' => 300,
			'arhsk' => 'h',
			'arf' => '天神的霞光',
			'arfk' => 'DF',
			'arfe' => 4000,
			'arfs' => 300,
			'arfsk' => 'A',
			'ara' => '天神的寒光',
			'arak' => 'DA',
			'arae' => 4000,
			'aras' => 300,
			'arask' => 'c',
			'art' => '天神的曙光',
			'artk' => 'A',
			'arte' => 200,
			'arts' => 300,
			'artsk' => 'H',
			'sub' => array
			(
				0 => array
				(
					'name' => '冴月麟MK-II',
					'gd' => 'f',
					'icon' => 3,
					'club' => 9,
					'mss' => 50,
					'att' => 23333,
					'skill' => array('wp' => 1600, 'wk' => 2300, 'wc' => 2700, 'wg' => 1900, 'wd' => 1500, 'wf' => 2800),
					'skills' => array('81' => '0', '461'=>'0'),
					'wep' => '键 希望弹',
					'wepk' => 'WC',
					'wepe' => 50000,
					'weps' => 998,
					'wepsk' => 'zdfkc',
					'arb' => '真 - 桔黄色的大衣',
					'arh' => '真 - 红色的发圈',
					'arf' => '真 - 橙黄学生鞋',
					'ara' => '真 - 带翅膀的书包',
					'art' => '真 - 奇迹之愿',
					'itm1' => '键 燃烧弹',
					'itmk1' => 'WF',
					'itme1' => 48000,
					'itms1' => '∞',
					'itmsk1' => 'Nfzr',
					'itm2' => '键 生命弹',
					'itmk2' => 'WG',
					'itme2' => 50000,
					'itms2' => 998,
					'itmsk2' => 'zdrfk',
					'itm3' => '键 未来弹',
					'itmk3' => 'WP',
					'itme3' => 50000,
					'itms3' => '∞',
					'itmsk3' => 'rcdfN',
		




					'itm5' => '键 旅途弹',
					'itmk5' => 'WK',
					'itme5' => 50000,
					'itms5' => 998,
					'itmsk5' => 'zdNkc',
					'itm6' => '键 审判弹',
					'itmk6' => 'WF',
					'itme6' => 100000,
					'itms6' => '∞',
					'itmsk6' => 'nrfkx',
					'description' => '天神 冴月麟MK-II，ACFUN大逃杀的最初创作者。KEY社的铁杆粉丝。会切换武器。（没有键 催泪弹是刻意的）',
				),
				1 => array
				(
					'name' => '星莲船四面BOSS',
					'gd' => 'm',
					'icon' => 163,
					'club' => 18,
					'att' => 233,
					'mhp' => 4444,
					'skill' => 120,
					'skills' => array('461'=>'0'),
					'wep' => '【黑暗童话】',
					'wepk' => 'WJ',
					'wepe' => 1,
					'weps' => 9999,
					'wepsk' => 'rdpn^ac1',
					'arb' => '可爱标记拼成的披风',
					'arh' => '天马经理的面罩',
					'arf' => '刀锋般的后腿',
					'ara' => '研究员的笔记本',
					'art' => 'S.M.I.L.E.!',
					'itm2' => '四面的腿',
					'itmk2' => 'PB2',
					'itme2' => 1,
					'itms2' => 1,
					'itmsk2' => 'x',
					'itm1' => '武器师安雅的奖赏',
					'itmk1' => 'Y',
					'itme1' => 1,
					'itms1' => 3,
					'itmsk1' => 'z',
					'description' => '天神 星莲船四面BOSS，AC大逃杀程序员、抖M，本体已经变成了马。虽然武器的攻击力是1，但由于重型枪械的百分比伤害设定，实际上对玩家拥有即死效果。',
				),
				2 => array
				(
					'name' => '虚子',
					'gd' => 'f',
					'icon' => 161,
					'club' => 18,
					'mhp' => 8932,
					'att' => 5120,
					'skill' => 1919,
					'skills' => array('400'=>'5','401'=>'5','402'=>'4','461'=>'1'),
					'wep' => 'WE will BURY YOU',
					'wepk' => 'WG',
					'wepe' => 3000,
					'weps' => 3000,
					'wepsk' => 'Nnrd',
					'arb' => 'Warsaw Pact',
					'arh' => 'De-Stalinization',
					'arf' => 'Muslim Revolution',
					'ara' => 'Flower Power',
					'art' => 'Glasnost',
					'itm1' => '『寻星者』',
					'itmk1' => 'WK',
					'itme1' => 90,
					'itms1' => 350,
					'itmsk1' => 'Nnrd',
					'itm2' => '超重型炮塔列车 古斯塔夫最大炮',
					'itmk2' => 'WG',
					'itme2' => 3000,
					'itms2' => 3000,
					'itmsk2' => 'Nnrd',
					'itm3' => '《董子语录》',
					'itmk3' => 'VV',
					'itme3' => 153,
					'itms3' => 1,
					'itmsk3' => 'Z',
					'description' => '天神 虚子，AC大逃杀程序员，毒舌属性。<br>附带很不要脸的<span class="red b">【直死4】</span>技能，命中抬走送往印度，现在订购还附赠美味香蕉一串。pong友，今天你被直死了吗？',
				),
				3 => array
				(
					'name' => 'lemon',
					'gd' => 'r',
					'icon' => 162,
					'club' => 7,
					'lvl' => 0,
					'rage' => 0,
					'mhp' => 9800,
					'att' => 32767,
					'def' => 32767,
					'skill' => 1150,
					'skills'=>array('412'=>'0','461'=>'1'),	
					'wep' => '电气火绳枪',
					'wepk' => 'WG',
					'wepe' => 30,
					'weps' => 60,
					'wepsk' => 'en',
					'arb' => '工作装',
					'arh' => '防灾头巾',
					'ara' => '垫肩',
					'arf' => '钉鞋',
					'art' => 'Untainted Glory',
					'itm1' => 'ACDTS Farming Helper',
					'itmk1' => 'ME',
					'itme1' => 20,
					'itms1' => 200,
					'itmsk1' => 'z',
					'description' => '天神 lemon，AC大逃杀程序员，代码力深不见底。<br>拥有全英灵殿最高的基础攻击与防御，而更吓人的是其拥有的<span class="red b">【反演】</span>技能，让无数屠殿老司机铩羽而归。',
				),
			),
		),
		
		45=> array
		(
			'mode' => 2,
			'num' => 8,
			'pass' => 'bra',
			'club' => 14,
			'bid' => 0,
			'inf' => '',
			'rage' => 0,
			'skills' => array('404'=>'2'),
			'pose'=> 4,
			'tactic' => 3,
			'killnum' => 0,
			'teamID' => 'MhHmpsz',
			'teamPass' => 'Eb2Lfz3Usvui',
			'pls' => 99,
			'mhp' => 5400,
			'msp' => 200,
			'att' => 200,
			'def' => 300,
			'lvl' => 25,
			'skill' => 120,
			'money' => 4500,
			'mss' => 50,
			'arb' => '电波的意志',
			'arbk' => 'DB',
			'arbe' => 420,
			'arbs' => 100,
			'arh' => '智者的头脑',
			'arhk' => 'DH',
			'arhe' => 340,
			'arhs' => 100,
			'ara' => '触手的潜能',
			'arak' => 'DA',
			'arae' => 340,
			'aras' => 100,
			'arask' => 'R',
			'arf' => '头名的尊严',
			'arfk' => 'DF',
			'arfe' => 340,
			'arfs' => 100,
			'art' => '你沒戲唱了，快去死吧！',
			'artk' => 'A',
			'arte' => 200,
			'arts' => 10,
			'artsk' => 'xa',
			'sub' => array
			(
				0 => array
				(
					'name' => '索菲亚小傻鸟',
					'gd' => 'm',
					'icon' => 109,
					'wep' => '燃烧吧',
					'wepk' => 'WG',
					'wepe' => 40,
					'weps' => 20000,
					'wepsk' => 'Au',
					'itm1' => '傻鸟的结婚请柬',
					'itmk1' => 'WC',
					'itme1' => 600,
					'itms1' => 150,
					'itmsk1' => 'rdc',
					'itm2' => '红烧小鸟',
					'itmk2' => 'HB',
					'itme2' => 500,
					'itms2' => 150,
					'itm3' => 'kitty酱的围裙',
					'itmk3' => 'DB',
					'itme3' => 500,
					'itms3' => 150,
					'itmsk3' => 'PF',
					'description' => '电波幽灵 索菲亚小傻鸟，电波第一代触手代表。另一个身份是A岛美食版女神kitty酱。',
				),
				1 => array
				(
					'name' => '虚名',
					'gd' => 'm',
					'icon' => 110,
					'wep' => '片翼虚影',
					'wepk' => 'WK',
					'wepe' => 15,
					'weps' => 100,
					'wepsk' => 'Ad',
					'itm1' => '虚名的精灵片翼',
					'itmk1' => 'WK',
					'itme1' => 600,
					'itms1' => 150,
					'itmsk1' => 'uid',
					'itm2' => '不明黑色物质',
					'itmk2' => 'HB',
					'itme2' => 500,
					'itms2' => 150,
					'itm3' => '悲叹之种',
					'itmk3' => 'DH',
					'itme3' => 500,
					'itms3' => 150,
					'itmsk3' => 'KG',
					'description' => '电波幽灵 虚名，电波第二代触手代表。本命武器为精灵片翼。',
				),
				2 => array
				(
					'name' => 'YS',
					'gd' => 'm',
					'icon' => 111,
					'wep' => '毁灭阴影',
					'wepk' => 'WF',
					'wepe' => 80,
					'weps' => 150,
					'wepsk' => 'Ac',
					'itm1' => 'YS的魂之挽歌',
					'itmk1' => 'WF',
					'itme1' => 600,
					'itms1' => 20,
					'itmsk1' => 'd',
					'itm2' => '奶酪',
					'itmk2' => 'HB',
					'itme2' => 500,
					'itms2' => 150,
					'itm3' => '卜择手断',
					'itmk3' => 'DA',
					'itme3' => 500,
					'itms3' => 150,
					'itmsk3' => 'CD',
					'description' => '电波幽灵 YS，电波第三代触手代表。是一名脸很黑的小学生。',
				),
				3 => array
				(
					'name' => '逆向朝阳',
					'gd' => 'f',
					'icon' => 112,
					'wep' => '大爷星人',
					'wepk' => 'WC',
					'wepe' => 50,
					'weps' => 200,
					'wepsk' => 'AN',
					'itm1' => '朝阳的肥猫大爷',
					'itmk1' => 'WP',
					'itme1' => 600,
					'itms1' => 150,
					'itmsk1' => 'cd',
					'itm2' => '肉用大爷',
					'itmk2' => 'HB',
					'itme2' => 500,
					'itms2' => 150,
					'itm3' => '挂在腿上的大爷',
					'itmk3' => 'DF',
					'itme3' => 500,
					'itms3' => 150,
					'itmsk3' => 'a',
					'description' => '电波幽灵 逆向朝阳，电波第二代触手，电波前段时间的统治者。养了很多猫大爷。',
				),
			),
		),
		
		88 => array
		(
			'mode' => 1,
			'num' => 4,
			'pass' => 'bra',
			'club' => 17,
			'bid' => 0,
			'inf' => '',
			'rage' => 188,
			'pose'=> 2,
			'tactic' => 3,
			'killnum' => 88,
			'teamID' => '',
			'teamPass' => '',
			'gd' => 'm',
			'pls' => 32,
			'mhp' => 8888888,
			'msp' => 888,
			'att' => 88888,
			'def' => 88888,
			'lvl' => 88,
			'skill' => 88888,
			'money' => 88888,
			'arb' => '[数据删除]',
			'arbk' => 'DB',
			'arbe' => 8888,
			'arbs' => 8888,
			'arbsk' => 'Aa',
			'arh' => '[数据删除]',
			'arhk' => 'DH',
			'arhe' => 8888,
			'arhs' => 8888,
			'arhsk' => 'Bb',
			'arf' => '[数据删除]',
			'arfk' => 'DF',
			'arfe' => 8888,
			'arfs' => 8888,
			'arfsk' => 'Mm',
			'ara' => '[数据删除]',
			'arak' => 'DA',
			'arae' => 8888,
			'aras' => 8888,
			'arask' => 'Hc',
			'art' => '[数据删除]',
			'artk' => 'A',
			'arte' => 1,
			'arts' => 1,
			'artsk' => 'xH',
			'sub' => array
			(
				0 => array
				(
					'name' => 'SCP-682',
					'icon' => 103,
					'wep' => '[数据删除]',
					'wepk' => 'WN',
					'wepe' => 8888,
					'weps' => 8888,
					'wepsk' => 'nrd',
					'description' => 'SCP-682，坐镇于SCP研究设施，完全无敌的存在，要是不幸被打到的话，必死无疑。最好的避免方法，就是<span class="yellow b">永远不要去SCP研究设施</span>。',
				),
				1 => array
				(
					'name' => 'SCP-173',
					'icon' => 106,
					'wep' => '[数据删除]',
					'wepk' => 'WF',
					'wepe' => 8888,
					'weps' => 8888,
					'wepsk' => 'nrd',
					'description' => 'SCP-173，坐镇于SCP研究设施，完全无敌的存在，要是不幸被打到的话，必死无疑。最好的避免方法，就是<span class="yellow b">永远不要去SCP研究设施</span>。',
				),
				2 => array
				(
					'name' => 'SCP-076',
					'icon' => 107,
					'wep' => '[数据删除]',
					'wepk' => 'WK',
					'wepe' => 8888,
					'weps' => 8888,
					'wepsk' => 'nrd',
					'description' => 'SCP-076，坐镇于SCP研究设施，完全无敌的存在，要是不幸被打到的话，必死无疑。最好的避免方法，就是<span class="yellow b">永远不要去SCP研究设施</span>。',
				),
				3 => array
				(
					'name' => 'SCP-958',
					'icon' => 108,
					'wep' => '[数据删除]',
					'wepk' => 'WG',
					'wepe' => 8888,
					'weps' => 8888,
					'wepsk' => 'nrd',
					'description' => 'SCP-958，坐镇于SCP研究设施，完全无敌的存在，要是不幸被打到的话，必死无疑。最好的避免方法，就是<span class="yellow b">永远不要去SCP研究设施</span>。',
				),
			),
		),
		
		90 => array
		(
			'mode' => 2,
			'num' => 300,
			'pass' => 'bra',
			'club' => 0,
			'bid' => 0,
			'inf' => '',
			'rage' => 0,
			'pose'=> 0,
			'tactic' => 0,
			'killnum' => 0,
			'teamID' => '',
			'teamPass' => '',
			'gd' => 'r',
			'pls' => 99,
			'mhp' => 500,
			'msp' => 200,
			'att' => 130,
			'def' => 150,
			'lvl' => 10,
			'skill' => 40,
			'money' => 220,
			'arb' => '跟风群皮',
			'arbk' => 'DB',
			'arbe' => 35,
			'arbs' => 30,
			
			'arh' => '萌豚头像',
			'arhk' => 'DH',
			'arhe' => 25,
			'arhs' => 30,
			
			'arf' => '女装丝袜',
			'arfk' => 'DF',
			'arfe' => 25,
			'arfs' => 30,
			
			'ara' => '发送按钮',
			'arak' => 'DA',
			'arae' => 25,
			'aras' => 30,
			
			'art' => '键盘侠之证',
			'artk' => 'A',
			'arte' => 20,
			'arts' => 10,
			
	
	
	
	

			'itm1' => '压缩饼干',
			'itmk1' => 'HB',
			'itme1' => 35,
			'itms1' => 10,
			'itm2' => '紧急药剂',
			'itmk2' => 'Ca',
			'itme2' => 1,
			'itms2' => 1,
			
			'sub' => array
			(
				0 => array
				(
					'name' => '复读机',
					'icon' => 25,
					'wep' => '水群之枪',
					'wepk' => 'WG',
					'wepe' => 50,
					'weps' => 50,
					'description' => '“人类的本质就是复读机。”<br>无威胁的杂兵，也是数目最多的NPC之一，碰见了就上去给他一击吧。',
				),
				1 => array
				(
					'name' => '秦国人',
					'icon' => 26,
					'wep' => '丢人之摸',
					'wepk' => 'WP',
					'wepe' => 50,
					'weps' => 50,
					'description' => '“真鸡儿丢人！”<br>无威胁的杂兵，也是数目最多的NPC之一，碰见了就上去给他一击吧。',
				),
				2 => array
				(
					'name' => '白学家',
					'icon' => 29,
					'mss' => 30,
					'wep' => '雪碧之罐',
					'wepk' => 'WC',
					'wepe' => 50,
					'weps' => 50,
					'description' => '“又到了那个寒冷的季节……”<br>无威胁的杂兵，也是数目最多的NPC之一，碰见了就上去给他一击吧。',
				),
				3 => array
				(
					'name' => '膜触党',
					'icon' => 28,
					'wep' => '捧杀之钩',
					'wepk' => 'WK',
					'wepe' => 50,
					'weps' => 50,
					'description' => '“这服就我不是触手了。”<br>无威胁的杂兵，也是数目最多的NPC之一，碰见了就上去给他一击吧。',
				),
			),
		),
	);
}
?>