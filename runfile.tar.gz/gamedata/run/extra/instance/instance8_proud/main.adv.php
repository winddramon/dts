<?php

namespace instance8
{
	function init() {
		do { global $___LOCAL_SKILLBASE__VARS__acquired_list,$___LOCAL_SKILLBASE__VARS__parameter_list,$___LOCAL_SKILLBASE__VARS__ppid,$___LOCAL_SKILLBASE__VARS__valid_skills; $acquired_list=&$___LOCAL_SKILLBASE__VARS__acquired_list; $parameter_list=&$___LOCAL_SKILLBASE__VARS__parameter_list; $ppid=&$___LOCAL_SKILLBASE__VARS__ppid; $valid_skills=&$___LOCAL_SKILLBASE__VARS__valid_skills;  global $___LOCAL_CARDBASE__VARS__card_config_file,$___LOCAL_CARDBASE__VARS__card_main_file,$___LOCAL_CARDBASE__VARS__card_index_file,$___LOCAL_CARDBASE__VARS__card_force_different_gtype,$___LOCAL_CARDBASE__VARS__card_need_charge_gtype,$___LOCAL_CARDBASE__VARS__card_cooldown_discount_gtype,$___LOCAL_CARDBASE__VARS__cardtypecd,$___LOCAL_CARDBASE__VARS__card_recrate_base,$___LOCAL_CARDBASE__VARS__packlist,$___LOCAL_CARDBASE__VARS__packdesc, $___LOCAL_CARDBASE__VARS__pack_ignore_kuji,$___LOCAL_CARDBASE__VARS__packstart,$___LOCAL_CARDBASE__VARS__packicon,$___LOCAL_CARDBASE__VARS__cardindex,$___LOCAL_CARDBASE__VARS__card_rarecolor,$___LOCAL_CARDBASE__VARS__card_rarity_html,$___LOCAL_CARDBASE__VARS__card_blink_rate_20,$___LOCAL_CARDBASE__VARS__card_blink_rate_10,$___LOCAL_CARDBASE__VARS__card_price,$___LOCAL_CARDBASE__VARS__card_price_blink_rate, $___LOCAL_CARDBASE__VARS__cards,$___LOCAL_CARDBASE__VARS__cardindex_reverse; $card_config_file=&$___LOCAL_CARDBASE__VARS__card_config_file; $card_main_file=&$___LOCAL_CARDBASE__VARS__card_main_file; $card_index_file=&$___LOCAL_CARDBASE__VARS__card_index_file; $card_force_different_gtype=&$___LOCAL_CARDBASE__VARS__card_force_different_gtype; $card_need_charge_gtype=&$___LOCAL_CARDBASE__VARS__card_need_charge_gtype; $card_cooldown_discount_gtype=&$___LOCAL_CARDBASE__VARS__card_cooldown_discount_gtype; $cardtypecd=&$___LOCAL_CARDBASE__VARS__cardtypecd; $card_recrate_base=&$___LOCAL_CARDBASE__VARS__card_recrate_base; $packlist=&$___LOCAL_CARDBASE__VARS__packlist; $packdesc=&$___LOCAL_CARDBASE__VARS__packdesc;  $pack_ignore_kuji=&$___LOCAL_CARDBASE__VARS__pack_ignore_kuji; $packstart=&$___LOCAL_CARDBASE__VARS__packstart; $packicon=&$___LOCAL_CARDBASE__VARS__packicon; $cardindex=&$___LOCAL_CARDBASE__VARS__cardindex; $card_rarecolor=&$___LOCAL_CARDBASE__VARS__card_rarecolor; $card_rarity_html=&$___LOCAL_CARDBASE__VARS__card_rarity_html; $card_blink_rate_20=&$___LOCAL_CARDBASE__VARS__card_blink_rate_20; $card_blink_rate_10=&$___LOCAL_CARDBASE__VARS__card_blink_rate_10; $card_price=&$___LOCAL_CARDBASE__VARS__card_price; $card_price_blink_rate=&$___LOCAL_CARDBASE__VARS__card_price_blink_rate;  $cards=&$___LOCAL_CARDBASE__VARS__cards; $cardindex_reverse=&$___LOCAL_CARDBASE__VARS__cardindex_reverse;   } while (0);
		if(!isset($valid_skills[18])) {
			$valid_skills[18] = array();
		}
		$valid_skills[18] += array(1001);
		$card_force_different_gtype[] = 18;
		$card_need_charge_gtype[] = 18;
		$card_cooldown_discount_gtype[18] = 0.5;
	}
	
	
	function init_enter_battlefield_items($ebp){
		return \instance10\init_enter_battlefield_items($ebp);
	}
	
	function get_npclist(){
		return \instance10\get_npclist();
	}
	
	function get_shopconfig(){
		return \instance10\get_shopconfig();
	}
	
	function get_itemfilecont(){
		return \instance10\get_itemfilecont();
	}
	
	function get_startingitemfilecont(){
		return \instance10\get_startingitemfilecont();
	}
	
	function get_startingwepfilecont(){
		return \instance10\get_startingwepfilecont();
	}
	
	function get_trapfilecont(){
		return \instance10\get_trapfilecont();
	}
	
	
	function club_choice_probability_process($clublist){
		return \skill544\club_choice_probability_process($clublist);
	}
}

?>