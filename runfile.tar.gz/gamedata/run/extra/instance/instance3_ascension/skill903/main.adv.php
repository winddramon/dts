<?php

namespace skill903
{
	function init() 
	{
		define('MOD_SKILL903_INFO','card;');
		do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;   } while (0);
		$clubskillname[903] = '厄运';
	}
	
	function acquire903(&$pa)
	{
		
		\skillbase\skill_setvalue(903,'lvl','0',$pa);
	}
	
	function lost903(&$pa)
	{
		
	}
	
	function check_unlocked903(&$pa)
	{
		
		return 1;
	}
	
	function calculate_real_trap_obbs()
	{
		
		if (\skillbase\skill_query(903) && ((int)\skillbase\skill_getvalue(903, 'lvl') >= 1)) return \skill707\calculate_real_trap_obbs()*1.2;
		else return \skill707\calculate_real_trap_obbs();
	
	}

	function calculate_itemfind_obbs_multiplier()
	{
		
		if (\skillbase\skill_query(903) && ((int)\skillbase\skill_getvalue(903, 'lvl') >= 2)) return 0.8*\skill719\calculate_itemfind_obbs_multiplier();
		else return \skill719\calculate_itemfind_obbs_multiplier();
	
	}
	
	function calculate_meetman_rate($schmode)
	{
		
		if (\skillbase\skill_query(903) && ((int)\skillbase\skill_getvalue(903, 'lvl') >= 2)) return 0.8*\tactic\calculate_meetman_rate($schmode);
		else return \tactic\calculate_meetman_rate($schmode);
	
	}

	function get_ex_phy_nullify_proc_rate(&$pa, &$pd, $active)
	{
		return \skill510\get_ex_phy_nullify_proc_rate($pa,$pd,$active);
	}
	
	function get_ex_dmg_nullify_proc_rate(&$pa, &$pd, $active)
	{
		return \skill510\get_ex_dmg_nullify_proc_rate($pa,$pd,$active);
	}
	
	function get_dmg_def_proc_rate(&$pa, &$pd, $active)
	{
		return \skill510\get_dmg_def_proc_rate($pa,$pd,$active);
	}
	
	function calculate_active_obbs_multiplier(&$ldata,&$edata)
	{
		
		$r = 1;
		if (\skillbase\skill_query(903, $ldata) && ((int)\skillbase\skill_getvalue(903, 'lvl', $ldata) >= 5)) $r *= 0.8;
if(isset($r)) {$__VAR_DUMP_MOD_skill903_VARS_r = $r; unset($r); } else {$__VAR_DUMP_MOD_skill903_VARS_r = NULL;} 
		//======== Start of contents from mod skill604 ========
		do{
			$___TMP_MOD_skill604_FUNC_calculate_active_obbs_multiplier_RET = NULL;

		
		$r = 1;
		if (1 == \skill604\check_skill604_state ($ldata)) 
		{
			$r = 0.7;
		}elseif(1 == \skill604\check_skill604_state ($edata))
		{
			$r = 1/0.7;
		}
		if($r != 1) $ldata['active_words'] = \attack\multiply_format($r, $ldata['active_words'],0);
if(isset($r)) {$__VAR_DUMP_MOD_skill604_VARS_r = $r; unset($r); } else {$__VAR_DUMP_MOD_skill604_VARS_r = NULL;} 
		//======== Start of contents from mod skill108 ========
		do{
			$___TMP_MOD_skill108_FUNC_calculate_active_obbs_multiplier_RET = NULL;

		
		$r = 1;
		if (\skillbase\skill_query(108, $ldata) && \skill108\check_unlocked108 ($ldata))
		{
			$sanity = (int)\skillbase\skill_getvalue(107,'sanity',$ldata);
			if ($sanity < 3) $r *= 1.1;
		}
		if (\skillbase\skill_query(108, $edata) && \skill108\check_unlocked108 ($edata))
		{
			$sanity = (int)\skillbase\skill_getvalue(107,'sanity',$edata);
			if ($sanity < 3) $r /= 1.1;
		}
		if($r != 1) $ldata['active_words'] = \attack\multiply_format($r, $ldata['active_words'],0);
if(isset($r)) {$__VAR_DUMP_MOD_skill108_VARS_r = $r; unset($r); } else {$__VAR_DUMP_MOD_skill108_VARS_r = NULL;} 
		//======== Start of contents from mod skill50 ========
		do{
			$___TMP_MOD_skill50_FUNC_calculate_active_obbs_multiplier_RET = NULL;

		
		$r = 1;
		if (\skillbase\skill_query(50,$ldata) && \skill50\check_unlocked50 ($ldata) && \skill50\check_skill50_proc ($ldata, $edata, 1)) $r*=1.1;
		if (\skillbase\skill_query(50,$edata) && \skill50\check_unlocked50 ($edata) && \skill50\check_skill50_proc ($edata, $ldata, 0)) $r/=1.1;
		if($r != 1) $ldata['active_words'] = \attack\multiply_format($r, $ldata['active_words'],0);
if(isset($r)) {$__VAR_DUMP_MOD_skill50_VARS_r = $r; unset($r); } else {$__VAR_DUMP_MOD_skill50_VARS_r = NULL;} 
		//======== Start of contents from mod skill248 ========
		do{
			$___TMP_MOD_skill248_FUNC_calculate_active_obbs_multiplier_RET = NULL;

		
		$r = 1;
		if (\skillbase\skill_query(248,$ldata)) 
		{
			$lv=(int)\skillbase\skill_getvalue(248,'lvl1',$ldata);
			$r*=1+\skill248\calculate_skill248_obbs_gain ($lv)/100;
		}
		if (\skillbase\skill_query(248,$edata)) 
		{
			$lv=(int)\skillbase\skill_getvalue(248,'lvl1',$edata);
			$r/=1+\skill248\calculate_skill248_obbs_gain ($lv)/100;
		}
		if($r != 1) $ldata['active_words'] = \attack\multiply_format($r, $ldata['active_words'],0);
if(isset($r)) {$__VAR_DUMP_MOD_skill248_VARS_r = $r; unset($r); } else {$__VAR_DUMP_MOD_skill248_VARS_r = NULL;} 
		//======== Start of contents from mod skill96 ========
		do{
			$___TMP_MOD_skill96_FUNC_calculate_active_obbs_multiplier_RET = NULL;

		
		$r = 1;
		if (1 == \bufficons\bufficons_check_buff_state(96, $ldata))
		{
			$skill96_type = \skillbase\skill_getvalue(96, 'type', $ldata);
			if (!empty($skill96_type) && ($skill96_type[0] == '2'))
			{
				$skill96_effect = (int)\skillbase\skill_getvalue(96, 'effect', $ldata);
				$r *= 1 + round(0.06 * $skill96_effect) / 100;
			}
		}
		if (1 == \bufficons\bufficons_check_buff_state(96, $edata))
		{
			$skill96_type = \skillbase\skill_getvalue(96, 'type', $edata);
			if (!empty($skill96_type) && ($skill96_type[0] == '2'))
			{
				$skill96_effect = (int)\skillbase\skill_getvalue(96, 'effect', $edata);
				$r /= 1 + round(0.06 * $skill96_effect) / 100;
			}
		}
		if($r != 1) $ldata['active_words'] = \attack\multiply_format($r, $ldata['active_words'],0);
if(isset($r)) {$__VAR_DUMP_MOD_skill96_VARS_r = $r; unset($r); } else {$__VAR_DUMP_MOD_skill96_VARS_r = NULL;} 
		//======== Start of contents from mod skill961 ========
		do{
			$___TMP_MOD_skill961_FUNC_calculate_active_obbs_multiplier_RET = NULL;

		
		$r = 1;
		if (\skillbase\skill_query(961, $ldata) && ((int)\skillbase\skill_getvalue(961, 'lvl', $ldata) == 0)) $r = 0.75;
if(isset($r)) {$__VAR_DUMP_MOD_skill961_VARS_r = $r; unset($r); } else {$__VAR_DUMP_MOD_skill961_VARS_r = NULL;} 
		//======== Start of contents from mod skill270 ========
		do{
			$___TMP_MOD_skill270_FUNC_calculate_active_obbs_multiplier_RET = NULL;

		
		$r = 1;
		if (\skillbase\skill_query(270,$ldata) && \skill270\check_unlocked270 ($ldata) && \skill270\check_skill270_proc ($ldata, $edata, 1)) {
			do { global $___LOCAL_SKILL270__VARS__skill270active,$___LOCAL_SKILL270__VARS__skill270hitrate; $skill270active=&$___LOCAL_SKILL270__VARS__skill270active; $skill270hitrate=&$___LOCAL_SKILL270__VARS__skill270hitrate;   } while (0);
			$r += $skill270active/100;
		}
		if($r != 1) $ldata['active_words'] = \attack\multiply_format($r, $ldata['active_words'],0);
if(isset($r)) {$__VAR_DUMP_MOD_skill270_VARS_r = $r; unset($r); } else {$__VAR_DUMP_MOD_skill270_VARS_r = NULL;} 
		//======== Start of contents from mod skill42 ========
		do{
			$___TMP_MOD_skill42_FUNC_calculate_active_obbs_multiplier_RET = NULL;

		
		$r = 1;
		if (\skillbase\skill_query(42,$ldata) && \skill42\check_unlocked42 ($ldata)) $r*=1.12;
		if (\skillbase\skill_query(42,$edata) && \skill42\check_unlocked42 ($edata)) $r/=1.12;
		if($r != 1) $ldata['active_words'] = \attack\multiply_format($r, $ldata['active_words'],0);
if(isset($r)) {$__VAR_DUMP_MOD_skill42_VARS_r = $r; unset($r); } else {$__VAR_DUMP_MOD_skill42_VARS_r = NULL;} 
		//======== Start of contents from mod skill502 ========
		do{
			$___TMP_MOD_skill502_FUNC_calculate_active_obbs_multiplier_RET = NULL;

		
		$r = 1;
		if (\skillbase\skill_query(502,$ldata) && \skill502\check_unlocked502 ($ldata)) {
			$r += \skill502\get_skill502_active_effect ($ldata)/100;
		}
		if (\skillbase\skill_query(502,$edata) && \skill502\check_unlocked502 ($edata)) {
			$r -= \skill502\get_skill502_active_effect ($edata)/100;
		}
		if($r != 1) $ldata['active_words'] = \attack\multiply_format($r, $ldata['active_words'],0);
if(isset($r)) {$__VAR_DUMP_MOD_skill502_VARS_r = $r; unset($r); } else {$__VAR_DUMP_MOD_skill502_VARS_r = NULL;} 
		//======== Start of contents from mod skill9 ========
		do{
			$___TMP_MOD_skill9_FUNC_calculate_active_obbs_multiplier_RET = NULL;

		
		$var = 1;
		if (\skillbase\skill_query(9,$ldata)) {
			$var = 0.8;
			$ldata['active_words'] = \attack\multiply_format($var, $ldata['active_words'],0);
		}
if(isset($var)) {$__VAR_DUMP_MOD_skill9_VARS_var = $var; unset($var); } else {$__VAR_DUMP_MOD_skill9_VARS_var = NULL;} 
		//======== Start of contents from mod skill8 ========
		do{
			$___TMP_MOD_skill8_FUNC_calculate_active_obbs_multiplier_RET = NULL;

		
		$var = 1;
		if (\skillbase\skill_query(8,$ldata)) {
			$var = 0.2;
			$ldata['active_words'] = \attack\multiply_format($var, $ldata['active_words'],0);
		}
if(isset($var)) {$__VAR_DUMP_MOD_skill8_VARS_var = $var; unset($var); } else {$__VAR_DUMP_MOD_skill8_VARS_var = NULL;} 
		//======== Start of contents from mod skill7 ========
		do{
			$___TMP_MOD_skill7_FUNC_calculate_active_obbs_multiplier_RET = NULL;

		
		$var = 1;
		if (\skillbase\skill_query(7,$ldata)) {
			$var = 0.9;
			$ldata['active_words'] = \attack\multiply_format($var, $ldata['active_words'],0);
		}
if(isset($var)) {$__VAR_DUMP_MOD_skill7_VARS_var = $var; unset($var); } else {$__VAR_DUMP_MOD_skill7_VARS_var = NULL;} 
		//======== Start of contents from mod skill95 ========
		do{
			$___TMP_MOD_skill95_FUNC_calculate_active_obbs_multiplier_RET = NULL;

		
		$r = 1;
		if (\skillbase\skill_query(95,$edata) && !$edata['type'] && (\skillbase\skill_getvalue(95, 'spid', $edata) == $ldata['pid'])) $r *= 1.3;
		if (\skillbase\skill_query(95,$ldata) && !$ldata['type'] && (\skillbase\skill_getvalue(95, 'spid', $ldata) == $edata['pid'])) $r /= 1.3;
		if($r != 1) $ldata['active_words'] = \attack\multiply_format($r, $ldata['active_words'],0);
if(isset($r)) {$__VAR_DUMP_MOD_skill95_VARS_r = $r; unset($r); } else {$__VAR_DUMP_MOD_skill95_VARS_r = NULL;} 
		//======== Start of contents from mod skill719 ========
		do{
			$___TMP_MOD_skill719_FUNC_calculate_active_obbs_multiplier_RET = NULL;

		
		$r = 1;
		if (\skillbase\skill_query(719, $ldata))
		{
			$skill719_count_a = (int)\skillbase\skill_getvalue(719, 'acount', $ldata);
			if ($skill719_count_a)
			{
				if (\skillbase\skill_getvalue(719, 'release', $ldata)) $r *= 1 + 0.015 * $skill719_count_a;
				else $r *= 1 - 0.015 * $skill719_count_a;
			}
		}
		if (\skillbase\skill_query(719, $edata))
		{
			$skill719_count_d = (int)\skillbase\skill_getvalue(719, 'acount', $edata);
			if ($skill719_count_d)
			{
				if (\skillbase\skill_getvalue(719, 'release', $edata)) $r *= 1 - 0.015 * $skill719_count_d;
				else $r *= 1 + 0.015 * $skill719_count_d;
			}
		}
if(isset($r)) {$__VAR_DUMP_MOD_skill719_VARS_r = $r; unset($r); } else {$__VAR_DUMP_MOD_skill719_VARS_r = NULL;} 
		//======== Start of contents from mod skill84 ========
		do{
			$___TMP_MOD_skill84_FUNC_calculate_active_obbs_multiplier_RET = NULL;

		
		$r = 1;
		if (\skill84\check_skill84_state ($ldata)) $r*=\skill84\get_skill84_effect ($ldata);
		if($r != 1) $ldata['active_words'] = \attack\multiply_format($r, $ldata['active_words'],0);
		if (\skill84\check_skill84_state ($edata)) $r/=\skill84\get_skill84_effect ($edata);
		if($r != 1) $ldata['active_words'] = \attack\multiply_format($r, $ldata['active_words'],0);
if(isset($r)) {$__VAR_DUMP_MOD_skill84_VARS_r = $r; unset($r); } else {$__VAR_DUMP_MOD_skill84_VARS_r = NULL;} 
		//======== Start of contents from mod skill240 ========
		do{
			$___TMP_MOD_skill240_FUNC_calculate_active_obbs_multiplier_RET = NULL;

		
		$r = 1;
		if (\skillbase\skill_query(240,$ldata) && \skill240\check_unlocked240 ($ldata)) $r*=1.08;
		if (\skillbase\skill_query(240,$edata) && \skill240\check_unlocked240 ($edata)) $r/=1.08;
		if($r != 1) $ldata['active_words'] = \attack\multiply_format($r, $ldata['active_words'],0);
		//======== Start of contents from mod skill211 ========
		do{
			$___TMP_MOD_skill211_FUNC_calculate_active_obbs_multiplier_RET = NULL;

		
		$var = 1;
		if (\skillbase\skill_query(211,$ldata) && \skill211\check_unlocked211 ($ldata)) {
			$var = \skill211\get_skill211_extra_act_gain ($ldata, $edata);
			if($var != 1) $ldata['active_words'] = \attack\multiply_format($var, $ldata['active_words'],0);
		}
		//======== Start of contents from mod enemy ========
		do{
			$___TMP_MOD_enemy_FUNC_calculate_active_obbs_multiplier_RET = NULL;

		
		$___TMP_MOD_enemy_FUNC_calculate_active_obbs_multiplier_RET =  1.0;
			break; 
		}while(0);
		//======== End of contents from mod enemy ========

		$___TMP_MOD_skill211_FUNC_calculate_active_obbs_multiplier_RET =  $___TMP_MOD_enemy_FUNC_calculate_active_obbs_multiplier_RET*$var;
			break; 
		}while(0);
		//======== End of contents from mod skill211 ========

		$___TMP_MOD_skill240_FUNC_calculate_active_obbs_multiplier_RET =  $___TMP_MOD_skill211_FUNC_calculate_active_obbs_multiplier_RET*$r;
			break; 
		}while(0);
		//======== End of contents from mod skill240 ========

$r = $__VAR_DUMP_MOD_skill84_VARS_r; 
		$___TMP_MOD_skill84_FUNC_calculate_active_obbs_multiplier_RET =  $___TMP_MOD_skill240_FUNC_calculate_active_obbs_multiplier_RET*$r;
			break; 
		}while(0);
		//======== End of contents from mod skill84 ========

$r = $__VAR_DUMP_MOD_skill719_VARS_r; 
		$___TMP_MOD_skill719_FUNC_calculate_active_obbs_multiplier_RET =  $___TMP_MOD_skill84_FUNC_calculate_active_obbs_multiplier_RET*$r;
			break; 
		}while(0);
		//======== End of contents from mod skill719 ========

$r = $__VAR_DUMP_MOD_skill95_VARS_r; 
		$___TMP_MOD_skill95_FUNC_calculate_active_obbs_multiplier_RET =  $___TMP_MOD_skill719_FUNC_calculate_active_obbs_multiplier_RET*$r;
			break; 
		}while(0);
		//======== End of contents from mod skill95 ========

$var = $__VAR_DUMP_MOD_skill7_VARS_var; 
		$___TMP_MOD_skill7_FUNC_calculate_active_obbs_multiplier_RET =  $___TMP_MOD_skill95_FUNC_calculate_active_obbs_multiplier_RET*$var;
			break; 
		}while(0);
		//======== End of contents from mod skill7 ========

$var = $__VAR_DUMP_MOD_skill8_VARS_var; 
		$___TMP_MOD_skill8_FUNC_calculate_active_obbs_multiplier_RET =  $___TMP_MOD_skill7_FUNC_calculate_active_obbs_multiplier_RET*$var;
			break; 
		}while(0);
		//======== End of contents from mod skill8 ========

$var = $__VAR_DUMP_MOD_skill9_VARS_var; 
		$___TMP_MOD_skill9_FUNC_calculate_active_obbs_multiplier_RET =  $___TMP_MOD_skill8_FUNC_calculate_active_obbs_multiplier_RET*$var;
			break; 
		}while(0);
		//======== End of contents from mod skill9 ========

$r = $__VAR_DUMP_MOD_skill502_VARS_r; 
		$___TMP_MOD_skill502_FUNC_calculate_active_obbs_multiplier_RET =  $___TMP_MOD_skill9_FUNC_calculate_active_obbs_multiplier_RET*$r;
			break; 
		}while(0);
		//======== End of contents from mod skill502 ========

$r = $__VAR_DUMP_MOD_skill42_VARS_r; 
		$___TMP_MOD_skill42_FUNC_calculate_active_obbs_multiplier_RET =  $___TMP_MOD_skill502_FUNC_calculate_active_obbs_multiplier_RET*$r;
			break; 
		}while(0);
		//======== End of contents from mod skill42 ========

$r = $__VAR_DUMP_MOD_skill270_VARS_r; 
		$___TMP_MOD_skill270_FUNC_calculate_active_obbs_multiplier_RET =  $___TMP_MOD_skill42_FUNC_calculate_active_obbs_multiplier_RET*$r;
			break; 
		}while(0);
		//======== End of contents from mod skill270 ========

$r = $__VAR_DUMP_MOD_skill961_VARS_r; 
		$___TMP_MOD_skill961_FUNC_calculate_active_obbs_multiplier_RET =  $___TMP_MOD_skill270_FUNC_calculate_active_obbs_multiplier_RET*$r;
			break; 
		}while(0);
		//======== End of contents from mod skill961 ========

$r = $__VAR_DUMP_MOD_skill96_VARS_r; 
		$___TMP_MOD_skill96_FUNC_calculate_active_obbs_multiplier_RET =  $___TMP_MOD_skill961_FUNC_calculate_active_obbs_multiplier_RET*$r;
			break; 
		}while(0);
		//======== End of contents from mod skill96 ========

$r = $__VAR_DUMP_MOD_skill248_VARS_r; 
		$___TMP_MOD_skill248_FUNC_calculate_active_obbs_multiplier_RET =  $___TMP_MOD_skill96_FUNC_calculate_active_obbs_multiplier_RET*$r;
			break; 
		}while(0);
		//======== End of contents from mod skill248 ========

$r = $__VAR_DUMP_MOD_skill50_VARS_r; 
		$___TMP_MOD_skill50_FUNC_calculate_active_obbs_multiplier_RET =  $___TMP_MOD_skill248_FUNC_calculate_active_obbs_multiplier_RET*$r;
			break; 
		}while(0);
		//======== End of contents from mod skill50 ========

$r = $__VAR_DUMP_MOD_skill108_VARS_r; 
		$___TMP_MOD_skill108_FUNC_calculate_active_obbs_multiplier_RET =  $___TMP_MOD_skill50_FUNC_calculate_active_obbs_multiplier_RET*$r;
			break; 
		}while(0);
		//======== End of contents from mod skill108 ========

$r = $__VAR_DUMP_MOD_skill604_VARS_r; 
		$___TMP_MOD_skill604_FUNC_calculate_active_obbs_multiplier_RET =  $___TMP_MOD_skill108_FUNC_calculate_active_obbs_multiplier_RET*$r;
			break; 
		}while(0);
		//======== End of contents from mod skill604 ========

$r = $__VAR_DUMP_MOD_skill903_VARS_r; 
		return $___TMP_MOD_skill604_FUNC_calculate_active_obbs_multiplier_RET*$r;
	
	}
	
	function get_hitrate_multiplier(&$pa, &$pd, $active)
	{
		return \skill265\get_hitrate_multiplier($pa,$pd,$active);
	}
	
}

?>