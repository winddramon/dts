<?php

namespace instance3
{		
	function init() {}
	
	function get_shopconfig(){
		return \instance10\get_shopconfig();
	}
	
	function get_itemfilecont(){
		return \instance10\get_itemfilecont();
	}
	
	function get_npclist(){
		return \instance10\get_npclist();
	}
	
	function checkcombo($time){
		return \instance10\checkcombo($time);
	}
	
	function rs_game($xmode = 0) 	
	{
		return \instance10\rs_game($xmode);
	}
	
	function rs_areatime(){
		return \instance10\rs_areatime();
	}
	
	function check_addarea_gameover($atime){
		return \instance10\check_addarea_gameover($atime);
	}
	
	
	function gameover($time = 0, $gmode = '', $winname = '') {
		
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;   } while (0);
		if ((13==$gametype) && ((($gmode=='') && ($alivenum==1)) || ($gmode=='end2'))) return;
if(isset($time)) {$__VAR_DUMP_MOD_instance3_VARS_time = $time; } else {$__VAR_DUMP_MOD_instance3_VARS_time = NULL;} if(isset($gmode)) {$__VAR_DUMP_MOD_instance3_VARS_gmode = $gmode; } else {$__VAR_DUMP_MOD_instance3_VARS_gmode = NULL;} if(isset($winname)) {$__VAR_DUMP_MOD_instance3_VARS_winname = $winname; } else {$__VAR_DUMP_MOD_instance3_VARS_winname = NULL;} 
		//======== Start of contents from mod skill331 ========
		do{
			$___TMP_MOD_skill331_FUNC_gameover_RET = NULL;

		
		
		if($gamestate < 5){ $___TMP_MOD_skill331_FUNC_gameover_RET = NULL;
			break; }
		if($gmode=='end3'){
			$pw=\player\fetch_playerdata($winname);
			if (\skillbase\skill_query(331,$pw)){
				do { global $___LOCAL_SKILL331__VARS__ach331_name,$___LOCAL_SKILL331__VARS__ach331_threshold,$___LOCAL_SKILL331__VARS__ach331_qiegao_prize,$___LOCAL_SKILL331__VARS__ach331_itemnum; $ach331_name=&$___LOCAL_SKILL331__VARS__ach331_name; $ach331_threshold=&$___LOCAL_SKILL331__VARS__ach331_threshold; $ach331_qiegao_prize=&$___LOCAL_SKILL331__VARS__ach331_qiegao_prize; $ach331_itemnum=&$___LOCAL_SKILL331__VARS__ach331_itemnum;   } while (0);
				$num331 = \skill330\check_itemnum330($pw);
				if($num331 >= $ach331_itemnum && $now - $starttime <= 1200){
					\skillbase\skill_setvalue(331,'cnt',1,$pw);
					\player\player_save($pw);
				}
			} 
		}
if(isset($time)) {$__VAR_DUMP_MOD_skill331_VARS_time = $time; } else {$__VAR_DUMP_MOD_skill331_VARS_time = NULL;} if(isset($gmode)) {$__VAR_DUMP_MOD_skill331_VARS_gmode = $gmode; } else {$__VAR_DUMP_MOD_skill331_VARS_gmode = NULL;} if(isset($winname)) {$__VAR_DUMP_MOD_skill331_VARS_winname = $winname; } else {$__VAR_DUMP_MOD_skill331_VARS_winname = NULL;} if(isset($pw)) {$__VAR_DUMP_MOD_skill331_VARS_pw = $pw; unset($pw); } else {$__VAR_DUMP_MOD_skill331_VARS_pw = NULL;} 
		//======== Start of contents from mod skill306 ========
		do{
			$___TMP_MOD_skill306_FUNC_gameover_RET = NULL;

		
		
		if($gamestate < 5){ $___TMP_MOD_skill306_FUNC_gameover_RET = NULL;
			break; }
		if($gmode=='end5'){
			$pw=\player\fetch_playerdata($winname);
			if (\skillbase\skill_query(306,$pw)){
				\skillbase\skill_setvalue(306,'cnt',1,$pw);
				\player\player_save($pw);
			} 
		}
if(isset($time)) {$__VAR_DUMP_MOD_skill306_VARS_time = $time; } else {$__VAR_DUMP_MOD_skill306_VARS_time = NULL;} if(isset($gmode)) {$__VAR_DUMP_MOD_skill306_VARS_gmode = $gmode; } else {$__VAR_DUMP_MOD_skill306_VARS_gmode = NULL;} if(isset($winname)) {$__VAR_DUMP_MOD_skill306_VARS_winname = $winname; } else {$__VAR_DUMP_MOD_skill306_VARS_winname = NULL;} if(isset($pw)) {$__VAR_DUMP_MOD_skill306_VARS_pw = $pw; unset($pw); } else {$__VAR_DUMP_MOD_skill306_VARS_pw = NULL;} 
		//======== Start of contents from mod skill305 ========
		do{
			$___TMP_MOD_skill305_FUNC_gameover_RET = NULL;

		
		
		if($gamestate < 5){ $___TMP_MOD_skill305_FUNC_gameover_RET = NULL;
			break; }
		if(((!$gmode)||(($gmode=='end2')&&(!$winname)))&&(!in_array($gametype,$teamwin_mode))){
			$result = $db->query("SELECT * FROM {$tablepre}players WHERE hp>0 AND type=0");
			$alivenum = $db->num_rows($result);
			if($alivenum == 1){
				$pw = $db->fetch_array($result);
				$wn=$pw['name'];
				$pw=\player\fetch_playerdata($wn);
				if (\skillbase\skill_query(305,$pw)){
					\skillbase\skill_setvalue(305,'cnt',1,$pw);
					\player\player_save($pw);
				} 
			}
		}
if(isset($time)) {$__VAR_DUMP_MOD_skill305_VARS_time = $time; } else {$__VAR_DUMP_MOD_skill305_VARS_time = NULL;} if(isset($gmode)) {$__VAR_DUMP_MOD_skill305_VARS_gmode = $gmode; } else {$__VAR_DUMP_MOD_skill305_VARS_gmode = NULL;} if(isset($winname)) {$__VAR_DUMP_MOD_skill305_VARS_winname = $winname; } else {$__VAR_DUMP_MOD_skill305_VARS_winname = NULL;} if(isset($result)) {$__VAR_DUMP_MOD_skill305_VARS_result = $result; unset($result); } else {$__VAR_DUMP_MOD_skill305_VARS_result = NULL;} 
		//======== Start of contents from mod sys ========
		do{
			$___TMP_MOD_sys_FUNC_gameover_RET = NULL;

		
		do { global $___LOCAL_PLAYER__VARS__ss,$___LOCAL_PLAYER__VARS__db_player_structure,$___LOCAL_PLAYER__VARS__db_player_structure_types,$___LOCAL_PLAYER__VARS__gamedata,$___LOCAL_PLAYER__VARS__cmd,$___LOCAL_PLAYER__VARS__main,$___LOCAL_PLAYER__VARS__sdata,$___LOCAL_PLAYER__VARS__fog,$___LOCAL_PLAYER__VARS__upexp,$___LOCAL_PLAYER__VARS__lvlupexp, $___LOCAL_PLAYER__VARS__iconImg,$___LOCAL_PLAYER__VARS__iconImgB,$___LOCAL_PLAYER__VARS__iconImgBwidth,$___LOCAL_PLAYER__VARS__ardef,$___LOCAL_PLAYER__VARS__hpcolor,$___LOCAL_PLAYER__VARS__spcolor,$___LOCAL_PLAYER__VARS__newhpimg,$___LOCAL_PLAYER__VARS__newspimg,$___LOCAL_PLAYER__VARS__splt,$___LOCAL_PLAYER__VARS__hplt, $___LOCAL_PLAYER__VARS__tpldata,$___LOCAL_PLAYER__VARS__icon_list,$___LOCAL_PLAYER__VARS__icon_list_contents_to_frontend,$___LOCAL_PLAYER__VARS__typeinfo,$___LOCAL_PLAYER__VARS__killmsginfo,$___LOCAL_PLAYER__VARS__lwinfo,$___LOCAL_PLAYER__VARS__sexinfo,$___LOCAL_PLAYER__VARS__equip_list,$___LOCAL_PLAYER__VARS__battle_equip_list,$___LOCAL_PLAYER__VARS__pc_icon_range, $___LOCAL_PLAYER__VARS__pid,$___LOCAL_PLAYER__VARS__type,$___LOCAL_PLAYER__VARS__name,$___LOCAL_PLAYER__VARS__pass,$___LOCAL_PLAYER__VARS__ip,$___LOCAL_PLAYER__VARS__motto,$___LOCAL_PLAYER__VARS__killmsg,$___LOCAL_PLAYER__VARS__lastword,$___LOCAL_PLAYER__VARS__winner_flag,$___LOCAL_PLAYER__VARS__player_dead_flag, $___LOCAL_PLAYER__VARS__corpse_clear_flag,$___LOCAL_PLAYER__VARS__gd,$___LOCAL_PLAYER__VARS__sNo,$___LOCAL_PLAYER__VARS__club,$___LOCAL_PLAYER__VARS__validtime,$___LOCAL_PLAYER__VARS__endtime,$___LOCAL_PLAYER__VARS__cdsec,$___LOCAL_PLAYER__VARS__cdmsec,$___LOCAL_PLAYER__VARS__cdtime,$___LOCAL_PLAYER__VARS__action, $___LOCAL_PLAYER__VARS__a_actionnum,$___LOCAL_PLAYER__VARS__v_actionnum,$___LOCAL_PLAYER__VARS__hp,$___LOCAL_PLAYER__VARS__mhp,$___LOCAL_PLAYER__VARS__sp,$___LOCAL_PLAYER__VARS__msp,$___LOCAL_PLAYER__VARS__mss,$___LOCAL_PLAYER__VARS__att,$___LOCAL_PLAYER__VARS__def,$___LOCAL_PLAYER__VARS__pls, $___LOCAL_PLAYER__VARS__lvl,$___LOCAL_PLAYER__VARS__exp,$___LOCAL_PLAYER__VARS__money,$___LOCAL_PLAYER__VARS__rp,$___LOCAL_PLAYER__VARS__bid,$___LOCAL_PLAYER__VARS__inf,$___LOCAL_PLAYER__VARS__rage,$___LOCAL_PLAYER__VARS__pose,$___LOCAL_PLAYER__VARS__tactic,$___LOCAL_PLAYER__VARS__killnum, $___LOCAL_PLAYER__VARS__npckillnum,$___LOCAL_PLAYER__VARS__state,$___LOCAL_PLAYER__VARS__skillpoint,$___LOCAL_PLAYER__VARS__flare,$___LOCAL_PLAYER__VARS__wp,$___LOCAL_PLAYER__VARS__wk,$___LOCAL_PLAYER__VARS__wg,$___LOCAL_PLAYER__VARS__wc,$___LOCAL_PLAYER__VARS__wd,$___LOCAL_PLAYER__VARS__wf, $___LOCAL_PLAYER__VARS__icon,$___LOCAL_PLAYER__VARS__teamID,$___LOCAL_PLAYER__VARS__teamPass,$___LOCAL_PLAYER__VARS__card,$___LOCAL_PLAYER__VARS__cardname,$___LOCAL_PLAYER__VARS__wep,$___LOCAL_PLAYER__VARS__wepk,$___LOCAL_PLAYER__VARS__wepe,$___LOCAL_PLAYER__VARS__weps,$___LOCAL_PLAYER__VARS__wepsk, $___LOCAL_PLAYER__VARS__arb,$___LOCAL_PLAYER__VARS__arbk,$___LOCAL_PLAYER__VARS__arbe,$___LOCAL_PLAYER__VARS__arbs,$___LOCAL_PLAYER__VARS__arbsk,$___LOCAL_PLAYER__VARS__arh,$___LOCAL_PLAYER__VARS__arhk,$___LOCAL_PLAYER__VARS__arhe,$___LOCAL_PLAYER__VARS__arhs,$___LOCAL_PLAYER__VARS__arhsk, $___LOCAL_PLAYER__VARS__ara,$___LOCAL_PLAYER__VARS__arak,$___LOCAL_PLAYER__VARS__arae,$___LOCAL_PLAYER__VARS__aras,$___LOCAL_PLAYER__VARS__arask,$___LOCAL_PLAYER__VARS__arf,$___LOCAL_PLAYER__VARS__arfk,$___LOCAL_PLAYER__VARS__arfe,$___LOCAL_PLAYER__VARS__arfs,$___LOCAL_PLAYER__VARS__arfsk, $___LOCAL_PLAYER__VARS__art,$___LOCAL_PLAYER__VARS__artk,$___LOCAL_PLAYER__VARS__arte,$___LOCAL_PLAYER__VARS__arts,$___LOCAL_PLAYER__VARS__artsk,$___LOCAL_PLAYER__VARS__itm0,$___LOCAL_PLAYER__VARS__itmk0,$___LOCAL_PLAYER__VARS__itme0,$___LOCAL_PLAYER__VARS__itms0,$___LOCAL_PLAYER__VARS__itmsk0, $___LOCAL_PLAYER__VARS__itm1,$___LOCAL_PLAYER__VARS__itmk1,$___LOCAL_PLAYER__VARS__itme1,$___LOCAL_PLAYER__VARS__itms1,$___LOCAL_PLAYER__VARS__itmsk1,$___LOCAL_PLAYER__VARS__itm2,$___LOCAL_PLAYER__VARS__itmk2,$___LOCAL_PLAYER__VARS__itme2,$___LOCAL_PLAYER__VARS__itms2,$___LOCAL_PLAYER__VARS__itmsk2, $___LOCAL_PLAYER__VARS__itm3,$___LOCAL_PLAYER__VARS__itmk3,$___LOCAL_PLAYER__VARS__itme3,$___LOCAL_PLAYER__VARS__itms3,$___LOCAL_PLAYER__VARS__itmsk3,$___LOCAL_PLAYER__VARS__itm4,$___LOCAL_PLAYER__VARS__itmk4,$___LOCAL_PLAYER__VARS__itme4,$___LOCAL_PLAYER__VARS__itms4,$___LOCAL_PLAYER__VARS__itmsk4, $___LOCAL_PLAYER__VARS__itm5,$___LOCAL_PLAYER__VARS__itmk5,$___LOCAL_PLAYER__VARS__itme5,$___LOCAL_PLAYER__VARS__itms5,$___LOCAL_PLAYER__VARS__itmsk5,$___LOCAL_PLAYER__VARS__itm6,$___LOCAL_PLAYER__VARS__itmk6,$___LOCAL_PLAYER__VARS__itme6,$___LOCAL_PLAYER__VARS__itms6,$___LOCAL_PLAYER__VARS__itmsk6, $___LOCAL_PLAYER__VARS__searchmemory,$___LOCAL_PLAYER__VARS__nskill,$___LOCAL_PLAYER__VARS__nskillpara; $ss=&$___LOCAL_PLAYER__VARS__ss; $db_player_structure=&$___LOCAL_PLAYER__VARS__db_player_structure; $db_player_structure_types=&$___LOCAL_PLAYER__VARS__db_player_structure_types; $gamedata=&$___LOCAL_PLAYER__VARS__gamedata; $cmd=&$___LOCAL_PLAYER__VARS__cmd; $main=&$___LOCAL_PLAYER__VARS__main; $sdata=&$___LOCAL_PLAYER__VARS__sdata; $fog=&$___LOCAL_PLAYER__VARS__fog; $upexp=&$___LOCAL_PLAYER__VARS__upexp; $lvlupexp=&$___LOCAL_PLAYER__VARS__lvlupexp;  $iconImg=&$___LOCAL_PLAYER__VARS__iconImg; $iconImgB=&$___LOCAL_PLAYER__VARS__iconImgB; $iconImgBwidth=&$___LOCAL_PLAYER__VARS__iconImgBwidth; $ardef=&$___LOCAL_PLAYER__VARS__ardef; $hpcolor=&$___LOCAL_PLAYER__VARS__hpcolor; $spcolor=&$___LOCAL_PLAYER__VARS__spcolor; $newhpimg=&$___LOCAL_PLAYER__VARS__newhpimg; $newspimg=&$___LOCAL_PLAYER__VARS__newspimg; $splt=&$___LOCAL_PLAYER__VARS__splt; $hplt=&$___LOCAL_PLAYER__VARS__hplt;  $tpldata=&$___LOCAL_PLAYER__VARS__tpldata; $icon_list=&$___LOCAL_PLAYER__VARS__icon_list; $icon_list_contents_to_frontend=&$___LOCAL_PLAYER__VARS__icon_list_contents_to_frontend; $typeinfo=&$___LOCAL_PLAYER__VARS__typeinfo; $killmsginfo=&$___LOCAL_PLAYER__VARS__killmsginfo; $lwinfo=&$___LOCAL_PLAYER__VARS__lwinfo; $sexinfo=&$___LOCAL_PLAYER__VARS__sexinfo; $equip_list=&$___LOCAL_PLAYER__VARS__equip_list; $battle_equip_list=&$___LOCAL_PLAYER__VARS__battle_equip_list; $pc_icon_range=&$___LOCAL_PLAYER__VARS__pc_icon_range;  $pid=&$___LOCAL_PLAYER__VARS__pid; $type=&$___LOCAL_PLAYER__VARS__type; $name=&$___LOCAL_PLAYER__VARS__name; $pass=&$___LOCAL_PLAYER__VARS__pass; $ip=&$___LOCAL_PLAYER__VARS__ip; $motto=&$___LOCAL_PLAYER__VARS__motto; $killmsg=&$___LOCAL_PLAYER__VARS__killmsg; $lastword=&$___LOCAL_PLAYER__VARS__lastword; $winner_flag=&$___LOCAL_PLAYER__VARS__winner_flag; $player_dead_flag=&$___LOCAL_PLAYER__VARS__player_dead_flag;  $corpse_clear_flag=&$___LOCAL_PLAYER__VARS__corpse_clear_flag; $gd=&$___LOCAL_PLAYER__VARS__gd; $sNo=&$___LOCAL_PLAYER__VARS__sNo; $club=&$___LOCAL_PLAYER__VARS__club; $validtime=&$___LOCAL_PLAYER__VARS__validtime; $endtime=&$___LOCAL_PLAYER__VARS__endtime; $cdsec=&$___LOCAL_PLAYER__VARS__cdsec; $cdmsec=&$___LOCAL_PLAYER__VARS__cdmsec; $cdtime=&$___LOCAL_PLAYER__VARS__cdtime; $action=&$___LOCAL_PLAYER__VARS__action;  $a_actionnum=&$___LOCAL_PLAYER__VARS__a_actionnum; $v_actionnum=&$___LOCAL_PLAYER__VARS__v_actionnum; $hp=&$___LOCAL_PLAYER__VARS__hp; $mhp=&$___LOCAL_PLAYER__VARS__mhp; $sp=&$___LOCAL_PLAYER__VARS__sp; $msp=&$___LOCAL_PLAYER__VARS__msp; $mss=&$___LOCAL_PLAYER__VARS__mss; $att=&$___LOCAL_PLAYER__VARS__att; $def=&$___LOCAL_PLAYER__VARS__def; $pls=&$___LOCAL_PLAYER__VARS__pls;  $lvl=&$___LOCAL_PLAYER__VARS__lvl; $exp=&$___LOCAL_PLAYER__VARS__exp; $money=&$___LOCAL_PLAYER__VARS__money; $rp=&$___LOCAL_PLAYER__VARS__rp; $bid=&$___LOCAL_PLAYER__VARS__bid; $inf=&$___LOCAL_PLAYER__VARS__inf; $rage=&$___LOCAL_PLAYER__VARS__rage; $pose=&$___LOCAL_PLAYER__VARS__pose; $tactic=&$___LOCAL_PLAYER__VARS__tactic; $killnum=&$___LOCAL_PLAYER__VARS__killnum;  $npckillnum=&$___LOCAL_PLAYER__VARS__npckillnum; $state=&$___LOCAL_PLAYER__VARS__state; $skillpoint=&$___LOCAL_PLAYER__VARS__skillpoint; $flare=&$___LOCAL_PLAYER__VARS__flare; $wp=&$___LOCAL_PLAYER__VARS__wp; $wk=&$___LOCAL_PLAYER__VARS__wk; $wg=&$___LOCAL_PLAYER__VARS__wg; $wc=&$___LOCAL_PLAYER__VARS__wc; $wd=&$___LOCAL_PLAYER__VARS__wd; $wf=&$___LOCAL_PLAYER__VARS__wf;  $icon=&$___LOCAL_PLAYER__VARS__icon; $teamID=&$___LOCAL_PLAYER__VARS__teamID; $teamPass=&$___LOCAL_PLAYER__VARS__teamPass; $card=&$___LOCAL_PLAYER__VARS__card; $cardname=&$___LOCAL_PLAYER__VARS__cardname; $wep=&$___LOCAL_PLAYER__VARS__wep; $wepk=&$___LOCAL_PLAYER__VARS__wepk; $wepe=&$___LOCAL_PLAYER__VARS__wepe; $weps=&$___LOCAL_PLAYER__VARS__weps; $wepsk=&$___LOCAL_PLAYER__VARS__wepsk;  $arb=&$___LOCAL_PLAYER__VARS__arb; $arbk=&$___LOCAL_PLAYER__VARS__arbk; $arbe=&$___LOCAL_PLAYER__VARS__arbe; $arbs=&$___LOCAL_PLAYER__VARS__arbs; $arbsk=&$___LOCAL_PLAYER__VARS__arbsk; $arh=&$___LOCAL_PLAYER__VARS__arh; $arhk=&$___LOCAL_PLAYER__VARS__arhk; $arhe=&$___LOCAL_PLAYER__VARS__arhe; $arhs=&$___LOCAL_PLAYER__VARS__arhs; $arhsk=&$___LOCAL_PLAYER__VARS__arhsk;  $ara=&$___LOCAL_PLAYER__VARS__ara; $arak=&$___LOCAL_PLAYER__VARS__arak; $arae=&$___LOCAL_PLAYER__VARS__arae; $aras=&$___LOCAL_PLAYER__VARS__aras; $arask=&$___LOCAL_PLAYER__VARS__arask; $arf=&$___LOCAL_PLAYER__VARS__arf; $arfk=&$___LOCAL_PLAYER__VARS__arfk; $arfe=&$___LOCAL_PLAYER__VARS__arfe; $arfs=&$___LOCAL_PLAYER__VARS__arfs; $arfsk=&$___LOCAL_PLAYER__VARS__arfsk;  $art=&$___LOCAL_PLAYER__VARS__art; $artk=&$___LOCAL_PLAYER__VARS__artk; $arte=&$___LOCAL_PLAYER__VARS__arte; $arts=&$___LOCAL_PLAYER__VARS__arts; $artsk=&$___LOCAL_PLAYER__VARS__artsk; $itm0=&$___LOCAL_PLAYER__VARS__itm0; $itmk0=&$___LOCAL_PLAYER__VARS__itmk0; $itme0=&$___LOCAL_PLAYER__VARS__itme0; $itms0=&$___LOCAL_PLAYER__VARS__itms0; $itmsk0=&$___LOCAL_PLAYER__VARS__itmsk0;  $itm1=&$___LOCAL_PLAYER__VARS__itm1; $itmk1=&$___LOCAL_PLAYER__VARS__itmk1; $itme1=&$___LOCAL_PLAYER__VARS__itme1; $itms1=&$___LOCAL_PLAYER__VARS__itms1; $itmsk1=&$___LOCAL_PLAYER__VARS__itmsk1; $itm2=&$___LOCAL_PLAYER__VARS__itm2; $itmk2=&$___LOCAL_PLAYER__VARS__itmk2; $itme2=&$___LOCAL_PLAYER__VARS__itme2; $itms2=&$___LOCAL_PLAYER__VARS__itms2; $itmsk2=&$___LOCAL_PLAYER__VARS__itmsk2;  $itm3=&$___LOCAL_PLAYER__VARS__itm3; $itmk3=&$___LOCAL_PLAYER__VARS__itmk3; $itme3=&$___LOCAL_PLAYER__VARS__itme3; $itms3=&$___LOCAL_PLAYER__VARS__itms3; $itmsk3=&$___LOCAL_PLAYER__VARS__itmsk3; $itm4=&$___LOCAL_PLAYER__VARS__itm4; $itmk4=&$___LOCAL_PLAYER__VARS__itmk4; $itme4=&$___LOCAL_PLAYER__VARS__itme4; $itms4=&$___LOCAL_PLAYER__VARS__itms4; $itmsk4=&$___LOCAL_PLAYER__VARS__itmsk4;  $itm5=&$___LOCAL_PLAYER__VARS__itm5; $itmk5=&$___LOCAL_PLAYER__VARS__itmk5; $itme5=&$___LOCAL_PLAYER__VARS__itme5; $itms5=&$___LOCAL_PLAYER__VARS__itms5; $itmsk5=&$___LOCAL_PLAYER__VARS__itmsk5; $itm6=&$___LOCAL_PLAYER__VARS__itm6; $itmk6=&$___LOCAL_PLAYER__VARS__itmk6; $itme6=&$___LOCAL_PLAYER__VARS__itme6; $itms6=&$___LOCAL_PLAYER__VARS__itms6; $itmsk6=&$___LOCAL_PLAYER__VARS__itmsk6;  $searchmemory=&$___LOCAL_PLAYER__VARS__searchmemory; $nskill=&$___LOCAL_PLAYER__VARS__nskill; $nskillpara=&$___LOCAL_PLAYER__VARS__nskillpara;   } while (0);

		
		\sys\process_lock ();
		\sys\load_gameinfo ();
		
		if($gamestate < 5){ $___TMP_MOD_sys_FUNC_gameover_RET = NULL;
			break; }

		
		$gamestate = 0;
		$gamevars['o_starttime'] = $starttime; $starttime = 0; 
		\sys\save_gameinfo ();
		$starttime = $gamevars['o_starttime'];
		
		
		$gameover_plist = $gameover_alivelist = array();
		$result = $db->query("SELECT name FROM {$tablepre}players WHERE type=0");
		while($r = $db->fetch_array($result)){
			if(!empty($sdata) && $r['pid'] == $sdata['pid']){
				$gameover_plist[$r['name']] = $sdata;
			}else{
				$gameover_plist[$r['name']] = \player\fetch_playerdata($r['name']);
			}
			if($gameover_plist[$r['name']]['hp'] > 0) $gameover_alivelist[$r['name']] = &$gameover_plist[$r['name']];
		}
		if(!empty($gameover_plist)) {
			$gameover_ulist = fetch_udata_multilist('*', array('username' => array_keys($gameover_plist)));
			if(empty($gameover_ulist)){ $___TMP_MOD_sys_FUNC_gameover_RET = NULL;
			break; } 
		}else{
			$gameover_ulist = array();
		}
		$validnum = count($gameover_plist);
		$alivenum = count($gameover_alivelist);
		
		
		if((!$gmode)||(($gmode=='end2')&&(!$winname))) {
			if($validnum <= 0) {
				$alivenum = 0;
				$winnum = 0;
				$winmode = 4;
				$winner = '';
			} else {
				if(!$alivenum) {
					$winmode = 1;
					$winnum = 0;
					$winner = '';
				} else {
					if (!in_array($gametype,$teamwin_mode))
					{
						
						if($alivenum == 1) {
							$winmode = 2;
							$winnum = 1;
							foreach($gameover_alivelist as &$wdata){ break;}
							$winner = $wdata['name'];
							$wdata['winner_flag'] = $winmode;
							\player\player_save($wdata);
						} 
						else
						{	
							\sys\save_gameinfo ();
							$___TMP_MOD_sys_FUNC_gameover_RET = NULL;
			break; 
						}
					}
					else
					{
						$flag=1; $first=1; $firstteamID = '';
						foreach($gameover_alivelist as $ai => $data){
							if($first) {
								$first=0;
								$firstteamID=$data['teamID'];
							}elseif($firstteamID!=$data['teamID'] || !$data['teamID']){
								
								$flag=0; break;
							}
						}
						if ($flag && !$first)
						{
							if (!$firstteamID)	
							{	
								foreach($gameover_alivelist as &$wdata){ break;}
								$wdata['winner_flag'] = 2;
								\player\player_save($wdata);
								$winnum = 1;
								$winner = $wdata['name'];
							}
							else				
							{
								$teammatelist = array();
								foreach($gameover_plist as &$wdata){
									if($wdata['teamID'] == $firstteamID){
										$wdata['winner_flag'] = 2; 
										$teammatelist[] = $wdata['name'];
									}
								}
								$db->query("UPDATE {$tablepre}players SET winner_flag='2' WHERE type = 0 AND teamID = '$firstteamID'");
								
								$winnum=count($teammatelist);
								if ($winnum == 1)
								{
									$winner = $teammatelist[0];
								}elseif($winnum > 1){
									$winner = $namelist = implode(',',$teammatelist);
								}
							}
							
						}
						else
						{	
							\sys\save_gameinfo ();
							$___TMP_MOD_sys_FUNC_gameover_RET = NULL;
			break; 
						}
						$winmode = 2;
					}
				}
			}
		} else {
			$winmode = substr($gmode,3,1);
			$winnum = 1;
			$winner = $winname;
		}
		
		if(1==$winmode) {
			$db->query("UPDATE {$tablepre}players SET hp=0 AND state=11 WHERE type=0 AND hp>0");
		}
		
		
		\sys\post_winnercheck_events ($winner);		
		

		
		$time = !empty($time) ? $time : $now;
		
		$result = $db->query("SELECT gid FROM {$wtablepre}history ORDER BY gid DESC LIMIT 1");
		if($db->num_rows($result)&&($gamenum <= $db->result($result, 0))) {
			$gamenum = $db->result($result, 0) + 1;
		}
		$winnerdata = array(
			'gid' => $gamenum,
			'gametype' => $gametype,
			'wmode' => $winmode,
			'vnum' => $validnum,
			'gstime' => $starttime,
			'getime' => $time,
			'gtime' => $time - $starttime,
		);
		if(!in_array($winmode, array(0, 4))){
			$winnerdata['hdmg'] = $hdamage;
			$winnerdata['hdp'] = $hplayer;
			$result = $db->query("SELECT name,killnum FROM {$tablepre}players WHERE type=0 order by killnum desc, lvl desc limit 1");
			$hk = $db->fetch_array($result);
			$winnerdata['hkill'] = $hk['killnum'];
			$winnerdata['hkp'] = $hk['name'];
			$winnerdata['validlist'] = gencode($gameover_plist);
		}
		if(!in_array($winmode, array(0, 1, 4, 6))){
			$winnerdata['winner'] = $winner;
			$winnerdata['winnernum'] = $winnum;
			if ($winnum == 1){
				$winnerdata['winnerpdata'] = gencode($gameover_plist[$winner]);
			}else{
				
				$winnerdata['winnerteamID'] = $firstteamID;
				$winnerdata['winnerlist'] = $namelist;
			}
		}
		
		$db->array_insert("{$wtablepre}history", $winnerdata);
		
		$insert_gid = $gamenum;

		
		\sys\gameover_set_credits ();

		
		\sys\rs_sttime ();
		
		

		\sys\post_gameover_events ();

		
		
		
		$updatelist = $gameover_ulist;
		foreach($updatelist as &$gv){
			foreach (array_keys($gv) as $fv){
				if(!in_array($fv, \sys\get_gameover_udata_update_fields ()))
					unset($gv[$fv]);
			}
		}
		update_udata_multilist($updatelist);
		
		
		\sys\addnews ($time, "end$winmode",$winner);
		\sys\addnews ($time, 'gameover' ,$gamenum);
		\sys\systemputchat ($time,'gameover');
		$newsinfo = \sys\load_news ();
		$newsinfo = '<ul>'.implode('',$newsinfo).'</ul>';

		$newsinfo = gencode($newsinfo);
		if($hnewsstorage) 
		{
			$offset = 1024*1024-200;
			do{
				if($offset < strlen($newsinfo)){
					$tmp_newsinfo = substr($newsinfo, 0, $offset);
					$newsinfo = substr($newsinfo, $offset);
				}else{
					$tmp_newsinfo = $newsinfo;
					$newsinfo = '';
				}
				$db->query("UPDATE {$wtablepre}history SET hnews=CONCAT(hnews, '$tmp_newsinfo') WHERE gid='$insert_gid'");
			} while (!empty($newsinfo));
		}
		else
		{
			$room_gprefix = '';
			if (room_check_subroom($room_prefix)) $room_gprefix = (substr($room_prefix,0,1)).'.';
			writeover(GAME_ROOT."./gamedata/bak/{$room_gprefix}{$gamenum}_newsinfo.dat",$newsinfo,'wb+');
		}
		
		\sys\process_unlock ();
		

		$___TMP_MOD_sys_FUNC_gameover_RET = NULL;
			break; 
		}while(0);
		//======== End of contents from mod sys ========

$time = $__VAR_DUMP_MOD_skill305_VARS_time; unset($__VAR_DUMP_MOD_skill305_VARS_time);$gmode = $__VAR_DUMP_MOD_skill305_VARS_gmode; unset($__VAR_DUMP_MOD_skill305_VARS_gmode);$winname = $__VAR_DUMP_MOD_skill305_VARS_winname; unset($__VAR_DUMP_MOD_skill305_VARS_winname);$result = $__VAR_DUMP_MOD_skill305_VARS_result; 
		$___TMP_MOD_sys_FUNC_gameover_RET;
		}while(0);
		//======== End of contents from mod skill305 ========

$time = $__VAR_DUMP_MOD_skill306_VARS_time; unset($__VAR_DUMP_MOD_skill306_VARS_time);$gmode = $__VAR_DUMP_MOD_skill306_VARS_gmode; unset($__VAR_DUMP_MOD_skill306_VARS_gmode);$winname = $__VAR_DUMP_MOD_skill306_VARS_winname; unset($__VAR_DUMP_MOD_skill306_VARS_winname);$pw = $__VAR_DUMP_MOD_skill306_VARS_pw; 
		$___TMP_MOD_skill305_FUNC_gameover_RET;
		}while(0);
		//======== End of contents from mod skill306 ========

$time = $__VAR_DUMP_MOD_skill331_VARS_time; unset($__VAR_DUMP_MOD_skill331_VARS_time);$gmode = $__VAR_DUMP_MOD_skill331_VARS_gmode; unset($__VAR_DUMP_MOD_skill331_VARS_gmode);$winname = $__VAR_DUMP_MOD_skill331_VARS_winname; unset($__VAR_DUMP_MOD_skill331_VARS_winname);$pw = $__VAR_DUMP_MOD_skill331_VARS_pw; 
		$___TMP_MOD_skill306_FUNC_gameover_RET;
		}while(0);
		//======== End of contents from mod skill331 ========

$time = $__VAR_DUMP_MOD_instance3_VARS_time; unset($__VAR_DUMP_MOD_instance3_VARS_time);$gmode = $__VAR_DUMP_MOD_instance3_VARS_gmode; unset($__VAR_DUMP_MOD_instance3_VARS_gmode);$winname = $__VAR_DUMP_MOD_instance3_VARS_winname; unset($__VAR_DUMP_MOD_instance3_VARS_winname);
		$___TMP_MOD_skill331_FUNC_gameover_RET;
	
	}
	
	function init_enter_battlefield_items($ebp)
	{
		return \instance10\init_enter_battlefield_items($ebp);
	}
	
	
	function get_enter_battlefield_card($card){
		return \instance10\get_enter_battlefield_card($card);
	}
	
	
	function enter_battlefield_cardproc($ebp, $card)
	{
		
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;   } while (0);
if(isset($ebp)) {$__VAR_DUMP_MOD_instance3_VARS_ebp = $ebp; } else {$__VAR_DUMP_MOD_instance3_VARS_ebp = NULL;} if(isset($card)) {$__VAR_DUMP_MOD_instance3_VARS_card = $card; } else {$__VAR_DUMP_MOD_instance3_VARS_card = NULL;} 
		//======== Start of contents from mod skill720 ========
		do{
			$___TMP_MOD_skill720_FUNC_enter_battlefield_cardproc_RET = NULL;

		
		$ebp_temp = $ebp;
if(isset($ebp)) {$__VAR_DUMP_MOD_skill720_VARS_ebp = $ebp; } else {$__VAR_DUMP_MOD_skill720_VARS_ebp = NULL;} if(isset($card)) {$__VAR_DUMP_MOD_skill720_VARS_card = $card; } else {$__VAR_DUMP_MOD_skill720_VARS_card = NULL;} 
		//======== Start of contents from mod skill584 ========
		do{
			$___TMP_MOD_skill584_FUNC_enter_battlefield_cardproc_RET = NULL;

		
		do { global $___LOCAL_CARDBASE__VARS__card_config_file,$___LOCAL_CARDBASE__VARS__card_main_file,$___LOCAL_CARDBASE__VARS__card_index_file,$___LOCAL_CARDBASE__VARS__card_force_different_gtype,$___LOCAL_CARDBASE__VARS__card_need_charge_gtype,$___LOCAL_CARDBASE__VARS__card_cooldown_discount_gtype,$___LOCAL_CARDBASE__VARS__cardtypecd,$___LOCAL_CARDBASE__VARS__card_recrate_base,$___LOCAL_CARDBASE__VARS__packlist,$___LOCAL_CARDBASE__VARS__packdesc, $___LOCAL_CARDBASE__VARS__pack_ignore_kuji,$___LOCAL_CARDBASE__VARS__packstart,$___LOCAL_CARDBASE__VARS__packicon,$___LOCAL_CARDBASE__VARS__cardindex,$___LOCAL_CARDBASE__VARS__card_rarecolor,$___LOCAL_CARDBASE__VARS__card_rarity_html,$___LOCAL_CARDBASE__VARS__card_blink_rate_20,$___LOCAL_CARDBASE__VARS__card_blink_rate_10,$___LOCAL_CARDBASE__VARS__card_price,$___LOCAL_CARDBASE__VARS__card_price_blink_rate, $___LOCAL_CARDBASE__VARS__cards,$___LOCAL_CARDBASE__VARS__cardindex_reverse; $card_config_file=&$___LOCAL_CARDBASE__VARS__card_config_file; $card_main_file=&$___LOCAL_CARDBASE__VARS__card_main_file; $card_index_file=&$___LOCAL_CARDBASE__VARS__card_index_file; $card_force_different_gtype=&$___LOCAL_CARDBASE__VARS__card_force_different_gtype; $card_need_charge_gtype=&$___LOCAL_CARDBASE__VARS__card_need_charge_gtype; $card_cooldown_discount_gtype=&$___LOCAL_CARDBASE__VARS__card_cooldown_discount_gtype; $cardtypecd=&$___LOCAL_CARDBASE__VARS__cardtypecd; $card_recrate_base=&$___LOCAL_CARDBASE__VARS__card_recrate_base; $packlist=&$___LOCAL_CARDBASE__VARS__packlist; $packdesc=&$___LOCAL_CARDBASE__VARS__packdesc;  $pack_ignore_kuji=&$___LOCAL_CARDBASE__VARS__pack_ignore_kuji; $packstart=&$___LOCAL_CARDBASE__VARS__packstart; $packicon=&$___LOCAL_CARDBASE__VARS__packicon; $cardindex=&$___LOCAL_CARDBASE__VARS__cardindex; $card_rarecolor=&$___LOCAL_CARDBASE__VARS__card_rarecolor; $card_rarity_html=&$___LOCAL_CARDBASE__VARS__card_rarity_html; $card_blink_rate_20=&$___LOCAL_CARDBASE__VARS__card_blink_rate_20; $card_blink_rate_10=&$___LOCAL_CARDBASE__VARS__card_blink_rate_10; $card_price=&$___LOCAL_CARDBASE__VARS__card_price; $card_price_blink_rate=&$___LOCAL_CARDBASE__VARS__card_price_blink_rate;  $cards=&$___LOCAL_CARDBASE__VARS__cards; $cardindex_reverse=&$___LOCAL_CARDBASE__VARS__cardindex_reverse;   } while (0);
if(isset($ebp)) {$__VAR_DUMP_MOD_skill584_VARS_ebp = $ebp; } else {$__VAR_DUMP_MOD_skill584_VARS_ebp = NULL;} if(isset($card)) {$__VAR_DUMP_MOD_skill584_VARS_card = $card; } else {$__VAR_DUMP_MOD_skill584_VARS_card = NULL;} 
		//======== Start of contents from mod cardbase ========
		do{
			$___TMP_MOD_cardbase_FUNC_enter_battlefield_cardproc_RET = NULL;

		
		do { global $___LOCAL_CARDBASE__VARS__card_config_file,$___LOCAL_CARDBASE__VARS__card_main_file,$___LOCAL_CARDBASE__VARS__card_index_file,$___LOCAL_CARDBASE__VARS__card_force_different_gtype,$___LOCAL_CARDBASE__VARS__card_need_charge_gtype,$___LOCAL_CARDBASE__VARS__card_cooldown_discount_gtype,$___LOCAL_CARDBASE__VARS__cardtypecd,$___LOCAL_CARDBASE__VARS__card_recrate_base,$___LOCAL_CARDBASE__VARS__packlist,$___LOCAL_CARDBASE__VARS__packdesc, $___LOCAL_CARDBASE__VARS__pack_ignore_kuji,$___LOCAL_CARDBASE__VARS__packstart,$___LOCAL_CARDBASE__VARS__packicon,$___LOCAL_CARDBASE__VARS__cardindex,$___LOCAL_CARDBASE__VARS__card_rarecolor,$___LOCAL_CARDBASE__VARS__card_rarity_html,$___LOCAL_CARDBASE__VARS__card_blink_rate_20,$___LOCAL_CARDBASE__VARS__card_blink_rate_10,$___LOCAL_CARDBASE__VARS__card_price,$___LOCAL_CARDBASE__VARS__card_price_blink_rate, $___LOCAL_CARDBASE__VARS__cards,$___LOCAL_CARDBASE__VARS__cardindex_reverse; $card_config_file=&$___LOCAL_CARDBASE__VARS__card_config_file; $card_main_file=&$___LOCAL_CARDBASE__VARS__card_main_file; $card_index_file=&$___LOCAL_CARDBASE__VARS__card_index_file; $card_force_different_gtype=&$___LOCAL_CARDBASE__VARS__card_force_different_gtype; $card_need_charge_gtype=&$___LOCAL_CARDBASE__VARS__card_need_charge_gtype; $card_cooldown_discount_gtype=&$___LOCAL_CARDBASE__VARS__card_cooldown_discount_gtype; $cardtypecd=&$___LOCAL_CARDBASE__VARS__cardtypecd; $card_recrate_base=&$___LOCAL_CARDBASE__VARS__card_recrate_base; $packlist=&$___LOCAL_CARDBASE__VARS__packlist; $packdesc=&$___LOCAL_CARDBASE__VARS__packdesc;  $pack_ignore_kuji=&$___LOCAL_CARDBASE__VARS__pack_ignore_kuji; $packstart=&$___LOCAL_CARDBASE__VARS__packstart; $packicon=&$___LOCAL_CARDBASE__VARS__packicon; $cardindex=&$___LOCAL_CARDBASE__VARS__cardindex; $card_rarecolor=&$___LOCAL_CARDBASE__VARS__card_rarecolor; $card_rarity_html=&$___LOCAL_CARDBASE__VARS__card_rarity_html; $card_blink_rate_20=&$___LOCAL_CARDBASE__VARS__card_blink_rate_20; $card_blink_rate_10=&$___LOCAL_CARDBASE__VARS__card_blink_rate_10; $card_price=&$___LOCAL_CARDBASE__VARS__card_price; $card_price_blink_rate=&$___LOCAL_CARDBASE__VARS__card_price_blink_rate;  $cards=&$___LOCAL_CARDBASE__VARS__cards; $cardindex_reverse=&$___LOCAL_CARDBASE__VARS__cardindex_reverse;   } while (0);
		
		
		if(!empty($cards[$card]['valid']['cardchange'])){
			if(empty($cards[$card]['valid']['cardchange']['perm_change'])) $ebp['o_card'] = $card;
			$card = \cardbase\cardchange ($card);
			
			
			if(empty($cards[$card])) {
				$card = 0;				
			}
		}
		
		
		$card_valid_info = $cards[$card]['valid'];
	
		$cardname = $newscardname = $cards[$card]['name'];
		$cardrare = $newscardrare = $cards[$card]['rare'];
		
		if(!empty($cards[$card]['title'])) $cardname = $cards[$card]['title'];
		
		
		if(!empty($ebp['o_card'])) {
			$newscardname=$cards[$ebp['o_card']]['name'];
			$newscardrare=$cards[$ebp['o_card']]['rare'];
		}
		
		$prefix = '<span class="'.$card_rarecolor[$newscardrare].'">'.$newscardname.'</span> ';
		
		
		
		
		$skills = Array();
		list($ebp, $skills) = \cardbase\card_valid_info_process ($card_valid_info, $ebp, $skills);
		
		$ebp['card'] = $card;
		$ebp['cardname'] = $cardname;
		
		$___TMP_MOD_cardbase_FUNC_enter_battlefield_cardproc_RET =  Array($ebp, $skills, $prefix);
			break; 
		}while(0);
		//======== End of contents from mod cardbase ========

$ebp = $__VAR_DUMP_MOD_skill584_VARS_ebp; unset($__VAR_DUMP_MOD_skill584_VARS_ebp);$card = $__VAR_DUMP_MOD_skill584_VARS_card; unset($__VAR_DUMP_MOD_skill584_VARS_card);
		$ret = $___TMP_MOD_cardbase_FUNC_enter_battlefield_cardproc_RET;
		if ($card == 344){ $___TMP_MOD_skill584_FUNC_enter_battlefield_cardproc_RET =  \skill584\skill584_add_flag ($ret);
			break; }
		else{ $___TMP_MOD_skill584_FUNC_enter_battlefield_cardproc_RET =  $ret;
			break; }
		}while(0);
		//======== End of contents from mod skill584 ========

$ebp = $__VAR_DUMP_MOD_skill720_VARS_ebp; unset($__VAR_DUMP_MOD_skill720_VARS_ebp);$card = $__VAR_DUMP_MOD_skill720_VARS_card; unset($__VAR_DUMP_MOD_skill720_VARS_card);
		$ret = $___TMP_MOD_skill584_FUNC_enter_battlefield_cardproc_RET;
		if ($card == 381){ $___TMP_MOD_skill720_FUNC_enter_battlefield_cardproc_RET =  \skill720\skill720_proc ($ret, $ebp_temp);
			break; }
		$___TMP_MOD_skill720_FUNC_enter_battlefield_cardproc_RET =  $ret;
			break; 
		}while(0);
		//======== End of contents from mod skill720 ========

$ebp = $__VAR_DUMP_MOD_instance3_VARS_ebp; unset($__VAR_DUMP_MOD_instance3_VARS_ebp);$card = $__VAR_DUMP_MOD_instance3_VARS_card; unset($__VAR_DUMP_MOD_instance3_VARS_card);
		$ret = $___TMP_MOD_skill720_FUNC_enter_battlefield_cardproc_RET;
		if(13==$gametype){
			$option = $roomvars['current_game_option'];
			if(isset($option['lvl']))
			{
				$alvl = (int)$option['lvl'];
				$ret = \instance3\instance3_add_skills ($ret, $alvl);
				if ($alvl >= 4)
				{
					$ret[0]['msp'] -= 200;
					$ret[0]['sp'] -= 200;
					if ($alvl >= 8)
					{
						$ret[0]['mhp'] -= 100;
						$ret[0]['hp'] -= 100;
					}
					elseif ($alvl >= 5)
					{
						$ret[0]['mhp'] -= 50;
						$ret[0]['hp'] -= 50;
					}
				}
			}
		}
		return $ret;
	
	}
	
	function instance3_add_skills($proc, $alvl)
	{
		
		
		if ($alvl >= 9) $proc[1][474] = '0';
		
		if ($alvl >= 26) $proc[1][901] = '5';
		elseif ($alvl >= 13) $proc[1][901] = '4';
		elseif ($alvl >= 12) $proc[1][901] = '3';
		elseif ($alvl >= 7) $proc[1][901] = '2';
		elseif ($alvl >= 1) $proc[1][901] = '1';
		
		if ($alvl >= 25) $proc[1][902] = '4';
		elseif ($alvl >= 15) $proc[1][902] = '3';
		elseif ($alvl >= 3) $proc[1][902] = '2';
		elseif ($alvl >= 2) $proc[1][902] = '1';
		
		if ($alvl >= 30) $proc[1][903] = '5';
		elseif ($alvl >= 29) $proc[1][903] = '4';
		elseif ($alvl >= 28) $proc[1][903] = '3';
		elseif ($alvl >= 27) $proc[1][903] = '2';
		elseif ($alvl >= 6) $proc[1][903] = '1';
		
		if ($alvl >= 21) $proc[1][904] = '3';
		elseif ($alvl >= 19) $proc[1][904] = '2';
		elseif ($alvl >= 10) $proc[1][904] = '1';
		
		if ($alvl >= 24) $proc[1][905] = '3';
		elseif ($alvl >= 17) $proc[1][905] = '2';
		elseif ($alvl >= 11) $proc[1][905] = '1';
		
		if ($alvl >= 18) $proc[1][906] = '2';
		elseif ($alvl >= 16) $proc[1][906] = '1';
		
		if ($alvl >= 23) $proc[1][907] = '0';
		return $proc;
	}
	
	
	function post_enterbattlefield_events(&$pa)
	{
		return \skill714\post_enterbattlefield_events($pa);
	}
	
	function itemuse(&$theitem) 
	{
		$___TEMP_backtrace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 2); 
		array_shift($___TEMP_backtrace);
		if (count($___TEMP_backtrace)==0) $___TEMP_PARENT_NAME=''; else $___TEMP_PARENT_NAME=strtolower($___TEMP_backtrace[0]['function']);
		if ($___TEMP_PARENT_NAME!='ex_alternative\itemuse') 
		{
			return \instance10\itemuse($theitem);
		}
		unset($___TEMP_PARENT_NAME); unset($___TEMP_backtrace); 
	
		
		
		
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;  global $___LOCAL_PLAYER__VARS__ss,$___LOCAL_PLAYER__VARS__db_player_structure,$___LOCAL_PLAYER__VARS__db_player_structure_types,$___LOCAL_PLAYER__VARS__gamedata,$___LOCAL_PLAYER__VARS__cmd,$___LOCAL_PLAYER__VARS__main,$___LOCAL_PLAYER__VARS__sdata,$___LOCAL_PLAYER__VARS__fog,$___LOCAL_PLAYER__VARS__upexp,$___LOCAL_PLAYER__VARS__lvlupexp, $___LOCAL_PLAYER__VARS__iconImg,$___LOCAL_PLAYER__VARS__iconImgB,$___LOCAL_PLAYER__VARS__iconImgBwidth,$___LOCAL_PLAYER__VARS__ardef,$___LOCAL_PLAYER__VARS__hpcolor,$___LOCAL_PLAYER__VARS__spcolor,$___LOCAL_PLAYER__VARS__newhpimg,$___LOCAL_PLAYER__VARS__newspimg,$___LOCAL_PLAYER__VARS__splt,$___LOCAL_PLAYER__VARS__hplt, $___LOCAL_PLAYER__VARS__tpldata,$___LOCAL_PLAYER__VARS__icon_list,$___LOCAL_PLAYER__VARS__icon_list_contents_to_frontend,$___LOCAL_PLAYER__VARS__typeinfo,$___LOCAL_PLAYER__VARS__killmsginfo,$___LOCAL_PLAYER__VARS__lwinfo,$___LOCAL_PLAYER__VARS__sexinfo,$___LOCAL_PLAYER__VARS__equip_list,$___LOCAL_PLAYER__VARS__battle_equip_list,$___LOCAL_PLAYER__VARS__pc_icon_range, $___LOCAL_PLAYER__VARS__pid,$___LOCAL_PLAYER__VARS__type,$___LOCAL_PLAYER__VARS__name,$___LOCAL_PLAYER__VARS__pass,$___LOCAL_PLAYER__VARS__ip,$___LOCAL_PLAYER__VARS__motto,$___LOCAL_PLAYER__VARS__killmsg,$___LOCAL_PLAYER__VARS__lastword,$___LOCAL_PLAYER__VARS__winner_flag,$___LOCAL_PLAYER__VARS__player_dead_flag, $___LOCAL_PLAYER__VARS__corpse_clear_flag,$___LOCAL_PLAYER__VARS__gd,$___LOCAL_PLAYER__VARS__sNo,$___LOCAL_PLAYER__VARS__club,$___LOCAL_PLAYER__VARS__validtime,$___LOCAL_PLAYER__VARS__endtime,$___LOCAL_PLAYER__VARS__cdsec,$___LOCAL_PLAYER__VARS__cdmsec,$___LOCAL_PLAYER__VARS__cdtime,$___LOCAL_PLAYER__VARS__action, $___LOCAL_PLAYER__VARS__a_actionnum,$___LOCAL_PLAYER__VARS__v_actionnum,$___LOCAL_PLAYER__VARS__hp,$___LOCAL_PLAYER__VARS__mhp,$___LOCAL_PLAYER__VARS__sp,$___LOCAL_PLAYER__VARS__msp,$___LOCAL_PLAYER__VARS__mss,$___LOCAL_PLAYER__VARS__att,$___LOCAL_PLAYER__VARS__def,$___LOCAL_PLAYER__VARS__pls, $___LOCAL_PLAYER__VARS__lvl,$___LOCAL_PLAYER__VARS__exp,$___LOCAL_PLAYER__VARS__money,$___LOCAL_PLAYER__VARS__rp,$___LOCAL_PLAYER__VARS__bid,$___LOCAL_PLAYER__VARS__inf,$___LOCAL_PLAYER__VARS__rage,$___LOCAL_PLAYER__VARS__pose,$___LOCAL_PLAYER__VARS__tactic,$___LOCAL_PLAYER__VARS__killnum, $___LOCAL_PLAYER__VARS__npckillnum,$___LOCAL_PLAYER__VARS__state,$___LOCAL_PLAYER__VARS__skillpoint,$___LOCAL_PLAYER__VARS__flare,$___LOCAL_PLAYER__VARS__wp,$___LOCAL_PLAYER__VARS__wk,$___LOCAL_PLAYER__VARS__wg,$___LOCAL_PLAYER__VARS__wc,$___LOCAL_PLAYER__VARS__wd,$___LOCAL_PLAYER__VARS__wf, $___LOCAL_PLAYER__VARS__icon,$___LOCAL_PLAYER__VARS__teamID,$___LOCAL_PLAYER__VARS__teamPass,$___LOCAL_PLAYER__VARS__card,$___LOCAL_PLAYER__VARS__cardname,$___LOCAL_PLAYER__VARS__wep,$___LOCAL_PLAYER__VARS__wepk,$___LOCAL_PLAYER__VARS__wepe,$___LOCAL_PLAYER__VARS__weps,$___LOCAL_PLAYER__VARS__wepsk, $___LOCAL_PLAYER__VARS__arb,$___LOCAL_PLAYER__VARS__arbk,$___LOCAL_PLAYER__VARS__arbe,$___LOCAL_PLAYER__VARS__arbs,$___LOCAL_PLAYER__VARS__arbsk,$___LOCAL_PLAYER__VARS__arh,$___LOCAL_PLAYER__VARS__arhk,$___LOCAL_PLAYER__VARS__arhe,$___LOCAL_PLAYER__VARS__arhs,$___LOCAL_PLAYER__VARS__arhsk, $___LOCAL_PLAYER__VARS__ara,$___LOCAL_PLAYER__VARS__arak,$___LOCAL_PLAYER__VARS__arae,$___LOCAL_PLAYER__VARS__aras,$___LOCAL_PLAYER__VARS__arask,$___LOCAL_PLAYER__VARS__arf,$___LOCAL_PLAYER__VARS__arfk,$___LOCAL_PLAYER__VARS__arfe,$___LOCAL_PLAYER__VARS__arfs,$___LOCAL_PLAYER__VARS__arfsk, $___LOCAL_PLAYER__VARS__art,$___LOCAL_PLAYER__VARS__artk,$___LOCAL_PLAYER__VARS__arte,$___LOCAL_PLAYER__VARS__arts,$___LOCAL_PLAYER__VARS__artsk,$___LOCAL_PLAYER__VARS__itm0,$___LOCAL_PLAYER__VARS__itmk0,$___LOCAL_PLAYER__VARS__itme0,$___LOCAL_PLAYER__VARS__itms0,$___LOCAL_PLAYER__VARS__itmsk0, $___LOCAL_PLAYER__VARS__itm1,$___LOCAL_PLAYER__VARS__itmk1,$___LOCAL_PLAYER__VARS__itme1,$___LOCAL_PLAYER__VARS__itms1,$___LOCAL_PLAYER__VARS__itmsk1,$___LOCAL_PLAYER__VARS__itm2,$___LOCAL_PLAYER__VARS__itmk2,$___LOCAL_PLAYER__VARS__itme2,$___LOCAL_PLAYER__VARS__itms2,$___LOCAL_PLAYER__VARS__itmsk2, $___LOCAL_PLAYER__VARS__itm3,$___LOCAL_PLAYER__VARS__itmk3,$___LOCAL_PLAYER__VARS__itme3,$___LOCAL_PLAYER__VARS__itms3,$___LOCAL_PLAYER__VARS__itmsk3,$___LOCAL_PLAYER__VARS__itm4,$___LOCAL_PLAYER__VARS__itmk4,$___LOCAL_PLAYER__VARS__itme4,$___LOCAL_PLAYER__VARS__itms4,$___LOCAL_PLAYER__VARS__itmsk4, $___LOCAL_PLAYER__VARS__itm5,$___LOCAL_PLAYER__VARS__itmk5,$___LOCAL_PLAYER__VARS__itme5,$___LOCAL_PLAYER__VARS__itms5,$___LOCAL_PLAYER__VARS__itmsk5,$___LOCAL_PLAYER__VARS__itm6,$___LOCAL_PLAYER__VARS__itmk6,$___LOCAL_PLAYER__VARS__itme6,$___LOCAL_PLAYER__VARS__itms6,$___LOCAL_PLAYER__VARS__itmsk6, $___LOCAL_PLAYER__VARS__searchmemory,$___LOCAL_PLAYER__VARS__nskill,$___LOCAL_PLAYER__VARS__nskillpara; $ss=&$___LOCAL_PLAYER__VARS__ss; $db_player_structure=&$___LOCAL_PLAYER__VARS__db_player_structure; $db_player_structure_types=&$___LOCAL_PLAYER__VARS__db_player_structure_types; $gamedata=&$___LOCAL_PLAYER__VARS__gamedata; $cmd=&$___LOCAL_PLAYER__VARS__cmd; $main=&$___LOCAL_PLAYER__VARS__main; $sdata=&$___LOCAL_PLAYER__VARS__sdata; $fog=&$___LOCAL_PLAYER__VARS__fog; $upexp=&$___LOCAL_PLAYER__VARS__upexp; $lvlupexp=&$___LOCAL_PLAYER__VARS__lvlupexp;  $iconImg=&$___LOCAL_PLAYER__VARS__iconImg; $iconImgB=&$___LOCAL_PLAYER__VARS__iconImgB; $iconImgBwidth=&$___LOCAL_PLAYER__VARS__iconImgBwidth; $ardef=&$___LOCAL_PLAYER__VARS__ardef; $hpcolor=&$___LOCAL_PLAYER__VARS__hpcolor; $spcolor=&$___LOCAL_PLAYER__VARS__spcolor; $newhpimg=&$___LOCAL_PLAYER__VARS__newhpimg; $newspimg=&$___LOCAL_PLAYER__VARS__newspimg; $splt=&$___LOCAL_PLAYER__VARS__splt; $hplt=&$___LOCAL_PLAYER__VARS__hplt;  $tpldata=&$___LOCAL_PLAYER__VARS__tpldata; $icon_list=&$___LOCAL_PLAYER__VARS__icon_list; $icon_list_contents_to_frontend=&$___LOCAL_PLAYER__VARS__icon_list_contents_to_frontend; $typeinfo=&$___LOCAL_PLAYER__VARS__typeinfo; $killmsginfo=&$___LOCAL_PLAYER__VARS__killmsginfo; $lwinfo=&$___LOCAL_PLAYER__VARS__lwinfo; $sexinfo=&$___LOCAL_PLAYER__VARS__sexinfo; $equip_list=&$___LOCAL_PLAYER__VARS__equip_list; $battle_equip_list=&$___LOCAL_PLAYER__VARS__battle_equip_list; $pc_icon_range=&$___LOCAL_PLAYER__VARS__pc_icon_range;  $pid=&$___LOCAL_PLAYER__VARS__pid; $type=&$___LOCAL_PLAYER__VARS__type; $name=&$___LOCAL_PLAYER__VARS__name; $pass=&$___LOCAL_PLAYER__VARS__pass; $ip=&$___LOCAL_PLAYER__VARS__ip; $motto=&$___LOCAL_PLAYER__VARS__motto; $killmsg=&$___LOCAL_PLAYER__VARS__killmsg; $lastword=&$___LOCAL_PLAYER__VARS__lastword; $winner_flag=&$___LOCAL_PLAYER__VARS__winner_flag; $player_dead_flag=&$___LOCAL_PLAYER__VARS__player_dead_flag;  $corpse_clear_flag=&$___LOCAL_PLAYER__VARS__corpse_clear_flag; $gd=&$___LOCAL_PLAYER__VARS__gd; $sNo=&$___LOCAL_PLAYER__VARS__sNo; $club=&$___LOCAL_PLAYER__VARS__club; $validtime=&$___LOCAL_PLAYER__VARS__validtime; $endtime=&$___LOCAL_PLAYER__VARS__endtime; $cdsec=&$___LOCAL_PLAYER__VARS__cdsec; $cdmsec=&$___LOCAL_PLAYER__VARS__cdmsec; $cdtime=&$___LOCAL_PLAYER__VARS__cdtime; $action=&$___LOCAL_PLAYER__VARS__action;  $a_actionnum=&$___LOCAL_PLAYER__VARS__a_actionnum; $v_actionnum=&$___LOCAL_PLAYER__VARS__v_actionnum; $hp=&$___LOCAL_PLAYER__VARS__hp; $mhp=&$___LOCAL_PLAYER__VARS__mhp; $sp=&$___LOCAL_PLAYER__VARS__sp; $msp=&$___LOCAL_PLAYER__VARS__msp; $mss=&$___LOCAL_PLAYER__VARS__mss; $att=&$___LOCAL_PLAYER__VARS__att; $def=&$___LOCAL_PLAYER__VARS__def; $pls=&$___LOCAL_PLAYER__VARS__pls;  $lvl=&$___LOCAL_PLAYER__VARS__lvl; $exp=&$___LOCAL_PLAYER__VARS__exp; $money=&$___LOCAL_PLAYER__VARS__money; $rp=&$___LOCAL_PLAYER__VARS__rp; $bid=&$___LOCAL_PLAYER__VARS__bid; $inf=&$___LOCAL_PLAYER__VARS__inf; $rage=&$___LOCAL_PLAYER__VARS__rage; $pose=&$___LOCAL_PLAYER__VARS__pose; $tactic=&$___LOCAL_PLAYER__VARS__tactic; $killnum=&$___LOCAL_PLAYER__VARS__killnum;  $npckillnum=&$___LOCAL_PLAYER__VARS__npckillnum; $state=&$___LOCAL_PLAYER__VARS__state; $skillpoint=&$___LOCAL_PLAYER__VARS__skillpoint; $flare=&$___LOCAL_PLAYER__VARS__flare; $wp=&$___LOCAL_PLAYER__VARS__wp; $wk=&$___LOCAL_PLAYER__VARS__wk; $wg=&$___LOCAL_PLAYER__VARS__wg; $wc=&$___LOCAL_PLAYER__VARS__wc; $wd=&$___LOCAL_PLAYER__VARS__wd; $wf=&$___LOCAL_PLAYER__VARS__wf;  $icon=&$___LOCAL_PLAYER__VARS__icon; $teamID=&$___LOCAL_PLAYER__VARS__teamID; $teamPass=&$___LOCAL_PLAYER__VARS__teamPass; $card=&$___LOCAL_PLAYER__VARS__card; $cardname=&$___LOCAL_PLAYER__VARS__cardname; $wep=&$___LOCAL_PLAYER__VARS__wep; $wepk=&$___LOCAL_PLAYER__VARS__wepk; $wepe=&$___LOCAL_PLAYER__VARS__wepe; $weps=&$___LOCAL_PLAYER__VARS__weps; $wepsk=&$___LOCAL_PLAYER__VARS__wepsk;  $arb=&$___LOCAL_PLAYER__VARS__arb; $arbk=&$___LOCAL_PLAYER__VARS__arbk; $arbe=&$___LOCAL_PLAYER__VARS__arbe; $arbs=&$___LOCAL_PLAYER__VARS__arbs; $arbsk=&$___LOCAL_PLAYER__VARS__arbsk; $arh=&$___LOCAL_PLAYER__VARS__arh; $arhk=&$___LOCAL_PLAYER__VARS__arhk; $arhe=&$___LOCAL_PLAYER__VARS__arhe; $arhs=&$___LOCAL_PLAYER__VARS__arhs; $arhsk=&$___LOCAL_PLAYER__VARS__arhsk;  $ara=&$___LOCAL_PLAYER__VARS__ara; $arak=&$___LOCAL_PLAYER__VARS__arak; $arae=&$___LOCAL_PLAYER__VARS__arae; $aras=&$___LOCAL_PLAYER__VARS__aras; $arask=&$___LOCAL_PLAYER__VARS__arask; $arf=&$___LOCAL_PLAYER__VARS__arf; $arfk=&$___LOCAL_PLAYER__VARS__arfk; $arfe=&$___LOCAL_PLAYER__VARS__arfe; $arfs=&$___LOCAL_PLAYER__VARS__arfs; $arfsk=&$___LOCAL_PLAYER__VARS__arfsk;  $art=&$___LOCAL_PLAYER__VARS__art; $artk=&$___LOCAL_PLAYER__VARS__artk; $arte=&$___LOCAL_PLAYER__VARS__arte; $arts=&$___LOCAL_PLAYER__VARS__arts; $artsk=&$___LOCAL_PLAYER__VARS__artsk; $itm0=&$___LOCAL_PLAYER__VARS__itm0; $itmk0=&$___LOCAL_PLAYER__VARS__itmk0; $itme0=&$___LOCAL_PLAYER__VARS__itme0; $itms0=&$___LOCAL_PLAYER__VARS__itms0; $itmsk0=&$___LOCAL_PLAYER__VARS__itmsk0;  $itm1=&$___LOCAL_PLAYER__VARS__itm1; $itmk1=&$___LOCAL_PLAYER__VARS__itmk1; $itme1=&$___LOCAL_PLAYER__VARS__itme1; $itms1=&$___LOCAL_PLAYER__VARS__itms1; $itmsk1=&$___LOCAL_PLAYER__VARS__itmsk1; $itm2=&$___LOCAL_PLAYER__VARS__itm2; $itmk2=&$___LOCAL_PLAYER__VARS__itmk2; $itme2=&$___LOCAL_PLAYER__VARS__itme2; $itms2=&$___LOCAL_PLAYER__VARS__itms2; $itmsk2=&$___LOCAL_PLAYER__VARS__itmsk2;  $itm3=&$___LOCAL_PLAYER__VARS__itm3; $itmk3=&$___LOCAL_PLAYER__VARS__itmk3; $itme3=&$___LOCAL_PLAYER__VARS__itme3; $itms3=&$___LOCAL_PLAYER__VARS__itms3; $itmsk3=&$___LOCAL_PLAYER__VARS__itmsk3; $itm4=&$___LOCAL_PLAYER__VARS__itm4; $itmk4=&$___LOCAL_PLAYER__VARS__itmk4; $itme4=&$___LOCAL_PLAYER__VARS__itme4; $itms4=&$___LOCAL_PLAYER__VARS__itms4; $itmsk4=&$___LOCAL_PLAYER__VARS__itmsk4;  $itm5=&$___LOCAL_PLAYER__VARS__itm5; $itmk5=&$___LOCAL_PLAYER__VARS__itmk5; $itme5=&$___LOCAL_PLAYER__VARS__itme5; $itms5=&$___LOCAL_PLAYER__VARS__itms5; $itmsk5=&$___LOCAL_PLAYER__VARS__itmsk5; $itm6=&$___LOCAL_PLAYER__VARS__itm6; $itmk6=&$___LOCAL_PLAYER__VARS__itmk6; $itme6=&$___LOCAL_PLAYER__VARS__itme6; $itms6=&$___LOCAL_PLAYER__VARS__itms6; $itmsk6=&$___LOCAL_PLAYER__VARS__itmsk6;  $searchmemory=&$___LOCAL_PLAYER__VARS__searchmemory; $nskill=&$___LOCAL_PLAYER__VARS__nskill; $nskillpara=&$___LOCAL_PLAYER__VARS__nskillpara;  global $___LOCAL_ITEMMAIN__VARS__tmp_itmsk_arr_pool,$___LOCAL_ITEMMAIN__VARS__itemfind_extra_log,$___LOCAL_ITEMMAIN__VARS__item_equip_list,$___LOCAL_ITEMMAIN__VARS__item_hotkey_id_list,$___LOCAL_ITEMMAIN__VARS__itemmain_drophint,$___LOCAL_ITEMMAIN__VARS__item_allow_find_and_use,$___LOCAL_ITEMMAIN__VARS__nosta,$___LOCAL_ITEMMAIN__VARS__nospk,$___LOCAL_ITEMMAIN__VARS__item_obbs,$___LOCAL_ITEMMAIN__VARS__map_noitemdrop_arealist, $___LOCAL_ITEMMAIN__VARS__itemkind_equipable,$___LOCAL_ITEMMAIN__VARS__iteminfo,$___LOCAL_ITEMMAIN__VARS__itemspkinfo,$___LOCAL_ITEMMAIN__VARS__itemspkdesc,$___LOCAL_ITEMMAIN__VARS__itemspkdesc_help,$___LOCAL_ITEMMAIN__VARS__itemspkremark; $tmp_itmsk_arr_pool=&$___LOCAL_ITEMMAIN__VARS__tmp_itmsk_arr_pool; $itemfind_extra_log=&$___LOCAL_ITEMMAIN__VARS__itemfind_extra_log; $item_equip_list=&$___LOCAL_ITEMMAIN__VARS__item_equip_list; $item_hotkey_id_list=&$___LOCAL_ITEMMAIN__VARS__item_hotkey_id_list; $itemmain_drophint=&$___LOCAL_ITEMMAIN__VARS__itemmain_drophint; $item_allow_find_and_use=&$___LOCAL_ITEMMAIN__VARS__item_allow_find_and_use; $nosta=&$___LOCAL_ITEMMAIN__VARS__nosta; $nospk=&$___LOCAL_ITEMMAIN__VARS__nospk; $item_obbs=&$___LOCAL_ITEMMAIN__VARS__item_obbs; $map_noitemdrop_arealist=&$___LOCAL_ITEMMAIN__VARS__map_noitemdrop_arealist;  $itemkind_equipable=&$___LOCAL_ITEMMAIN__VARS__itemkind_equipable; $iteminfo=&$___LOCAL_ITEMMAIN__VARS__iteminfo; $itemspkinfo=&$___LOCAL_ITEMMAIN__VARS__itemspkinfo; $itemspkdesc=&$___LOCAL_ITEMMAIN__VARS__itemspkdesc; $itemspkdesc_help=&$___LOCAL_ITEMMAIN__VARS__itemspkdesc_help; $itemspkremark=&$___LOCAL_ITEMMAIN__VARS__itemspkremark;  global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
		
		$itm=&$theitem['itm']; $itmk=&$theitem['itmk'];
		$itme=&$theitem['itme']; $itms=&$theitem['itms']; $itmsk=&$theitem['itmsk'];
		
		if (strpos ( $itmk, 'Y' ) === 0 || strpos ( $itmk, 'Z' ) === 0) {
			if ($itm == '试炼解除钥匙') 
			{
				if(13==$gametype){
					addnews ( $now, 'itemuse', $name, $itm );
					$log .= '<span class="red b">钥匙中涌出无边的黑暗，将你的身体和灵魂吞噬了。</span><br>';
					$state = 50;
					$sdata['sourceless'] = 1; 
					\player\kill($sdata,$sdata);
					return;
				}else{
					$log .= '这玩意究竟是怎么冒出来的呢？<br>';
					$mode = 'command';
					return;
				}
			}
			elseif ($itm == '游戏解除钥匙' && 13==$gametype) 
			{
				$log .= '<span class="ltcrimson">『忘了我说的话了？』</span><br><br><span class="yellow b">看起来这把钥匙没有任何功能。</span><br>';
				$mode = 'command';
				return;
			}
			elseif ($itm == '奇怪的按钮' && 13==$gametype) 
			{
				$log .= '<span class="ltcrimson">『忘了我说的话了？』</span><br><br><span class="yellow b">看起来这个按钮没有任何功能。</span><br>';
				$mode = 'command';
				return;
			}
		}
if(isset($itm)) {$__VAR_DUMP_MOD_instance3_VARS_itm = &$itm; unset($itm); } else {$__VAR_DUMP_MOD_instance3_VARS_itm = NULL;}if(isset($itmk)) {$__VAR_DUMP_MOD_instance3_VARS_itmk = &$itmk; unset($itmk); } else {$__VAR_DUMP_MOD_instance3_VARS_itmk = NULL;}if(isset($itme)) {$__VAR_DUMP_MOD_instance3_VARS_itme = &$itme; unset($itme); } else {$__VAR_DUMP_MOD_instance3_VARS_itme = NULL;}if(isset($itms)) {$__VAR_DUMP_MOD_instance3_VARS_itms = &$itms; unset($itms); } else {$__VAR_DUMP_MOD_instance3_VARS_itms = NULL;}if(isset($itmsk)) {$__VAR_DUMP_MOD_instance3_VARS_itmsk = &$itmsk; unset($itmsk); } else {$__VAR_DUMP_MOD_instance3_VARS_itmsk = NULL;}
		//======== Start of contents from mod randrecipe ========
		do{
			$___TMP_MOD_randrecipe_FUNC_itemuse_RET = NULL;

		
		
		
		
		$itm=&$theitem['itm']; $itmk=&$theitem['itmk'];
		$itme=&$theitem['itme']; $itms=&$theitem['itms']; $itmsk=&$theitem['itmsk'];
		
		if (strpos ( $itmk, 'Y' ) === 0 || strpos ( $itmk, 'Z' ) === 0)
		{	
			if ($itm == '测试配方config生成器')
			{
				$log .= "使用了<span class=\"yellow b\">$itm</span>。<br>";
				\randrecipe\create_randrecipe_config (12);
				$___TMP_MOD_randrecipe_FUNC_itemuse_RET = NULL;
			break; 
			}
			elseif ($itm == '测试配方生成器')
			{
				$log .= "使用了<span class=\"yellow b\">$itm</span>。<br><br>";
				$recipe = \randrecipe\generate_randrecipe();
				$recipe_tip = '';
				$flag = 0;
				for ($i=1;$i<=5;$i++)
				{
					if (isset($recipe['stuff'.$i]))
					{
						$recipe_tip .= \item_recipe\generate_single_itemtip($recipe['stuff'.$i]).'<br>+ ';
						$flag = 1;
					}
				}
				if (1 === $flag) $recipe_tip = substr($recipe_tip,0,-2);
				if (isset($recipe['stuffa']))
				{
					if (1 === $flag) $recipe_tip .= '其余';
					$recipe_tip .= '素材为：'.\item_recipe\generate_single_itemtip($recipe['stuffa']).'<br>';
				}
				if (isset($recipe['extra']))
				{
					if (isset($recipe['extra']['link'])) $recipe_tip .= '连接'.$recipe['extra']['link'].'，';
					if (isset($recipe['extra']['materials']))
					{
						$recipe_tip .= '素材数';
						if (0 === strpos($recipe['extra']['materials'],'>')) $recipe_tip .= '不少于'.((int)substr($recipe['extra']['materials'],1)+1).'，';
						else $recipe_tip .= '为'.$recipe['extra']['materials'].'，';
					}
					if (isset($recipe['extra']['allow_repeat']) && (false === $recipe['extra']['allow_repeat'])) $recipe_tip .= '素材不允许重复，';
					if (isset($recipe['extra']['consume_recipe']) && (true === $recipe['extra']['consume_recipe'])) $recipe_tip .= '消耗配方，';
				}
				$recipe_tip .= '<br>合成结果：<br>'.\itemmix\parse_itemmix_resultshow($recipe['result']);
				$log .= "你产生的配方公式：<br><span class=\"yellow b\">$recipe_tip</span><br>";
				$___TMP_MOD_randrecipe_FUNC_itemuse_RET = NULL;
			break; 
			}
		}
if(isset($itm)) {$__VAR_DUMP_MOD_randrecipe_VARS_itm = &$itm; unset($itm); } else {$__VAR_DUMP_MOD_randrecipe_VARS_itm = NULL;}if(isset($itmk)) {$__VAR_DUMP_MOD_randrecipe_VARS_itmk = &$itmk; unset($itmk); } else {$__VAR_DUMP_MOD_randrecipe_VARS_itmk = NULL;}if(isset($itme)) {$__VAR_DUMP_MOD_randrecipe_VARS_itme = &$itme; unset($itme); } else {$__VAR_DUMP_MOD_randrecipe_VARS_itme = NULL;}if(isset($itms)) {$__VAR_DUMP_MOD_randrecipe_VARS_itms = &$itms; unset($itms); } else {$__VAR_DUMP_MOD_randrecipe_VARS_itms = NULL;}if(isset($itmsk)) {$__VAR_DUMP_MOD_randrecipe_VARS_itmsk = &$itmsk; unset($itmsk); } else {$__VAR_DUMP_MOD_randrecipe_VARS_itmsk = NULL;}if(isset($flag)) {$__VAR_DUMP_MOD_randrecipe_VARS_flag = $flag; unset($flag); } else {$__VAR_DUMP_MOD_randrecipe_VARS_flag = NULL;} if(isset($i)) {$__VAR_DUMP_MOD_randrecipe_VARS_i = $i; unset($i); } else {$__VAR_DUMP_MOD_randrecipe_VARS_i = NULL;} 
		//======== Start of contents from mod tutorial ========
		do{
			$___TMP_MOD_tutorial_FUNC_itemuse_RET = NULL;

		
		do { global $___LOCAL_TUTORIAL__VARS__tutorial_tough_hp,$___LOCAL_TUTORIAL__VARS__tutorial_areahour_augment,$___LOCAL_TUTORIAL__VARS__tutorial_disable_area_timing,$___LOCAL_TUTORIAL__VARS__tutorial_disable_combo,$___LOCAL_TUTORIAL__VARS__tutorial_force_teamer,$___LOCAL_TUTORIAL__VARS__tutorial_allowed_weather,$___LOCAL_TUTORIAL__VARS__tutorial_story,$___LOCAL_TUTORIAL__VARS__tutorial_npc; $tutorial_tough_hp=&$___LOCAL_TUTORIAL__VARS__tutorial_tough_hp; $tutorial_areahour_augment=&$___LOCAL_TUTORIAL__VARS__tutorial_areahour_augment; $tutorial_disable_area_timing=&$___LOCAL_TUTORIAL__VARS__tutorial_disable_area_timing; $tutorial_disable_combo=&$___LOCAL_TUTORIAL__VARS__tutorial_disable_combo; $tutorial_force_teamer=&$___LOCAL_TUTORIAL__VARS__tutorial_force_teamer; $tutorial_allowed_weather=&$___LOCAL_TUTORIAL__VARS__tutorial_allowed_weather; $tutorial_story=&$___LOCAL_TUTORIAL__VARS__tutorial_story; $tutorial_npc=&$___LOCAL_TUTORIAL__VARS__tutorial_npc;   } while (0);
		$oitm = $theitem['itm'];
		$oitmk = $theitem['itmk'];
		//======== Start of contents from mod ex_mhp_temp_up ========
		do{
			$___TMP_MOD_ex_mhp_temp_up_FUNC_itemuse_RET = NULL;

		
		
		$itm=&$theitem['itm']; $itmk=&$theitem['itmk'];
		$itme=&$theitem['itme']; $itms=&$theitem['itms']; $itmsk=&$theitem['itmsk'];
		
		$lose_flag = 0;
		if(strpos ( $itmk, 'W' ) === 0 || strpos ( $itmk, 'D' ) === 0 || strpos ( $itmk, 'A' ) === 0) {
			
			if(strpos ( $itmk, 'W' ) === 0) $obj = 'wep';
			elseif(strpos ( $itmk, 'DB' ) === 0) $obj = 'arb';
			elseif(strpos ( $itmk, 'DH' ) === 0) $obj = 'arh';
			elseif(strpos ( $itmk, 'DA' ) === 0) $obj = 'ara';
			elseif(strpos ( $itmk, 'DF' ) === 0) $obj = 'arf';
			elseif(strpos ( $itmk, 'A' ) === 0) $obj = 'art';
			
			$flag = \attrbase\check_in_itmsk('^hu',\itemmain\get_itmsk_array(${$obj.'sk'}));
			if(false !== $flag){
				$lose_flag = 1;
			}
		}
if(isset($itm)) {$__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_itm = &$itm; unset($itm); } else {$__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_itm = NULL;}if(isset($itmk)) {$__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_itmk = &$itmk; unset($itmk); } else {$__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_itmk = NULL;}if(isset($itme)) {$__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_itme = &$itme; unset($itme); } else {$__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_itme = NULL;}if(isset($itms)) {$__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_itms = &$itms; unset($itms); } else {$__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_itms = NULL;}if(isset($itmsk)) {$__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_itmsk = &$itmsk; unset($itmsk); } else {$__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_itmsk = NULL;}if(isset($obj)) {$__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_obj = $obj; unset($obj); } else {$__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_obj = NULL;} if(isset($flag)) {$__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_flag = $flag; unset($flag); } else {$__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_flag = NULL;} 
		//======== Start of contents from mod empowers ========
		do{
			$___TMP_MOD_empowers_FUNC_itemuse_RET = NULL;

		
		
		do { global $___LOCAL_ARMOR__VARS__nosta,$___LOCAL_ARMOR__VARS__noarb,$___LOCAL_ARMOR__VARS__armor_equip_list,$___LOCAL_ARMOR__VARS__armor_iteminfo; $nosta=&$___LOCAL_ARMOR__VARS__nosta; $noarb=&$___LOCAL_ARMOR__VARS__noarb; $armor_equip_list=&$___LOCAL_ARMOR__VARS__armor_equip_list; $armor_iteminfo=&$___LOCAL_ARMOR__VARS__armor_iteminfo;   } while (0);
		
		$itm=&$theitem['itm']; $itmk=&$theitem['itmk'];
		$itme=&$theitem['itme']; $itms=&$theitem['itms']; $itmsk=&$theitem['itmsk'];
		
		if (strpos ( $itmk, 'Y' ) === 0 || strpos ( $itmk, 'Z' ) === 0) 
		{
			if (\empowers\check_hone ($itm)) 
			{
				if (\empowers\use_hone ($itm,$itme)) \itemmain\itms_reduce($theitem);
				$___TMP_MOD_empowers_FUNC_itemuse_RET = NULL;
			break; 
			} 
			elseif (\empowers\check_nail ($itm)) 
			{
				if (\empowers\use_nail ($itm,$itme)) \itemmain\itms_reduce($theitem);
				$___TMP_MOD_empowers_FUNC_itemuse_RET = NULL;
			break; 
			} 
			elseif ($itm == '针线包') 
			{
				if (\empowers\use_sewing_kit ($theitem)) \itemmain\itms_reduce($theitem);
				$___TMP_MOD_empowers_FUNC_itemuse_RET = NULL;
			break; 
			}
			elseif ($itm == '武器师安雅的奖赏') 
			{
				if (\empowers\use_weapon_improvement ($itm, $itmsk)) \itemmain\itms_reduce($theitem);
				$___TMP_MOD_empowers_FUNC_itemuse_RET = NULL;
			break; 
			}
		}elseif($itmk == 'EI'){
			if (\empowers\use_weapon_improvement ($itm, $itmsk)) \itemmain\itms_reduce($theitem);
			$___TMP_MOD_empowers_FUNC_itemuse_RET = NULL;
			break; 
		}
if(isset($itm)) {$__VAR_DUMP_MOD_empowers_VARS_itm = &$itm; unset($itm); } else {$__VAR_DUMP_MOD_empowers_VARS_itm = NULL;}if(isset($itmk)) {$__VAR_DUMP_MOD_empowers_VARS_itmk = &$itmk; unset($itmk); } else {$__VAR_DUMP_MOD_empowers_VARS_itmk = NULL;}if(isset($itme)) {$__VAR_DUMP_MOD_empowers_VARS_itme = &$itme; unset($itme); } else {$__VAR_DUMP_MOD_empowers_VARS_itme = NULL;}if(isset($itms)) {$__VAR_DUMP_MOD_empowers_VARS_itms = &$itms; unset($itms); } else {$__VAR_DUMP_MOD_empowers_VARS_itms = NULL;}if(isset($itmsk)) {$__VAR_DUMP_MOD_empowers_VARS_itmsk = &$itmsk; unset($itmsk); } else {$__VAR_DUMP_MOD_empowers_VARS_itmsk = NULL;}
		//======== Start of contents from mod news_observe ========
		do{
			$___TMP_MOD_news_observe_FUNC_itemuse_RET = NULL;

		
		
		
		
		$itm=&$theitem['itm']; $itmk=&$theitem['itmk'];
		$itme=&$theitem['itme']; $itms=&$theitem['itms']; $itmsk=&$theitem['itmsk'];

		if (strpos ( $itmk, 'Y' ) === 0 || strpos ( $itmk, 'Z' ) === 0) {	
			if ($itm == '测试用窥屏显示器') {
				ob_start();
				include template('MOD_NEWS_OBSERVE_OBSERVE_SELECT');
				$cmd = ob_get_contents();
				ob_end_clean();
				$log .= '你打开了'.$itm.'的开关……<br><br>';
				$___TMP_MOD_news_observe_FUNC_itemuse_RET = NULL;
			break; 
			}
		}
if(isset($itm)) {$__VAR_DUMP_MOD_news_observe_VARS_itm = &$itm; unset($itm); } else {$__VAR_DUMP_MOD_news_observe_VARS_itm = NULL;}if(isset($itmk)) {$__VAR_DUMP_MOD_news_observe_VARS_itmk = &$itmk; unset($itmk); } else {$__VAR_DUMP_MOD_news_observe_VARS_itmk = NULL;}if(isset($itme)) {$__VAR_DUMP_MOD_news_observe_VARS_itme = &$itme; unset($itme); } else {$__VAR_DUMP_MOD_news_observe_VARS_itme = NULL;}if(isset($itms)) {$__VAR_DUMP_MOD_news_observe_VARS_itms = &$itms; unset($itms); } else {$__VAR_DUMP_MOD_news_observe_VARS_itms = NULL;}if(isset($itmsk)) {$__VAR_DUMP_MOD_news_observe_VARS_itmsk = &$itmsk; unset($itmsk); } else {$__VAR_DUMP_MOD_news_observe_VARS_itmsk = NULL;}
		//======== Start of contents from mod song ========
		do{
			$___TMP_MOD_song_FUNC_itemuse_RET = NULL;

		
		
		$itm=&$theitem['itm']; $itmk=&$theitem['itmk'];
		$itme=&$theitem['itme']; $itms=&$theitem['itms']; $itmsk=&$theitem['itmsk'];
		
		do { global $___LOCAL_SONG__VARS__ef_type,$___LOCAL_SONG__VARS__ef_type2,$___LOCAL_SONG__VARS__songlist,$___LOCAL_SONG__VARS__songchatlimit,$___LOCAL_SONG__VARS__song_font_size,$___LOCAL_SONG__VARS__song_line_height; $ef_type=&$___LOCAL_SONG__VARS__ef_type; $ef_type2=&$___LOCAL_SONG__VARS__ef_type2; $songlist=&$___LOCAL_SONG__VARS__songlist; $songchatlimit=&$___LOCAL_SONG__VARS__songchatlimit; $song_font_size=&$___LOCAL_SONG__VARS__song_font_size; $song_line_height=&$___LOCAL_SONG__VARS__song_line_height;   } while (0);
		if (strpos ( $itmk, 'HM' ) === 0) {
			$mss+=$itme;
			$ss+=$itme;


			
			$log .= "你使用了<span class=\"red b\">$itm</span>，增加了<span class=\"yellow b\">$itme</span>点歌魂上限。<br>";
			\itemmain\itms_reduce($theitem);
			$___TMP_MOD_song_FUNC_itemuse_RET = NULL;
			break; 
		}elseif (strpos ( $itmk, 'HT' ) === 0) {
			$ssup=$itme;
			if ($ss < $mss) {
				$oldss = $ss;
				$ss += $ssup;
				$ss = $ss > $mss ? $mss : $ss;
				$oldss = $ss - $oldss;
				$log .= "你使用了<span class=\"red b\">$itm</span>，恢复了<span class=\"yellow b\">$oldss</span>点歌魂。<br>";
				\itemmain\itms_reduce($theitem);
			} else {
				$log .= '你的歌魂不需要恢复。<br>';
			}
			$___TMP_MOD_song_FUNC_itemuse_RET = NULL;
			break; 
		} 
		
		if (strpos ( $itmk, 'ss' ) === 0)
		{
			$eqp = 'art';
			$noeqp = '';
			
			if (($noeqp && strpos ( ${$eqp.'k'}, $noeqp ) === 0) || ! ${$eqp.'s'}) {
				${$eqp} = $itm;
				${$eqp.'k'} = $itmk;
				${$eqp.'e'} = $itme;
				${$eqp.'s'} = $itms;
				${$eqp.'sk'} = $itmsk;
				$log .= "装备了<span class=\"yellow b\">$itm</span>。<br>";
				$itm = $itmk = $itmsk = '';
				$itme = $itms = 0;
			} else {
				swap(${$eqp},$itm);
				swap(${$eqp.'k'},$itmk);
				swap(${$eqp.'e'},$itme);
				swap(${$eqp.'s'},$itms);
				swap(${$eqp.'sk'},$itmsk);
				$log .= "卸下了<span class=\"red b\">$itm</span>，装备了<span class=\"yellow b\">${$eqp}</span>。<br>";
			}
			$___TMP_MOD_song_FUNC_itemuse_RET = NULL;
			break; 
		}
if(isset($itm)) {$__VAR_DUMP_MOD_song_VARS_itm = &$itm; unset($itm); } else {$__VAR_DUMP_MOD_song_VARS_itm = NULL;}if(isset($itmk)) {$__VAR_DUMP_MOD_song_VARS_itmk = &$itmk; unset($itmk); } else {$__VAR_DUMP_MOD_song_VARS_itmk = NULL;}if(isset($itme)) {$__VAR_DUMP_MOD_song_VARS_itme = &$itme; unset($itme); } else {$__VAR_DUMP_MOD_song_VARS_itme = NULL;}if(isset($itms)) {$__VAR_DUMP_MOD_song_VARS_itms = &$itms; unset($itms); } else {$__VAR_DUMP_MOD_song_VARS_itms = NULL;}if(isset($itmsk)) {$__VAR_DUMP_MOD_song_VARS_itmsk = &$itmsk; unset($itmsk); } else {$__VAR_DUMP_MOD_song_VARS_itmsk = NULL;}if(isset($eqp)) {$__VAR_DUMP_MOD_song_VARS_eqp = $eqp; unset($eqp); } else {$__VAR_DUMP_MOD_song_VARS_eqp = NULL;} if(isset($noeqp)) {$__VAR_DUMP_MOD_song_VARS_noeqp = $noeqp; unset($noeqp); } else {$__VAR_DUMP_MOD_song_VARS_noeqp = NULL;} 
		//======== Start of contents from mod item_recipe ========
		do{
			$___TMP_MOD_item_recipe_FUNC_itemuse_RET = NULL;

		
		
		
		
		$itm = &$theitem['itm'];
		$itmk = &$theitem['itmk'];
		
		if (strpos($itmk, 'R') === 0)
		{
			
			$log .= "你打开了配方<span class=\"yellow b\">$itm</span>。<br>";
			ob_start();
			include template(MOD_ITEM_RECIPE_USE_RECIPE);
			$cmd = ob_get_contents();
			ob_end_clean();
			$___TMP_MOD_item_recipe_FUNC_itemuse_RET = NULL;
			break; 
		}
if(isset($itm)) {$__VAR_DUMP_MOD_item_recipe_VARS_itm = &$itm; unset($itm); } else {$__VAR_DUMP_MOD_item_recipe_VARS_itm = NULL;}if(isset($itmk)) {$__VAR_DUMP_MOD_item_recipe_VARS_itmk = &$itmk; unset($itmk); } else {$__VAR_DUMP_MOD_item_recipe_VARS_itmk = NULL;}
		//======== Start of contents from mod item_uu ========
		do{
			$___TMP_MOD_item_uu_FUNC_itemuse_RET = NULL;

		
		
		
		
		$itm=&$theitem['itm']; $itmk=&$theitem['itmk'];
		$itme=&$theitem['itme']; $itms=&$theitem['itms']; $itmsk=&$theitem['itmsk'];
		
		if ($itmk=='U') 
		{
			$log.="你使用了<span class=\"yellow b\">{$itm}</span>。";
			
			$amount = $itme;
			$traps = $traps_swept_ids = $traps_swept_names = Array();
			$result = $db->query("SELECT * FROM {$tablepre}maptrap WHERE pls = '$pls' AND itmk != 'TOc'");
			while($traparr = $db->fetch_array($result)){
				$traps[] = $traparr;
			}
			shuffle($traps);
			$i = 0;
			foreach($traps as $tv){
				if($tv['itme'] <= $amount) {
					$traps_swept_ids[] = $tv['tid'];
					$traps_swept_names[] = $tv['itm'];
					$amount -= $tv['itme'];
					$i++;
				}
				
				if($i>=77) break;
			}
			
			if(!empty($traps_swept_ids)) {
				$delc = implode(',',$traps_swept_ids);
				$db->query("DELETE FROM {$tablepre}maptrap WHERE tid IN ($delc)");
			
				$traps_swept_names_log = $traps_swept_names_by_name = array();
				
				foreach($traps_swept_names as $nv) {
					if(empty($traps_swept_names_by_name[$nv])) {
						$traps_swept_names_by_name[$nv] = 1;
					}else{
						$traps_swept_names_by_name[$nv] ++;
					}
				}
				foreach($traps_swept_names_by_name as $nk => $nv) {
					$traps_swept_names_log[] = $nv.'个'.$nk;
				}
				$traps_swept_names_log = implode('、', $traps_swept_names_log);
				if($itm=='☆混沌人肉探雷车★') $log.="远方传来一阵爆炸声，伟大的<span class=\"yellow b\">{$itm}</span>用生命和鲜血扫除了<span class=\"yellow b\">{$traps_swept_names_log}</span>。<br><span class=\"red b\">实在是大快人心啊！</span><br>";
				else $log.="远方传来一阵爆炸声，<span class=\"yellow b\">{$itm}</span>引爆并扫除了<span class=\"yellow b\">{$traps_swept_names_log}</span>。<br>";
				\sys\addnews ( 0, 'minesweep', $name, $itm, $traps_swept_names_log, $pls);
			}else{
				$log.="但是，没有触发任何陷阱。<br>";
			}

			\itemmain\itms_reduce($theitem);
			$___TMP_MOD_item_uu_FUNC_itemuse_RET = NULL;
			break; 
		}
if(isset($itm)) {$__VAR_DUMP_MOD_item_uu_VARS_itm = &$itm; unset($itm); } else {$__VAR_DUMP_MOD_item_uu_VARS_itm = NULL;}if(isset($itmk)) {$__VAR_DUMP_MOD_item_uu_VARS_itmk = &$itmk; unset($itmk); } else {$__VAR_DUMP_MOD_item_uu_VARS_itmk = NULL;}if(isset($itme)) {$__VAR_DUMP_MOD_item_uu_VARS_itme = &$itme; unset($itme); } else {$__VAR_DUMP_MOD_item_uu_VARS_itme = NULL;}if(isset($itms)) {$__VAR_DUMP_MOD_item_uu_VARS_itms = &$itms; unset($itms); } else {$__VAR_DUMP_MOD_item_uu_VARS_itms = NULL;}if(isset($itmsk)) {$__VAR_DUMP_MOD_item_uu_VARS_itmsk = &$itmsk; unset($itmsk); } else {$__VAR_DUMP_MOD_item_uu_VARS_itmsk = NULL;}if(isset($result)) {$__VAR_DUMP_MOD_item_uu_VARS_result = $result; unset($result); } else {$__VAR_DUMP_MOD_item_uu_VARS_result = NULL;} if(isset($i)) {$__VAR_DUMP_MOD_item_uu_VARS_i = $i; unset($i); } else {$__VAR_DUMP_MOD_item_uu_VARS_i = NULL;} 
		//======== Start of contents from mod wep_b_extra_reloading ========
		do{
			$___TMP_MOD_wep_b_extra_reloading_FUNC_itemuse_RET = NULL;

		
		
		
		
		$itm=&$theitem['itm']; $itmk=&$theitem['itmk'];
		$itme=&$theitem['itme']; $itms=&$theitem['itms']; $itmsk=&$theitem['itmsk'];
		
		if (strpos ( $itmk, 'WC' ) === 0 && strpos ( $wepk, 'WB' ) === 0)
		{
			
			if(\wep_b_extra_reloading\wep_b_extra_reloading_check ($theitem)){
				\wep_b\itemuse_uga($theitem);
				$___TMP_MOD_wep_b_extra_reloading_FUNC_itemuse_RET = NULL;
			break; 
			}
			if($nosta == $theitem['itms']) {
				$log .= '系统自动将你的指令识别为切换武器。<br>';
			}else{
				$___TMP_MOD_wep_b_extra_reloading_FUNC_itemuse_RET = NULL;
			break; 
			}















			
		}
if(isset($itm)) {$__VAR_DUMP_MOD_wep_b_extra_reloading_VARS_itm = &$itm; unset($itm); } else {$__VAR_DUMP_MOD_wep_b_extra_reloading_VARS_itm = NULL;}if(isset($itmk)) {$__VAR_DUMP_MOD_wep_b_extra_reloading_VARS_itmk = &$itmk; unset($itmk); } else {$__VAR_DUMP_MOD_wep_b_extra_reloading_VARS_itmk = NULL;}if(isset($itme)) {$__VAR_DUMP_MOD_wep_b_extra_reloading_VARS_itme = &$itme; unset($itme); } else {$__VAR_DUMP_MOD_wep_b_extra_reloading_VARS_itme = NULL;}if(isset($itms)) {$__VAR_DUMP_MOD_wep_b_extra_reloading_VARS_itms = &$itms; unset($itms); } else {$__VAR_DUMP_MOD_wep_b_extra_reloading_VARS_itms = NULL;}if(isset($itmsk)) {$__VAR_DUMP_MOD_wep_b_extra_reloading_VARS_itmsk = &$itmsk; unset($itmsk); } else {$__VAR_DUMP_MOD_wep_b_extra_reloading_VARS_itmsk = NULL;}
		//======== Start of contents from mod skill729 ========
		do{
			$___TMP_MOD_skill729_FUNC_itemuse_RET = NULL;

		
		
		
		
		$itm=&$theitem['itm']; $itmk=&$theitem['itmk'];
		$itme=&$theitem['itme']; $itms=&$theitem['itms']; $itmsk=&$theitem['itmsk'];
		
		if (strpos ( $itmk, 'Y' ) === 0 || strpos ( $itmk, 'Z' ) === 0) 
		{
			if (\skillbase\skill_query(729,$sdata) && \skill729\check_unlocked729 ($sdata) && ($itm == '二十面骰'))
			{
				do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;   } while (0);
				$log .= "你使用了<span class=\"yellow b\">{$itm}</span>。<br>";
				
				$acquired_skills = \skillbase\get_acquired_skill_array($sdata);
				$count = 0;
				
				if (!empty($acquired_skills))
				{
					foreach ($acquired_skills as $skillid)
					{
						if (isset($clubskillname[$skillid]) && (strpos(constant('MOD_SKILL'.$skillid.'_INFO'),'hidden;') === false))
						{
							\skillbase\skill_lost($skillid, $sdata);
							$count += 1;
						}
					}
				}
				
				if ($count > 0)
				{
					$clubskillcount = rand(floor($count/3),$count);
					\item_randskills\get_rand_clubskill($sdata, $clubskillcount);
					$cardskillcount = $count - $clubskillcount;
					if ($cardskillcount > 0)
					{
						do { global $___LOCAL_ITEM_RANDSKILLS__VARS__rs_allowclublist,$___LOCAL_ITEM_RANDSKILLS__VARS__rs_banlist,$___LOCAL_ITEM_RANDSKILLS__VARS__rs_feature,$___LOCAL_ITEM_RANDSKILLS__VARS__rs_cardskills; $rs_allowclublist=&$___LOCAL_ITEM_RANDSKILLS__VARS__rs_allowclublist; $rs_banlist=&$___LOCAL_ITEM_RANDSKILLS__VARS__rs_banlist; $rs_feature=&$___LOCAL_ITEM_RANDSKILLS__VARS__rs_feature; $rs_cardskills=&$___LOCAL_ITEM_RANDSKILLS__VARS__rs_cardskills;   } while (0);
						$ls_skills = array_merge(...array_values($rs_cardskills));
						$rs_skills = array_randompick($ls_skills, $cardskillcount);
						if (!is_array($rs_skills)) $rs_skills = [$rs_skills];
						foreach ($rs_skills as $skillid)
						{
							\skillbase\skill_acquire($skillid, $sdata);
						}
					}
					$log .= "随着骰子的转动，你感到自己的身体变得焕然一新！<br>";
				}
				else
				{
					$log .= "但是，这个骰子对你好像没什么用的样子……<br>";
				}
				\itemmain\itms_reduce($theitem);
				$___TMP_MOD_skill729_FUNC_itemuse_RET = NULL;
			break; 
			}	
		}
if(isset($itm)) {$__VAR_DUMP_MOD_skill729_VARS_itm = &$itm; unset($itm); } else {$__VAR_DUMP_MOD_skill729_VARS_itm = NULL;}if(isset($itmk)) {$__VAR_DUMP_MOD_skill729_VARS_itmk = &$itmk; unset($itmk); } else {$__VAR_DUMP_MOD_skill729_VARS_itmk = NULL;}if(isset($itme)) {$__VAR_DUMP_MOD_skill729_VARS_itme = &$itme; unset($itme); } else {$__VAR_DUMP_MOD_skill729_VARS_itme = NULL;}if(isset($itms)) {$__VAR_DUMP_MOD_skill729_VARS_itms = &$itms; unset($itms); } else {$__VAR_DUMP_MOD_skill729_VARS_itms = NULL;}if(isset($itmsk)) {$__VAR_DUMP_MOD_skill729_VARS_itmsk = &$itmsk; unset($itmsk); } else {$__VAR_DUMP_MOD_skill729_VARS_itmsk = NULL;}if(isset($acquired_skills)) {$__VAR_DUMP_MOD_skill729_VARS_acquired_skills = $acquired_skills; unset($acquired_skills); } else {$__VAR_DUMP_MOD_skill729_VARS_acquired_skills = NULL;} if(isset($count)) {$__VAR_DUMP_MOD_skill729_VARS_count = $count; unset($count); } else {$__VAR_DUMP_MOD_skill729_VARS_count = NULL;} if(isset($ls_skills)) {$__VAR_DUMP_MOD_skill729_VARS_ls_skills = $ls_skills; unset($ls_skills); } else {$__VAR_DUMP_MOD_skill729_VARS_ls_skills = NULL;} if(isset($rs_skills)) {$__VAR_DUMP_MOD_skill729_VARS_rs_skills = $rs_skills; unset($rs_skills); } else {$__VAR_DUMP_MOD_skill729_VARS_rs_skills = NULL;} 
		//======== Start of contents from mod skill732 ========
		do{
			$___TMP_MOD_skill732_FUNC_itemuse_RET = NULL;

		
		
		
		
		$itm=&$theitem['itm']; $itmk=&$theitem['itmk'];
		$itme=&$theitem['itme']; $itms=&$theitem['itms']; $itmsk=&$theitem['itmsk'];
		
		if (strpos ( $itmk, 'Z' ) === 0) 
		{
			if (\skillbase\skill_query(732,$sdata) && \skill732\check_unlocked732 ($sdata) && ($itm == '漏水的雪管' || $itm == '漏雪的水管' || $itm == '漏雪的雪管'))
			{
				$log .= "你修好了<span class=\"yellow b\">{$itm}</span>！<br>";
				if ((int)\itemmain\check_in_itmsk('^skflag', $itmsk) == 732)
				{
					$log .= "看起来真不错！……嗯，好像有什么不对？<br><span class=\"red b\">糟糕，水管爆炸了！</span><br><br>你费了好大工夫才从雪水中挣扎着爬出来，但身体和精神都受到了沉重的伤害。<br>";
					$hp = 1;
					$sp = 1;
					$mhp = max($mhp-rand(100,250), 1);
					$msp = max($msp-rand(100,250), 1);
					foreach(array('h','b','a','f','p','w') as $v)
					{
						$inf = str_replace($v,'',$inf);
					}
					$inf .= 'hbafpw';
				}
				else
				{
					$log .= "看起来真不错！你获得了<span class=\"yellow b\">30</span>点经验。<br>";
					\lvlctl\getexp(30, $sdata);
				}
				$itm = $itmk = $itmsk = '';
				$itme = $itms = 0;
				$___TMP_MOD_skill732_FUNC_itemuse_RET = NULL;
			break; 
			}
		}
if(isset($itm)) {$__VAR_DUMP_MOD_skill732_VARS_itm = &$itm; unset($itm); } else {$__VAR_DUMP_MOD_skill732_VARS_itm = NULL;}if(isset($itmk)) {$__VAR_DUMP_MOD_skill732_VARS_itmk = &$itmk; unset($itmk); } else {$__VAR_DUMP_MOD_skill732_VARS_itmk = NULL;}if(isset($itme)) {$__VAR_DUMP_MOD_skill732_VARS_itme = &$itme; unset($itme); } else {$__VAR_DUMP_MOD_skill732_VARS_itme = NULL;}if(isset($itms)) {$__VAR_DUMP_MOD_skill732_VARS_itms = &$itms; unset($itms); } else {$__VAR_DUMP_MOD_skill732_VARS_itms = NULL;}if(isset($itmsk)) {$__VAR_DUMP_MOD_skill732_VARS_itmsk = &$itmsk; unset($itmsk); } else {$__VAR_DUMP_MOD_skill732_VARS_itmsk = NULL;}
		//======== Start of contents from mod ex_uselog ========
		do{
			$___TMP_MOD_ex_uselog_FUNC_itemuse_RET = NULL;

		
		$itmsk = &$theitem['itmsk'];
		$headlog = \itemmain\check_in_itmsk('^hlog', $itmsk);
		$taillog = \itemmain\check_in_itmsk('^tlog', $itmsk);
		if (!empty($headlog))
		{
			
			$log .= \attrbase\base64_decode_comp_itmsk($headlog);
		}
if(isset($itmsk)) {$__VAR_DUMP_MOD_ex_uselog_VARS_itmsk = &$itmsk; unset($itmsk); } else {$__VAR_DUMP_MOD_ex_uselog_VARS_itmsk = NULL;}
		//======== Start of contents from mod ex_cursed ========
		do{
			$___TMP_MOD_ex_cursed_FUNC_itemuse_RET = NULL;

		
		
		$itm=&$theitem['itm']; $itmk=&$theitem['itmk'];
		$itme=&$theitem['itme']; $itms=&$theitem['itms']; $itmsk=&$theitem['itmsk'];
		
		if(strpos ( $itmk, 'W' ) === 0 || strpos ( $itmk, 'D' ) === 0 || strpos ( $itmk, 'A' ) === 0) {
			
			if(strpos ( $itmk, 'W' ) === 0) $obj = 'wep';
			elseif(strpos ( $itmk, 'DB' ) === 0) $obj = 'arb';
			elseif(strpos ( $itmk, 'DH' ) === 0) $obj = 'arh';
			elseif(strpos ( $itmk, 'DA' ) === 0) $obj = 'ara';
			elseif(strpos ( $itmk, 'DF' ) === 0) $obj = 'arf';
			elseif(strpos ( $itmk, 'A' ) === 0) $obj = 'art';
			if(\itemmain\check_in_itmsk('O', ${$obj.'sk'})){
				if(\ex_cursed\check_enkan ()) {
					$log .= '<span class="lime b">圆环之理的光辉暂时消解了道具的诅咒。</span><br>';
				}else{
					$log .= '<span class="red b">摆脱这个道具的诅咒是不可能的。</span><br>';
					$___TMP_MOD_ex_cursed_FUNC_itemuse_RET = NULL;
			break; 
				}
			}
		}
if(isset($itm)) {$__VAR_DUMP_MOD_ex_cursed_VARS_itm = &$itm; unset($itm); } else {$__VAR_DUMP_MOD_ex_cursed_VARS_itm = NULL;}if(isset($itmk)) {$__VAR_DUMP_MOD_ex_cursed_VARS_itmk = &$itmk; unset($itmk); } else {$__VAR_DUMP_MOD_ex_cursed_VARS_itmk = NULL;}if(isset($itme)) {$__VAR_DUMP_MOD_ex_cursed_VARS_itme = &$itme; unset($itme); } else {$__VAR_DUMP_MOD_ex_cursed_VARS_itme = NULL;}if(isset($itms)) {$__VAR_DUMP_MOD_ex_cursed_VARS_itms = &$itms; unset($itms); } else {$__VAR_DUMP_MOD_ex_cursed_VARS_itms = NULL;}if(isset($itmsk)) {$__VAR_DUMP_MOD_ex_cursed_VARS_itmsk = &$itmsk; unset($itmsk); } else {$__VAR_DUMP_MOD_ex_cursed_VARS_itmsk = NULL;}
		//======== Start of contents from mod ex_attr_silencer ========
		do{
			$___TMP_MOD_ex_attr_silencer_FUNC_itemuse_RET = NULL;

		
		
		
		
		$itm=&$theitem['itm']; $itmk=&$theitem['itmk'];
		$itme=&$theitem['itme']; $itms=&$theitem['itms']; $itmsk=&$theitem['itmsk'];
		
		if (strpos ( $itmk, 'Y' ) === 0 || strpos ( $itmk, 'Z' ) === 0) 
			if ($itm == '消音器') 
			{
				if (strpos ( $wepk, 'WG' ) !== 0 && strpos ( $wepk, 'WJ' ) !== 0) {
					$log .= '你没有装备枪械，不能使用消音器。<br>';
				} elseif (\itemmain\check_in_itmsk('S', $wepsk)) {
					$log .= "你的武器已经安装了消音器。<br>";
				} else {
					$wepsk .= 'S';
					$log .= "你给<span class=\"yellow b\">$wep</span>安装了<span class=\"yellow b\">$itm</span>。<br>";
					\itemmain\itms_reduce($theitem);
				}
				$___TMP_MOD_ex_attr_silencer_FUNC_itemuse_RET = NULL;
			break; 
			}
if(isset($itm)) {$__VAR_DUMP_MOD_ex_attr_silencer_VARS_itm = &$itm; unset($itm); } else {$__VAR_DUMP_MOD_ex_attr_silencer_VARS_itm = NULL;}if(isset($itmk)) {$__VAR_DUMP_MOD_ex_attr_silencer_VARS_itmk = &$itmk; unset($itmk); } else {$__VAR_DUMP_MOD_ex_attr_silencer_VARS_itmk = NULL;}if(isset($itme)) {$__VAR_DUMP_MOD_ex_attr_silencer_VARS_itme = &$itme; unset($itme); } else {$__VAR_DUMP_MOD_ex_attr_silencer_VARS_itme = NULL;}if(isset($itms)) {$__VAR_DUMP_MOD_ex_attr_silencer_VARS_itms = &$itms; unset($itms); } else {$__VAR_DUMP_MOD_ex_attr_silencer_VARS_itms = NULL;}if(isset($itmsk)) {$__VAR_DUMP_MOD_ex_attr_silencer_VARS_itmsk = &$itmsk; unset($itmsk); } else {$__VAR_DUMP_MOD_ex_attr_silencer_VARS_itmsk = NULL;}
		//======== Start of contents from mod rage ========
		do{
			$___TMP_MOD_rage_FUNC_itemuse_RET = NULL;

		
		
		do { global $___LOCAL_WOUND__VARS__inf_place,$___LOCAL_WOUND__VARS__infinfo,$___LOCAL_WOUND__VARS__infname,$___LOCAL_WOUND__VARS__infskillinfo,$___LOCAL_WOUND__VARS__wep_infatt,$___LOCAL_WOUND__VARS__wep_infobbs,$___LOCAL_WOUND__VARS__inf_recover_sp_cost; $inf_place=&$___LOCAL_WOUND__VARS__inf_place; $infinfo=&$___LOCAL_WOUND__VARS__infinfo; $infname=&$___LOCAL_WOUND__VARS__infname; $infskillinfo=&$___LOCAL_WOUND__VARS__infskillinfo; $wep_infatt=&$___LOCAL_WOUND__VARS__wep_infatt; $wep_infobbs=&$___LOCAL_WOUND__VARS__wep_infobbs; $inf_recover_sp_cost=&$___LOCAL_WOUND__VARS__inf_recover_sp_cost;  global $___LOCAL_RAGE__VARS__max_rage,$___LOCAL_RAGE__VARS__rest_rage_time; $max_rage=&$___LOCAL_RAGE__VARS__max_rage; $rest_rage_time=&$___LOCAL_RAGE__VARS__rest_rage_time;   } while (0);
		
		$itm=&$theitem['itm']; $itmk=&$theitem['itmk'];
		$itme=&$theitem['itme']; $itms=&$theitem['itms']; $itmsk=&$theitem['itmsk'];
		
		if (strpos ( $itmk, 'HR' ) === 0) 
		{
			$rageup = \rage\get_rage ($itme);
			if ($rageup<=0)
			{
				$log.='你已经出离愤怒了，动怒伤肝，还是歇歇吧！<br>';
				$___TMP_MOD_rage_FUNC_itemuse_RET = NULL;
			break; 
			}
			$log.="你吃了一口{$itm}，顿时感觉心中充满了愤怒。你的怒气值增加了<span class=\"yellow b\">{$rageup}</span>点！<br>";
			\itemmain\itms_reduce($theitem);
			$___TMP_MOD_rage_FUNC_itemuse_RET = NULL;
			break; 
		}
if(isset($itm)) {$__VAR_DUMP_MOD_rage_VARS_itm = &$itm; unset($itm); } else {$__VAR_DUMP_MOD_rage_VARS_itm = NULL;}if(isset($itmk)) {$__VAR_DUMP_MOD_rage_VARS_itmk = &$itmk; unset($itmk); } else {$__VAR_DUMP_MOD_rage_VARS_itmk = NULL;}if(isset($itme)) {$__VAR_DUMP_MOD_rage_VARS_itme = &$itme; unset($itme); } else {$__VAR_DUMP_MOD_rage_VARS_itme = NULL;}if(isset($itms)) {$__VAR_DUMP_MOD_rage_VARS_itms = &$itms; unset($itms); } else {$__VAR_DUMP_MOD_rage_VARS_itms = NULL;}if(isset($itmsk)) {$__VAR_DUMP_MOD_rage_VARS_itmsk = &$itmsk; unset($itmsk); } else {$__VAR_DUMP_MOD_rage_VARS_itmsk = NULL;}
		//======== Start of contents from mod wep_b ========
		do{
			$___TMP_MOD_wep_b_FUNC_itemuse_RET = NULL;

		
		
		
		$itm=&$theitem['itm']; $itmk=&$theitem['itmk'];
		$itme=&$theitem['itme']; $itms=&$theitem['itms']; $itmsk=&$theitem['itmsk'];
		
		if (strpos ( $itmk, 'GA' ) === 0) 
		{
			if (strpos ( $wepk, 'WB' ) !== 0) {
				$log .= "<span class=\"red b\">你没有装备弓，不能给武器上箭。</span><br>";
				$mode = 'command';
				$___TMP_MOD_wep_b_FUNC_itemuse_RET = NULL;
			break; 
			} elseif('0' === $theitem['itmn']) {
				
				$log .= "你一只手捏着弓箭，一只手抓着刚捡到的箭矢，没法马上弯弓搭箭。<span class=\"red b\">还是先把箭矢收进包裹里吧。</span><br>";
				$mode = 'command';
				$___TMP_MOD_wep_b_FUNC_itemuse_RET = NULL;
			break; 
			} 
			\wep_b\itemuse_uga ($theitem);
			$___TMP_MOD_wep_b_FUNC_itemuse_RET = NULL;
			break; 
		}
if(isset($itm)) {$__VAR_DUMP_MOD_wep_b_VARS_itm = &$itm; unset($itm); } else {$__VAR_DUMP_MOD_wep_b_VARS_itm = NULL;}if(isset($itmk)) {$__VAR_DUMP_MOD_wep_b_VARS_itmk = &$itmk; unset($itmk); } else {$__VAR_DUMP_MOD_wep_b_VARS_itmk = NULL;}if(isset($itme)) {$__VAR_DUMP_MOD_wep_b_VARS_itme = &$itme; unset($itme); } else {$__VAR_DUMP_MOD_wep_b_VARS_itme = NULL;}if(isset($itms)) {$__VAR_DUMP_MOD_wep_b_VARS_itms = &$itms; unset($itms); } else {$__VAR_DUMP_MOD_wep_b_VARS_itms = NULL;}if(isset($itmsk)) {$__VAR_DUMP_MOD_wep_b_VARS_itmsk = &$itmsk; unset($itmsk); } else {$__VAR_DUMP_MOD_wep_b_VARS_itmsk = NULL;}
		//======== Start of contents from mod item_randskills ========
		do{
			$___TMP_MOD_item_randskills_FUNC_itemuse_RET = NULL;

		
		
		
		
		$itm=&$theitem['itm']; $itmk=&$theitem['itmk'];
		$itme=&$theitem['itme']; $itms=&$theitem['itms']; $itmsk=&$theitem['itmsk'];
		
		if (strpos ( $itmk, 'Y' ) === 0 || strpos ( $itmk, 'Z' ) === 0) 
		{
			if ($itm == '四面骰') {
				do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;   } while (0);
				$log.="你使用了<span class=\"yellow b\">{$itm}</span>。<br>";
				
				$acquired_skills = \skillbase\get_acquired_skill_array($sdata);
				$count = 0;
				
				if (!empty($acquired_skills))
				{
					foreach ($acquired_skills as $skillid)
					{
						if (isset($clubskillname[$skillid]) && (strpos(constant('MOD_SKILL'.$skillid.'_INFO'),'hidden;') === false))
						{
							\skillbase\skill_lost($skillid, $sdata);
							$count += 1;
						}
					}
				}
				
				if ($count > 0)
				{
					\item_randskills\get_rand_clubskill ($sdata, $count);
					$log .= "随着骰子的转动，你感到自己的身体变得焕然一新！<br>";
				}
				else
				{
					$log .= "但是，这个骰子对你好像没什么用的样子……<br>";
				}
				\itemmain\itms_reduce($theitem);
				$___TMP_MOD_item_randskills_FUNC_itemuse_RET = NULL;
			break; 
			}	
		}
		elseif (strpos($itmk, 'SC') === 0)
		{
			do { global $___LOCAL_ITEM_RANDSKILLS__VARS__rs_allowclublist,$___LOCAL_ITEM_RANDSKILLS__VARS__rs_banlist,$___LOCAL_ITEM_RANDSKILLS__VARS__rs_feature,$___LOCAL_ITEM_RANDSKILLS__VARS__rs_cardskills; $rs_allowclublist=&$___LOCAL_ITEM_RANDSKILLS__VARS__rs_allowclublist; $rs_banlist=&$___LOCAL_ITEM_RANDSKILLS__VARS__rs_banlist; $rs_feature=&$___LOCAL_ITEM_RANDSKILLS__VARS__rs_feature; $rs_cardskills=&$___LOCAL_ITEM_RANDSKILLS__VARS__rs_cardskills;   } while (0);
			$log .= "你使用了<span class=\"yellow b\">{$itm}</span>。<br>";
			if ($itmk[3] === '1')
			{
				$sclist = \item_randskills\get_skcore_skilllist ($itmk, $itmsk);
				$skcore_choice = get_var_input('skcore_choice');
				if (empty($skcore_choice))
				{
					ob_start();
					include template(MOD_ITEM_RANDSKILLS_USE_SKCORE);
					$cmd = ob_get_contents();
					ob_end_clean();	
					$___TMP_MOD_item_randskills_FUNC_itemuse_RET = NULL;
			break; 
				}
				else
				{
					if (!in_array((int)$skcore_choice, array(1,2,3)))
					{
						$log .= '参数不合法。<br>';
						$mode = 'command';
						$___TMP_MOD_item_randskills_FUNC_itemuse_RET = NULL;
			break; 
					}
					else
					{
						do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;  global $___LOCAL_ITEM_RANDSKILLS__VARS__rs_allowclublist,$___LOCAL_ITEM_RANDSKILLS__VARS__rs_banlist,$___LOCAL_ITEM_RANDSKILLS__VARS__rs_feature,$___LOCAL_ITEM_RANDSKILLS__VARS__rs_cardskills; $rs_allowclublist=&$___LOCAL_ITEM_RANDSKILLS__VARS__rs_allowclublist; $rs_banlist=&$___LOCAL_ITEM_RANDSKILLS__VARS__rs_banlist; $rs_feature=&$___LOCAL_ITEM_RANDSKILLS__VARS__rs_feature; $rs_cardskills=&$___LOCAL_ITEM_RANDSKILLS__VARS__rs_cardskills;   } while (0);
						$skillid = $sclist[(int)$skcore_choice-1];
						\skillbase\skill_acquire($skillid, $sdata);
						if (array_key_exists($skillid, $rs_feature))
						{
							foreach ($rs_feature[$skillid] as $extra_skillid) \skillbase\skill_acquire($extra_skillid, $pa);
						}
						$log .= "你习得了技能<span class=\"yellow b\">「{$clubskillname[$skillid]}」</span>！<br>";
						\item_randskills\use_skcore_success ($sdata);
					}
				}
				\itemmain\itms_reduce($theitem);
				$___TMP_MOD_item_randskills_FUNC_itemuse_RET = NULL;
			break; 
			}
			elseif ($itmk[3] === '2')
			{
				if ($itmk[2] === '0') $rs_skills = \item_randskills\get_rand_clubskill ($sdata, 1);
				elseif (in_array($itmk[2], array('S','A','B','C','X')))
				{
					$ls_skills = array_diff($rs_cardskills[$itmk[2]], \skillbase\get_acquired_skill_array($sdata));		
					if (empty($ls_skills)) $rs_skills = array();
					else
					{
						$skillid = array_randompick($ls_skills, 1);
						\skillbase\skill_acquire($skillid, $sdata);
						$rs_skills = [$skillid];
					}
				}
				if (!empty($rs_skills))
				{
					do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;   } while (0);
					$log .= "你习得了技能<span class=\"yellow b\">「{$clubskillname[$rs_skills[0]]}」</span>！<br>";
					\item_randskills\use_skcore_success ($sdata);
				}
				else
				{
					$log .= "但是好像什么也没有发生。<br>";
				}
				\itemmain\itms_reduce($theitem);
				$___TMP_MOD_item_randskills_FUNC_itemuse_RET = NULL;
			break; 
			}
		}
if(isset($itm)) {$__VAR_DUMP_MOD_item_randskills_VARS_itm = &$itm; unset($itm); } else {$__VAR_DUMP_MOD_item_randskills_VARS_itm = NULL;}if(isset($itmk)) {$__VAR_DUMP_MOD_item_randskills_VARS_itmk = &$itmk; unset($itmk); } else {$__VAR_DUMP_MOD_item_randskills_VARS_itmk = NULL;}if(isset($itme)) {$__VAR_DUMP_MOD_item_randskills_VARS_itme = &$itme; unset($itme); } else {$__VAR_DUMP_MOD_item_randskills_VARS_itme = NULL;}if(isset($itms)) {$__VAR_DUMP_MOD_item_randskills_VARS_itms = &$itms; unset($itms); } else {$__VAR_DUMP_MOD_item_randskills_VARS_itms = NULL;}if(isset($itmsk)) {$__VAR_DUMP_MOD_item_randskills_VARS_itmsk = &$itmsk; unset($itmsk); } else {$__VAR_DUMP_MOD_item_randskills_VARS_itmsk = NULL;}
		//======== Start of contents from mod skill329 ========
		do{
			$___TMP_MOD_skill329_FUNC_itemuse_RET = NULL;

		
		
		$ach329_flag = 0;
		if('破灭之诗' == $theitem['itm'] && 'Y' == $theitem['itmk']){
			$ach329_flag = 1;
		}
		//======== Start of contents from mod addnpc ========
		do{
			$___TMP_MOD_addnpc_FUNC_itemuse_RET = NULL;

		
		
		
		
		$itm=&$theitem['itm']; $itmk=&$theitem['itmk'];
		$itme=&$theitem['itme']; $itms=&$theitem['itms']; $itmsk=&$theitem['itmsk'];
		
		if (strpos ( $itmk, 'Y' ) === 0 || strpos ( $itmk, 'Z' ) === 0) 
		{
			if ($itm == '挑战者之印') {
				if (in_array($gametype,$pve_ignore_mode))
				{
					$log.="你使用了{$itm}，但是什么也没有发生（当前游戏模式下不允许PVE）。<br>";
					$___TMP_MOD_addnpc_FUNC_itemuse_RET = NULL;
			break; 
				}
				$log .= '你已经呼唤了幻影执行官，现在寻找并击败他们，<br>并且搜寻他们的ID卡吧！<br>';
				\addnpc\addnpc ( 7, 0,1);
				\addnpc\addnpc ( 7, 1,1);
				\addnpc\addnpc ( 7, 2,1);
				addnews ($now , 'secphase', $name);
				$itm = $itmk = $itmsk = '';
				$itme = $itms = 0;
				$___TMP_MOD_addnpc_FUNC_itemuse_RET = NULL;
			break; 
			} elseif ($itm == '破灭之诗') {
				if (in_array($gametype,$pve_ignore_mode))
				{
					$log.="你使用了{$itm}，但是什么也没有发生（当前游戏模式下不允许PVE）。<br>";
					$___TMP_MOD_addnpc_FUNC_itemuse_RET = NULL;
			break; 
				}
				$rp = 0;
				$log .= '在你唱出那单一的旋律的霎那，<br>整个虚拟世界起了翻天覆地的变化……<br>';
				\addnpc\addnpc ( 4, 0,1);
				do { global $___LOCAL_WEATHER__VARS__wthinfo,$___LOCAL_WEATHER__VARS__weather_itemfind_obbs,$___LOCAL_WEATHER__VARS__weather_meetman_obbs,$___LOCAL_WEATHER__VARS__weather_active_obbs,$___LOCAL_WEATHER__VARS__weather_attack_modifier,$___LOCAL_WEATHER__VARS__weather_defend_modifier,$___LOCAL_WEATHER__VARS__weather_fog; $wthinfo=&$___LOCAL_WEATHER__VARS__wthinfo; $weather_itemfind_obbs=&$___LOCAL_WEATHER__VARS__weather_itemfind_obbs; $weather_meetman_obbs=&$___LOCAL_WEATHER__VARS__weather_meetman_obbs; $weather_active_obbs=&$___LOCAL_WEATHER__VARS__weather_active_obbs; $weather_attack_modifier=&$___LOCAL_WEATHER__VARS__weather_attack_modifier; $weather_defend_modifier=&$___LOCAL_WEATHER__VARS__weather_defend_modifier; $weather_fog=&$___LOCAL_WEATHER__VARS__weather_fog;   } while (0);
				$log .= '世界响应着这旋律，产生了异变……<br>';
				\weather\wthchange( $itm, 95);
				addnews ($now , 'thiphase', $name);
				$hack = 1;
				$log .= '因为破灭之歌的作用，全部锁定被打破了！<br>';
				
				addnews($now,'hackb',$name);
				\sys\systemputchat($now,'hack');
				$gamevars['forbid_antiAFK'] = 1;
				save_gameinfo();
				$itm = $itmk = $itmsk = '';
				$itme = $itms = 0;
				$___TMP_MOD_addnpc_FUNC_itemuse_RET = NULL;
			break; 
			} elseif ($itm == '黑色碎片') {
				if (in_array($gametype,$pve_ignore_mode))
				{
					$log.="你使用了{$itm}，但是什么也没有发生（当前游戏模式下不允许PVE）。<br>";
					$___TMP_MOD_addnpc_FUNC_itemuse_RET = NULL;
			break; 
				}
				$log .= '你已经呼唤了一个未知的存在，现在寻找并击败她，<br>并且搜寻她的游戏解除钥匙吧！<br>';
				addnews ($now , 'dfphase', $name);
				\addnpc\addnpc ( 12, 0,1);
				
				$itm = $itmk = $itmsk = '';
				$itme = $itms = 0;
				$___TMP_MOD_addnpc_FUNC_itemuse_RET = NULL;
			break; 
			}
		}
if(isset($itm)) {$__VAR_DUMP_MOD_addnpc_VARS_itm = &$itm; unset($itm); } else {$__VAR_DUMP_MOD_addnpc_VARS_itm = NULL;}if(isset($itmk)) {$__VAR_DUMP_MOD_addnpc_VARS_itmk = &$itmk; unset($itmk); } else {$__VAR_DUMP_MOD_addnpc_VARS_itmk = NULL;}if(isset($itme)) {$__VAR_DUMP_MOD_addnpc_VARS_itme = &$itme; unset($itme); } else {$__VAR_DUMP_MOD_addnpc_VARS_itme = NULL;}if(isset($itms)) {$__VAR_DUMP_MOD_addnpc_VARS_itms = &$itms; unset($itms); } else {$__VAR_DUMP_MOD_addnpc_VARS_itms = NULL;}if(isset($itmsk)) {$__VAR_DUMP_MOD_addnpc_VARS_itmsk = &$itmsk; unset($itmsk); } else {$__VAR_DUMP_MOD_addnpc_VARS_itmsk = NULL;}
		//======== Start of contents from mod weather ========
		do{
			$___TMP_MOD_weather_FUNC_itemuse_RET = NULL;

		
		
		
		
		$itm=&$theitem['itm']; $itmk=&$theitem['itmk'];
		$itme=&$theitem['itme']; $itms=&$theitem['itms']; $itmsk=&$theitem['itmsk'];
		
		if ( strpos( $itmk,'EW' ) ===0 )	
		{
			\weather\wthchange ( $itm,$itmsk);
			\itemmain\itms_reduce($theitem);
			$___TMP_MOD_weather_FUNC_itemuse_RET = NULL;
			break; 
		}
if(isset($itm)) {$__VAR_DUMP_MOD_weather_VARS_itm = &$itm; unset($itm); } else {$__VAR_DUMP_MOD_weather_VARS_itm = NULL;}if(isset($itmk)) {$__VAR_DUMP_MOD_weather_VARS_itmk = &$itmk; unset($itmk); } else {$__VAR_DUMP_MOD_weather_VARS_itmk = NULL;}if(isset($itme)) {$__VAR_DUMP_MOD_weather_VARS_itme = &$itme; unset($itme); } else {$__VAR_DUMP_MOD_weather_VARS_itme = NULL;}if(isset($itms)) {$__VAR_DUMP_MOD_weather_VARS_itms = &$itms; unset($itms); } else {$__VAR_DUMP_MOD_weather_VARS_itms = NULL;}if(isset($itmsk)) {$__VAR_DUMP_MOD_weather_VARS_itmsk = &$itmsk; unset($itmsk); } else {$__VAR_DUMP_MOD_weather_VARS_itmsk = NULL;}
		//======== Start of contents from mod skill600 ========
		do{
			$___TMP_MOD_skill600_FUNC_itemuse_RET = NULL;

		
		do {  __MODULE_NULLFUNCTION__();  } while (0);
		if ((strpos ( $theitem['itmk'], 'C' ) === 0)&&(1 == \skill600\check_skill600_state ())) 
		{
			$log .= '你喝了一小口药剂，感觉自己根本就喝不下去！';
			$mode = 'command';
			$___TMP_MOD_skill600_FUNC_itemuse_RET = NULL;
			break; 
		}
if(isset($mode)) {$__VAR_DUMP_MOD_skill600_VARS_mode = $mode; unset($mode); } else {$__VAR_DUMP_MOD_skill600_VARS_mode = NULL;} 
		//======== Start of contents from mod skill557 ========
		do{
			$___TMP_MOD_skill557_FUNC_itemuse_RET = NULL;

		
		
		if (\skillbase\skill_query(557) && strpos ( $theitem['itmk'], 'DF' ) === 0) 
		{			
			$skill557_choice = get_var_input('skill557_choice');
			
			if (empty($skill557_choice))
			{
				ob_start();
				include template(MOD_SKILL557_CASTSK557);
				$cmd = ob_get_contents();
				ob_end_clean();	
				$___TMP_MOD_skill557_FUNC_itemuse_RET = NULL;
			break; 
			}
			else
			{
				
				if ('ara' != $skill557_choice && 'arf' != $skill557_choice)
				{
					$log.='参数不合法。<br>';
					$mode = 'command';
					$___TMP_MOD_skill557_FUNC_itemuse_RET = NULL;
			break; 
				}
				\armor\use_armor($theitem, $skill557_choice);
				$___TMP_MOD_skill557_FUNC_itemuse_RET = NULL;
			break; 
			}
		}
		//======== Start of contents from mod armor_art ========
		do{
			$___TMP_MOD_armor_art_FUNC_itemuse_RET = NULL;

		
		
		
		
		$itm=&$theitem['itm']; $itmk=&$theitem['itmk'];
		$itme=&$theitem['itme']; $itms=&$theitem['itms']; $itmsk=&$theitem['itmsk'];
		
		if (strpos ( $itmk, 'A' ) === 0)
		{
			$eqp = 'art';
			$noeqp = '';
			
			if (($noeqp && strpos ( ${$eqp.'k'}, $noeqp ) === 0) || ! ${$eqp.'s'}) {
				${$eqp} = $itm;
				${$eqp.'k'} = $itmk;
				${$eqp.'e'} = $itme;
				${$eqp.'s'} = $itms;
				${$eqp.'sk'} = $itmsk;
				$log .= "装备了<span class=\"yellow b\">$itm</span>。<br>";
				$itm = $itmk = $itmsk = '';
				$itme = $itms = 0;
			} else {
				swap(${$eqp},$itm);
				swap(${$eqp.'k'},$itmk);
				swap(${$eqp.'e'},$itme);
				swap(${$eqp.'s'},$itms);
				swap(${$eqp.'sk'},$itmsk);
				$log .= "卸下了<span class=\"red b\">$itm</span>，装备了<span class=\"yellow b\">${$eqp}</span>。<br>";
			}
			$___TMP_MOD_armor_art_FUNC_itemuse_RET = NULL;
			break; 
		}
if(isset($itm)) {$__VAR_DUMP_MOD_armor_art_VARS_itm = &$itm; unset($itm); } else {$__VAR_DUMP_MOD_armor_art_VARS_itm = NULL;}if(isset($itmk)) {$__VAR_DUMP_MOD_armor_art_VARS_itmk = &$itmk; unset($itmk); } else {$__VAR_DUMP_MOD_armor_art_VARS_itmk = NULL;}if(isset($itme)) {$__VAR_DUMP_MOD_armor_art_VARS_itme = &$itme; unset($itme); } else {$__VAR_DUMP_MOD_armor_art_VARS_itme = NULL;}if(isset($itms)) {$__VAR_DUMP_MOD_armor_art_VARS_itms = &$itms; unset($itms); } else {$__VAR_DUMP_MOD_armor_art_VARS_itms = NULL;}if(isset($itmsk)) {$__VAR_DUMP_MOD_armor_art_VARS_itmsk = &$itmsk; unset($itmsk); } else {$__VAR_DUMP_MOD_armor_art_VARS_itmsk = NULL;}
		//======== Start of contents from mod ammunition ========
		do{
			$___TMP_MOD_ammunition_FUNC_itemuse_RET = NULL;

		
		
		
		
		$itm=&$theitem['itm']; $itmk=&$theitem['itmk'];
		$itme=&$theitem['itme']; $itms=&$theitem['itms']; $itmsk=&$theitem['itmsk'];
		
		if (strpos ( $itmk, 'GB' ) === 0) 
		{
			\ammunition\itemuse_ugb ($theitem);
			$___TMP_MOD_ammunition_FUNC_itemuse_RET = NULL;
			break; 
		}
if(isset($itm)) {$__VAR_DUMP_MOD_ammunition_VARS_itm = &$itm; unset($itm); } else {$__VAR_DUMP_MOD_ammunition_VARS_itm = NULL;}if(isset($itmk)) {$__VAR_DUMP_MOD_ammunition_VARS_itmk = &$itmk; unset($itmk); } else {$__VAR_DUMP_MOD_ammunition_VARS_itmk = NULL;}if(isset($itme)) {$__VAR_DUMP_MOD_ammunition_VARS_itme = &$itme; unset($itme); } else {$__VAR_DUMP_MOD_ammunition_VARS_itme = NULL;}if(isset($itms)) {$__VAR_DUMP_MOD_ammunition_VARS_itms = &$itms; unset($itms); } else {$__VAR_DUMP_MOD_ammunition_VARS_itms = NULL;}if(isset($itmsk)) {$__VAR_DUMP_MOD_ammunition_VARS_itmsk = &$itmsk; unset($itmsk); } else {$__VAR_DUMP_MOD_ammunition_VARS_itmsk = NULL;}
		//======== Start of contents from mod item_slip ========
		do{
			$___TMP_MOD_item_slip_FUNC_itemuse_RET = NULL;

		
		
		do { global $___LOCAL_ITEM_SLIP__VARS__item_slip_npclist,$___LOCAL_ITEM_SLIP__VARS__item_slip_hint,$___LOCAL_ITEM_SLIP__VARS__item_slip_npc,$___LOCAL_ITEM_SLIP__VARS__item_slip_metagame_list; $item_slip_npclist=&$___LOCAL_ITEM_SLIP__VARS__item_slip_npclist; $item_slip_hint=&$___LOCAL_ITEM_SLIP__VARS__item_slip_hint; $item_slip_npc=&$___LOCAL_ITEM_SLIP__VARS__item_slip_npc; $item_slip_metagame_list=&$___LOCAL_ITEM_SLIP__VARS__item_slip_metagame_list;   } while (0);
		
		$itm=&$theitem['itm']; $itmk=&$theitem['itmk'];
		$itme=&$theitem['itme']; $itms=&$theitem['itms']; $itmsk=&$theitem['itmsk'];
		if (('Y' == $itmk || 'Z' == $itmk) && strpos($itm,'提示纸条') === 0) {
			
			$slip_mark = str_replace('提示纸条','',$itm);
			if(!empty($item_slip_hint[$slip_mark])) {
				$log .= '你读着纸条上的内容：<br><br>'.$item_slip_hint[$slip_mark].'<br><br>';
			}else{
				$log .= '你打开了纸条，发现是一张白纸。<br>';
			}
			
			
			if(!empty($itmsk && is_numeric($itmsk))){
				if($itmsk >= 500 && $itmsk <= 1000){
					$log .= '除此之外，纸条上有一句意味深长的话：<br>“有的提示在字里，有的提示在行间，有的提示甚至在游戏之外。”后面是一大段空白。<br><br>';
					$log .= '<!--'.gurl().'gamedata/cache/'.$itmsk.'.htm-->';
					$log .= '<br><br>这是什么意思呢？<br><br>';
				}elseif($itmsk > 1000){
					$nid = floor($itmsk / 1000);
					$npls = $itmsk % 1000;
					$result = $db->query("SELECT * FROM {$tablepre}players WHERE pid='$nid' AND type>0");
					if($db->num_rows($result)){
						do { global $___LOCAL_NPC__VARS__npcinit,$___LOCAL_NPC__VARS__npcinfo,$___LOCAL_NPC__VARS__killzone_resistant_typelist,$___LOCAL_NPC__VARS__npc_typeinfo,$___LOCAL_NPC__VARS__npc_killmsginfo,$___LOCAL_NPC__VARS__npc_lwinfo,$___LOCAL_NPC__VARS__npc_revive_info; $npcinit=&$___LOCAL_NPC__VARS__npcinit; $npcinfo=&$___LOCAL_NPC__VARS__npcinfo; $killzone_resistant_typelist=&$___LOCAL_NPC__VARS__killzone_resistant_typelist; $npc_typeinfo=&$___LOCAL_NPC__VARS__npc_typeinfo; $npc_killmsginfo=&$___LOCAL_NPC__VARS__npc_killmsginfo; $npc_lwinfo=&$___LOCAL_NPC__VARS__npc_lwinfo; $npc_revive_info=&$___LOCAL_NPC__VARS__npc_revive_info;  global $___LOCAL_MAP__VARS__all_plsno_cache,$___LOCAL_MAP__VARS__areainterval,$___LOCAL_MAP__VARS__areaadd,$___LOCAL_MAP__VARS__areawarntime,$___LOCAL_MAP__VARS__arealimit,$___LOCAL_MAP__VARS__areaesc,$___LOCAL_MAP__VARS__area_on_start,$___LOCAL_MAP__VARS__dangerous_zone,$___LOCAL_MAP__VARS__plsinfo,$___LOCAL_MAP__VARS__plsinfo_o, $___LOCAL_MAP__VARS__plsinfo_disp,$___LOCAL_MAP__VARS__plsinfo_for_short,$___LOCAL_MAP__VARS__xyinfo,$___LOCAL_MAP__VARS__areainfo; $all_plsno_cache=&$___LOCAL_MAP__VARS__all_plsno_cache; $areainterval=&$___LOCAL_MAP__VARS__areainterval; $areaadd=&$___LOCAL_MAP__VARS__areaadd; $areawarntime=&$___LOCAL_MAP__VARS__areawarntime; $arealimit=&$___LOCAL_MAP__VARS__arealimit; $areaesc=&$___LOCAL_MAP__VARS__areaesc; $area_on_start=&$___LOCAL_MAP__VARS__area_on_start; $dangerous_zone=&$___LOCAL_MAP__VARS__dangerous_zone; $plsinfo=&$___LOCAL_MAP__VARS__plsinfo; $plsinfo_o=&$___LOCAL_MAP__VARS__plsinfo_o;  $plsinfo_disp=&$___LOCAL_MAP__VARS__plsinfo_disp; $plsinfo_for_short=&$___LOCAL_MAP__VARS__plsinfo_for_short; $xyinfo=&$___LOCAL_MAP__VARS__xyinfo; $areainfo=&$___LOCAL_MAP__VARS__areainfo;   } while (0);
						$edata = $db->fetch_array($result);
						$log .= '除此之外，纸条上还草草写着……<br>“<span class="yellow b">「'.$npc_typeinfo[$edata['type']].'」'.$edata['name'].'</span>在游戏开始时位于<span class="yellow b">'.$plsinfo[$npls].'</span>。”<br><br>';
						if(\gameflow_duel\is_gamestate_duel()){
							$log .= '不过，游戏已经进入了死斗阶段。<span class="yellow b">'.$edata['name'].'肯定已经不在那里了。</span><br><br>';
						}
						elseif($edata['pls'] != $npls) {
							$log .= '不过，游戏已经过去一段时间了。<span class="yellow b">你怀疑'.$edata['name'].'现在已经不在那里了。</span><br><br>';
						}
					}else{
						$log .= '纸条上还有一些字迹被擦掉了。';
					}
				}
			}
			$___TMP_MOD_item_slip_FUNC_itemuse_RET = NULL;
			break; 
		}
if(isset($itm)) {$__VAR_DUMP_MOD_item_slip_VARS_itm = &$itm; unset($itm); } else {$__VAR_DUMP_MOD_item_slip_VARS_itm = NULL;}if(isset($itmk)) {$__VAR_DUMP_MOD_item_slip_VARS_itmk = &$itmk; unset($itmk); } else {$__VAR_DUMP_MOD_item_slip_VARS_itmk = NULL;}if(isset($itme)) {$__VAR_DUMP_MOD_item_slip_VARS_itme = &$itme; unset($itme); } else {$__VAR_DUMP_MOD_item_slip_VARS_itme = NULL;}if(isset($itms)) {$__VAR_DUMP_MOD_item_slip_VARS_itms = &$itms; unset($itms); } else {$__VAR_DUMP_MOD_item_slip_VARS_itms = NULL;}if(isset($itmsk)) {$__VAR_DUMP_MOD_item_slip_VARS_itmsk = &$itmsk; unset($itmsk); } else {$__VAR_DUMP_MOD_item_slip_VARS_itmsk = NULL;}
		//======== Start of contents from mod item_uc ========
		do{
			$___TMP_MOD_item_uc_FUNC_itemuse_RET = NULL;

		
		
		do { global $___LOCAL_WOUND__VARS__inf_place,$___LOCAL_WOUND__VARS__infinfo,$___LOCAL_WOUND__VARS__infname,$___LOCAL_WOUND__VARS__infskillinfo,$___LOCAL_WOUND__VARS__wep_infatt,$___LOCAL_WOUND__VARS__wep_infobbs,$___LOCAL_WOUND__VARS__inf_recover_sp_cost; $inf_place=&$___LOCAL_WOUND__VARS__inf_place; $infinfo=&$___LOCAL_WOUND__VARS__infinfo; $infname=&$___LOCAL_WOUND__VARS__infname; $infskillinfo=&$___LOCAL_WOUND__VARS__infskillinfo; $wep_infatt=&$___LOCAL_WOUND__VARS__wep_infatt; $wep_infobbs=&$___LOCAL_WOUND__VARS__wep_infobbs; $inf_recover_sp_cost=&$___LOCAL_WOUND__VARS__inf_recover_sp_cost;   } while (0);
		
		$itm=&$theitem['itm']; $itmk=&$theitem['itmk'];
		$itme=&$theitem['itme']; $itms=&$theitem['itms']; $itmsk=&$theitem['itmsk'];
		
		if (strpos ( $itmk, 'C' ) === 0) 
		{
			$ck=substr($itmk,1,1);
			if($ck == 'a'){
				$flag=false;
				$log .= "服用了<span class=\"red b\">$itm</span>。<br>";
				$inf0 = $inf;
				for ($i=0; $i<strlen($inf0); $i++)
				{
					if(strpos($inf_place,$inf0[$i])===false){
						$log .= "{$infname[$inf0[$i]]}状态解除了。<br>";
						$inf = str_replace($inf0[$i],'',$inf);
						$flag=true;
					}
				}
				
				if(!$flag){
					$log .= '但是什么也没发生。<br>';
				}
			}
			else
			{
				if(strpos ( $inf, $ck ) !== false){
					$inf = str_replace ( $ck, '', $inf );
					$log .= "服用了<span class=\"red b\">$itm</span>，{$infname[$ck]}状态解除了。<br>";
				}else{
					$log .= "服用了<span class=\"red b\">$itm</span>，但是什么效果也没有。<br>";
				}
			}
			
			\itemmain\itms_reduce($theitem);
			$___TMP_MOD_item_uc_FUNC_itemuse_RET = NULL;
			break; 
		}
if(isset($itm)) {$__VAR_DUMP_MOD_item_uc_VARS_itm = &$itm; unset($itm); } else {$__VAR_DUMP_MOD_item_uc_VARS_itm = NULL;}if(isset($itmk)) {$__VAR_DUMP_MOD_item_uc_VARS_itmk = &$itmk; unset($itmk); } else {$__VAR_DUMP_MOD_item_uc_VARS_itmk = NULL;}if(isset($itme)) {$__VAR_DUMP_MOD_item_uc_VARS_itme = &$itme; unset($itme); } else {$__VAR_DUMP_MOD_item_uc_VARS_itme = NULL;}if(isset($itms)) {$__VAR_DUMP_MOD_item_uc_VARS_itms = &$itms; unset($itms); } else {$__VAR_DUMP_MOD_item_uc_VARS_itms = NULL;}if(isset($itmsk)) {$__VAR_DUMP_MOD_item_uc_VARS_itmsk = &$itmsk; unset($itmsk); } else {$__VAR_DUMP_MOD_item_uc_VARS_itmsk = NULL;}if(isset($flag)) {$__VAR_DUMP_MOD_item_uc_VARS_flag = $flag; unset($flag); } else {$__VAR_DUMP_MOD_item_uc_VARS_flag = NULL;} if(isset($i)) {$__VAR_DUMP_MOD_item_uc_VARS_i = $i; unset($i); } else {$__VAR_DUMP_MOD_item_uc_VARS_i = NULL;} 
		//======== Start of contents from mod armor ========
		do{
			$___TMP_MOD_armor_FUNC_itemuse_RET = NULL;

		
		
		if (strpos ( $theitem['itmk'], 'D' ) === 0) {
			\armor\use_armor ($theitem);
			$___TMP_MOD_armor_FUNC_itemuse_RET = NULL;
			break; 
		}
		//======== Start of contents from mod poison ========
		do{
			$___TMP_MOD_poison_FUNC_itemuse_RET = NULL;

		
		
		
		
		$itm=&$theitem['itm']; $itmk=&$theitem['itmk'];
		$itme=&$theitem['itme']; $itms=&$theitem['itms']; $itmsk=&$theitem['itmsk'];
		
		if (strpos ( $itmk, 'P' ) === 0) {
			$m=(int)substr($itmk, 2,1);
			if($m < 1) $m = 1;
			elseif($m == 1) $m = 1.5;
			$damage = round($itme * $m);
			
			if (defined('MOD_WOUND')) \wound\get_inf('p');
			
			$hp -= $damage;
			
			$playerflag = 0;
			$poisonerid = \poison\poison_check_pid ($itmsk);
			if (!empty($poisonerid)) $playerflag = 1;
			
			$selflag = 0;
			if ($playerflag && $poisonerid == $pid) $selflag = 1;
			if ($playerflag && $selflag) {
				$log .= "糟糕，<span class=\"yellow b\">$itm</span>中被<span class=\"yellow b\">你自己</span>掺入了毒药！你受到了<span class=\"dmg\">$damage</span>点伤害！<br>";
				addnews ( $now, 'poison', $name, $name, $itm );
			}
			elseif ($playerflag){
				$wdata = \player\fetch_playerdata_by_pid($poisonerid);
				$wprefix = '<span class="yellow b">'.$wdata['name'].'</span>';
				$log .= "糟糕，<span class=\"yellow b\">$itm</span>中被{$wprefix}掺入了毒药！你受到了<span class=\"dmg\">$damage</span>点伤害！<br>";
				addnews ( $now, 'poison', $name, $wdata ['name'], $itm );
				\poison\send_poison_enemylog ($itm,$poisonerid);
			} else {
				$log .= "糟糕，<span class=\"yellow b\">$itm</span>有毒！你受到了<span class=\"dmg\">$damage</span>点伤害！<br>";
			}
			if ($hp <= 0) {
			
				$state = 26;
				\player\update_sdata();
				
				if ($playerflag && !$selflag) 	
				{	
					$sdata['bid'] = $poisonerid;
					$log .= "你被<span class=\"red b\">" . $wdata ['name'] . "</span>毒死了！";
				}
				elseif ($playerflag)			
				{
					$sdata['bid'] = $poisonerid;
					$wdata = &$sdata;
					$log .= "你被毒死了！";
				}
				else						
				{
					$wdata = &$sdata;
					$sdata['sourceless']=1;
					$sdata['bid'] = 0;
					$log .= "你被毒死了！";
				}
				$wdata['attackwith']=$itm;
				$killmsg = \player\kill($wdata,$sdata);
				if (isset($sdata['sourceless'])) unset($sdata['sourceless']);
				
				if($killmsg){$log .= "<span class=\"yellow b\">{$wdata['name']}对你说：“{$killmsg}”</span><br>";}
				
				if ($playerflag && !$selflag) \player\player_save($wdata);
				\player\player_save($sdata);
				\player\load_playerdata($sdata);
			} 
			\itemmain\itms_reduce($theitem);
			$___TMP_MOD_poison_FUNC_itemuse_RET = NULL;
			break; 
		}
		
		if ((strpos ( $itmk, 'Y' ) === 0 || strpos ( $itmk, 'Z' ) === 0) && ($itm == '毒药')) 
		{
			include template(MOD_POISON_POISON);
			$cmd = ob_get_contents();
			ob_clean();
			$___TMP_MOD_poison_FUNC_itemuse_RET = NULL;
			break; 
		}
if(isset($itm)) {$__VAR_DUMP_MOD_poison_VARS_itm = &$itm; unset($itm); } else {$__VAR_DUMP_MOD_poison_VARS_itm = NULL;}if(isset($itmk)) {$__VAR_DUMP_MOD_poison_VARS_itmk = &$itmk; unset($itmk); } else {$__VAR_DUMP_MOD_poison_VARS_itmk = NULL;}if(isset($itme)) {$__VAR_DUMP_MOD_poison_VARS_itme = &$itme; unset($itme); } else {$__VAR_DUMP_MOD_poison_VARS_itme = NULL;}if(isset($itms)) {$__VAR_DUMP_MOD_poison_VARS_itms = &$itms; unset($itms); } else {$__VAR_DUMP_MOD_poison_VARS_itms = NULL;}if(isset($itmsk)) {$__VAR_DUMP_MOD_poison_VARS_itmsk = &$itmsk; unset($itmsk); } else {$__VAR_DUMP_MOD_poison_VARS_itmsk = NULL;}
		//======== Start of contents from mod skill725 ========
		do{
			$___TMP_MOD_skill725_FUNC_itemuse_RET = NULL;

			
		$itm=&$theitem['itm']; $itmk=&$theitem['itmk'];
		$itme=&$theitem['itme']; $itms=&$theitem['itms']; $itmsk=&$theitem['itmsk'];
		
		if ($itm == '打火机' && \skillbase\skill_query(725))
		{
			
			if($itme <= 0) {
				$log .= "<span class=\"yellow b\">$itm</span>没油了。<br>";
				$___TMP_MOD_skill725_FUNC_itemuse_RET = NULL;
			break; 
			}
			$log .= "你使用了<span class=\"yellow b\">$itm</span>。<br>";
			$flag = 0;
			for($i=1;$i<=6;$i++)
			{
				if (${'itms'.$i} && (strpos(${'itm'.$i},'灵魂碎片')!==false) && (strpos(${'itm'.$i},'加工过的')===false))
				{
					${'itme'.$i} += ceil(rand(50,150) * ${'itme'.$i} / 100);
					if (${'itms'.$i} != '∞') ${'itms'.$i} += ceil(rand(50,150) * ${'itms'.$i} / 100);
					$log .= "<span class=\"yellow b\">${'itm'.$i}</span>变成了";
					${'itm'.$i} = '加工过的'.${'itm'.$i};
					$log .= "<span class=\"yellow b\">${'itm'.$i}</span>！<br>";
					$flag = 1;
					break;
				}
			}
			if ($flag)
			{
				$itme -= 1;
				if ($itme == 0)
				{
					if ($itms > 1)
					{
						$log .= "打火机没油了，你换了一个新的打火机。<br>";
						$itme = 1;
						$itms -= 1;
					}
					else $log .= "打火机没油了。<br>";
				}
			}
			else $log .= "包裹里没有要加工的灵魂碎片。<br>";
			$___TMP_MOD_skill725_FUNC_itemuse_RET = NULL;
			break; 
		}
if(isset($itm)) {$__VAR_DUMP_MOD_skill725_VARS_itm = &$itm; unset($itm); } else {$__VAR_DUMP_MOD_skill725_VARS_itm = NULL;}if(isset($itmk)) {$__VAR_DUMP_MOD_skill725_VARS_itmk = &$itmk; unset($itmk); } else {$__VAR_DUMP_MOD_skill725_VARS_itmk = NULL;}
		//======== Start of contents from mod skill907 ========
		do{
			$___TMP_MOD_skill907_FUNC_itemuse_RET = NULL;

		
		$itm=&$theitem['itm']; $itmk=&$theitem['itmk'];
		if (\skillbase\skill_query(907))
		{
			if (strpos($itmk, 'EE') === 0 || ((strpos($itmk, 'ER') === 0) && rand(0,99)))
			{
					
				$log .= "周围充斥的强电磁波使你使用{$itm}的尝试失败了。<br>";
				$___TMP_MOD_skill907_FUNC_itemuse_RET = NULL;
			break; 
			}
		}
		//======== Start of contents from mod skill323 ========
		do{
			$___TMP_MOD_skill323_FUNC_itemuse_RET = NULL;

		
		
		if ($theitem['itm']=="『G.A.M.E.O.V.E.R』"){
			if (\skillbase\skill_query(323)){
				\skillbase\skill_setvalue(323,'cnt',$now-$starttime);
				\player\player_save($sdata);
			}
		}
		//======== Start of contents from mod skill322 ========
		do{
			$___TMP_MOD_skill322_FUNC_itemuse_RET = NULL;

		
		
		if (($theitem['itm']=="杏仁豆腐的ID卡")&&($theitem['itmk']=="Z")&&($gamestate>=30)&&($gamestate<50)){
			if (\skillbase\skill_query(322)){
				\skillbase\skill_setvalue(322,'cnt',$now-$starttime);
				\player\player_save($sdata);
			}
		}
		//======== Start of contents from mod skill318 ========
		do{
			$___TMP_MOD_skill318_FUNC_itemuse_RET = NULL;

		
		
		if ($theitem['itm']=="『G.A.M.E.O.V.E.R』"){
			if (\skillbase\skill_query(318)){
				\skillbase\skill_setvalue(318,'cnt',1);
				\player\player_save($sdata);
			}
		}
		//======== Start of contents from mod skill307 ========
		do{
			$___TMP_MOD_skill307_FUNC_itemuse_RET = NULL;

		
		
		if ($theitem['itm']=="『G.A.M.E.O.V.E.R』"){
			if (\skillbase\skill_query(307)){
				\skillbase\skill_setvalue(307,'cnt',1);
				\player\player_save($sdata);
			}
		}
		//======== Start of contents from mod skill301 ========
		do{
			$___TMP_MOD_skill301_FUNC_itemuse_RET = NULL;

		
		
		if ($theitem['itm']=="游戏解除钥匙"){
			if (\skillbase\skill_query(301)){
				\skillbase\skill_setvalue(301,'cnt',1);
				\player\player_save($sdata);
			}
		}
		//======== Start of contents from mod skill574 ========
		do{
			$___TMP_MOD_skill574_FUNC_itemuse_RET = NULL;

		
		do { global $___LOCAL_SKILL574__VARS__skill574_itmlist; $skill574_itmlist=&$___LOCAL_SKILL574__VARS__skill574_itmlist;   } while (0);
		if (\skillbase\skill_query(574, $sdata) && \skill574\check_unlocked574 ($sdata) && in_array($theitem['itm'], $skill574_itmlist))
		{
			$temp_itmk = $theitem['itmk'];
			$temp_itme = $theitem['itme'];
			$theitem['itmk'] = 'HB';
			$theitem['itme'] = '200';		
			\skill531\itemuse($theitem);
			if (!empty($theitem['itms']))
			{
				$theitem['itmk'] = $temp_itmk;
				$theitem['itme'] = $temp_itme;
			}
		}
		else \skill531\itemuse($theitem);
		}while(0);
		//======== End of contents from mod skill574 ========

		$___TMP_MOD_skill574_FUNC_itemuse_RET;
		}while(0);
		//======== End of contents from mod skill301 ========

		$___TMP_MOD_skill301_FUNC_itemuse_RET;
		}while(0);
		//======== End of contents from mod skill307 ========

		$___TMP_MOD_skill307_FUNC_itemuse_RET;
		}while(0);
		//======== End of contents from mod skill318 ========

		$___TMP_MOD_skill318_FUNC_itemuse_RET;
		}while(0);
		//======== End of contents from mod skill322 ========

		$___TMP_MOD_skill322_FUNC_itemuse_RET;
		}while(0);
		//======== End of contents from mod skill323 ========

		$___TMP_MOD_skill323_FUNC_itemuse_RET;
		}while(0);
		//======== End of contents from mod skill907 ========

$itm = &$__VAR_DUMP_MOD_skill725_VARS_itm; $itmk = &$__VAR_DUMP_MOD_skill725_VARS_itmk; 
		$___TMP_MOD_skill907_FUNC_itemuse_RET;
		}while(0);
		//======== End of contents from mod skill725 ========

$itm = &$__VAR_DUMP_MOD_poison_VARS_itm; $itmk = &$__VAR_DUMP_MOD_poison_VARS_itmk; $itme = &$__VAR_DUMP_MOD_poison_VARS_itme; $itms = &$__VAR_DUMP_MOD_poison_VARS_itms; $itmsk = &$__VAR_DUMP_MOD_poison_VARS_itmsk; 
		
		$___TMP_MOD_skill725_FUNC_itemuse_RET;
		}while(0);
		//======== End of contents from mod poison ========

		$___TMP_MOD_poison_FUNC_itemuse_RET;
		}while(0);
		//======== End of contents from mod armor ========

$itm = &$__VAR_DUMP_MOD_item_uc_VARS_itm; $itmk = &$__VAR_DUMP_MOD_item_uc_VARS_itmk; $itme = &$__VAR_DUMP_MOD_item_uc_VARS_itme; $itms = &$__VAR_DUMP_MOD_item_uc_VARS_itms; $itmsk = &$__VAR_DUMP_MOD_item_uc_VARS_itmsk; $flag = $__VAR_DUMP_MOD_item_uc_VARS_flag; $i = $__VAR_DUMP_MOD_item_uc_VARS_i; 
		$___TMP_MOD_armor_FUNC_itemuse_RET;
		}while(0);
		//======== End of contents from mod item_uc ========

$itm = &$__VAR_DUMP_MOD_item_slip_VARS_itm; $itmk = &$__VAR_DUMP_MOD_item_slip_VARS_itmk; $itme = &$__VAR_DUMP_MOD_item_slip_VARS_itme; $itms = &$__VAR_DUMP_MOD_item_slip_VARS_itms; $itmsk = &$__VAR_DUMP_MOD_item_slip_VARS_itmsk; 
		$___TMP_MOD_item_uc_FUNC_itemuse_RET;
		}while(0);
		//======== End of contents from mod item_slip ========

$itm = &$__VAR_DUMP_MOD_ammunition_VARS_itm; $itmk = &$__VAR_DUMP_MOD_ammunition_VARS_itmk; $itme = &$__VAR_DUMP_MOD_ammunition_VARS_itme; $itms = &$__VAR_DUMP_MOD_ammunition_VARS_itms; $itmsk = &$__VAR_DUMP_MOD_ammunition_VARS_itmsk; 
		$___TMP_MOD_item_slip_FUNC_itemuse_RET;
		}while(0);
		//======== End of contents from mod ammunition ========

$itm = &$__VAR_DUMP_MOD_armor_art_VARS_itm; $itmk = &$__VAR_DUMP_MOD_armor_art_VARS_itmk; $itme = &$__VAR_DUMP_MOD_armor_art_VARS_itme; $itms = &$__VAR_DUMP_MOD_armor_art_VARS_itms; $itmsk = &$__VAR_DUMP_MOD_armor_art_VARS_itmsk; 
		$___TMP_MOD_ammunition_FUNC_itemuse_RET;
		}while(0);
		//======== End of contents from mod armor_art ========

		$___TMP_MOD_armor_art_FUNC_itemuse_RET;
		}while(0);
		//======== End of contents from mod skill557 ========

$mode = $__VAR_DUMP_MOD_skill600_VARS_mode; 
		$___TMP_MOD_skill557_FUNC_itemuse_RET;
		}while(0);
		//======== End of contents from mod skill600 ========

$itm = &$__VAR_DUMP_MOD_weather_VARS_itm; $itmk = &$__VAR_DUMP_MOD_weather_VARS_itmk; $itme = &$__VAR_DUMP_MOD_weather_VARS_itme; $itms = &$__VAR_DUMP_MOD_weather_VARS_itms; $itmsk = &$__VAR_DUMP_MOD_weather_VARS_itmsk; 
		$___TMP_MOD_skill600_FUNC_itemuse_RET;
		}while(0);
		//======== End of contents from mod weather ========

$itm = &$__VAR_DUMP_MOD_addnpc_VARS_itm; $itmk = &$__VAR_DUMP_MOD_addnpc_VARS_itmk; $itme = &$__VAR_DUMP_MOD_addnpc_VARS_itme; $itms = &$__VAR_DUMP_MOD_addnpc_VARS_itms; $itmsk = &$__VAR_DUMP_MOD_addnpc_VARS_itmsk; 
		$___TMP_MOD_weather_FUNC_itemuse_RET;
		}while(0);
		//======== End of contents from mod addnpc ========

		$___TMP_MOD_addnpc_FUNC_itemuse_RET;
		if(18 == $gametype && \skillbase\skill_query(329,$sdata) && $ach329_flag) {
			$x=(int)\skillbase\skill_getvalue(329,'cnt',$sdata);
			$x+=1;
			\skillbase\skill_setvalue(329,'cnt',$x,$sdata);
		}
		}while(0);
		//======== End of contents from mod skill329 ========

$itm = &$__VAR_DUMP_MOD_item_randskills_VARS_itm; $itmk = &$__VAR_DUMP_MOD_item_randskills_VARS_itmk; $itme = &$__VAR_DUMP_MOD_item_randskills_VARS_itme; $itms = &$__VAR_DUMP_MOD_item_randskills_VARS_itms; $itmsk = &$__VAR_DUMP_MOD_item_randskills_VARS_itmsk; 
		
		$___TMP_MOD_skill329_FUNC_itemuse_RET;
		}while(0);
		//======== End of contents from mod item_randskills ========

$itm = &$__VAR_DUMP_MOD_wep_b_VARS_itm; $itmk = &$__VAR_DUMP_MOD_wep_b_VARS_itmk; $itme = &$__VAR_DUMP_MOD_wep_b_VARS_itme; $itms = &$__VAR_DUMP_MOD_wep_b_VARS_itms; $itmsk = &$__VAR_DUMP_MOD_wep_b_VARS_itmsk; 
		$___TMP_MOD_item_randskills_FUNC_itemuse_RET;
		}while(0);
		//======== End of contents from mod wep_b ========

$itm = &$__VAR_DUMP_MOD_rage_VARS_itm; $itmk = &$__VAR_DUMP_MOD_rage_VARS_itmk; $itme = &$__VAR_DUMP_MOD_rage_VARS_itme; $itms = &$__VAR_DUMP_MOD_rage_VARS_itms; $itmsk = &$__VAR_DUMP_MOD_rage_VARS_itmsk; 
		
		$___TMP_MOD_wep_b_FUNC_itemuse_RET;
		}while(0);
		//======== End of contents from mod rage ========

$itm = &$__VAR_DUMP_MOD_ex_attr_silencer_VARS_itm; $itmk = &$__VAR_DUMP_MOD_ex_attr_silencer_VARS_itmk; $itme = &$__VAR_DUMP_MOD_ex_attr_silencer_VARS_itme; $itms = &$__VAR_DUMP_MOD_ex_attr_silencer_VARS_itms; $itmsk = &$__VAR_DUMP_MOD_ex_attr_silencer_VARS_itmsk; 
		$___TMP_MOD_rage_FUNC_itemuse_RET;
		}while(0);
		//======== End of contents from mod ex_attr_silencer ========

$itm = &$__VAR_DUMP_MOD_ex_cursed_VARS_itm; $itmk = &$__VAR_DUMP_MOD_ex_cursed_VARS_itmk; $itme = &$__VAR_DUMP_MOD_ex_cursed_VARS_itme; $itms = &$__VAR_DUMP_MOD_ex_cursed_VARS_itms; $itmsk = &$__VAR_DUMP_MOD_ex_cursed_VARS_itmsk; 
		$___TMP_MOD_ex_attr_silencer_FUNC_itemuse_RET;
		}while(0);
		//======== End of contents from mod ex_cursed ========

$itmsk = &$__VAR_DUMP_MOD_ex_uselog_VARS_itmsk; 
		$___TMP_MOD_ex_cursed_FUNC_itemuse_RET;
		if (!empty($taillog))
		{
			
			$log .= \attrbase\base64_decode_comp_itmsk($taillog);
		}
		}while(0);
		//======== End of contents from mod ex_uselog ========

$itm = &$__VAR_DUMP_MOD_skill732_VARS_itm; $itmk = &$__VAR_DUMP_MOD_skill732_VARS_itmk; $itme = &$__VAR_DUMP_MOD_skill732_VARS_itme; $itms = &$__VAR_DUMP_MOD_skill732_VARS_itms; $itmsk = &$__VAR_DUMP_MOD_skill732_VARS_itmsk; 
		$___TMP_MOD_ex_uselog_FUNC_itemuse_RET;
		}while(0);
		//======== End of contents from mod skill732 ========

$itm = &$__VAR_DUMP_MOD_skill729_VARS_itm; $itmk = &$__VAR_DUMP_MOD_skill729_VARS_itmk; $itme = &$__VAR_DUMP_MOD_skill729_VARS_itme; $itms = &$__VAR_DUMP_MOD_skill729_VARS_itms; $itmsk = &$__VAR_DUMP_MOD_skill729_VARS_itmsk; $acquired_skills = $__VAR_DUMP_MOD_skill729_VARS_acquired_skills; $count = $__VAR_DUMP_MOD_skill729_VARS_count; $ls_skills = $__VAR_DUMP_MOD_skill729_VARS_ls_skills; $rs_skills = $__VAR_DUMP_MOD_skill729_VARS_rs_skills; 
		$___TMP_MOD_skill732_FUNC_itemuse_RET;
		}while(0);
		//======== End of contents from mod skill729 ========

$itm = &$__VAR_DUMP_MOD_wep_b_extra_reloading_VARS_itm; $itmk = &$__VAR_DUMP_MOD_wep_b_extra_reloading_VARS_itmk; $itme = &$__VAR_DUMP_MOD_wep_b_extra_reloading_VARS_itme; $itms = &$__VAR_DUMP_MOD_wep_b_extra_reloading_VARS_itms; $itmsk = &$__VAR_DUMP_MOD_wep_b_extra_reloading_VARS_itmsk; 
		$___TMP_MOD_skill729_FUNC_itemuse_RET;
		}while(0);
		//======== End of contents from mod wep_b_extra_reloading ========

$itm = &$__VAR_DUMP_MOD_item_uu_VARS_itm; $itmk = &$__VAR_DUMP_MOD_item_uu_VARS_itmk; $itme = &$__VAR_DUMP_MOD_item_uu_VARS_itme; $itms = &$__VAR_DUMP_MOD_item_uu_VARS_itms; $itmsk = &$__VAR_DUMP_MOD_item_uu_VARS_itmsk; $result = $__VAR_DUMP_MOD_item_uu_VARS_result; $i = $__VAR_DUMP_MOD_item_uu_VARS_i; 
		
		$___TMP_MOD_wep_b_extra_reloading_FUNC_itemuse_RET;
		}while(0);
		//======== End of contents from mod item_uu ========

$itm = &$__VAR_DUMP_MOD_item_recipe_VARS_itm; $itmk = &$__VAR_DUMP_MOD_item_recipe_VARS_itmk; 
		$___TMP_MOD_item_uu_FUNC_itemuse_RET;
		}while(0);
		//======== End of contents from mod item_recipe ========

$itm = &$__VAR_DUMP_MOD_song_VARS_itm; $itmk = &$__VAR_DUMP_MOD_song_VARS_itmk; $itme = &$__VAR_DUMP_MOD_song_VARS_itme; $itms = &$__VAR_DUMP_MOD_song_VARS_itms; $itmsk = &$__VAR_DUMP_MOD_song_VARS_itmsk; $eqp = $__VAR_DUMP_MOD_song_VARS_eqp; $noeqp = $__VAR_DUMP_MOD_song_VARS_noeqp; 
		
		$___TMP_MOD_item_recipe_FUNC_itemuse_RET;
		}while(0);
		//======== End of contents from mod song ========

$itm = &$__VAR_DUMP_MOD_news_observe_VARS_itm; $itmk = &$__VAR_DUMP_MOD_news_observe_VARS_itmk; $itme = &$__VAR_DUMP_MOD_news_observe_VARS_itme; $itms = &$__VAR_DUMP_MOD_news_observe_VARS_itms; $itmsk = &$__VAR_DUMP_MOD_news_observe_VARS_itmsk; 
		
		$___TMP_MOD_song_FUNC_itemuse_RET;
		}while(0);
		//======== End of contents from mod news_observe ========

$itm = &$__VAR_DUMP_MOD_empowers_VARS_itm; $itmk = &$__VAR_DUMP_MOD_empowers_VARS_itmk; $itme = &$__VAR_DUMP_MOD_empowers_VARS_itme; $itms = &$__VAR_DUMP_MOD_empowers_VARS_itms; $itmsk = &$__VAR_DUMP_MOD_empowers_VARS_itmsk; 
		$___TMP_MOD_news_observe_FUNC_itemuse_RET;
		}while(0);
		//======== End of contents from mod empowers ========

$itm = &$__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_itm; $itmk = &$__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_itmk; $itme = &$__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_itme; $itms = &$__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_itms; $itmsk = &$__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_itmsk; $obj = $__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_obj; $flag = $__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_flag; 
		$___TMP_MOD_empowers_FUNC_itemuse_RET;
		if($lose_flag) {
			\ex_mhp_temp_up\ex_mhp_temp_lose ();
		}
		}while(0);
		//======== End of contents from mod ex_mhp_temp_up ========

		$___TMP_MOD_ex_mhp_temp_up_FUNC_itemuse_RET;
		if($gametype == 17) {
			if(('Y' == $theitem['itmk'] || 'Z' == $theitem['itmk']) && '教程解除钥匙' == $theitem['itm']){
				\tutorial\tutorial_win ();
			}else{
				$ct = \tutorial\get_tutorial ();
				$flag = 0;
				if($ct['object'] == 'itemuse'){
					if(!empty($ct['obj2']['itm']) && $oitm == $ct['obj2']['itm']) $flag = 1;
					elseif(!empty($ct['obj2']['itmk']) && in_array($oitmk,$ct['obj2']['itmk'])) $flag = 1;
					if(!empty($flag)) \tutorial\tutorial_pushforward_process ();
				}
			}			
		}
		$___TMP_MOD_tutorial_FUNC_itemuse_RET = NULL;
			break; 
		}while(0);
		//======== End of contents from mod tutorial ========

$itm = &$__VAR_DUMP_MOD_randrecipe_VARS_itm; $itmk = &$__VAR_DUMP_MOD_randrecipe_VARS_itmk; $itme = &$__VAR_DUMP_MOD_randrecipe_VARS_itme; $itms = &$__VAR_DUMP_MOD_randrecipe_VARS_itms; $itmsk = &$__VAR_DUMP_MOD_randrecipe_VARS_itmsk; $flag = $__VAR_DUMP_MOD_randrecipe_VARS_flag; $i = $__VAR_DUMP_MOD_randrecipe_VARS_i; 
		$___TMP_MOD_tutorial_FUNC_itemuse_RET;
		}while(0);
		//======== End of contents from mod randrecipe ========

$itm = &$__VAR_DUMP_MOD_instance3_VARS_itm; $itmk = &$__VAR_DUMP_MOD_instance3_VARS_itmk; $itme = &$__VAR_DUMP_MOD_instance3_VARS_itme; $itms = &$__VAR_DUMP_MOD_instance3_VARS_itms; $itmsk = &$__VAR_DUMP_MOD_instance3_VARS_itmsk; 
		$___TMP_MOD_randrecipe_FUNC_itemuse_RET;
	
	}
	
	
	function search_area()
	{
		
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;  global $___LOCAL_PLAYER__VARS__ss,$___LOCAL_PLAYER__VARS__db_player_structure,$___LOCAL_PLAYER__VARS__db_player_structure_types,$___LOCAL_PLAYER__VARS__gamedata,$___LOCAL_PLAYER__VARS__cmd,$___LOCAL_PLAYER__VARS__main,$___LOCAL_PLAYER__VARS__sdata,$___LOCAL_PLAYER__VARS__fog,$___LOCAL_PLAYER__VARS__upexp,$___LOCAL_PLAYER__VARS__lvlupexp, $___LOCAL_PLAYER__VARS__iconImg,$___LOCAL_PLAYER__VARS__iconImgB,$___LOCAL_PLAYER__VARS__iconImgBwidth,$___LOCAL_PLAYER__VARS__ardef,$___LOCAL_PLAYER__VARS__hpcolor,$___LOCAL_PLAYER__VARS__spcolor,$___LOCAL_PLAYER__VARS__newhpimg,$___LOCAL_PLAYER__VARS__newspimg,$___LOCAL_PLAYER__VARS__splt,$___LOCAL_PLAYER__VARS__hplt, $___LOCAL_PLAYER__VARS__tpldata,$___LOCAL_PLAYER__VARS__icon_list,$___LOCAL_PLAYER__VARS__icon_list_contents_to_frontend,$___LOCAL_PLAYER__VARS__typeinfo,$___LOCAL_PLAYER__VARS__killmsginfo,$___LOCAL_PLAYER__VARS__lwinfo,$___LOCAL_PLAYER__VARS__sexinfo,$___LOCAL_PLAYER__VARS__equip_list,$___LOCAL_PLAYER__VARS__battle_equip_list,$___LOCAL_PLAYER__VARS__pc_icon_range, $___LOCAL_PLAYER__VARS__pid,$___LOCAL_PLAYER__VARS__type,$___LOCAL_PLAYER__VARS__name,$___LOCAL_PLAYER__VARS__pass,$___LOCAL_PLAYER__VARS__ip,$___LOCAL_PLAYER__VARS__motto,$___LOCAL_PLAYER__VARS__killmsg,$___LOCAL_PLAYER__VARS__lastword,$___LOCAL_PLAYER__VARS__winner_flag,$___LOCAL_PLAYER__VARS__player_dead_flag, $___LOCAL_PLAYER__VARS__corpse_clear_flag,$___LOCAL_PLAYER__VARS__gd,$___LOCAL_PLAYER__VARS__sNo,$___LOCAL_PLAYER__VARS__club,$___LOCAL_PLAYER__VARS__validtime,$___LOCAL_PLAYER__VARS__endtime,$___LOCAL_PLAYER__VARS__cdsec,$___LOCAL_PLAYER__VARS__cdmsec,$___LOCAL_PLAYER__VARS__cdtime,$___LOCAL_PLAYER__VARS__action, $___LOCAL_PLAYER__VARS__a_actionnum,$___LOCAL_PLAYER__VARS__v_actionnum,$___LOCAL_PLAYER__VARS__hp,$___LOCAL_PLAYER__VARS__mhp,$___LOCAL_PLAYER__VARS__sp,$___LOCAL_PLAYER__VARS__msp,$___LOCAL_PLAYER__VARS__mss,$___LOCAL_PLAYER__VARS__att,$___LOCAL_PLAYER__VARS__def,$___LOCAL_PLAYER__VARS__pls, $___LOCAL_PLAYER__VARS__lvl,$___LOCAL_PLAYER__VARS__exp,$___LOCAL_PLAYER__VARS__money,$___LOCAL_PLAYER__VARS__rp,$___LOCAL_PLAYER__VARS__bid,$___LOCAL_PLAYER__VARS__inf,$___LOCAL_PLAYER__VARS__rage,$___LOCAL_PLAYER__VARS__pose,$___LOCAL_PLAYER__VARS__tactic,$___LOCAL_PLAYER__VARS__killnum, $___LOCAL_PLAYER__VARS__npckillnum,$___LOCAL_PLAYER__VARS__state,$___LOCAL_PLAYER__VARS__skillpoint,$___LOCAL_PLAYER__VARS__flare,$___LOCAL_PLAYER__VARS__wp,$___LOCAL_PLAYER__VARS__wk,$___LOCAL_PLAYER__VARS__wg,$___LOCAL_PLAYER__VARS__wc,$___LOCAL_PLAYER__VARS__wd,$___LOCAL_PLAYER__VARS__wf, $___LOCAL_PLAYER__VARS__icon,$___LOCAL_PLAYER__VARS__teamID,$___LOCAL_PLAYER__VARS__teamPass,$___LOCAL_PLAYER__VARS__card,$___LOCAL_PLAYER__VARS__cardname,$___LOCAL_PLAYER__VARS__wep,$___LOCAL_PLAYER__VARS__wepk,$___LOCAL_PLAYER__VARS__wepe,$___LOCAL_PLAYER__VARS__weps,$___LOCAL_PLAYER__VARS__wepsk, $___LOCAL_PLAYER__VARS__arb,$___LOCAL_PLAYER__VARS__arbk,$___LOCAL_PLAYER__VARS__arbe,$___LOCAL_PLAYER__VARS__arbs,$___LOCAL_PLAYER__VARS__arbsk,$___LOCAL_PLAYER__VARS__arh,$___LOCAL_PLAYER__VARS__arhk,$___LOCAL_PLAYER__VARS__arhe,$___LOCAL_PLAYER__VARS__arhs,$___LOCAL_PLAYER__VARS__arhsk, $___LOCAL_PLAYER__VARS__ara,$___LOCAL_PLAYER__VARS__arak,$___LOCAL_PLAYER__VARS__arae,$___LOCAL_PLAYER__VARS__aras,$___LOCAL_PLAYER__VARS__arask,$___LOCAL_PLAYER__VARS__arf,$___LOCAL_PLAYER__VARS__arfk,$___LOCAL_PLAYER__VARS__arfe,$___LOCAL_PLAYER__VARS__arfs,$___LOCAL_PLAYER__VARS__arfsk, $___LOCAL_PLAYER__VARS__art,$___LOCAL_PLAYER__VARS__artk,$___LOCAL_PLAYER__VARS__arte,$___LOCAL_PLAYER__VARS__arts,$___LOCAL_PLAYER__VARS__artsk,$___LOCAL_PLAYER__VARS__itm0,$___LOCAL_PLAYER__VARS__itmk0,$___LOCAL_PLAYER__VARS__itme0,$___LOCAL_PLAYER__VARS__itms0,$___LOCAL_PLAYER__VARS__itmsk0, $___LOCAL_PLAYER__VARS__itm1,$___LOCAL_PLAYER__VARS__itmk1,$___LOCAL_PLAYER__VARS__itme1,$___LOCAL_PLAYER__VARS__itms1,$___LOCAL_PLAYER__VARS__itmsk1,$___LOCAL_PLAYER__VARS__itm2,$___LOCAL_PLAYER__VARS__itmk2,$___LOCAL_PLAYER__VARS__itme2,$___LOCAL_PLAYER__VARS__itms2,$___LOCAL_PLAYER__VARS__itmsk2, $___LOCAL_PLAYER__VARS__itm3,$___LOCAL_PLAYER__VARS__itmk3,$___LOCAL_PLAYER__VARS__itme3,$___LOCAL_PLAYER__VARS__itms3,$___LOCAL_PLAYER__VARS__itmsk3,$___LOCAL_PLAYER__VARS__itm4,$___LOCAL_PLAYER__VARS__itmk4,$___LOCAL_PLAYER__VARS__itme4,$___LOCAL_PLAYER__VARS__itms4,$___LOCAL_PLAYER__VARS__itmsk4, $___LOCAL_PLAYER__VARS__itm5,$___LOCAL_PLAYER__VARS__itmk5,$___LOCAL_PLAYER__VARS__itme5,$___LOCAL_PLAYER__VARS__itms5,$___LOCAL_PLAYER__VARS__itmsk5,$___LOCAL_PLAYER__VARS__itm6,$___LOCAL_PLAYER__VARS__itmk6,$___LOCAL_PLAYER__VARS__itme6,$___LOCAL_PLAYER__VARS__itms6,$___LOCAL_PLAYER__VARS__itmsk6, $___LOCAL_PLAYER__VARS__searchmemory,$___LOCAL_PLAYER__VARS__nskill,$___LOCAL_PLAYER__VARS__nskillpara; $ss=&$___LOCAL_PLAYER__VARS__ss; $db_player_structure=&$___LOCAL_PLAYER__VARS__db_player_structure; $db_player_structure_types=&$___LOCAL_PLAYER__VARS__db_player_structure_types; $gamedata=&$___LOCAL_PLAYER__VARS__gamedata; $cmd=&$___LOCAL_PLAYER__VARS__cmd; $main=&$___LOCAL_PLAYER__VARS__main; $sdata=&$___LOCAL_PLAYER__VARS__sdata; $fog=&$___LOCAL_PLAYER__VARS__fog; $upexp=&$___LOCAL_PLAYER__VARS__upexp; $lvlupexp=&$___LOCAL_PLAYER__VARS__lvlupexp;  $iconImg=&$___LOCAL_PLAYER__VARS__iconImg; $iconImgB=&$___LOCAL_PLAYER__VARS__iconImgB; $iconImgBwidth=&$___LOCAL_PLAYER__VARS__iconImgBwidth; $ardef=&$___LOCAL_PLAYER__VARS__ardef; $hpcolor=&$___LOCAL_PLAYER__VARS__hpcolor; $spcolor=&$___LOCAL_PLAYER__VARS__spcolor; $newhpimg=&$___LOCAL_PLAYER__VARS__newhpimg; $newspimg=&$___LOCAL_PLAYER__VARS__newspimg; $splt=&$___LOCAL_PLAYER__VARS__splt; $hplt=&$___LOCAL_PLAYER__VARS__hplt;  $tpldata=&$___LOCAL_PLAYER__VARS__tpldata; $icon_list=&$___LOCAL_PLAYER__VARS__icon_list; $icon_list_contents_to_frontend=&$___LOCAL_PLAYER__VARS__icon_list_contents_to_frontend; $typeinfo=&$___LOCAL_PLAYER__VARS__typeinfo; $killmsginfo=&$___LOCAL_PLAYER__VARS__killmsginfo; $lwinfo=&$___LOCAL_PLAYER__VARS__lwinfo; $sexinfo=&$___LOCAL_PLAYER__VARS__sexinfo; $equip_list=&$___LOCAL_PLAYER__VARS__equip_list; $battle_equip_list=&$___LOCAL_PLAYER__VARS__battle_equip_list; $pc_icon_range=&$___LOCAL_PLAYER__VARS__pc_icon_range;  $pid=&$___LOCAL_PLAYER__VARS__pid; $type=&$___LOCAL_PLAYER__VARS__type; $name=&$___LOCAL_PLAYER__VARS__name; $pass=&$___LOCAL_PLAYER__VARS__pass; $ip=&$___LOCAL_PLAYER__VARS__ip; $motto=&$___LOCAL_PLAYER__VARS__motto; $killmsg=&$___LOCAL_PLAYER__VARS__killmsg; $lastword=&$___LOCAL_PLAYER__VARS__lastword; $winner_flag=&$___LOCAL_PLAYER__VARS__winner_flag; $player_dead_flag=&$___LOCAL_PLAYER__VARS__player_dead_flag;  $corpse_clear_flag=&$___LOCAL_PLAYER__VARS__corpse_clear_flag; $gd=&$___LOCAL_PLAYER__VARS__gd; $sNo=&$___LOCAL_PLAYER__VARS__sNo; $club=&$___LOCAL_PLAYER__VARS__club; $validtime=&$___LOCAL_PLAYER__VARS__validtime; $endtime=&$___LOCAL_PLAYER__VARS__endtime; $cdsec=&$___LOCAL_PLAYER__VARS__cdsec; $cdmsec=&$___LOCAL_PLAYER__VARS__cdmsec; $cdtime=&$___LOCAL_PLAYER__VARS__cdtime; $action=&$___LOCAL_PLAYER__VARS__action;  $a_actionnum=&$___LOCAL_PLAYER__VARS__a_actionnum; $v_actionnum=&$___LOCAL_PLAYER__VARS__v_actionnum; $hp=&$___LOCAL_PLAYER__VARS__hp; $mhp=&$___LOCAL_PLAYER__VARS__mhp; $sp=&$___LOCAL_PLAYER__VARS__sp; $msp=&$___LOCAL_PLAYER__VARS__msp; $mss=&$___LOCAL_PLAYER__VARS__mss; $att=&$___LOCAL_PLAYER__VARS__att; $def=&$___LOCAL_PLAYER__VARS__def; $pls=&$___LOCAL_PLAYER__VARS__pls;  $lvl=&$___LOCAL_PLAYER__VARS__lvl; $exp=&$___LOCAL_PLAYER__VARS__exp; $money=&$___LOCAL_PLAYER__VARS__money; $rp=&$___LOCAL_PLAYER__VARS__rp; $bid=&$___LOCAL_PLAYER__VARS__bid; $inf=&$___LOCAL_PLAYER__VARS__inf; $rage=&$___LOCAL_PLAYER__VARS__rage; $pose=&$___LOCAL_PLAYER__VARS__pose; $tactic=&$___LOCAL_PLAYER__VARS__tactic; $killnum=&$___LOCAL_PLAYER__VARS__killnum;  $npckillnum=&$___LOCAL_PLAYER__VARS__npckillnum; $state=&$___LOCAL_PLAYER__VARS__state; $skillpoint=&$___LOCAL_PLAYER__VARS__skillpoint; $flare=&$___LOCAL_PLAYER__VARS__flare; $wp=&$___LOCAL_PLAYER__VARS__wp; $wk=&$___LOCAL_PLAYER__VARS__wk; $wg=&$___LOCAL_PLAYER__VARS__wg; $wc=&$___LOCAL_PLAYER__VARS__wc; $wd=&$___LOCAL_PLAYER__VARS__wd; $wf=&$___LOCAL_PLAYER__VARS__wf;  $icon=&$___LOCAL_PLAYER__VARS__icon; $teamID=&$___LOCAL_PLAYER__VARS__teamID; $teamPass=&$___LOCAL_PLAYER__VARS__teamPass; $card=&$___LOCAL_PLAYER__VARS__card; $cardname=&$___LOCAL_PLAYER__VARS__cardname; $wep=&$___LOCAL_PLAYER__VARS__wep; $wepk=&$___LOCAL_PLAYER__VARS__wepk; $wepe=&$___LOCAL_PLAYER__VARS__wepe; $weps=&$___LOCAL_PLAYER__VARS__weps; $wepsk=&$___LOCAL_PLAYER__VARS__wepsk;  $arb=&$___LOCAL_PLAYER__VARS__arb; $arbk=&$___LOCAL_PLAYER__VARS__arbk; $arbe=&$___LOCAL_PLAYER__VARS__arbe; $arbs=&$___LOCAL_PLAYER__VARS__arbs; $arbsk=&$___LOCAL_PLAYER__VARS__arbsk; $arh=&$___LOCAL_PLAYER__VARS__arh; $arhk=&$___LOCAL_PLAYER__VARS__arhk; $arhe=&$___LOCAL_PLAYER__VARS__arhe; $arhs=&$___LOCAL_PLAYER__VARS__arhs; $arhsk=&$___LOCAL_PLAYER__VARS__arhsk;  $ara=&$___LOCAL_PLAYER__VARS__ara; $arak=&$___LOCAL_PLAYER__VARS__arak; $arae=&$___LOCAL_PLAYER__VARS__arae; $aras=&$___LOCAL_PLAYER__VARS__aras; $arask=&$___LOCAL_PLAYER__VARS__arask; $arf=&$___LOCAL_PLAYER__VARS__arf; $arfk=&$___LOCAL_PLAYER__VARS__arfk; $arfe=&$___LOCAL_PLAYER__VARS__arfe; $arfs=&$___LOCAL_PLAYER__VARS__arfs; $arfsk=&$___LOCAL_PLAYER__VARS__arfsk;  $art=&$___LOCAL_PLAYER__VARS__art; $artk=&$___LOCAL_PLAYER__VARS__artk; $arte=&$___LOCAL_PLAYER__VARS__arte; $arts=&$___LOCAL_PLAYER__VARS__arts; $artsk=&$___LOCAL_PLAYER__VARS__artsk; $itm0=&$___LOCAL_PLAYER__VARS__itm0; $itmk0=&$___LOCAL_PLAYER__VARS__itmk0; $itme0=&$___LOCAL_PLAYER__VARS__itme0; $itms0=&$___LOCAL_PLAYER__VARS__itms0; $itmsk0=&$___LOCAL_PLAYER__VARS__itmsk0;  $itm1=&$___LOCAL_PLAYER__VARS__itm1; $itmk1=&$___LOCAL_PLAYER__VARS__itmk1; $itme1=&$___LOCAL_PLAYER__VARS__itme1; $itms1=&$___LOCAL_PLAYER__VARS__itms1; $itmsk1=&$___LOCAL_PLAYER__VARS__itmsk1; $itm2=&$___LOCAL_PLAYER__VARS__itm2; $itmk2=&$___LOCAL_PLAYER__VARS__itmk2; $itme2=&$___LOCAL_PLAYER__VARS__itme2; $itms2=&$___LOCAL_PLAYER__VARS__itms2; $itmsk2=&$___LOCAL_PLAYER__VARS__itmsk2;  $itm3=&$___LOCAL_PLAYER__VARS__itm3; $itmk3=&$___LOCAL_PLAYER__VARS__itmk3; $itme3=&$___LOCAL_PLAYER__VARS__itme3; $itms3=&$___LOCAL_PLAYER__VARS__itms3; $itmsk3=&$___LOCAL_PLAYER__VARS__itmsk3; $itm4=&$___LOCAL_PLAYER__VARS__itm4; $itmk4=&$___LOCAL_PLAYER__VARS__itmk4; $itme4=&$___LOCAL_PLAYER__VARS__itme4; $itms4=&$___LOCAL_PLAYER__VARS__itms4; $itmsk4=&$___LOCAL_PLAYER__VARS__itmsk4;  $itm5=&$___LOCAL_PLAYER__VARS__itm5; $itmk5=&$___LOCAL_PLAYER__VARS__itmk5; $itme5=&$___LOCAL_PLAYER__VARS__itme5; $itms5=&$___LOCAL_PLAYER__VARS__itms5; $itmsk5=&$___LOCAL_PLAYER__VARS__itmsk5; $itm6=&$___LOCAL_PLAYER__VARS__itm6; $itmk6=&$___LOCAL_PLAYER__VARS__itmk6; $itme6=&$___LOCAL_PLAYER__VARS__itme6; $itms6=&$___LOCAL_PLAYER__VARS__itms6; $itmsk6=&$___LOCAL_PLAYER__VARS__itmsk6;  $searchmemory=&$___LOCAL_PLAYER__VARS__searchmemory; $nskill=&$___LOCAL_PLAYER__VARS__nskill; $nskillpara=&$___LOCAL_PLAYER__VARS__nskillpara;   } while (0);
		if(13 == $gametype)
		{
			if(0 == $pls && !empty($gamevars['crimson_dead']))
			{
				do { global $___LOCAL_EVENT__VARS__event_obbs; $event_obbs=&$___LOCAL_EVENT__VARS__event_obbs;   } while (0);
				$event_obbs = 50;
			}
		}
		//======== Start of contents from mod tutorial ========
		do{
			$___TMP_MOD_tutorial_FUNC_search_area_RET = NULL;

		
		
		
		if(17 == $gametype){
			$ct = \tutorial\get_tutorial ();
			if(30 == $pls && !empty($ct['obj2']['min_money'])){
				do { global $___LOCAL_EVENT__VARS__event_obbs; $event_obbs=&$___LOCAL_EVENT__VARS__event_obbs;   } while (0);
				$event_obbs = 40;
			}
		}
		//======== Start of contents from mod weather ========
		do{
			$___TMP_MOD_weather_FUNC_search_area_RET = NULL;

		
		
		do { global $___LOCAL_MAP__VARS__all_plsno_cache,$___LOCAL_MAP__VARS__areainterval,$___LOCAL_MAP__VARS__areaadd,$___LOCAL_MAP__VARS__areawarntime,$___LOCAL_MAP__VARS__arealimit,$___LOCAL_MAP__VARS__areaesc,$___LOCAL_MAP__VARS__area_on_start,$___LOCAL_MAP__VARS__dangerous_zone,$___LOCAL_MAP__VARS__plsinfo,$___LOCAL_MAP__VARS__plsinfo_o, $___LOCAL_MAP__VARS__plsinfo_disp,$___LOCAL_MAP__VARS__plsinfo_for_short,$___LOCAL_MAP__VARS__xyinfo,$___LOCAL_MAP__VARS__areainfo; $all_plsno_cache=&$___LOCAL_MAP__VARS__all_plsno_cache; $areainterval=&$___LOCAL_MAP__VARS__areainterval; $areaadd=&$___LOCAL_MAP__VARS__areaadd; $areawarntime=&$___LOCAL_MAP__VARS__areawarntime; $arealimit=&$___LOCAL_MAP__VARS__arealimit; $areaesc=&$___LOCAL_MAP__VARS__areaesc; $area_on_start=&$___LOCAL_MAP__VARS__area_on_start; $dangerous_zone=&$___LOCAL_MAP__VARS__dangerous_zone; $plsinfo=&$___LOCAL_MAP__VARS__plsinfo; $plsinfo_o=&$___LOCAL_MAP__VARS__plsinfo_o;  $plsinfo_disp=&$___LOCAL_MAP__VARS__plsinfo_disp; $plsinfo_for_short=&$___LOCAL_MAP__VARS__plsinfo_for_short; $xyinfo=&$___LOCAL_MAP__VARS__xyinfo; $areainfo=&$___LOCAL_MAP__VARS__areainfo;  global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
		if($weather == 13) 
		{
			\weather\deal_hailstorm_weather_damage ();
			if ($hp<=0){ $___TMP_MOD_weather_FUNC_search_area_RET =  false;
			break; }
		} 
		elseif($weather == 14)	
		{
			$dice = rand(0,9);
			if($dice ==0 && strpos($inf,'e')===false){
				$log .= "空气中充斥着的<span class=\"linen b\">狂暴电磁波</span>导致你<span class=\"yellow b\">身体麻痹</span>了！<br>";
				\wound\get_inf('e');
			}elseif($dice ==1 && strpos($inf,'w')===false){
				$log .= "空气中充斥着的<span class=\"linen b\">狂暴电磁波</span>导致你<span class=\"grey b\">混乱</span>了！<br>";
				\wound\get_inf('w');
			}else{
				$log .= "空气中充斥着狂暴的电磁波……<br>";
			}
		} 
		elseif($weather == 15)	
		{
			$dice = rand(0,9);
			if($dice == 0){
				$mhpdown = rand(1,4);
				if($mhp > $mhpdown){
					$log .= "空气中弥漫着的<span class=\"green b\">放射性尘埃</span>导致你的生命上限减少了<span class=\"red b\">{$mhpdown}</span>点！<br>";
					$mhp -= $mhpdown;
					if($hp > $mhp){$hp = $mhp;}
				}
			}else{
				$log .= "空气中弥漫着放射性尘埃……<br>";
			}
		} 
		elseif($weather == 16)	
		{
			$dice = rand(0,9);
			if($dice == 0){
				$defdown = rand(2,5);
				if($def > $defdown){
					$log .= "高强度的<span class=\"purple b\">紫外线照射</span>导致你的防御力减少了<span class=\"red b\">{$defdown}</span>点！<br>";
					$def -= $defdown;if($def < 0) $def = 0;
				}
			}elseif($dice ==1 && strpos($inf,'u')===false){
				$log .= "高强度的<span class=\"purple b\">紫外线照射</span>导致你<span class=\"red b\">烧伤</span>了！<br>";
				\wound\get_inf('u');
			}else{
				$log .= "高强度的紫外线灼烧着大地……<br>";
			}
		} 
		elseif($weather == 17)	
		{
			
		}
		elseif($weather == 18) 
		{
			$dice = rand(0,99);
			if($dice == 0)
			{
				$log .= "你感觉到一股苍凉的杀气！开得过低的空调导致你<span class=\"cyan b\">冻结</span>了！<br>";
				\wound\get_inf('i');
			}elseif($dice <= 10)
			{
				$log .= "你感觉到一股苍凉的杀气！可能是空调开得太冷了。<br>";
			}
		}
		elseif($weather == 19) 
		{
			$dice = rand(0,99);
			if($dice <= 10)
			{
				$log .= "你好像闻到了<span class=\"ltcrimson b\">煤气罐</span>的气味……<br>";
			}
		}
		//======== Start of contents from mod skill6 ========
		do{
			$___TMP_MOD_skill6_FUNC_search_area_RET = NULL;

		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
		if (\skillbase\skill_query(6))
		{
			$damage = round($mhp * 0.03125) + rand(0,10);
			\skill6\deal_burn_move_damage ($damage);
		}
		if($hp <= 0){ $___TMP_MOD_skill6_FUNC_search_area_RET =  false;
			break; }
if(isset($damage)) {$__VAR_DUMP_MOD_skill6_VARS_damage = $damage; unset($damage); } else {$__VAR_DUMP_MOD_skill6_VARS_damage = NULL;} 
		//======== Start of contents from mod skill5 ========
		do{
			$___TMP_MOD_skill5_FUNC_search_area_RET = NULL;

		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
		if (\skillbase\skill_query(5))
		{
			$damage = round($mhp * 0.03125) + rand(0,10);
			\skill5\deal_poison_move_damage ($damage);
		}
		if($hp <= 0){ $___TMP_MOD_skill5_FUNC_search_area_RET =  false;
			break; }
		//======== Start of contents from mod explore ========
		do{
			$___TMP_MOD_explore_FUNC_search_area_RET = NULL;

		
		$___TMP_MOD_explore_FUNC_search_area_RET =  \explore\discover ('search');
			break; 
		}while(0);
		//======== End of contents from mod explore ========

		$___TMP_MOD_skill5_FUNC_search_area_RET =  $___TMP_MOD_explore_FUNC_search_area_RET;
			break; 
		}while(0);
		//======== End of contents from mod skill5 ========

$damage = $__VAR_DUMP_MOD_skill6_VARS_damage; 
		$___TMP_MOD_skill6_FUNC_search_area_RET =  $___TMP_MOD_skill5_FUNC_search_area_RET;
			break; 
		}while(0);
		//======== End of contents from mod skill6 ========

		$___TMP_MOD_weather_FUNC_search_area_RET =  $___TMP_MOD_skill6_FUNC_search_area_RET;
			break; 
		}while(0);
		//======== End of contents from mod weather ========

		
		$___TMP_MOD_tutorial_FUNC_search_area_RET =  $___TMP_MOD_weather_FUNC_search_area_RET;
			break; 
		}while(0);
		//======== End of contents from mod tutorial ========

		
		return $___TMP_MOD_tutorial_FUNC_search_area_RET;
	
	}
	
	
	function kill(&$pa, &$pd)
	{
		return \skill576\kill($pa,$pd);
	}
	
	function event_core($dice, $dice2)
	{
		
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;  global $___LOCAL_PLAYER__VARS__ss,$___LOCAL_PLAYER__VARS__db_player_structure,$___LOCAL_PLAYER__VARS__db_player_structure_types,$___LOCAL_PLAYER__VARS__gamedata,$___LOCAL_PLAYER__VARS__cmd,$___LOCAL_PLAYER__VARS__main,$___LOCAL_PLAYER__VARS__sdata,$___LOCAL_PLAYER__VARS__fog,$___LOCAL_PLAYER__VARS__upexp,$___LOCAL_PLAYER__VARS__lvlupexp, $___LOCAL_PLAYER__VARS__iconImg,$___LOCAL_PLAYER__VARS__iconImgB,$___LOCAL_PLAYER__VARS__iconImgBwidth,$___LOCAL_PLAYER__VARS__ardef,$___LOCAL_PLAYER__VARS__hpcolor,$___LOCAL_PLAYER__VARS__spcolor,$___LOCAL_PLAYER__VARS__newhpimg,$___LOCAL_PLAYER__VARS__newspimg,$___LOCAL_PLAYER__VARS__splt,$___LOCAL_PLAYER__VARS__hplt, $___LOCAL_PLAYER__VARS__tpldata,$___LOCAL_PLAYER__VARS__icon_list,$___LOCAL_PLAYER__VARS__icon_list_contents_to_frontend,$___LOCAL_PLAYER__VARS__typeinfo,$___LOCAL_PLAYER__VARS__killmsginfo,$___LOCAL_PLAYER__VARS__lwinfo,$___LOCAL_PLAYER__VARS__sexinfo,$___LOCAL_PLAYER__VARS__equip_list,$___LOCAL_PLAYER__VARS__battle_equip_list,$___LOCAL_PLAYER__VARS__pc_icon_range, $___LOCAL_PLAYER__VARS__pid,$___LOCAL_PLAYER__VARS__type,$___LOCAL_PLAYER__VARS__name,$___LOCAL_PLAYER__VARS__pass,$___LOCAL_PLAYER__VARS__ip,$___LOCAL_PLAYER__VARS__motto,$___LOCAL_PLAYER__VARS__killmsg,$___LOCAL_PLAYER__VARS__lastword,$___LOCAL_PLAYER__VARS__winner_flag,$___LOCAL_PLAYER__VARS__player_dead_flag, $___LOCAL_PLAYER__VARS__corpse_clear_flag,$___LOCAL_PLAYER__VARS__gd,$___LOCAL_PLAYER__VARS__sNo,$___LOCAL_PLAYER__VARS__club,$___LOCAL_PLAYER__VARS__validtime,$___LOCAL_PLAYER__VARS__endtime,$___LOCAL_PLAYER__VARS__cdsec,$___LOCAL_PLAYER__VARS__cdmsec,$___LOCAL_PLAYER__VARS__cdtime,$___LOCAL_PLAYER__VARS__action, $___LOCAL_PLAYER__VARS__a_actionnum,$___LOCAL_PLAYER__VARS__v_actionnum,$___LOCAL_PLAYER__VARS__hp,$___LOCAL_PLAYER__VARS__mhp,$___LOCAL_PLAYER__VARS__sp,$___LOCAL_PLAYER__VARS__msp,$___LOCAL_PLAYER__VARS__mss,$___LOCAL_PLAYER__VARS__att,$___LOCAL_PLAYER__VARS__def,$___LOCAL_PLAYER__VARS__pls, $___LOCAL_PLAYER__VARS__lvl,$___LOCAL_PLAYER__VARS__exp,$___LOCAL_PLAYER__VARS__money,$___LOCAL_PLAYER__VARS__rp,$___LOCAL_PLAYER__VARS__bid,$___LOCAL_PLAYER__VARS__inf,$___LOCAL_PLAYER__VARS__rage,$___LOCAL_PLAYER__VARS__pose,$___LOCAL_PLAYER__VARS__tactic,$___LOCAL_PLAYER__VARS__killnum, $___LOCAL_PLAYER__VARS__npckillnum,$___LOCAL_PLAYER__VARS__state,$___LOCAL_PLAYER__VARS__skillpoint,$___LOCAL_PLAYER__VARS__flare,$___LOCAL_PLAYER__VARS__wp,$___LOCAL_PLAYER__VARS__wk,$___LOCAL_PLAYER__VARS__wg,$___LOCAL_PLAYER__VARS__wc,$___LOCAL_PLAYER__VARS__wd,$___LOCAL_PLAYER__VARS__wf, $___LOCAL_PLAYER__VARS__icon,$___LOCAL_PLAYER__VARS__teamID,$___LOCAL_PLAYER__VARS__teamPass,$___LOCAL_PLAYER__VARS__card,$___LOCAL_PLAYER__VARS__cardname,$___LOCAL_PLAYER__VARS__wep,$___LOCAL_PLAYER__VARS__wepk,$___LOCAL_PLAYER__VARS__wepe,$___LOCAL_PLAYER__VARS__weps,$___LOCAL_PLAYER__VARS__wepsk, $___LOCAL_PLAYER__VARS__arb,$___LOCAL_PLAYER__VARS__arbk,$___LOCAL_PLAYER__VARS__arbe,$___LOCAL_PLAYER__VARS__arbs,$___LOCAL_PLAYER__VARS__arbsk,$___LOCAL_PLAYER__VARS__arh,$___LOCAL_PLAYER__VARS__arhk,$___LOCAL_PLAYER__VARS__arhe,$___LOCAL_PLAYER__VARS__arhs,$___LOCAL_PLAYER__VARS__arhsk, $___LOCAL_PLAYER__VARS__ara,$___LOCAL_PLAYER__VARS__arak,$___LOCAL_PLAYER__VARS__arae,$___LOCAL_PLAYER__VARS__aras,$___LOCAL_PLAYER__VARS__arask,$___LOCAL_PLAYER__VARS__arf,$___LOCAL_PLAYER__VARS__arfk,$___LOCAL_PLAYER__VARS__arfe,$___LOCAL_PLAYER__VARS__arfs,$___LOCAL_PLAYER__VARS__arfsk, $___LOCAL_PLAYER__VARS__art,$___LOCAL_PLAYER__VARS__artk,$___LOCAL_PLAYER__VARS__arte,$___LOCAL_PLAYER__VARS__arts,$___LOCAL_PLAYER__VARS__artsk,$___LOCAL_PLAYER__VARS__itm0,$___LOCAL_PLAYER__VARS__itmk0,$___LOCAL_PLAYER__VARS__itme0,$___LOCAL_PLAYER__VARS__itms0,$___LOCAL_PLAYER__VARS__itmsk0, $___LOCAL_PLAYER__VARS__itm1,$___LOCAL_PLAYER__VARS__itmk1,$___LOCAL_PLAYER__VARS__itme1,$___LOCAL_PLAYER__VARS__itms1,$___LOCAL_PLAYER__VARS__itmsk1,$___LOCAL_PLAYER__VARS__itm2,$___LOCAL_PLAYER__VARS__itmk2,$___LOCAL_PLAYER__VARS__itme2,$___LOCAL_PLAYER__VARS__itms2,$___LOCAL_PLAYER__VARS__itmsk2, $___LOCAL_PLAYER__VARS__itm3,$___LOCAL_PLAYER__VARS__itmk3,$___LOCAL_PLAYER__VARS__itme3,$___LOCAL_PLAYER__VARS__itms3,$___LOCAL_PLAYER__VARS__itmsk3,$___LOCAL_PLAYER__VARS__itm4,$___LOCAL_PLAYER__VARS__itmk4,$___LOCAL_PLAYER__VARS__itme4,$___LOCAL_PLAYER__VARS__itms4,$___LOCAL_PLAYER__VARS__itmsk4, $___LOCAL_PLAYER__VARS__itm5,$___LOCAL_PLAYER__VARS__itmk5,$___LOCAL_PLAYER__VARS__itme5,$___LOCAL_PLAYER__VARS__itms5,$___LOCAL_PLAYER__VARS__itmsk5,$___LOCAL_PLAYER__VARS__itm6,$___LOCAL_PLAYER__VARS__itmk6,$___LOCAL_PLAYER__VARS__itme6,$___LOCAL_PLAYER__VARS__itms6,$___LOCAL_PLAYER__VARS__itmsk6, $___LOCAL_PLAYER__VARS__searchmemory,$___LOCAL_PLAYER__VARS__nskill,$___LOCAL_PLAYER__VARS__nskillpara; $ss=&$___LOCAL_PLAYER__VARS__ss; $db_player_structure=&$___LOCAL_PLAYER__VARS__db_player_structure; $db_player_structure_types=&$___LOCAL_PLAYER__VARS__db_player_structure_types; $gamedata=&$___LOCAL_PLAYER__VARS__gamedata; $cmd=&$___LOCAL_PLAYER__VARS__cmd; $main=&$___LOCAL_PLAYER__VARS__main; $sdata=&$___LOCAL_PLAYER__VARS__sdata; $fog=&$___LOCAL_PLAYER__VARS__fog; $upexp=&$___LOCAL_PLAYER__VARS__upexp; $lvlupexp=&$___LOCAL_PLAYER__VARS__lvlupexp;  $iconImg=&$___LOCAL_PLAYER__VARS__iconImg; $iconImgB=&$___LOCAL_PLAYER__VARS__iconImgB; $iconImgBwidth=&$___LOCAL_PLAYER__VARS__iconImgBwidth; $ardef=&$___LOCAL_PLAYER__VARS__ardef; $hpcolor=&$___LOCAL_PLAYER__VARS__hpcolor; $spcolor=&$___LOCAL_PLAYER__VARS__spcolor; $newhpimg=&$___LOCAL_PLAYER__VARS__newhpimg; $newspimg=&$___LOCAL_PLAYER__VARS__newspimg; $splt=&$___LOCAL_PLAYER__VARS__splt; $hplt=&$___LOCAL_PLAYER__VARS__hplt;  $tpldata=&$___LOCAL_PLAYER__VARS__tpldata; $icon_list=&$___LOCAL_PLAYER__VARS__icon_list; $icon_list_contents_to_frontend=&$___LOCAL_PLAYER__VARS__icon_list_contents_to_frontend; $typeinfo=&$___LOCAL_PLAYER__VARS__typeinfo; $killmsginfo=&$___LOCAL_PLAYER__VARS__killmsginfo; $lwinfo=&$___LOCAL_PLAYER__VARS__lwinfo; $sexinfo=&$___LOCAL_PLAYER__VARS__sexinfo; $equip_list=&$___LOCAL_PLAYER__VARS__equip_list; $battle_equip_list=&$___LOCAL_PLAYER__VARS__battle_equip_list; $pc_icon_range=&$___LOCAL_PLAYER__VARS__pc_icon_range;  $pid=&$___LOCAL_PLAYER__VARS__pid; $type=&$___LOCAL_PLAYER__VARS__type; $name=&$___LOCAL_PLAYER__VARS__name; $pass=&$___LOCAL_PLAYER__VARS__pass; $ip=&$___LOCAL_PLAYER__VARS__ip; $motto=&$___LOCAL_PLAYER__VARS__motto; $killmsg=&$___LOCAL_PLAYER__VARS__killmsg; $lastword=&$___LOCAL_PLAYER__VARS__lastword; $winner_flag=&$___LOCAL_PLAYER__VARS__winner_flag; $player_dead_flag=&$___LOCAL_PLAYER__VARS__player_dead_flag;  $corpse_clear_flag=&$___LOCAL_PLAYER__VARS__corpse_clear_flag; $gd=&$___LOCAL_PLAYER__VARS__gd; $sNo=&$___LOCAL_PLAYER__VARS__sNo; $club=&$___LOCAL_PLAYER__VARS__club; $validtime=&$___LOCAL_PLAYER__VARS__validtime; $endtime=&$___LOCAL_PLAYER__VARS__endtime; $cdsec=&$___LOCAL_PLAYER__VARS__cdsec; $cdmsec=&$___LOCAL_PLAYER__VARS__cdmsec; $cdtime=&$___LOCAL_PLAYER__VARS__cdtime; $action=&$___LOCAL_PLAYER__VARS__action;  $a_actionnum=&$___LOCAL_PLAYER__VARS__a_actionnum; $v_actionnum=&$___LOCAL_PLAYER__VARS__v_actionnum; $hp=&$___LOCAL_PLAYER__VARS__hp; $mhp=&$___LOCAL_PLAYER__VARS__mhp; $sp=&$___LOCAL_PLAYER__VARS__sp; $msp=&$___LOCAL_PLAYER__VARS__msp; $mss=&$___LOCAL_PLAYER__VARS__mss; $att=&$___LOCAL_PLAYER__VARS__att; $def=&$___LOCAL_PLAYER__VARS__def; $pls=&$___LOCAL_PLAYER__VARS__pls;  $lvl=&$___LOCAL_PLAYER__VARS__lvl; $exp=&$___LOCAL_PLAYER__VARS__exp; $money=&$___LOCAL_PLAYER__VARS__money; $rp=&$___LOCAL_PLAYER__VARS__rp; $bid=&$___LOCAL_PLAYER__VARS__bid; $inf=&$___LOCAL_PLAYER__VARS__inf; $rage=&$___LOCAL_PLAYER__VARS__rage; $pose=&$___LOCAL_PLAYER__VARS__pose; $tactic=&$___LOCAL_PLAYER__VARS__tactic; $killnum=&$___LOCAL_PLAYER__VARS__killnum;  $npckillnum=&$___LOCAL_PLAYER__VARS__npckillnum; $state=&$___LOCAL_PLAYER__VARS__state; $skillpoint=&$___LOCAL_PLAYER__VARS__skillpoint; $flare=&$___LOCAL_PLAYER__VARS__flare; $wp=&$___LOCAL_PLAYER__VARS__wp; $wk=&$___LOCAL_PLAYER__VARS__wk; $wg=&$___LOCAL_PLAYER__VARS__wg; $wc=&$___LOCAL_PLAYER__VARS__wc; $wd=&$___LOCAL_PLAYER__VARS__wd; $wf=&$___LOCAL_PLAYER__VARS__wf;  $icon=&$___LOCAL_PLAYER__VARS__icon; $teamID=&$___LOCAL_PLAYER__VARS__teamID; $teamPass=&$___LOCAL_PLAYER__VARS__teamPass; $card=&$___LOCAL_PLAYER__VARS__card; $cardname=&$___LOCAL_PLAYER__VARS__cardname; $wep=&$___LOCAL_PLAYER__VARS__wep; $wepk=&$___LOCAL_PLAYER__VARS__wepk; $wepe=&$___LOCAL_PLAYER__VARS__wepe; $weps=&$___LOCAL_PLAYER__VARS__weps; $wepsk=&$___LOCAL_PLAYER__VARS__wepsk;  $arb=&$___LOCAL_PLAYER__VARS__arb; $arbk=&$___LOCAL_PLAYER__VARS__arbk; $arbe=&$___LOCAL_PLAYER__VARS__arbe; $arbs=&$___LOCAL_PLAYER__VARS__arbs; $arbsk=&$___LOCAL_PLAYER__VARS__arbsk; $arh=&$___LOCAL_PLAYER__VARS__arh; $arhk=&$___LOCAL_PLAYER__VARS__arhk; $arhe=&$___LOCAL_PLAYER__VARS__arhe; $arhs=&$___LOCAL_PLAYER__VARS__arhs; $arhsk=&$___LOCAL_PLAYER__VARS__arhsk;  $ara=&$___LOCAL_PLAYER__VARS__ara; $arak=&$___LOCAL_PLAYER__VARS__arak; $arae=&$___LOCAL_PLAYER__VARS__arae; $aras=&$___LOCAL_PLAYER__VARS__aras; $arask=&$___LOCAL_PLAYER__VARS__arask; $arf=&$___LOCAL_PLAYER__VARS__arf; $arfk=&$___LOCAL_PLAYER__VARS__arfk; $arfe=&$___LOCAL_PLAYER__VARS__arfe; $arfs=&$___LOCAL_PLAYER__VARS__arfs; $arfsk=&$___LOCAL_PLAYER__VARS__arfsk;  $art=&$___LOCAL_PLAYER__VARS__art; $artk=&$___LOCAL_PLAYER__VARS__artk; $arte=&$___LOCAL_PLAYER__VARS__arte; $arts=&$___LOCAL_PLAYER__VARS__arts; $artsk=&$___LOCAL_PLAYER__VARS__artsk; $itm0=&$___LOCAL_PLAYER__VARS__itm0; $itmk0=&$___LOCAL_PLAYER__VARS__itmk0; $itme0=&$___LOCAL_PLAYER__VARS__itme0; $itms0=&$___LOCAL_PLAYER__VARS__itms0; $itmsk0=&$___LOCAL_PLAYER__VARS__itmsk0;  $itm1=&$___LOCAL_PLAYER__VARS__itm1; $itmk1=&$___LOCAL_PLAYER__VARS__itmk1; $itme1=&$___LOCAL_PLAYER__VARS__itme1; $itms1=&$___LOCAL_PLAYER__VARS__itms1; $itmsk1=&$___LOCAL_PLAYER__VARS__itmsk1; $itm2=&$___LOCAL_PLAYER__VARS__itm2; $itmk2=&$___LOCAL_PLAYER__VARS__itmk2; $itme2=&$___LOCAL_PLAYER__VARS__itme2; $itms2=&$___LOCAL_PLAYER__VARS__itms2; $itmsk2=&$___LOCAL_PLAYER__VARS__itmsk2;  $itm3=&$___LOCAL_PLAYER__VARS__itm3; $itmk3=&$___LOCAL_PLAYER__VARS__itmk3; $itme3=&$___LOCAL_PLAYER__VARS__itme3; $itms3=&$___LOCAL_PLAYER__VARS__itms3; $itmsk3=&$___LOCAL_PLAYER__VARS__itmsk3; $itm4=&$___LOCAL_PLAYER__VARS__itm4; $itmk4=&$___LOCAL_PLAYER__VARS__itmk4; $itme4=&$___LOCAL_PLAYER__VARS__itme4; $itms4=&$___LOCAL_PLAYER__VARS__itms4; $itmsk4=&$___LOCAL_PLAYER__VARS__itmsk4;  $itm5=&$___LOCAL_PLAYER__VARS__itm5; $itmk5=&$___LOCAL_PLAYER__VARS__itmk5; $itme5=&$___LOCAL_PLAYER__VARS__itme5; $itms5=&$___LOCAL_PLAYER__VARS__itms5; $itmsk5=&$___LOCAL_PLAYER__VARS__itmsk5; $itm6=&$___LOCAL_PLAYER__VARS__itm6; $itmk6=&$___LOCAL_PLAYER__VARS__itmk6; $itme6=&$___LOCAL_PLAYER__VARS__itme6; $itms6=&$___LOCAL_PLAYER__VARS__itms6; $itmsk6=&$___LOCAL_PLAYER__VARS__itmsk6;  $searchmemory=&$___LOCAL_PLAYER__VARS__searchmemory; $nskill=&$___LOCAL_PLAYER__VARS__nskill; $nskillpara=&$___LOCAL_PLAYER__VARS__nskillpara;  global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
if(isset($dice)) {$__VAR_DUMP_MOD_instance3_VARS_dice = $dice; } else {$__VAR_DUMP_MOD_instance3_VARS_dice = NULL;} if(isset($dice2)) {$__VAR_DUMP_MOD_instance3_VARS_dice2 = $dice2; } else {$__VAR_DUMP_MOD_instance3_VARS_dice2 = NULL;} 
		//======== Start of contents from mod tutorial ========
		do{
			$___TMP_MOD_tutorial_FUNC_event_core_RET = NULL;

		
		
if(isset($dice)) {$__VAR_DUMP_MOD_tutorial_VARS_dice = $dice; } else {$__VAR_DUMP_MOD_tutorial_VARS_dice = NULL;} if(isset($dice2)) {$__VAR_DUMP_MOD_tutorial_VARS_dice2 = $dice2; } else {$__VAR_DUMP_MOD_tutorial_VARS_dice2 = NULL;} 
		//======== Start of contents from mod event ========
		do{
			$___TMP_MOD_event_FUNC_event_core_RET = NULL;

		
		do { global $___LOCAL_MAP__VARS__all_plsno_cache,$___LOCAL_MAP__VARS__areainterval,$___LOCAL_MAP__VARS__areaadd,$___LOCAL_MAP__VARS__areawarntime,$___LOCAL_MAP__VARS__arealimit,$___LOCAL_MAP__VARS__areaesc,$___LOCAL_MAP__VARS__area_on_start,$___LOCAL_MAP__VARS__dangerous_zone,$___LOCAL_MAP__VARS__plsinfo,$___LOCAL_MAP__VARS__plsinfo_o, $___LOCAL_MAP__VARS__plsinfo_disp,$___LOCAL_MAP__VARS__plsinfo_for_short,$___LOCAL_MAP__VARS__xyinfo,$___LOCAL_MAP__VARS__areainfo; $all_plsno_cache=&$___LOCAL_MAP__VARS__all_plsno_cache; $areainterval=&$___LOCAL_MAP__VARS__areainterval; $areaadd=&$___LOCAL_MAP__VARS__areaadd; $areawarntime=&$___LOCAL_MAP__VARS__areawarntime; $arealimit=&$___LOCAL_MAP__VARS__arealimit; $areaesc=&$___LOCAL_MAP__VARS__areaesc; $area_on_start=&$___LOCAL_MAP__VARS__area_on_start; $dangerous_zone=&$___LOCAL_MAP__VARS__dangerous_zone; $plsinfo=&$___LOCAL_MAP__VARS__plsinfo; $plsinfo_o=&$___LOCAL_MAP__VARS__plsinfo_o;  $plsinfo_disp=&$___LOCAL_MAP__VARS__plsinfo_disp; $plsinfo_for_short=&$___LOCAL_MAP__VARS__plsinfo_for_short; $xyinfo=&$___LOCAL_MAP__VARS__xyinfo; $areainfo=&$___LOCAL_MAP__VARS__areainfo;   } while (0);
		$ret = 0;
		
		switch ($pls) {
			case 2:
				$log .= '<br>突然，一个头戴面具的制服怪人华丽地现身，向你发出不容拒绝的挑战！<br>';
				
				$winrate = \event\event_winrate_process (10 + ($hp - 400) / 10);
				if($dice < $winrate) {
					$log .= '你奋力还击，怪人“呜嘛呜——！”地怪叫着。<br>';
					if(rand(0,99) < 20 && $rp <= 45) {
						$log .= '他双手奉上一个钱包，转身逃走了。<br>钱包里面是'.$dice2.'个硬币……<br>';
						\event\event_get_money ($dice2);
						\event\event_get_rp (15);
					}else{
						$log .= '借此机会，你顺利逃跑了。<br>';
					}
				}else{
					$log .= '“呜嘛呜——！”怪人挥动长矛（的柄），打中了你的脑袋！<br>';
					if(rand(0,99) < 50) {
						\event\event_suffer_inf ('h');
					}else{
						\event\event_suffer_dmg ($dice2);
					}
				}
				$ret = 1;
				break;
			
			case 3:
				if($rp <= 70){
					$log .= '在你正要穿过商店街拐角时，一名拿着纸袋的少女朝你撞来！<br><br>';
					
					$escrate = \event\event_escrate_process (20 + $lvl/3);
					if($dice < $escrate) {
						$log .= '你敏捷地一闪，成功回避了被撞倒的厄运，而少女面朝下重重地摔在地上。<br>少女“呜咕……”地哭泣着，爬起来跑掉了。而你觉得有些过意不去。<br>';
						\event\event_get_rp ($dice2);
					}else{
						$log .= '你回避不及，被少女撞个正着！<br>你重重地摔在地上，而少女因为有你做缓冲，幸免于难。<br>';
						\event\event_suffer_dmg ($dice2);
						\event\event_suffer_inf (array_randompick(Array('h','b','a','f')));
						$log .= '<br>少女忙不迭地向你道歉，并把她手中的鲷鱼烧塞给了你，然后飞快地跑掉了。<br>';
						$getitem = Array(
							'itm' => '鲷鱼烧',
							'itmk' => 'HB',
							'itme' => 500,
							'itms' => 2,
							'itmsk' => 'z'
						);
						\event\event_get_item ($getitem);
						\event\event_get_rp ($dice2);
					}
				}else{
					$log .= '在你正要穿过商店街拐角时，一个瘦高的身影朝你撞来！<br>哗，原来是一具穿着围巾和披风的大只骷髅！<br>从那热忱的眼神，开朗的笑意，便知他是骷髅中的极品了！<br><br>';
					
					$escrate = \event\event_escrate_process (20 + $lvl/3);
					if($dice < $escrate){
						$log .= '你敏捷地一闪，成功回避了被撞倒的厄运，而骷髅面朝下重重地摔在地上。<br>看着骷髅在地上扑腾的诡异光景，你吓得转身就跑。<br>';
						\event\event_get_rp ($dice2);
					}
					else{
						$log .= '你回避不及，被骷髅撞个正着！<br>你重重地摔在地上，而骷髅因为有你做缓冲，幸免于难。<br>';
						\event\event_suffer_dmg ($dice2 * 2);
						\event\event_suffer_inf (array_randompick(Array('h','b','a','f')));
						if($rp < 1000) {
							$log .= '<br>骷髅忙不迭地向你道歉，向你解释说他是这里的保安，并把他的名片塞给了你。<br>';
							$getitem = Array(
								'itm' => '自奏圣乐·谐谑曲骷髅 ★3',
								'itmk' => 'WC03',
								'itme' => 120,
								'itms' => 1,
								'itmsk' => 'O'
							);
							\event\event_get_item ($getitem);
							$log .= '直到骷髅离开，你依然觉得此事甚为诡异。<br>';
							\event\event_get_rp ($dice2);
						}else{
							$log .= '<br>骷髅把你拉了起来，对你进行了一通安全教育之后离开了。<br>';
						}
					}
				}		
				$ret = 1;
				break;

			case 21:
				if(\gameflow_duel\is_gamestate_duel()) {
					$log .= '<br>就在不久之前，特殊部队『天使』的少女们正在这里实弹演习，不过现在她们不知所踪。<br>';
				}else{
					$log .= '<br>隶属于时空部门G的特殊部队『天使』的少女们驾驶着帅气的机体，正在进行实弹演习！<br>你被卷入了弹幕中！<br>';
					
					if($dice < 1 && $rp > 40 && $killnum > 0) {
						$log .= '咦，头顶上……好像有一名少女被弹幕击中了……？<br>';
						\event\event_death (33);
						$___TMP_MOD_event_FUNC_event_core_RET =  $ret;
			break; 
					}
					
					$escrate = \event\event_escrate_process (33 + $lvl/3);
					if($dice < $escrate) {
						$log .= '在弹幕的狂风中，你有惊无险地回避着弹幕，总算擦弹成功了。<br>';
						
						if($dice < 5 && $rp < 100) {
							$log .= '<br>你看见驾驶着棕色机体的少女向你飞来。<br>“实在对不起，我们看起来没有放假的时候啊。危险躲藏在每个大意之中不是么？”<br>她扔给了你一叠东西，看起来是面额为573的『纸币』？<br>“祝你好运！”少女这么说完就飞走了。<br>';
							\event\event_get_money (573);
							$log .= '<br>这样的纸钞真的能用吗……？<br>';
							\event\event_get_rp (100);
						}
					}else{
						$log .= '<br>在弹幕的狂风中，你徒劳地试图回避弹幕……<br>擦弹什么的根本做不到啊！<br><br>你被少女们打成了筛子！<br>';
						
						$infcache = '';
						foreach(Array('h','b','a','f') as $v){
							if(rand(0,99) <= 60){
								$infcache .= $v;
							}
						}
						if(!empty($infcache)) \event\event_suffer_inf ($infcache);
						
						if($dice2 >= 39){
							$log .= '并且，弹幕击中了要害！<br><span class="red b">你感觉自己的小命差点就交代在这里了</span>。<br>';
							\event\event_suffer_dmg ($hp-1);
						}
						elseif($dice2 >= 36){
							$log .= '一发<span class="cyan b">黑洞激光</span>正中你的面门，';
							\event\event_suffer_inf ('i');
						}
						elseif($dice2 >= 33){
							$log .= '一发<span class="red b">环形激光</span>正中你的面门，';
							\event\event_suffer_inf ('u');
						}
						elseif($dice2 >= 30){
							$log .= '一发<span class="yellow b">精神震荡弹</span>正中你的面门，';
							\event\event_suffer_inf ('e');
						}
						elseif($dice2 >= 27){
							$log .= '一发<span class="grey b">音波装备</span>正中你的面门，';
							\event\event_suffer_inf ('w');
						}
						elseif($dice2 >= 24){
							$log .= '一发<span class="purple b">干扰用强袭装备</span>正中你的面门，';
							\event\event_suffer_inf ('p');
						}
						if(!empty($inf) || $hp < 10) $log .= '<br>你遍体鳞伤、连滚带爬地逃走了。<br><br>';
						else $log .= '<br>你一边离开战场，一边庆幸还能全身而退。<br><br>';
					}
				}
				$ret = 1;
				break;
			case 7:
				$log .= '在你东张西望时，四周突然聚集起一股寒气。<br>一名<span class="cyan b">看起来很智慧的冰精</span>在湖面上现身，并向你发出决定最强者的挑战！<br><br>';
				
				$winrate = \event\event_winrate_process (9 + $skillpoint * 9);
				if($dice < $winrate) {
					$log .= '你急中生智，向对方发问：⑨+10等于多少？<br>冰精果然掰起手指开始计算，而你趁机逃离了现场。<br>';
				}else{
					$log .= '没等你回应，成片的冰柱就向你射来！你手忙脚乱地开始躲避弹幕。<br>';
					$spdown = $dice2;
					\event\event_get_field (-$spdown, 'sp');
					if($rp > 1000) {
						\event\event_suffer_inf ('i');
					}
					$log .= '冰柱掀起的烟尘遮盖了视线，你连忙逃离了现场。<br>';
				}

				$ret = 1;
				break;
			case 15:
				$log .= '伴随着诡异的怪笑声，令人眼花缭乱的弹幕从四面八方飞来。<br>有妖怪来袭击人类了！<br><br>';
				
				$escrate = \event\event_escrate_process (60 + $lvl/3);
				if($dice < $escrate){
					if($dice2 == 40 && $rp < 100) {
						$log .= '你躲开袭来的弹幕，定睛看去，所谓的妖怪不过是个配色像蔬菜一样的少女而已。<br>似乎是察觉到被发现了，她把一双拖鞋塞到你手中，蹦蹦跳跳地跑掉了。<br>';
						$getitem = Array(
							'itm' => '小五拖鞋',
							'itmk' => 'DF',
							'itme' => 5,
							'itms' => 10,
							'itmsk' => ''
						);
						\event\event_get_item ($getitem);
						$log .= '<br>妖怪的想法真难猜啊。<br>你决定还是不要操心了。<br>';
						\event\event_get_rp ($dice2);
					}elseif($dice2 > 30 && $rp < 100) {
						$log .= '你躲开袭来的弹幕，定睛看去，所谓的妖怪不过是个长着狐狸尾巴的少女而已。<br>对方见弹幕都被躲过，丢下用于攻击的道具就离开了。<br>';
						$getitem = Array(
							'itm' => '试管',
							'itmk' => 'WC',
							'itme' => 1,
							'itms' => 1,
							'itmsk' => '^res_<:comp_itmsk:>{空瓶,X,1,1,,}1^reptype2^rtype4'
						);
						\event\event_get_item ($getitem);
						$log .= '<br>你觉得刚才的战斗有些意犹未尽。<br>';
						\event\event_get_rp ($dice2);
					}else{
						$log .= '你躲开袭来的弹幕，定睛看去，所谓的妖怪不过是个举着紫色怪伞的少女而已。<br>趁她不知所措，你抢先一步上去摸了摸少女的头，把她吓得夺路而逃。<br>手感挺好的，真是可惜啊。<br>';
						
					}
				}else{
					if(rand(0,1)) {
						$log .= '被妖怪撒出的弹幕吓着了！<br>你慌不择路，一头撞到了林立的御柱上！<br>';
						\event\event_suffer_inf ('h');
					}else{
						$log .= '妖怪撒出了密集的爱心……不，是密集的弹幕！<br>';
						\event\event_suffer_dmg ($dice2);
					}
				}
				$ret = 1;
				break;

			case 16:
				$log .= '野生的黄色老鼠从草丛中钻了出来！<br>你需要一只帕鲁才能对战，但你并没有一只帕鲁。<br><br>';
				
				$escrate = \event\event_escrate_process (60 + $lvl/3);
				if($dice < $escrate){
					$log .= '不过你还是成功地逃跑了。<br>';
				}else{
					if(rand(0,1)) {
						$log .= '黄色老鼠使用了电击！<br>';
						if($rp > 1000) {
							\event\event_suffer_inf (array_randompick(Array('h','b','a','f')).'e');
						}else{
							\event\event_suffer_inf (array_randompick(Array('h','b','a','f')));
						}
					}else{
						$log .= '黄色老鼠使用了电光石火！<br>';
						\event\event_suffer_dmg ($dice2);
					}
				}

				$ret = 1;
				break;

			case 33:
				$kdata = \player\fetch_playerdata('■', 4);
				if(empty($kdata)) {
					$flag = 0;
				}elseif($kdata['hp'] > 0) {
					$flag = 1;
				}else{
					$flag = 2;
				}
				unset($kdata);

				$log .= '<br>';
				if(1 == $flag){
					$log .= '端坐在雏菊之丘的少女现在拥有敌意。<br>明白这一点的你，刻意躲避着少女的追踪——现在不用担心被绘卷搞得七窍流血了。<br>';
				}elseif(2 == $flag){
					$log .= '雏菊盛开的山丘上，少女的尸体静静地躺着，犹如睡着了一般——这里再也没有任何危险了。<br>但不知为何，你丝毫没有轻松的感觉。<br>';
				}else{
					if ($dice < 30){
						if ($rp < 40){
							$log .= '少女抬头看了你一眼，随后低下头去继续她的研究。<br>';
							\event\event_get_rp (round($dice2 / 2));
						}elseif ($rp < 500){
							$log .= '少女抬头看了你一眼，视线在你身上多停留了几秒钟，随后低下头去继续她的研究。<br>';
							\event\event_get_rp (round($dice2 * 2.5));
						}elseif ($rp < 1000 && $killnum == 0){
							$log .= '少女抬头看了你一眼。<br>从那深不可测的眼神中，你读不出任何情感，但不知为什么，你觉得身体稍微舒服了些。<br>';
							$spup = round($dice2 * 2.5);
							if($sp + $spup > $msp) $spup = $msp - $sp;
							if($spup) {
								\event\event_get_field ($spup, 'sp');
								\event\event_get_rp ($spup);
							}
						}elseif ($rp < 1000){
							$log .= '少女抬头看了你一眼。<br>从那深不可测的眼神中，你读不出任何情感，但不知为什么，你觉得双腿一软……<br>';
							$spdown = round($rp/4);
							\event\event_get_field (-$spdown, 'sp');
						}elseif ($rp < 5000 && $killnum == 0){
							$log .= '少女抬头看了你一眼，随后起身离去。<br>你好奇地看向少女原本翻看的那幅不明『绘卷』……<br>';
							\event\event_suffer_dmg (floor($hp / 2));
							$log .= '『绘卷』记述的知识对你来说太沉重了！<br>你浑身冒血、连滚带爬地逃走了。<br>';
							\event\event_get_rp (-$dice2);
						}else{
							$log .= '少女抬头看了你一眼，随后起身离去。<br>你好奇地看向少女原本翻看的那幅不明『绘卷』……<br><br>';
							\event\event_suffer_dmg (floor($hp * 2 / 3));
							$min_msp = 51;
							if($msp > $min_msp) {
								$mspdown = round($dice2);
								if($msp - $mspdown < $min_msp) {
									$mspdown = $msp - $min_msp;
								}
								\event\event_get_field (-$mspdown, 'sp');
								\event\event_get_field (-$mspdown, 'msp');
							}
							$log .= '<br>你感受到了『绘卷』所散发的敌意！<br>不顾身上的重伤，你拼命逃走了。<br>';
						}
					}elseif ($dice < 60){
						if ($rp < 40){
							$log .= '少女抬头看着你，貌似对你的举动很感兴趣的样子。可惜，片刻之后，她又低下头去继续她的研究。<br>';
							\event\event_get_rp ($dice2);
						}elseif ($rp < 500){
							$log .= '少女抬头看着你，貌似对你的举动很感兴趣的样子。你觉得稍微有些不自在。<br>';
							\event\event_get_rp ($dice2 * 5);
						}elseif ($rp < 1000 && $killnum == 0){
							$log .= '少女抬头看着你，随后向你扔来一个保温瓶。<br>里面装着奇怪的深色液体。<br>你喝了一口，感觉味道不怎么样，不过身体变得更加灵活了些。<br>';
							$spup = $dice2;
							\event\event_get_field ($spup, 'msp');
							\event\event_get_field ($spup, 'sp');
							\event\event_get_rp ($dice2 * 2);
						}elseif ($rp < 1000){
							$log .= '少女抬头看着你，随后向你扔来一个保温瓶。<br>你没能接住保温瓶，脸上挨了重重的一下，砸得你晕头转向。<br>';
							$spdown = $sp - 1;
							\event\event_get_field (-$spdown, 'sp');
							\event\event_suffer_inf ('h');
						}elseif ($rp < 5000 && $killnum == 0){
							$log .= '少女身后的丝带如闪电般袭来，在你的头上重重地敲了一下。<br>';
							\event\event_suffer_dmg (floor($hp * 0.9));
							\event\event_suffer_inf ('hwe');
							\event\event_get_rp (-$dice2);
							$log .= '<br>你几乎被这一下打晕过去，连滚带爬地逃走了。<br>';
						}else{
							\event\death_kagari (rand(1,2));
						}	
					}elseif ($dice < 90){
						if ($rp < 40){
							$log .= '少女抬头盯着你，开始注意你的一举一动。<br>';
							\event\event_get_rp ($dice2 * 2);
						}elseif ($rp < 500){
							$log .= '少女抬头盯着你，开始注意你的一举一动。她那看不出情感的眼神让你感到不安。<br>';
							\event\event_get_rp ($dice2 * 8);
						}elseif ($rp < 1000 && $killnum == 0){
							$log .= '少女抬头看着你，随后向你扔来一个保温瓶。<br>里面装着奇怪的深色液体。<br>你喝了一口，感觉体内有一种力量涌出来。<br>';
							$hpup = $dice2;
							\event\event_get_field ($hpup, 'mhp');
							\event\event_get_field ($hpup, 'hp');
							\event\event_get_rp ($dice2 * 4);
						}elseif ($rp < 1000){
							$log .= '少女抬头看着你，随后向你扔来一个保温瓶。<br>保温瓶重重地砸在你的胸口，你差点喷出一口老血。<br>';
							\event\event_suffer_dmg (floor($hp * 0.6));
							\event\event_suffer_inf ('bw');	
						}elseif ($rp < 5000 && $killnum == 0){
							$log .= '少女身后的丝带如闪电般袭来，如斩击一般划开了你的身躯。<br>';
							\event\event_suffer_dmg (floor($hp * 0.99));
							\event\event_suffer_inf ('hbaf');
							$log .= '<br>你侥幸捡回一条命，连滚带爬地逃走了。<br>';
							\event\event_get_rp (-$dice2);
						}else{
							\event\death_kagari (rand(1,2));
						}		
					}else{
						if ($rp < 40){
							$log .= '少女飘了起来，像幽灵一般在你身后跟随了一阵子。<br>那深不可测的眼神让你觉得恐怖异常，所幸你最终甩掉了她。<br>';
							\event\event_get_rp ($dice2 * 15);
						}elseif ($rp < 500){
							$log .= '你小心翼翼地在少女旁边坐下（竟然没被她赶走！），向她身下的『绘卷』看去……<br>';

							$skillupsum = 0;
							foreach(array('wp','wk','wg','wc','wd','wf') as $val){
								$up = rand(floor($dice2/2), $dice2);
								\event\event_get_field ($up, $val);
								$skillupsum += $up;
							}
							\event\event_get_rp ($skillupsum * 2);
							$log .= '当你觉得你看懂了点什么的时候，只见少女用惊讶的眼光盯着你，这时你才发现你已经七窍流血。<br>';
							$hpdown = floor($hp * 0.8);
							$spdown = floor($sp * 0.8);
							\event\event_get_field (-$hpdown, 'hp');
							\event\event_get_field (-$spdown, 'sp');
						}elseif ($rp < 1000 && $killnum == 0){
							$log .= '你小心翼翼地在少女旁边坐下，但少女似乎有些不太情愿。<br>她悄无声息地合上『绘卷』，起身离去。<br>';
							$up = $dice2;
							\event\event_get_field ($up, 'exp');
							\event\event_get_rp ($up * 15);
							$log .= '虽然只短暂地窥见『绘卷』上的一鳞半爪，但你仍为那庞大的信息量震撼，几乎昏迷过去。<br>';
							$hpdown = floor($hp * 0.99);
							$spdown = floor($sp * 0.99);
							\event\event_get_field (-$hpdown, 'hp');
							\event\event_get_field (-$spdown, 'sp');
						}elseif ($rp < 1000){
							$log .= '你试图在少女身旁坐下，但少女只是瞪了你一眼，你便觉得头晕目眩，生命力也似乎被抽干。<br>';
							$skilldownsum = 0;
							foreach(array('wp','wk','wg','wc','wd','wf') as $val){
								$down = rand(floor($dice2/4), floor($dice2/2));
								\event\event_get_field (-$down, $val);
								$skilldownsum += $down;
							}
							\event\event_get_rp (-$skilldownsum);
							\event\event_get_field (-($hp-1), 'hp');
							\event\event_get_field (-($sp-1), 'sp');
							$log .= '太可怕了，还是赶快离开为妙！<br>';
						}elseif ($rp < 5000 && $killnum == 0){
							$log .= '少女瞪了你一眼，你被一种无形的压力直接压在了地上。<br>';
							if($mhp > 37){
								$mhpdown = rand(1, floor($mhp / 2));
								\event\event_get_field (-$mhpdown, 'mhp');
								\event\event_get_field (-$mhpdown, 'hp');
							}
							if($msp > 37){
								$mspdown = rand(1, floor($msp / 2));
								\event\event_get_field (-$mspdown, 'msp');
								\event\event_get_field (-$mspdown, 'sp');
							}
							\event\event_get_rp (-37);
							$log .= '太可怕了，还是赶快离开为妙！<br>';
						}elseif ($rp < 5000){
							\event\death_kagari (rand(1,2));
						}else{
							\event\death_kagari (3);
						}		
					}
					$ret = 1;
					
				}
				break;

			case 34:
				if (!\event\check_pls34_enterable ()) {
					$safe_plslist = \map\get_safe_plslist(0);
					if($hack || sizeof($safe_plslist) > 1) {
						do{
							if($hack) $rpls = array_randompick(\map\get_all_plsno());
							else $rpls = array_randompick($safe_plslist);
						}
						while ($rpls == 34);
						$pls=$rpls;
						$log .= "殿堂的深处传来一个声音：<span class=\"evergreen b\">“你还没有进入这里的资格”。</span><br>一股未知的力量包围了你，当你反应过来的时候，发现自己正身处<span class=\"yellow b\">{$plsinfo[$pls]}</span>。<br>";
						
						$ret = 1;
					}
				}
				break;

			default:
				
				break;
		}

		if(!empty($ret)) {
			$log .= '<br>';
		}

		$___TMP_MOD_event_FUNC_event_core_RET =  $ret;
			break; 
		}while(0);
		//======== End of contents from mod event ========

$dice = $__VAR_DUMP_MOD_tutorial_VARS_dice; unset($__VAR_DUMP_MOD_tutorial_VARS_dice);$dice2 = $__VAR_DUMP_MOD_tutorial_VARS_dice2; unset($__VAR_DUMP_MOD_tutorial_VARS_dice2);

		$ret = $___TMP_MOD_event_FUNC_event_core_RET;
		if(!$ret && 17 == $gametype) {
			$ct = \tutorial\get_tutorial ();
			if(30 == $pls && !empty($ct['obj2']['min_money'])) {
				list($tno, $tstep, $tprog) = \tutorial\get_current_tutorial_step ();
				if($money < $ct['obj2']['min_money']){
					$get = rand(573,765);
					$log .= '你在一个虚掩着的保险箱里捡到了一些电子货币，或者说能被当做货币使用的垃圾——大约值<span class="yellow b">'.$get.'</span>元。<br>';
					\event\event_get_money($get);
					$ret = 1;
				}
			}
		
		}
		
		$___TMP_MOD_tutorial_FUNC_event_core_RET =  $ret;
			break; 
		}while(0);
		//======== End of contents from mod tutorial ========

$dice = $__VAR_DUMP_MOD_instance3_VARS_dice; unset($__VAR_DUMP_MOD_instance3_VARS_dice);$dice2 = $__VAR_DUMP_MOD_instance3_VARS_dice2; unset($__VAR_DUMP_MOD_instance3_VARS_dice2);
		
		$ret = $___TMP_MOD_tutorial_FUNC_event_core_RET;
		if(!$ret && 13 == $gametype){
			if(0 == $pls && $gamevars['crimson_dead'])
			{
				if(\skillbase\skill_query(1003,$sdata) && !\skillbase\skill_getvalue(1003,'instance3_flag0',$sdata)) 
				{
					$alvl = !empty($roomvars['current_game_option']['lvl']) ? (int)$roomvars['current_game_option']['lvl'] : 0;
					$log .= '一个高台突兀地悬浮在一片烟尘和血污中。从周围地面破碎的痕迹看来，它不久之前才刚刚冲破伪装，从地面升起。<br><br>
					你踏上高台并仔细检查。<br>';
					if($alvl < 20) {
						$log .= '那是一圈展示着幻境各处情况的大显示屏，以及看起来像是操作面板一样的仪器，风格在这个时代可以说是相当复古。你猜测这是幻境的总控制台，虽然它们并不接受你的命令。<br>';
					}else{
						$log .= '几乎所有仪器和操作面板都已经遭到了严重的腐蚀破坏。看起来这并不是值得久留之地。<br>';
					}
					$log .= '你还发现了一个保险箱。在暴力破拆之后，你找到了一些聊胜于无的资料。<br><br>';
					
					$doc = Array(
						'『林氏软件的现任董事长……或者说，假冒林无月女儿的人，现在依然在静坐。除了往公司里硬塞了一百来个鱼腩，看不出有什么动作。<br>但就凭查不清底细这一点，她就不是善茬。必须警惕。』',
						'『我委托冰炎去分析时空特使的装备，以及……那个东西了。结果还没有出来。林无月曾经暗示过一些事，但我直到现在才想清楚应该如何去验证，以及如果验证了该怎么做。<br>我真希望是她杞人忧天，而不是我后知后觉。』',
						'『不少人对蓝凝的「不务正业」颇有微词。确实一开始连我也很惊讶，但我觉得未尝不能将计就计。不只是为了狡兔三窟，我有一种感觉，有些东西只有她才能做到……』',
					);
					
					$log .= array_randompick($doc).'<br><br>';
					
					if ($alvl >= 20)
					{
						$log .= '除此之外，你还发现了<span class="yellow b">76573</span>元的纸币。<br>';
						\event\event_get_money(76573);
					}
					
					\skillbase\skill_setvalue(1003,'instance3_flag0','1',$sdata);
					$ret = 1;
				}else{
					$log .= '一个高台突兀地悬浮在一片烟尘和血污中。不过你确信刚才已经仔细检查过了。<br>';
				}
			}
			
		}
		return $ret;
	
	}
	
	function parse_news($nid, $news, $hour, $min, $sec, $a, $b, $c, $d, $e, $exarr = array())	
	{
		return \skill489\parse_news($nid,$news,$hour,$min,$sec,$a,$b,$c,$d,$e,$exarr);
	}
	
	function instance3_calc_qiegao_prize($alvl)
	{
		
		if ($alvl == 0) return 100;
		elseif ($alvl <= 10) return 200*$alvl;
		elseif ($alvl < 20) return 500*$alvl-3000;
		elseif ($alvl == 20) return 12000;
		elseif ($alvl < 25) return 1000*$alvl-5000;
		else return 2000*$alvl-30000;
	}
	
	function post_winnercheck_events($winner)
	{
if(isset($winner)) {$__VAR_DUMP_MOD_instance3_VARS_winner = $winner; } else {$__VAR_DUMP_MOD_instance3_VARS_winner = NULL;} 
		//======== Start of contents from mod skill501 ========
		do{
			$___TMP_MOD_skill501_FUNC_post_winnercheck_events_RET = NULL;
$wn = $winner; 

		
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;   } while (0);
		if(2 == $winmode) {
			
			$pa = \player\fetch_playerdata($wn);
			if(\skillbase\skill_query(501,$pa)) {
				if(\skillbase\skill_query(500,$pa)) $pa['state'] = 42;
				else $pa['state'] = 48;
				$gameover_plist[$pa['name']]['state'] = $pa['state'];
				$pa['sourceless'] = 1;
				\player\kill($pa,$pa);
				\player\player_save($pa);
				$winmode = 1;
				$winnum = 0;
				$winner = '';
			}
		}
if(isset($wn)) {$__VAR_DUMP_MOD_skill501_VARS_wn = $wn; } else {$__VAR_DUMP_MOD_skill501_VARS_wn = NULL;} if(isset($pa)) {$__VAR_DUMP_MOD_skill501_VARS_pa = $pa; unset($pa); } else {$__VAR_DUMP_MOD_skill501_VARS_pa = NULL;} 
		//======== Start of contents from mod skill330 ========
		do{
			$___TMP_MOD_skill330_FUNC_post_winnercheck_events_RET = NULL;
if(isset($wn)) {$__VAR_DUMP_MOD_skill330_VARS_wn = $wn; } else {$__VAR_DUMP_MOD_skill330_VARS_wn = NULL;} 
		//======== Start of contents from mod sys ========
		do{
			$___TMP_MOD_sys_FUNC_post_winnercheck_events_RET = NULL;

		
		}while(0);
		//======== End of contents from mod sys ========

$wn = $__VAR_DUMP_MOD_skill330_VARS_wn; unset($__VAR_DUMP_MOD_skill330_VARS_wn);

		
		$___TMP_MOD_sys_FUNC_post_winnercheck_events_RET;
		if(!$wn || strpos($wn,',')!==false){ $___TMP_MOD_skill330_FUNC_post_winnercheck_events_RET = NULL;
			break; }
		$pa = \player\fetch_playerdata($wn,0,1);
		if(!$pa){ $___TMP_MOD_skill330_FUNC_post_winnercheck_events_RET = NULL;
			break; }
		if (\skillbase\skill_query(330,$pa)){
			$num330 = \skill330\check_itemnum330 ($pa);
			\skillbase\skill_setvalue(330,'cnt',$num330,$pa);
			\player\player_save($pa);
		}
		}while(0);
		//======== End of contents from mod skill330 ========

$wn = $__VAR_DUMP_MOD_skill501_VARS_wn; unset($__VAR_DUMP_MOD_skill501_VARS_wn);$pa = $__VAR_DUMP_MOD_skill501_VARS_pa; 
		$___TMP_MOD_skill330_FUNC_post_winnercheck_events_RET;
		}while(0);
		//======== End of contents from mod skill501 ========

$winner = $__VAR_DUMP_MOD_instance3_VARS_winner; unset($__VAR_DUMP_MOD_instance3_VARS_winner);
		
		$___TMP_MOD_skill501_FUNC_post_winnercheck_events_RET;
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;   } while (0);
		if ($winmode == 7 && $gametype == 13)
		{
			$pa = \player\fetch_playerdata($winner);
			$alvl = (int)\skillbase\skill_getvalue(1003,'instance3_lvl',$pa);
			$qiegao_prize = \instance3\instance3_calc_qiegao_prize ($alvl);
			if ($qiegao_prize)
			{
				include_once './include/messages.func.php';
				message_create(
					$pa['name'],
					'试炼模式奖励',
					'祝贺你在房间第'.$gamenum.'局试炼模式获得了奖励！<br>',
					'getqiegao_'.$qiegao_prize
				);
			}
		}
	
	}
	
	
	function init_battle($ismeet = 0)
	{
		return \skill507\init_battle($ismeet);
	}
	
	
	function npcchat_get_chatlog($chattag,$sid,$nchat)
	{
if(isset($chattag)) {$__VAR_DUMP_MOD_instance3_VARS_chattag = $chattag; } else {$__VAR_DUMP_MOD_instance3_VARS_chattag = NULL;} if(isset($sid)) {$__VAR_DUMP_MOD_instance3_VARS_sid = $sid; } else {$__VAR_DUMP_MOD_instance3_VARS_sid = NULL;} if(isset($nchat)) {$__VAR_DUMP_MOD_instance3_VARS_nchat = $nchat; } else {$__VAR_DUMP_MOD_instance3_VARS_nchat = NULL;} 
		//======== Start of contents from mod npcchat_bubble ========
		do{
			$___TMP_MOD_npcchat_bubble_FUNC_npcchat_get_chatlog_RET = NULL;
if(isset($chattag)) {$__VAR_DUMP_MOD_npcchat_bubble_VARS_chattag = $chattag; } else {$__VAR_DUMP_MOD_npcchat_bubble_VARS_chattag = NULL;} if(isset($sid)) {$__VAR_DUMP_MOD_npcchat_bubble_VARS_sid = $sid; } else {$__VAR_DUMP_MOD_npcchat_bubble_VARS_sid = NULL;} if(isset($nchat)) {$__VAR_DUMP_MOD_npcchat_bubble_VARS_nchat = $nchat; } else {$__VAR_DUMP_MOD_npcchat_bubble_VARS_nchat = NULL;} 
		//======== Start of contents from mod npcchat ========
		do{
			$___TMP_MOD_npcchat_FUNC_npcchat_get_chatlog_RET = NULL;

		
		$chatlog = NULL;
		if(isset($nchat[$chattag])) {
			$chatlog = $nchat[$chattag];
			if(is_array($chatlog)){
				$chatlog = array_randompick($chatlog);
			}
		}elseif(isset($nchat[$sid])){
			$chatlog = $nchat[$sid];
		}
		$___TMP_MOD_npcchat_FUNC_npcchat_get_chatlog_RET =  $chatlog;
			break; 
		}while(0);
		//======== End of contents from mod npcchat ========

$chattag = $__VAR_DUMP_MOD_npcchat_bubble_VARS_chattag; unset($__VAR_DUMP_MOD_npcchat_bubble_VARS_chattag);$sid = $__VAR_DUMP_MOD_npcchat_bubble_VARS_sid; unset($__VAR_DUMP_MOD_npcchat_bubble_VARS_sid);$nchat = $__VAR_DUMP_MOD_npcchat_bubble_VARS_nchat; unset($__VAR_DUMP_MOD_npcchat_bubble_VARS_nchat);

		
		$ret = $___TMP_MOD_npcchat_FUNC_npcchat_get_chatlog_RET;
		if('evolve' == $chattag && NULL !== $ret){
			do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;  global $___LOCAL_NPCCHAT_BUBBLE__VARS__npcchat_bubble_on,$___LOCAL_NPCCHAT_BUBBLE__VARS__npcchat_bubble_replace_log; $npcchat_bubble_on=&$___LOCAL_NPCCHAT_BUBBLE__VARS__npcchat_bubble_on; $npcchat_bubble_replace_log=&$___LOCAL_NPCCHAT_BUBBLE__VARS__npcchat_bubble_replace_log;   } while (0);
			if(!isset($uip['npcchat']['enemy'])) $uip['npcchat']['enemy']=array();
			foreach($nchat[$chattag] as $cv){
				$uip['npcchat']['enemy'][] = \npcchat\npcchat_decorate(\npcchat_bubble\npcchat_bubble_cleanqm ($cv), $nchat, $chattag);
			}
			$ret = NULL;
		}
		$___TMP_MOD_npcchat_bubble_FUNC_npcchat_get_chatlog_RET =  $ret;
			break; 
		}while(0);
		//======== End of contents from mod npcchat_bubble ========

$chattag = $__VAR_DUMP_MOD_instance3_VARS_chattag; unset($__VAR_DUMP_MOD_instance3_VARS_chattag);$sid = $__VAR_DUMP_MOD_instance3_VARS_sid; unset($__VAR_DUMP_MOD_instance3_VARS_sid);$nchat = $__VAR_DUMP_MOD_instance3_VARS_nchat; unset($__VAR_DUMP_MOD_instance3_VARS_nchat);
		
		$ret = $___TMP_MOD_npcchat_bubble_FUNC_npcchat_get_chatlog_RET;
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;   } while (0);
		if(13==$gametype && !empty($roomvars['current_game_option']['lvl']) && defined('MOD_ENDING')) {
			$alvl = $roomvars['current_game_option']['lvl'];
			if($alvl > 10) {
				$dice = rand(0,99);
				$glitch_scale = 0;
				if($alvl <= 20 && $dice <= $alvl) {
					$glitch_scale = $alvl;
				}elseif($alvl > 20 && $dice <= $alvl * 2) {
					$glitch_scale = $alvl * 2;
				}
				if(!empty($glitch_scale)) {
					$ret = \ending\ending_psyche_attack_txt_parse($ret, $glitch_scale);
				}
			}
		}
		return $ret;
	
	}
}

?>