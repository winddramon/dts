<?php

namespace skill904
{
	$sk904_dmggain = array(0,10,20,35);
	
	function init() 
	{
		define('MOD_SKILL904_INFO','card;');
		do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;   } while (0);
		$clubskillname[904] = '脆弱';
	}
	
	function acquire904(&$pa)
	{
		
		\skillbase\skill_setvalue(904,'lvl','0',$pa);
	}
	
	function lost904(&$pa)
	{
		
	}
	
	function check_unlocked904(&$pa)
	{
		
		return 1;
	}
	
	function get_sk904_dmggain(&$pa)
	{
		
		do { global $___LOCAL_SKILL904__VARS__sk904_dmggain; $sk904_dmggain=&$___LOCAL_SKILL904__VARS__sk904_dmggain;   } while (0);
		$sk904_lvl = (int)\skillbase\skill_getvalue(904,'lvl',$pa);
		return $sk904_dmggain[$sk904_lvl];
	}
	
	function get_final_dmg_multiplier(&$pa, &$pd, $active)
	{
		return \skill507\get_final_dmg_multiplier($pa,$pd,$active);
	}

}

?>