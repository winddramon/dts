<?php

namespace skill907
{
	////////// MODULE HEADER START ///////////////
	$___MODULE_dependency = 'sys player skillbase clubbase logger itemmain';
	$___MODULE_dependency_optional = '';
	$___MODULE_conflict = '';
	$___MODULE_codelist = 'main.php';
	$___MODULE_templatelist = 'desc';
	////////// MODULE HEADER END /////////////////
	require __INIT_MODULE__(__NAMESPACE__,__DIR__);
}

?>
