<?php

namespace instance7
{
	$npcinfo_instance7 = array
		( 
		10 => array
			(
			'mode' => 2,
			'num' => 1,
			'pass' => 'bra',
			'club' => 10,
			'bid' => 0,
			'inf' => '',
			'rage' => 0,
			'pose'=> 2,
			'tactic' => 3,
			'killnum' => 0,
			'teamID' => '',
			'teamPass' => '',
			'gd' => 'f',
			'pls' => 0,
			'mhp' => 4000,
			'msp' => 1000,
			'att' => 500,
			'def' => 2000,
			'lvl' => 33,
			'skill' => 480,
			'money' => 65000,
			'arb' => 'cosplay用强者披风',
			'arbk' => 'DB',
			'arbe' => 50,
			'arbs' => 600,
			'arbsk' => 'b',
			'arh' => 'cosplay用银色墨镜',
			'arhk' => 'DH',
			'arhe' => 50,
			'arhs' => 600,		
			'arhsk' => 'h',
			'arf' => 'cosplay用帅气皮靴',
			'arfk' => 'DF',
			'arfe' => 50,
			'arfs' => 60,
			'arfsk' => 'mM',
			'ara' => 'cosplay用护盾',
			'arak' => 'DA',
			'arae' => 50,
			'aras' => 600,
			'arask' => 'B',
			'art' => 'cosplay用强者光环',
			'artk' => 'A',
			'arte' => 1,
			'arts' => 1,
			'artsk' => 'AaH',
			'itm1' => '教程解除钥匙',
			'itmk1' => 'Y',
			'itme1' => 1,
			'itms1' => 1,
			'itmsk1' => '',
			'itm2' => '【乾坤爆破】',
			'itmk2' => 'WD',
			'itme2' => 700,
			'itms2' => 2000,
			'itmsk2' => 'drNp',
			'skills' => Array(
				'81' => '0', '405' => '0','459'=>'0','461'=>'1','462'=>'0','432'=>'0'
			),
			'sub' => array
			(
			0 => array
				(
				'name' => '李天明',
				'icon' => 212,
				'wep' => '【天明绝刀】',
				'wepk' => 'WK',
				'wepe' => 800,
				'weps' => 1000,
				'wepsk' => 'nyrf',
				'description' => '仅在教程房出现的谜之角色。',
				),
			),
		),
	);
}
?>