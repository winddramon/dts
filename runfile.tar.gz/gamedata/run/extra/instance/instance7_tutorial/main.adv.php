<?php

namespace instance7
{
	function init() {}
	
	
	function get_enter_battlefield_card($card){
		return \instance10\get_enter_battlefield_card($card);
	}

	
	function get_npclist(){
		return \instance10\get_npclist();
	}
	
	
	function get_shopconfig(){
		return \instance10\get_shopconfig();
	}
	
	
	function get_itemfilecont(){
		return \instance10\get_itemfilecont();
	}
	
	
	function get_trapfilecont(){
		return \instance10\get_trapfilecont();
	}
	
	
	function get_startingitemfilecont(){
		return \instance10\get_startingitemfilecont();
	}
}

?>