<?php

namespace instance5
{
	function init() {}
	
	function get_shopconfig(){
		return \instance10\get_shopconfig();
	}
	
	function get_npclist(){
		return \instance10\get_npclist();
	}
	
	function checkcombo($time){
		return \instance10\checkcombo($time);
	}
	
	function rs_game($xmode = 0) 	
	{
		return \instance10\rs_game($xmode);
	}
	
	function rs_areatime(){
		return \instance10\rs_areatime();
	}
	
	function check_addarea_gameover($atime){
		return \instance10\check_addarea_gameover($atime);
	}
	
	function itemuse(&$theitem) 
	{
		return \instance10\itemuse($theitem);
	}
	
	function get_club_choice_array()
	{
		return \skill544\get_club_choice_array();
	}
	
	function parse_itmuse_desc($n, $k, $e, $s, $sk){
		return \item_armor_empower\parse_itmuse_desc($n,$k,$e,$s,$sk);
	}
	
	function parse_news($nid, $news, $hour, $min, $sec, $a, $b, $c, $d, $e, $exarr = array())	
	{
		return \skill489\parse_news($nid,$news,$hour,$min,$sec,$a,$b,$c,$d,$e,$exarr);
	}
}

?>