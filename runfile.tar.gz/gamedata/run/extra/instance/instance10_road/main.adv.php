<?php

namespace instance10
{
	function init() {
		do { global $___LOCAL_SKILLBASE__VARS__acquired_list,$___LOCAL_SKILLBASE__VARS__parameter_list,$___LOCAL_SKILLBASE__VARS__ppid,$___LOCAL_SKILLBASE__VARS__valid_skills; $acquired_list=&$___LOCAL_SKILLBASE__VARS__acquired_list; $parameter_list=&$___LOCAL_SKILLBASE__VARS__parameter_list; $ppid=&$___LOCAL_SKILLBASE__VARS__ppid; $valid_skills=&$___LOCAL_SKILLBASE__VARS__valid_skills;   } while (0);
		if(!isset($valid_skills[20])) {
			$valid_skills[20] = array();
		}
		$valid_skills[20] += array(181,951,952,960);
	}
	
	
	function get_enter_battlefield_card($card){
		
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;   } while (0);
if(isset($card)) {$__VAR_DUMP_MOD_instance10_VARS_card = $card; } else {$__VAR_DUMP_MOD_instance10_VARS_card = NULL;} 
		//======== Start of contents from mod instance3 ========
		do{
			$___TMP_MOD_instance3_FUNC_get_enter_battlefield_card_RET = NULL;

		
		
		if(13==$gametype){
			$option = $roomvars['current_game_option'];
			if(isset($option['lvl']))
			{
				$alvl = (int)$option['lvl'];
				$card = array(303,304,305)[floor(max($alvl-1,0)/10)];
				$___TMP_MOD_instance3_FUNC_get_enter_battlefield_card_RET =  $card;
			break; 
			}
			else{ $___TMP_MOD_instance3_FUNC_get_enter_battlefield_card_RET =  303;
			break; }
		}
if(isset($card)) {$__VAR_DUMP_MOD_instance3_VARS_card = $card; } else {$__VAR_DUMP_MOD_instance3_VARS_card = NULL;} 
		//======== Start of contents from mod gtype1 ========
		do{
			$___TMP_MOD_gtype1_FUNC_get_enter_battlefield_card_RET = NULL;

		
		
if(isset($card)) {$__VAR_DUMP_MOD_gtype1_VARS_card = $card; } else {$__VAR_DUMP_MOD_gtype1_VARS_card = NULL;} 
		//======== Start of contents from mod gtype6 ========
		do{
			$___TMP_MOD_gtype6_FUNC_get_enter_battlefield_card_RET = NULL;

		
		
if(isset($card)) {$__VAR_DUMP_MOD_gtype6_VARS_card = $card; } else {$__VAR_DUMP_MOD_gtype6_VARS_card = NULL;} 
		//======== Start of contents from mod instance7 ========
		do{
			$___TMP_MOD_instance7_FUNC_get_enter_battlefield_card_RET = NULL;

		
		
if(isset($card)) {$__VAR_DUMP_MOD_instance7_VARS_card = $card; } else {$__VAR_DUMP_MOD_instance7_VARS_card = NULL;} 
		//======== Start of contents from mod cardbase ========
		do{
			$___TMP_MOD_cardbase_FUNC_get_enter_battlefield_card_RET = NULL;

		
		
		
		if(0==$gametype){
			$card = 0;
		}
		$___TMP_MOD_cardbase_FUNC_get_enter_battlefield_card_RET =  $card;
			break; 
		}while(0);
		//======== End of contents from mod cardbase ========

$card = $__VAR_DUMP_MOD_instance7_VARS_card; unset($__VAR_DUMP_MOD_instance7_VARS_card);
		$card = $___TMP_MOD_cardbase_FUNC_get_enter_battlefield_card_RET;
		if(17==$gametype) {
			$card = 1000;
		}	
		$___TMP_MOD_instance7_FUNC_get_enter_battlefield_card_RET =  $card;
			break; 
		}while(0);
		//======== End of contents from mod instance7 ========

$card = $__VAR_DUMP_MOD_gtype6_VARS_card; unset($__VAR_DUMP_MOD_gtype6_VARS_card);
		$card = $___TMP_MOD_instance7_FUNC_get_enter_battlefield_card_RET;
		if (6==$gametype){
			$card=1001;
		}
		$___TMP_MOD_gtype6_FUNC_get_enter_battlefield_card_RET =  $card;
			break; 
		}while(0);
		//======== End of contents from mod gtype6 ========

$card = $__VAR_DUMP_MOD_gtype1_VARS_card; unset($__VAR_DUMP_MOD_gtype1_VARS_card);
		$card = $___TMP_MOD_gtype6_FUNC_get_enter_battlefield_card_RET;
		if (1==$gametype){
			$card=93;
		}
		$___TMP_MOD_gtype1_FUNC_get_enter_battlefield_card_RET =  $card;
			break; 
		}while(0);
		//======== End of contents from mod gtype1 ========

$card = $__VAR_DUMP_MOD_instance3_VARS_card; unset($__VAR_DUMP_MOD_instance3_VARS_card);
		$___TMP_MOD_instance3_FUNC_get_enter_battlefield_card_RET =  $___TMP_MOD_gtype1_FUNC_get_enter_battlefield_card_RET;
			break; 
		}while(0);
		//======== End of contents from mod instance3 ========

$card = $__VAR_DUMP_MOD_instance10_VARS_card; unset($__VAR_DUMP_MOD_instance10_VARS_card);
		$card = $___TMP_MOD_instance3_FUNC_get_enter_battlefield_card_RET;
		if (20 == $gametype){
			$card=1001;
		}
		return $card;
	
	}
	
	
	function card_validate_get_forbidden_cards($card_disabledlist, $card_ownlist){
		
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;   } while (0);
if(isset($card_disabledlist)) {$__VAR_DUMP_MOD_instance10_VARS_card_disabledlist = $card_disabledlist; } else {$__VAR_DUMP_MOD_instance10_VARS_card_disabledlist = NULL;} if(isset($card_ownlist)) {$__VAR_DUMP_MOD_instance10_VARS_card_ownlist = $card_ownlist; } else {$__VAR_DUMP_MOD_instance10_VARS_card_ownlist = NULL;} 
		//======== Start of contents from mod instance11 ========
		do{
			$___TMP_MOD_instance11_FUNC_card_validate_get_forbidden_cards_RET = NULL;

		
		
if(isset($card_disabledlist)) {$__VAR_DUMP_MOD_instance11_VARS_card_disabledlist = $card_disabledlist; } else {$__VAR_DUMP_MOD_instance11_VARS_card_disabledlist = NULL;} if(isset($card_ownlist)) {$__VAR_DUMP_MOD_instance11_VARS_card_ownlist = $card_ownlist; } else {$__VAR_DUMP_MOD_instance11_VARS_card_ownlist = NULL;} 
		//======== Start of contents from mod instance9 ========
		do{
			$___TMP_MOD_instance9_FUNC_card_validate_get_forbidden_cards_RET = NULL;

		
		
if(isset($card_disabledlist)) {$__VAR_DUMP_MOD_instance9_VARS_card_disabledlist = $card_disabledlist; } else {$__VAR_DUMP_MOD_instance9_VARS_card_disabledlist = NULL;} if(isset($card_ownlist)) {$__VAR_DUMP_MOD_instance9_VARS_card_ownlist = $card_ownlist; } else {$__VAR_DUMP_MOD_instance9_VARS_card_ownlist = NULL;} 
		//======== Start of contents from mod gtype1 ========
		do{
			$___TMP_MOD_gtype1_FUNC_card_validate_get_forbidden_cards_RET = NULL;

		
		
if(isset($card_disabledlist)) {$__VAR_DUMP_MOD_gtype1_VARS_card_disabledlist = $card_disabledlist; } else {$__VAR_DUMP_MOD_gtype1_VARS_card_disabledlist = NULL;} if(isset($card_ownlist)) {$__VAR_DUMP_MOD_gtype1_VARS_card_ownlist = $card_ownlist; } else {$__VAR_DUMP_MOD_gtype1_VARS_card_ownlist = NULL;} 
		//======== Start of contents from mod gtype6 ========
		do{
			$___TMP_MOD_gtype6_FUNC_card_validate_get_forbidden_cards_RET = NULL;

		
		
if(isset($card_disabledlist)) {$__VAR_DUMP_MOD_gtype6_VARS_card_disabledlist = $card_disabledlist; } else {$__VAR_DUMP_MOD_gtype6_VARS_card_disabledlist = NULL;} if(isset($card_ownlist)) {$__VAR_DUMP_MOD_gtype6_VARS_card_ownlist = $card_ownlist; } else {$__VAR_DUMP_MOD_gtype6_VARS_card_ownlist = NULL;} 
		//======== Start of contents from mod cardbase ========
		do{
			$___TMP_MOD_cardbase_FUNC_card_validate_get_forbidden_cards_RET = NULL;

		
		
		
		if(0==$gametype) 
		{
			foreach($card_ownlist as $cv){
				if($cv) $card_disabledlist[$cv][]='e3';
			}
		}












		
		$___TMP_MOD_cardbase_FUNC_card_validate_get_forbidden_cards_RET =  $card_disabledlist;
			break; 
		}while(0);
		//======== End of contents from mod cardbase ========

$card_disabledlist = $__VAR_DUMP_MOD_gtype6_VARS_card_disabledlist; unset($__VAR_DUMP_MOD_gtype6_VARS_card_disabledlist);$card_ownlist = $__VAR_DUMP_MOD_gtype6_VARS_card_ownlist; unset($__VAR_DUMP_MOD_gtype6_VARS_card_ownlist);
		
		$card_disabledlist = $___TMP_MOD_cardbase_FUNC_card_validate_get_forbidden_cards_RET;
		if(6==$gametype)
		{
			foreach($card_ownlist as $cv){
				if(1001 != $cv) $card_disabledlist[$cv][]='e3';
			}
		}
		$___TMP_MOD_gtype6_FUNC_card_validate_get_forbidden_cards_RET =  $card_disabledlist;
			break; 
		}while(0);
		//======== End of contents from mod gtype6 ========

$card_disabledlist = $__VAR_DUMP_MOD_gtype1_VARS_card_disabledlist; unset($__VAR_DUMP_MOD_gtype1_VARS_card_disabledlist);$card_ownlist = $__VAR_DUMP_MOD_gtype1_VARS_card_ownlist; unset($__VAR_DUMP_MOD_gtype1_VARS_card_ownlist);
		
		$card_disabledlist = $___TMP_MOD_gtype6_FUNC_card_validate_get_forbidden_cards_RET;
		if (1==$gametype)	
		{
			foreach($card_ownlist as $cv){
				if(93 != $cv) $card_disabledlist[$cv][]='e3';
			}
		}
		$___TMP_MOD_gtype1_FUNC_card_validate_get_forbidden_cards_RET =  $card_disabledlist;
			break; 
		}while(0);
		//======== End of contents from mod gtype1 ========

$card_disabledlist = $__VAR_DUMP_MOD_instance9_VARS_card_disabledlist; unset($__VAR_DUMP_MOD_instance9_VARS_card_disabledlist);$card_ownlist = $__VAR_DUMP_MOD_instance9_VARS_card_ownlist; unset($__VAR_DUMP_MOD_instance9_VARS_card_ownlist);
		
		$card_disabledlist = $___TMP_MOD_gtype1_FUNC_card_validate_get_forbidden_cards_RET;
		if (19==$gametype)
		{
			foreach(Array(123,124) as $c){
				if (in_array($c,$card_ownlist)) $card_disabledlist[$c][]='e3';
			}
		}
		$___TMP_MOD_instance9_FUNC_card_validate_get_forbidden_cards_RET =  $card_disabledlist;
			break; 
		}while(0);
		//======== End of contents from mod instance9 ========

$card_disabledlist = $__VAR_DUMP_MOD_instance11_VARS_card_disabledlist; unset($__VAR_DUMP_MOD_instance11_VARS_card_disabledlist);$card_ownlist = $__VAR_DUMP_MOD_instance11_VARS_card_ownlist; unset($__VAR_DUMP_MOD_instance11_VARS_card_ownlist);
		
		$card_disabledlist = $___TMP_MOD_instance9_FUNC_card_validate_get_forbidden_cards_RET;
		if (21==$gametype)
		{
			foreach(Array(117,196,209,231) as $c){
				if (in_array($c,$card_ownlist)) $card_disabledlist[$c][]='e3';
			}
		}
		$___TMP_MOD_instance11_FUNC_card_validate_get_forbidden_cards_RET =  $card_disabledlist;
			break; 
		}while(0);
		//======== End of contents from mod instance11 ========

$card_disabledlist = $__VAR_DUMP_MOD_instance10_VARS_card_disabledlist; unset($__VAR_DUMP_MOD_instance10_VARS_card_disabledlist);$card_ownlist = $__VAR_DUMP_MOD_instance10_VARS_card_ownlist; unset($__VAR_DUMP_MOD_instance10_VARS_card_ownlist);
		
		$card_disabledlist = $___TMP_MOD_instance11_FUNC_card_validate_get_forbidden_cards_RET;
		if (20 == $gametype)
		{
			foreach($card_ownlist as $cv){
				if(1001 != $cv) $card_disabledlist[$cv][]='e3';
			}
		}
		return $card_disabledlist;
	
	}
	
	
	function card_validate_display($cardChosen, $card_ownlist, $packlist, $hideDisableButton){
		
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;  global $___LOCAL_CARDBASE__VARS__card_config_file,$___LOCAL_CARDBASE__VARS__card_main_file,$___LOCAL_CARDBASE__VARS__card_index_file,$___LOCAL_CARDBASE__VARS__card_force_different_gtype,$___LOCAL_CARDBASE__VARS__card_need_charge_gtype,$___LOCAL_CARDBASE__VARS__card_cooldown_discount_gtype,$___LOCAL_CARDBASE__VARS__cardtypecd,$___LOCAL_CARDBASE__VARS__card_recrate_base,$___LOCAL_CARDBASE__VARS__packlist,$___LOCAL_CARDBASE__VARS__packdesc, $___LOCAL_CARDBASE__VARS__pack_ignore_kuji,$___LOCAL_CARDBASE__VARS__packstart,$___LOCAL_CARDBASE__VARS__packicon,$___LOCAL_CARDBASE__VARS__cardindex,$___LOCAL_CARDBASE__VARS__card_rarecolor,$___LOCAL_CARDBASE__VARS__card_rarity_html,$___LOCAL_CARDBASE__VARS__card_blink_rate_20,$___LOCAL_CARDBASE__VARS__card_blink_rate_10,$___LOCAL_CARDBASE__VARS__card_price,$___LOCAL_CARDBASE__VARS__card_price_blink_rate, $___LOCAL_CARDBASE__VARS__cards,$___LOCAL_CARDBASE__VARS__cardindex_reverse; $card_config_file=&$___LOCAL_CARDBASE__VARS__card_config_file; $card_main_file=&$___LOCAL_CARDBASE__VARS__card_main_file; $card_index_file=&$___LOCAL_CARDBASE__VARS__card_index_file; $card_force_different_gtype=&$___LOCAL_CARDBASE__VARS__card_force_different_gtype; $card_need_charge_gtype=&$___LOCAL_CARDBASE__VARS__card_need_charge_gtype; $card_cooldown_discount_gtype=&$___LOCAL_CARDBASE__VARS__card_cooldown_discount_gtype; $cardtypecd=&$___LOCAL_CARDBASE__VARS__cardtypecd; $card_recrate_base=&$___LOCAL_CARDBASE__VARS__card_recrate_base; $packlist=&$___LOCAL_CARDBASE__VARS__packlist; $packdesc=&$___LOCAL_CARDBASE__VARS__packdesc;  $pack_ignore_kuji=&$___LOCAL_CARDBASE__VARS__pack_ignore_kuji; $packstart=&$___LOCAL_CARDBASE__VARS__packstart; $packicon=&$___LOCAL_CARDBASE__VARS__packicon; $cardindex=&$___LOCAL_CARDBASE__VARS__cardindex; $card_rarecolor=&$___LOCAL_CARDBASE__VARS__card_rarecolor; $card_rarity_html=&$___LOCAL_CARDBASE__VARS__card_rarity_html; $card_blink_rate_20=&$___LOCAL_CARDBASE__VARS__card_blink_rate_20; $card_blink_rate_10=&$___LOCAL_CARDBASE__VARS__card_blink_rate_10; $card_price=&$___LOCAL_CARDBASE__VARS__card_price; $card_price_blink_rate=&$___LOCAL_CARDBASE__VARS__card_price_blink_rate;  $cards=&$___LOCAL_CARDBASE__VARS__cards; $cardindex_reverse=&$___LOCAL_CARDBASE__VARS__cardindex_reverse;   } while (0);
if(isset($cardChosen)) {$__VAR_DUMP_MOD_instance10_VARS_cardChosen = $cardChosen; } else {$__VAR_DUMP_MOD_instance10_VARS_cardChosen = NULL;} if(isset($card_ownlist)) {$__VAR_DUMP_MOD_instance10_VARS_card_ownlist = $card_ownlist; } else {$__VAR_DUMP_MOD_instance10_VARS_card_ownlist = NULL;} if(isset($packlist)) {$__VAR_DUMP_MOD_instance10_VARS_packlist = $packlist; } else {$__VAR_DUMP_MOD_instance10_VARS_packlist = NULL;} if(isset($hideDisableButton)) {$__VAR_DUMP_MOD_instance10_VARS_hideDisableButton = $hideDisableButton; } else {$__VAR_DUMP_MOD_instance10_VARS_hideDisableButton = NULL;} 
		//======== Start of contents from mod gtype1 ========
		do{
			$___TMP_MOD_gtype1_FUNC_card_validate_display_RET = NULL;

		
		
if(isset($cardChosen)) {$__VAR_DUMP_MOD_gtype1_VARS_cardChosen = $cardChosen; } else {$__VAR_DUMP_MOD_gtype1_VARS_cardChosen = NULL;} if(isset($card_ownlist)) {$__VAR_DUMP_MOD_gtype1_VARS_card_ownlist = $card_ownlist; } else {$__VAR_DUMP_MOD_gtype1_VARS_card_ownlist = NULL;} if(isset($packlist)) {$__VAR_DUMP_MOD_gtype1_VARS_packlist = $packlist; } else {$__VAR_DUMP_MOD_gtype1_VARS_packlist = NULL;} if(isset($hideDisableButton)) {$__VAR_DUMP_MOD_gtype1_VARS_hideDisableButton = $hideDisableButton; } else {$__VAR_DUMP_MOD_gtype1_VARS_hideDisableButton = NULL;} 
		//======== Start of contents from mod gtype6 ========
		do{
			$___TMP_MOD_gtype6_FUNC_card_validate_display_RET = NULL;

		
		
if(isset($cardChosen)) {$__VAR_DUMP_MOD_gtype6_VARS_cardChosen = $cardChosen; } else {$__VAR_DUMP_MOD_gtype6_VARS_cardChosen = NULL;} if(isset($card_ownlist)) {$__VAR_DUMP_MOD_gtype6_VARS_card_ownlist = $card_ownlist; } else {$__VAR_DUMP_MOD_gtype6_VARS_card_ownlist = NULL;} if(isset($packlist)) {$__VAR_DUMP_MOD_gtype6_VARS_packlist = $packlist; } else {$__VAR_DUMP_MOD_gtype6_VARS_packlist = NULL;} if(isset($hideDisableButton)) {$__VAR_DUMP_MOD_gtype6_VARS_hideDisableButton = $hideDisableButton; } else {$__VAR_DUMP_MOD_gtype6_VARS_hideDisableButton = NULL;} 
		//======== Start of contents from mod cardbase ========
		do{
			$___TMP_MOD_cardbase_FUNC_card_validate_display_RET = NULL;

		
		
		
		if(0==$gametype) 
		{
			$cardChosen = 0;
			$hideDisableButton = 0;
		}













		
		
		$___TMP_MOD_cardbase_FUNC_card_validate_display_RET =  array($cardChosen, $card_ownlist, $packlist, $hideDisableButton);
			break; 
		}while(0);
		//======== End of contents from mod cardbase ========

$cardChosen = $__VAR_DUMP_MOD_gtype6_VARS_cardChosen; unset($__VAR_DUMP_MOD_gtype6_VARS_cardChosen);$card_ownlist = $__VAR_DUMP_MOD_gtype6_VARS_card_ownlist; unset($__VAR_DUMP_MOD_gtype6_VARS_card_ownlist);$packlist = $__VAR_DUMP_MOD_gtype6_VARS_packlist; unset($__VAR_DUMP_MOD_gtype6_VARS_packlist);$hideDisableButton = $__VAR_DUMP_MOD_gtype6_VARS_hideDisableButton; unset($__VAR_DUMP_MOD_gtype6_VARS_hideDisableButton);
		
		list($cardChosen, $card_ownlist, $packlist, $hideDisableButton) = $___TMP_MOD_cardbase_FUNC_card_validate_display_RET;
		
		if(6==$gametype)
		{
			$cardChosen = 1001;
			$card_ownlist[] = 1001;
			$cards[1001]['pack'] = 'Ranmen';
			$hideDisableButton = 0;
		}
		
		$___TMP_MOD_gtype6_FUNC_card_validate_display_RET =  array($cardChosen, $card_ownlist, $packlist, $hideDisableButton);
			break; 
		}while(0);
		//======== End of contents from mod gtype6 ========

$cardChosen = $__VAR_DUMP_MOD_gtype1_VARS_cardChosen; unset($__VAR_DUMP_MOD_gtype1_VARS_cardChosen);$card_ownlist = $__VAR_DUMP_MOD_gtype1_VARS_card_ownlist; unset($__VAR_DUMP_MOD_gtype1_VARS_card_ownlist);$packlist = $__VAR_DUMP_MOD_gtype1_VARS_packlist; unset($__VAR_DUMP_MOD_gtype1_VARS_packlist);$hideDisableButton = $__VAR_DUMP_MOD_gtype1_VARS_hideDisableButton; unset($__VAR_DUMP_MOD_gtype1_VARS_hideDisableButton);
		
		list($cardChosen, $card_ownlist, $packlist, $hideDisableButton) = $___TMP_MOD_gtype6_FUNC_card_validate_display_RET;
		
		if (1==$gametype)	
		{
			$cardChosen = 93;
			$card_ownlist[] = 93;
			$packlist[] = $cards[93]['pack'] = 'Testing Fan Club';
			$hideDisableButton = 0;
		}
		
		$___TMP_MOD_gtype1_FUNC_card_validate_display_RET =  array($cardChosen, $card_ownlist, $packlist, $hideDisableButton);
			break; 
		}while(0);
		//======== End of contents from mod gtype1 ========

$cardChosen = $__VAR_DUMP_MOD_instance10_VARS_cardChosen; unset($__VAR_DUMP_MOD_instance10_VARS_cardChosen);$card_ownlist = $__VAR_DUMP_MOD_instance10_VARS_card_ownlist; unset($__VAR_DUMP_MOD_instance10_VARS_card_ownlist);$packlist = $__VAR_DUMP_MOD_instance10_VARS_packlist; unset($__VAR_DUMP_MOD_instance10_VARS_packlist);$hideDisableButton = $__VAR_DUMP_MOD_instance10_VARS_hideDisableButton; unset($__VAR_DUMP_MOD_instance10_VARS_hideDisableButton);
		list($cardChosen, $card_ownlist, $packlist, $hideDisableButton) = $___TMP_MOD_gtype1_FUNC_card_validate_display_RET;	
		if (20 == $gametype)
		{
			$cardChosen = 1001;
			$card_ownlist[] = 1001;
			$cards[1001]['pack'] = 'Ranmen';
			$hideDisableButton = 0;
		}
		return array($cardChosen, $card_ownlist, $packlist, $hideDisableButton);
	
	}
	
	
	function init_enter_battlefield_items($ebp){
if(isset($ebp)) {$__VAR_DUMP_MOD_instance10_VARS_ebp = $ebp; } else {$__VAR_DUMP_MOD_instance10_VARS_ebp = NULL;} 
		//======== Start of contents from mod instance11 ========
		do{
			$___TMP_MOD_instance11_FUNC_init_enter_battlefield_items_RET = NULL;
if(isset($ebp)) {$__VAR_DUMP_MOD_instance11_VARS_ebp = $ebp; } else {$__VAR_DUMP_MOD_instance11_VARS_ebp = NULL;} 
		//======== Start of contents from mod instance3 ========
		do{
			$___TMP_MOD_instance3_FUNC_init_enter_battlefield_items_RET = NULL;
if(isset($ebp)) {$__VAR_DUMP_MOD_instance3_VARS_ebp = $ebp; } else {$__VAR_DUMP_MOD_instance3_VARS_ebp = NULL;} 
		//======== Start of contents from mod instance9 ========
		do{
			$___TMP_MOD_instance9_FUNC_init_enter_battlefield_items_RET = NULL;
if(isset($ebp)) {$__VAR_DUMP_MOD_instance9_VARS_ebp = $ebp; } else {$__VAR_DUMP_MOD_instance9_VARS_ebp = NULL;} 
		//======== Start of contents from mod instance8 ========
		do{
			$___TMP_MOD_instance8_FUNC_init_enter_battlefield_items_RET = NULL;
if(isset($ebp)) {$__VAR_DUMP_MOD_instance8_VARS_ebp = $ebp; } else {$__VAR_DUMP_MOD_instance8_VARS_ebp = NULL;} 
		//======== Start of contents from mod attrbase ========
		do{
			$___TMP_MOD_attrbase_FUNC_init_enter_battlefield_items_RET = NULL;
if(isset($ebp)) {$__VAR_DUMP_MOD_attrbase_VARS_ebp = $ebp; } else {$__VAR_DUMP_MOD_attrbase_VARS_ebp = NULL;} 
		//======== Start of contents from mod elorating ========
		do{
			$___TMP_MOD_elorating_FUNC_init_enter_battlefield_items_RET = NULL;
if(isset($ebp)) {$__VAR_DUMP_MOD_elorating_VARS_ebp = $ebp; } else {$__VAR_DUMP_MOD_elorating_VARS_ebp = NULL;} 
		//======== Start of contents from mod itemmain ========
		do{
			$___TMP_MOD_itemmain_FUNC_init_enter_battlefield_items_RET = NULL;

		 
		$ebp['arb'] = $ebp['gd'] == 'm' ? '男生校服' : '女生校服';
		$ebp['arbk'] = 'DB'; $ebp['arbe'] = 5; $ebp['arbs'] = 15;
		$ebp['itm1'] = '面包'; $ebp['itmk1'] = 'HH'; $ebp['itme1'] = 100; $ebp['itms1'] = 30;
		$ebp['itm2'] = '矿泉水'; $ebp['itmk2'] = 'HS'; $ebp['itme2'] = 100; $ebp['itms2'] = 30;
		
		$weplist = \itemmain\get_startingwepfilecont ();
		do { 
			$index = rand(1,count($weplist)-1); 
			list($ebp['wep'],$ebp['wepk'],$ebp['wepe'],$ebp['weps'],$ebp['wepsk']) = explode(",",$weplist[$index]);
		} while(!$ebp['wepk']);

		$stitemlist = \itemmain\get_startingitemfilecont ();
		for($i=3;$i<=4;$i++){
			do { 
				$index = rand(1,count($stitemlist)-1); 
				list($ebp['itm'.$i],$ebp['itmk'.$i],$ebp['itme'.$i],$ebp['itms'.$i],$ebp['itmsk'.$i]) = explode(",",$stitemlist[$index]);
			} while(!$ebp['itms'.$i]);
		}
		$___TMP_MOD_itemmain_FUNC_init_enter_battlefield_items_RET =  $ebp;
			break; 
		}while(0);
		//======== End of contents from mod itemmain ========

$ebp = $__VAR_DUMP_MOD_elorating_VARS_ebp; unset($__VAR_DUMP_MOD_elorating_VARS_ebp);

		 
		$ebp = $___TMP_MOD_itemmain_FUNC_init_enter_battlefield_items_RET;
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;   } while (0);
		if (in_array($gametype,$elorated_mode))
		{
			$ebp['itms1'] = 50; $ebp['itms2'] = 50;
			$ebp['itm5'] = '生命探测器'; $ebp['itmk5'] = 'ER'; $ebp['itme5'] = 5; $ebp['itms5'] = 1;$ebp['itmsk5'] = '';
		}
		$___TMP_MOD_elorating_FUNC_init_enter_battlefield_items_RET =  $ebp;
			break; 
		}while(0);
		//======== End of contents from mod elorating ========

$ebp = $__VAR_DUMP_MOD_attrbase_VARS_ebp; unset($__VAR_DUMP_MOD_attrbase_VARS_ebp);

		
		$ret = $___TMP_MOD_elorating_FUNC_init_enter_battlefield_items_RET;
		if(!empty($ret)) {
			
			$equip_list = Array('wep', 'arb', 'arh', 'ara', 'arf', 'art', 'itm0', 'itm1', 'itm2', 'itm3', 'itm4', 'itm5', 'itm6');
			foreach($equip_list as $pos) {
				if(strpos($pos, 'itm')===0) {
					$posskn = 'itmsk'.substr($pos, 3);
				}else{
					$posskn = $pos.'sk';
				}
				if(!empty($ret[$posskn])) {
					$ret[$posskn] = \attrbase\config_process_encode_comp_itmsk ($ret[$posskn]);
				}
			}
		}
		$___TMP_MOD_attrbase_FUNC_init_enter_battlefield_items_RET =  $ret;
			break; 
		}while(0);
		//======== End of contents from mod attrbase ========

$ebp = $__VAR_DUMP_MOD_instance8_VARS_ebp; unset($__VAR_DUMP_MOD_instance8_VARS_ebp);

		 
		$ebp = $___TMP_MOD_attrbase_FUNC_init_enter_battlefield_items_RET;
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;   } while (0);
		if(18==$gametype){
			$ebp['itm4'] = '生命探测器'; $ebp['itmk4'] = 'ER'; $ebp['itme4'] = 3; $ebp['itms4'] = 1;$ebp['itmsk4'] = '';
			$ebp['itm5'] = '全恢复药剂'; $ebp['itmk5'] = 'Ca'; $ebp['itme5'] = 1; $ebp['itms5'] = 3;$ebp['itmsk5'] = '';
		}
		$___TMP_MOD_instance8_FUNC_init_enter_battlefield_items_RET =  $ebp;
			break; 
		}while(0);
		//======== End of contents from mod instance8 ========

$ebp = $__VAR_DUMP_MOD_instance9_VARS_ebp; unset($__VAR_DUMP_MOD_instance9_VARS_ebp);

		 
		$ebp = $___TMP_MOD_instance8_FUNC_init_enter_battlefield_items_RET;
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;   } while (0);
		if(19==$gametype){
			$ebp['arb'] = '挑战者战斗服';$ebp['arbk'] = 'DB'; $ebp['arbe'] = 60; $ebp['arbs'] = 10; $ebp['arbsk'] = '';
			$ebp['arh'] = '挑战者头盔';$ebp['arhk'] = 'DH'; $ebp['arhe'] = 37; $ebp['arhs'] = 5; $ebp['arhsk'] = '';
			$ebp['ara'] = '挑战者护手';$ebp['arak'] = 'DA'; $ebp['arae'] = 37; $ebp['aras'] = 5; $ebp['arask'] = '';
			$ebp['arf'] = '挑战者靴子';$ebp['arfk'] = 'DF'; $ebp['arfe'] = 37; $ebp['arfs'] = 5; $ebp['arfsk'] = '';
			$ebp['itm5'] = '全恢复药剂'; $ebp['itmk5'] = 'Ca'; $ebp['itme5'] = 1; $ebp['itms5'] = 3;$ebp['itmsk5'] = '';
		}
		$___TMP_MOD_instance9_FUNC_init_enter_battlefield_items_RET =  $ebp;
			break; 
		}while(0);
		//======== End of contents from mod instance9 ========

$ebp = $__VAR_DUMP_MOD_instance3_VARS_ebp; unset($__VAR_DUMP_MOD_instance3_VARS_ebp);

		 
		$ebp = $___TMP_MOD_instance9_FUNC_init_enter_battlefield_items_RET;
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;   } while (0);
		if(13==$gametype){
			$ebp['art'] = 'Untainted Glory'; $ebp['artk'] = 'A'; $ebp['arte'] = 1; $ebp['arts'] = 1;$ebp['artsk'] = 'Z';
			$ebp['itm4'] = '生命探测器'; $ebp['itmk4'] = 'ER'; $ebp['itme4'] = 5; $ebp['itms4'] = 1;$ebp['itmsk4'] = '';
			$ebp['itm5'] = '全恢复药剂'; $ebp['itmk5'] = 'Ca'; $ebp['itme5'] = 1; $ebp['itms5'] = 3;$ebp['itmsk5'] = '';
			$option = $roomvars['current_game_option'];
			if(isset($option['lvl']))
			{
				$alvl = (int)$option['lvl'];
				if ($alvl >= 14)
				{
					$ebp['itm6'] = '闪回的心伤'; $ebp['itmk6'] = 'Z'; $ebp['itme6'] = 1; $ebp['itms6'] = 1;$ebp['itmsk6'] = 'O';
					if ($alvl >= 22)
					{
						$ebp['itm5'] = '难抑的焦虑'; $ebp['itmk5'] = 'Z'; $ebp['itme5'] = 1; $ebp['itms5'] = 1;$ebp['itmsk5'] = 'O';
						if ($alvl >= 26)
						{
							$ebp['arb'] = '躯体化的恐惧'; $ebp['arbk'] = 'DB'; $ebp['arbe'] = 10; $ebp['arbs'] = 9999;$ebp['arbsk'] = 'O';
						}
					}
				}
			}
		}
		$___TMP_MOD_instance3_FUNC_init_enter_battlefield_items_RET =  $ebp;
			break; 
		}while(0);
		//======== End of contents from mod instance3 ========

$ebp = $__VAR_DUMP_MOD_instance11_VARS_ebp; unset($__VAR_DUMP_MOD_instance11_VARS_ebp);

		 
		$ebp = $___TMP_MOD_instance3_FUNC_init_enter_battlefield_items_RET;
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;   } while (0);
		if (21 == $gametype){
			$ebp['money'] += 980;
			$ebp['itm6'] = '窥屏用头戴式显示器'; $ebp['itmk6'] = 'DH'; $ebp['itme6'] = 76; $ebp['itms6'] = 5;$ebp['itmsk6'] = '';
			$ebp['itm0'] = '蓝凝的便签'; $ebp['itmk0'] = 'Z'; $ebp['itme0'] = 1; $ebp['itms0'] = 1;$ebp['itmsk0'] = '';
		}
		$___TMP_MOD_instance11_FUNC_init_enter_battlefield_items_RET =  $ebp;
			break; 
		}while(0);
		//======== End of contents from mod instance11 ========

$ebp = $__VAR_DUMP_MOD_instance10_VARS_ebp; unset($__VAR_DUMP_MOD_instance10_VARS_ebp);
		 
		$ebp = $___TMP_MOD_instance11_FUNC_init_enter_battlefield_items_RET;
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;   } while (0);
		if (20 == $gametype){
			$ebp['itm5'] = '全恢复药剂'; $ebp['itmk5'] = 'Ca'; $ebp['itme5'] = 1; $ebp['itms5'] = 3;$ebp['itmsk5'] = '';
		}
		return $ebp;
	
	}
	
	function get_npclist(){
		 
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;  global $___LOCAL_INSTANCE10__VARS__npcinfo_instance10; $npcinfo_instance10=&$___LOCAL_INSTANCE10__VARS__npcinfo_instance10;   } while (0);
		if (20 == $gametype){
			return $npcinfo_instance10;
		}else{
		//======== Start of contents from mod instance5 ========
		do{
			$___TMP_MOD_instance5_FUNC_get_npclist_RET = NULL;

		 
		do { global $___LOCAL_INSTANCE5__VARS__npcinfo_instance5; $npcinfo_instance5=&$___LOCAL_INSTANCE5__VARS__npcinfo_instance5;   } while (0);
		if (15 == $gametype){
			$___TMP_MOD_instance5_FUNC_get_npclist_RET =  $npcinfo_instance5;
			break; 
		}else{
		//======== Start of contents from mod instance11 ========
		do{
			$___TMP_MOD_instance11_FUNC_get_npclist_RET = NULL;

		 
		do { global $___LOCAL_INSTANCE11__VARS__plsinfo11,$___LOCAL_INSTANCE11__VARS__npcinfo_instance11,$___LOCAL_INSTANCE11__VARS__shops11,$___LOCAL_INSTANCE11__VARS__shop_tag_list11; $plsinfo11=&$___LOCAL_INSTANCE11__VARS__plsinfo11; $npcinfo_instance11=&$___LOCAL_INSTANCE11__VARS__npcinfo_instance11; $shops11=&$___LOCAL_INSTANCE11__VARS__shops11; $shop_tag_list11=&$___LOCAL_INSTANCE11__VARS__shop_tag_list11;   } while (0);
		if (21 == $gametype){
			$___TMP_MOD_instance11_FUNC_get_npclist_RET =  $npcinfo_instance11;
			break; 
		}else{
		//======== Start of contents from mod instance3 ========
		do{
			$___TMP_MOD_instance3_FUNC_get_npclist_RET = NULL;

		 
		do { global $___LOCAL_INSTANCE3__VARS__npcinfo_instance3; $npcinfo_instance3=&$___LOCAL_INSTANCE3__VARS__npcinfo_instance3;   } while (0);
		if (13 == $gametype){
			$ret = $npcinfo_instance3;
			
			$alvl = (int)$roomvars['current_game_option']['lvl'];
			if($alvl > 10) {
				$ret[1]['sub'][0]['name'] = '红暮 DUMMY';
			}
			$___TMP_MOD_instance3_FUNC_get_npclist_RET =  $ret;
			break; 
		}else{
if(isset($ret)) {$__VAR_DUMP_MOD_instance3_VARS_ret = $ret; unset($ret); } else {$__VAR_DUMP_MOD_instance3_VARS_ret = NULL;} 
		//======== Start of contents from mod aprilfool2018 ========
		do{
			$___TMP_MOD_aprilfool2018_FUNC_get_npclist_RET = NULL;

		 
		
		//======== Start of contents from mod instance9 ========
		do{
			$___TMP_MOD_instance9_FUNC_get_npclist_RET = NULL;

		 
		do { global $___LOCAL_INSTANCE9__VARS__npcinfo_instance9; $npcinfo_instance9=&$___LOCAL_INSTANCE9__VARS__npcinfo_instance9;   } while (0);
		if (19 == $gametype){
			$___TMP_MOD_instance9_FUNC_get_npclist_RET =  $npcinfo_instance9;
			break; 
		}else{
		//======== Start of contents from mod gtype1 ========
		do{
			$___TMP_MOD_gtype1_FUNC_get_npclist_RET = NULL;

		 
		do { global $___LOCAL_GTYPE1__VARS__npcinfo_gtype1,$___LOCAL_GTYPE1__VARS__enpcinfo_gtype1; $npcinfo_gtype1=&$___LOCAL_GTYPE1__VARS__npcinfo_gtype1; $enpcinfo_gtype1=&$___LOCAL_GTYPE1__VARS__enpcinfo_gtype1;   } while (0);
		if (1 == $gametype){
			$___TMP_MOD_gtype1_FUNC_get_npclist_RET =  $npcinfo_gtype1;
			break; 
		}else{
		//======== Start of contents from mod instance7 ========
		do{
			$___TMP_MOD_instance7_FUNC_get_npclist_RET = NULL;

		 
		do { global $___LOCAL_INSTANCE7__VARS__npcinfo_instance7; $npcinfo_instance7=&$___LOCAL_INSTANCE7__VARS__npcinfo_instance7;   } while (0);
		if (17 == $gametype){
			$___TMP_MOD_instance7_FUNC_get_npclist_RET =  $npcinfo_instance7;
			break; 
		}else{
		//======== Start of contents from mod instance8 ========
		do{
			$___TMP_MOD_instance8_FUNC_get_npclist_RET = NULL;

		 
		do { global $___LOCAL_INSTANCE8__VARS__npcinfo_instance8; $npcinfo_instance8=&$___LOCAL_INSTANCE8__VARS__npcinfo_instance8;   } while (0);
		if (18 == $gametype){
			$___TMP_MOD_instance8_FUNC_get_npclist_RET =  $npcinfo_instance8;
			break; 
		}else{
		//======== Start of contents from mod instance6 ========
		do{
			$___TMP_MOD_instance6_FUNC_get_npclist_RET = NULL;

		 
		do { global $___LOCAL_INSTANCE6__VARS__npcinfo_instance6; $npcinfo_instance6=&$___LOCAL_INSTANCE6__VARS__npcinfo_instance6;   } while (0);
		if (16 == $gametype){
			$___TMP_MOD_instance6_FUNC_get_npclist_RET =  $npcinfo_instance6;
			break; 
		}else{
		//======== Start of contents from mod npc ========
		do{
			$___TMP_MOD_npc_FUNC_get_npclist_RET = NULL;

		
		do { global $___LOCAL_MAP__VARS__all_plsno_cache,$___LOCAL_MAP__VARS__areainterval,$___LOCAL_MAP__VARS__areaadd,$___LOCAL_MAP__VARS__areawarntime,$___LOCAL_MAP__VARS__arealimit,$___LOCAL_MAP__VARS__areaesc,$___LOCAL_MAP__VARS__area_on_start,$___LOCAL_MAP__VARS__dangerous_zone,$___LOCAL_MAP__VARS__plsinfo,$___LOCAL_MAP__VARS__plsinfo_o, $___LOCAL_MAP__VARS__plsinfo_disp,$___LOCAL_MAP__VARS__plsinfo_for_short,$___LOCAL_MAP__VARS__xyinfo,$___LOCAL_MAP__VARS__areainfo; $all_plsno_cache=&$___LOCAL_MAP__VARS__all_plsno_cache; $areainterval=&$___LOCAL_MAP__VARS__areainterval; $areaadd=&$___LOCAL_MAP__VARS__areaadd; $areawarntime=&$___LOCAL_MAP__VARS__areawarntime; $arealimit=&$___LOCAL_MAP__VARS__arealimit; $areaesc=&$___LOCAL_MAP__VARS__areaesc; $area_on_start=&$___LOCAL_MAP__VARS__area_on_start; $dangerous_zone=&$___LOCAL_MAP__VARS__dangerous_zone; $plsinfo=&$___LOCAL_MAP__VARS__plsinfo; $plsinfo_o=&$___LOCAL_MAP__VARS__plsinfo_o;  $plsinfo_disp=&$___LOCAL_MAP__VARS__plsinfo_disp; $plsinfo_for_short=&$___LOCAL_MAP__VARS__plsinfo_for_short; $xyinfo=&$___LOCAL_MAP__VARS__xyinfo; $areainfo=&$___LOCAL_MAP__VARS__areainfo;  global $___LOCAL_NPC__VARS__npcinit,$___LOCAL_NPC__VARS__npcinfo,$___LOCAL_NPC__VARS__killzone_resistant_typelist,$___LOCAL_NPC__VARS__npc_typeinfo,$___LOCAL_NPC__VARS__npc_killmsginfo,$___LOCAL_NPC__VARS__npc_lwinfo,$___LOCAL_NPC__VARS__npc_revive_info; $npcinit=&$___LOCAL_NPC__VARS__npcinit; $npcinfo=&$___LOCAL_NPC__VARS__npcinfo; $killzone_resistant_typelist=&$___LOCAL_NPC__VARS__killzone_resistant_typelist; $npc_typeinfo=&$___LOCAL_NPC__VARS__npc_typeinfo; $npc_killmsginfo=&$___LOCAL_NPC__VARS__npc_killmsginfo; $npc_lwinfo=&$___LOCAL_NPC__VARS__npc_lwinfo; $npc_revive_info=&$___LOCAL_NPC__VARS__npc_revive_info;   } while (0);
		$___TMP_MOD_npc_FUNC_get_npclist_RET =  $npcinfo;
			break; 
		}while(0);
		//======== End of contents from mod npc ========
 $___TMP_MOD_instance6_FUNC_get_npclist_RET =  $___TMP_MOD_npc_FUNC_get_npclist_RET;
			break; }
		}while(0);
		//======== End of contents from mod instance6 ========
 $___TMP_MOD_instance8_FUNC_get_npclist_RET =  $___TMP_MOD_instance6_FUNC_get_npclist_RET;
			break; }
		}while(0);
		//======== End of contents from mod instance8 ========
 $___TMP_MOD_instance7_FUNC_get_npclist_RET =  $___TMP_MOD_instance8_FUNC_get_npclist_RET;
			break; }
		}while(0);
		//======== End of contents from mod instance7 ========
 $___TMP_MOD_gtype1_FUNC_get_npclist_RET =  $___TMP_MOD_instance7_FUNC_get_npclist_RET;
			break; }
		}while(0);
		//======== End of contents from mod gtype1 ========
 $___TMP_MOD_instance9_FUNC_get_npclist_RET =  $___TMP_MOD_gtype1_FUNC_get_npclist_RET;
			break; }
		}while(0);
		//======== End of contents from mod instance9 ========

		$ret = $___TMP_MOD_instance9_FUNC_get_npclist_RET;
		if(in_array($gametype, array(0,4)) && 1 == \achievement_base\check_achtype_available(34)) {
			do { global $___LOCAL_APRILFOOL2018__VARS__snpcinfo; $snpcinfo=&$___LOCAL_APRILFOOL2018__VARS__snpcinfo;   } while (0);
			foreach($snpcinfo as $i => $v){
				$ret[$i] = $v;
			}
		}
		$___TMP_MOD_aprilfool2018_FUNC_get_npclist_RET =  $ret;
			break; 
		}while(0);
		//======== End of contents from mod aprilfool2018 ========

$ret = $__VAR_DUMP_MOD_instance3_VARS_ret;  $___TMP_MOD_instance3_FUNC_get_npclist_RET =  $___TMP_MOD_aprilfool2018_FUNC_get_npclist_RET;
			break; }
		}while(0);
		//======== End of contents from mod instance3 ========
 $___TMP_MOD_instance11_FUNC_get_npclist_RET =  $___TMP_MOD_instance3_FUNC_get_npclist_RET;
			break; }
		}while(0);
		//======== End of contents from mod instance11 ========
 $___TMP_MOD_instance5_FUNC_get_npclist_RET =  $___TMP_MOD_instance11_FUNC_get_npclist_RET;
			break; }
		}while(0);
		//======== End of contents from mod instance5 ========
 return $___TMP_MOD_instance5_FUNC_get_npclist_RET;}
	
	}
	
	function get_shopconfig(){
		 
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;  global $___LOCAL_INSTANCE10__VARS__npcinfo_instance10; $npcinfo_instance10=&$___LOCAL_INSTANCE10__VARS__npcinfo_instance10;   } while (0);
		if (20 == $gametype){
			$file = 'D:\phpstudy_pro\WWW\dts\./include/modules/extra/instance/instance10_road'.'/config/shopitem.config.php';
			$l = openfile($file);
			return $l;
		}else{
if(isset($file)) {$__VAR_DUMP_MOD_instance10_VARS_file = $file; unset($file); } else {$__VAR_DUMP_MOD_instance10_VARS_file = NULL;} if(isset($l)) {$__VAR_DUMP_MOD_instance10_VARS_l = $l; unset($l); } else {$__VAR_DUMP_MOD_instance10_VARS_l = NULL;} 
		//======== Start of contents from mod instance5 ========
		do{
			$___TMP_MOD_instance5_FUNC_get_shopconfig_RET = NULL;

		 
		
		if ($gametype==15){
			$file = 'D:\phpstudy_pro\WWW\dts\./include/modules/extra/instance/instance5'.'/config/shopitem.config.php';
			$sl5 = openfile($file);
			$___TMP_MOD_instance5_FUNC_get_shopconfig_RET =  $sl5;
			break; 
		}else{
if(isset($file)) {$__VAR_DUMP_MOD_instance5_VARS_file = $file; unset($file); } else {$__VAR_DUMP_MOD_instance5_VARS_file = NULL;} 
		//======== Start of contents from mod instance11 ========
		do{
			$___TMP_MOD_instance11_FUNC_get_shopconfig_RET = NULL;

		 
		do { global $___LOCAL_INSTANCE11__VARS__plsinfo11,$___LOCAL_INSTANCE11__VARS__npcinfo_instance11,$___LOCAL_INSTANCE11__VARS__shops11,$___LOCAL_INSTANCE11__VARS__shop_tag_list11; $plsinfo11=&$___LOCAL_INSTANCE11__VARS__plsinfo11; $npcinfo_instance11=&$___LOCAL_INSTANCE11__VARS__npcinfo_instance11; $shops11=&$___LOCAL_INSTANCE11__VARS__shops11; $shop_tag_list11=&$___LOCAL_INSTANCE11__VARS__shop_tag_list11;   } while (0);
		if (21 == $gametype){
			$file = 'D:\phpstudy_pro\WWW\dts\./include/modules/extra/instance/instance11_observe'.'/config/shopitem.config.php';
			$l = openfile($file);
			$___TMP_MOD_instance11_FUNC_get_shopconfig_RET =  $l;
			break; 
		}
if(isset($file)) {$__VAR_DUMP_MOD_instance11_VARS_file = $file; unset($file); } else {$__VAR_DUMP_MOD_instance11_VARS_file = NULL;} if(isset($l)) {$__VAR_DUMP_MOD_instance11_VARS_l = $l; unset($l); } else {$__VAR_DUMP_MOD_instance11_VARS_l = NULL;} 
		//======== Start of contents from mod instance3 ========
		do{
			$___TMP_MOD_instance3_FUNC_get_shopconfig_RET = NULL;

		 
		
		if (13 == $gametype){
			$file = 'D:\phpstudy_pro\WWW\dts\./include/modules/extra/instance/instance3_ascension'.'/config/shopitem.config.php';
			$l = openfile($file);
			$___TMP_MOD_instance3_FUNC_get_shopconfig_RET =  $l;
			break; 
		}else{
if(isset($file)) {$__VAR_DUMP_MOD_instance3_VARS_file = $file; unset($file); } else {$__VAR_DUMP_MOD_instance3_VARS_file = NULL;} if(isset($l)) {$__VAR_DUMP_MOD_instance3_VARS_l = $l; unset($l); } else {$__VAR_DUMP_MOD_instance3_VARS_l = NULL;} 
		//======== Start of contents from mod instance9 ========
		do{
			$___TMP_MOD_instance9_FUNC_get_shopconfig_RET = NULL;

		 
		do { global $___LOCAL_INSTANCE9__VARS__npcinfo_instance9; $npcinfo_instance9=&$___LOCAL_INSTANCE9__VARS__npcinfo_instance9;   } while (0);
		if (19 == $gametype){
			$file = 'D:\phpstudy_pro\WWW\dts\./include/modules/extra/instance/instance9_rush'.'/config/shopitem.config.php';
			$l = openfile($file);
			$___TMP_MOD_instance9_FUNC_get_shopconfig_RET =  $l;
			break; 
		}else{
if(isset($file)) {$__VAR_DUMP_MOD_instance9_VARS_file = $file; unset($file); } else {$__VAR_DUMP_MOD_instance9_VARS_file = NULL;} if(isset($l)) {$__VAR_DUMP_MOD_instance9_VARS_l = $l; unset($l); } else {$__VAR_DUMP_MOD_instance9_VARS_l = NULL;} 
		//======== Start of contents from mod gtype1 ========
		do{
			$___TMP_MOD_gtype1_FUNC_get_shopconfig_RET = NULL;

		 
		
		if ($gametype==1){
			$file = 'D:\phpstudy_pro\WWW\dts\./include/modules/extra/instance/gtype1/main'.'/config/shopitem.config.php';
			$sl = openfile($file);
			$___TMP_MOD_gtype1_FUNC_get_shopconfig_RET =  $sl;
			break; 
		}else{
if(isset($file)) {$__VAR_DUMP_MOD_gtype1_VARS_file = $file; unset($file); } else {$__VAR_DUMP_MOD_gtype1_VARS_file = NULL;} if(isset($sl)) {$__VAR_DUMP_MOD_gtype1_VARS_sl = $sl; unset($sl); } else {$__VAR_DUMP_MOD_gtype1_VARS_sl = NULL;} 
		//======== Start of contents from mod instance7 ========
		do{
			$___TMP_MOD_instance7_FUNC_get_shopconfig_RET = NULL;

		 
		
		if (17 == $gametype){
			$file = 'D:\phpstudy_pro\WWW\dts\./include/modules/extra/instance/instance7_tutorial'.'/config/shopitem.config.php';
			$l = openfile($file);
			$___TMP_MOD_instance7_FUNC_get_shopconfig_RET =  $l;
			break; 
		}else{
if(isset($file)) {$__VAR_DUMP_MOD_instance7_VARS_file = $file; unset($file); } else {$__VAR_DUMP_MOD_instance7_VARS_file = NULL;} if(isset($l)) {$__VAR_DUMP_MOD_instance7_VARS_l = $l; unset($l); } else {$__VAR_DUMP_MOD_instance7_VARS_l = NULL;} 
		//======== Start of contents from mod instance8 ========
		do{
			$___TMP_MOD_instance8_FUNC_get_shopconfig_RET = NULL;

		 
		do { global $___LOCAL_INSTANCE8__VARS__npcinfo_instance8; $npcinfo_instance8=&$___LOCAL_INSTANCE8__VARS__npcinfo_instance8;   } while (0);
		if (18 == $gametype){
			$file = 'D:\phpstudy_pro\WWW\dts\./include/modules/extra/instance/instance8_proud'.'/config/shopitem.config.php';
			$l = openfile($file);
			$___TMP_MOD_instance8_FUNC_get_shopconfig_RET =  $l;
			break; 
		}else{
if(isset($file)) {$__VAR_DUMP_MOD_instance8_VARS_file = $file; unset($file); } else {$__VAR_DUMP_MOD_instance8_VARS_file = NULL;} 
		//======== Start of contents from mod instance6 ========
		do{
			$___TMP_MOD_instance6_FUNC_get_shopconfig_RET = NULL;

		 
		
		if ($gametype==16){
			$file = 'D:\phpstudy_pro\WWW\dts\./include/modules/extra/instance/instance6'.'/config/shopitem.config.php';
			$sl6 = openfile($file);
			$___TMP_MOD_instance6_FUNC_get_shopconfig_RET =  $sl6;
			break; 
		}else{
if(isset($file)) {$__VAR_DUMP_MOD_instance6_VARS_file = $file; unset($file); } else {$__VAR_DUMP_MOD_instance6_VARS_file = NULL;} 
		//======== Start of contents from mod itemshop ========
		do{
			$___TMP_MOD_itemshop_FUNC_get_shopconfig_RET = NULL;

		 
		$file = 'D:\phpstudy_pro\WWW\dts\./include/modules/base/itemshop'.'/config/shopitem.config.php';
		$sl = openfile($file);
		$___TMP_MOD_itemshop_FUNC_get_shopconfig_RET =  $sl;
			break; 
		}while(0);
		//======== End of contents from mod itemshop ========

$file = $__VAR_DUMP_MOD_instance6_VARS_file;  $___TMP_MOD_instance6_FUNC_get_shopconfig_RET =  $___TMP_MOD_itemshop_FUNC_get_shopconfig_RET;
			break; }
		}while(0);
		//======== End of contents from mod instance6 ========

$file = $__VAR_DUMP_MOD_instance8_VARS_file;  $___TMP_MOD_instance8_FUNC_get_shopconfig_RET =  $___TMP_MOD_instance6_FUNC_get_shopconfig_RET;
			break; }
		}while(0);
		//======== End of contents from mod instance8 ========

$file = $__VAR_DUMP_MOD_instance7_VARS_file; $l = $__VAR_DUMP_MOD_instance7_VARS_l;  $___TMP_MOD_instance7_FUNC_get_shopconfig_RET =  $___TMP_MOD_instance8_FUNC_get_shopconfig_RET;
			break; }
		}while(0);
		//======== End of contents from mod instance7 ========

$file = $__VAR_DUMP_MOD_gtype1_VARS_file; $sl = $__VAR_DUMP_MOD_gtype1_VARS_sl;  $___TMP_MOD_gtype1_FUNC_get_shopconfig_RET =  $___TMP_MOD_instance7_FUNC_get_shopconfig_RET;
			break; }
		}while(0);
		//======== End of contents from mod gtype1 ========

$file = $__VAR_DUMP_MOD_instance9_VARS_file; $l = $__VAR_DUMP_MOD_instance9_VARS_l;  $___TMP_MOD_instance9_FUNC_get_shopconfig_RET =  $___TMP_MOD_gtype1_FUNC_get_shopconfig_RET;
			break; }
		}while(0);
		//======== End of contents from mod instance9 ========

$file = $__VAR_DUMP_MOD_instance3_VARS_file; $l = $__VAR_DUMP_MOD_instance3_VARS_l;  $___TMP_MOD_instance3_FUNC_get_shopconfig_RET =  $___TMP_MOD_instance9_FUNC_get_shopconfig_RET;
			break; }
		}while(0);
		//======== End of contents from mod instance3 ========

$file = $__VAR_DUMP_MOD_instance11_VARS_file; $l = $__VAR_DUMP_MOD_instance11_VARS_l; 
		$___TMP_MOD_instance11_FUNC_get_shopconfig_RET =  $___TMP_MOD_instance3_FUNC_get_shopconfig_RET;
			break; 
		}while(0);
		//======== End of contents from mod instance11 ========

$file = $__VAR_DUMP_MOD_instance5_VARS_file;  $___TMP_MOD_instance5_FUNC_get_shopconfig_RET =  $___TMP_MOD_instance11_FUNC_get_shopconfig_RET;
			break; }
		}while(0);
		//======== End of contents from mod instance5 ========

$file = $__VAR_DUMP_MOD_instance10_VARS_file; $l = $__VAR_DUMP_MOD_instance10_VARS_l;  return $___TMP_MOD_instance5_FUNC_get_shopconfig_RET;}
	
	}
	
	function get_itemfilecont(){
		 
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;   } while (0);
		if (20 == $gametype){
			$file = 'D:\phpstudy_pro\WWW\dts\./include/modules/extra/instance/instance10_road'.'/config/mapitem.config.php';
			$l = openfile($file);
			return $l;
		}else{
if(isset($file)) {$__VAR_DUMP_MOD_instance10_VARS_file = $file; unset($file); } else {$__VAR_DUMP_MOD_instance10_VARS_file = NULL;} if(isset($l)) {$__VAR_DUMP_MOD_instance10_VARS_l = $l; unset($l); } else {$__VAR_DUMP_MOD_instance10_VARS_l = NULL;} 
		//======== Start of contents from mod instance11 ========
		do{
			$___TMP_MOD_instance11_FUNC_get_itemfilecont_RET = NULL;

		 
		
		if (21 == $gametype){
			$file = 'D:\phpstudy_pro\WWW\dts\./include/modules/extra/instance/instance11_observe'.'/config/mapitem.config.php';
			$l = openfile($file);
			$___TMP_MOD_instance11_FUNC_get_itemfilecont_RET =  $l;
			break; 
		}else{
if(isset($file)) {$__VAR_DUMP_MOD_instance11_VARS_file = $file; unset($file); } else {$__VAR_DUMP_MOD_instance11_VARS_file = NULL;} if(isset($l)) {$__VAR_DUMP_MOD_instance11_VARS_l = $l; unset($l); } else {$__VAR_DUMP_MOD_instance11_VARS_l = NULL;} 
		//======== Start of contents from mod instance3 ========
		do{
			$___TMP_MOD_instance3_FUNC_get_itemfilecont_RET = NULL;

		 
		
		if (13 == $gametype){
			$file = 'D:\phpstudy_pro\WWW\dts\./include/modules/extra/instance/instance3_ascension'.'/config/mapitem.config.php';
			$l = openfile($file);
			$___TMP_MOD_instance3_FUNC_get_itemfilecont_RET =  $l;
			break; 
		}else{
if(isset($file)) {$__VAR_DUMP_MOD_instance3_VARS_file = $file; unset($file); } else {$__VAR_DUMP_MOD_instance3_VARS_file = NULL;} if(isset($l)) {$__VAR_DUMP_MOD_instance3_VARS_l = $l; unset($l); } else {$__VAR_DUMP_MOD_instance3_VARS_l = NULL;} 
		//======== Start of contents from mod instance9 ========
		do{
			$___TMP_MOD_instance9_FUNC_get_itemfilecont_RET = NULL;

		 
		
		if (19 == $gametype){
			$file = 'D:\phpstudy_pro\WWW\dts\./include/modules/extra/instance/instance9_rush'.'/config/mapitem.config.php';
			$l = openfile($file);
			$___TMP_MOD_instance9_FUNC_get_itemfilecont_RET =  $l;
			break; 
		}else{
if(isset($file)) {$__VAR_DUMP_MOD_instance9_VARS_file = $file; unset($file); } else {$__VAR_DUMP_MOD_instance9_VARS_file = NULL;} if(isset($l)) {$__VAR_DUMP_MOD_instance9_VARS_l = $l; unset($l); } else {$__VAR_DUMP_MOD_instance9_VARS_l = NULL;} 
		//======== Start of contents from mod instance7 ========
		do{
			$___TMP_MOD_instance7_FUNC_get_itemfilecont_RET = NULL;

		 
		
		if (17 == $gametype){
			$file = 'D:\phpstudy_pro\WWW\dts\./include/modules/extra/instance/instance7_tutorial'.'/config/mapitem.config.php';
			$l = openfile($file);
			$___TMP_MOD_instance7_FUNC_get_itemfilecont_RET =  $l;
			break; 
		}else{
if(isset($file)) {$__VAR_DUMP_MOD_instance7_VARS_file = $file; unset($file); } else {$__VAR_DUMP_MOD_instance7_VARS_file = NULL;} if(isset($l)) {$__VAR_DUMP_MOD_instance7_VARS_l = $l; unset($l); } else {$__VAR_DUMP_MOD_instance7_VARS_l = NULL;} 
		//======== Start of contents from mod instance8 ========
		do{
			$___TMP_MOD_instance8_FUNC_get_itemfilecont_RET = NULL;

		 
		
		if (18 == $gametype){
			$file = 'D:\phpstudy_pro\WWW\dts\./include/modules/extra/instance/instance8_proud'.'/config/mapitem.config.php';
			$l = openfile($file);
			$___TMP_MOD_instance8_FUNC_get_itemfilecont_RET =  $l;
			break; 
		}else{
if(isset($file)) {$__VAR_DUMP_MOD_instance8_VARS_file = $file; unset($file); } else {$__VAR_DUMP_MOD_instance8_VARS_file = NULL;} if(isset($l)) {$__VAR_DUMP_MOD_instance8_VARS_l = $l; unset($l); } else {$__VAR_DUMP_MOD_instance8_VARS_l = NULL;} 
		//======== Start of contents from mod itemmain ========
		do{
			$___TMP_MOD_itemmain_FUNC_get_itemfilecont_RET = NULL;

		 
		$file = 'D:\phpstudy_pro\WWW\dts\./include/modules/base/itemmain'.'/config/mapitem.config.php';
		$l = openfile($file);
		$___TMP_MOD_itemmain_FUNC_get_itemfilecont_RET =  $l;
			break; 
		}while(0);
		//======== End of contents from mod itemmain ========

$file = $__VAR_DUMP_MOD_instance8_VARS_file; $l = $__VAR_DUMP_MOD_instance8_VARS_l;  $___TMP_MOD_instance8_FUNC_get_itemfilecont_RET =  $___TMP_MOD_itemmain_FUNC_get_itemfilecont_RET;
			break; }
		}while(0);
		//======== End of contents from mod instance8 ========

$file = $__VAR_DUMP_MOD_instance7_VARS_file; $l = $__VAR_DUMP_MOD_instance7_VARS_l;  $___TMP_MOD_instance7_FUNC_get_itemfilecont_RET =  $___TMP_MOD_instance8_FUNC_get_itemfilecont_RET;
			break; }
		}while(0);
		//======== End of contents from mod instance7 ========

$file = $__VAR_DUMP_MOD_instance9_VARS_file; $l = $__VAR_DUMP_MOD_instance9_VARS_l;  $___TMP_MOD_instance9_FUNC_get_itemfilecont_RET =  $___TMP_MOD_instance7_FUNC_get_itemfilecont_RET;
			break; }
		}while(0);
		//======== End of contents from mod instance9 ========

$file = $__VAR_DUMP_MOD_instance3_VARS_file; $l = $__VAR_DUMP_MOD_instance3_VARS_l;  $___TMP_MOD_instance3_FUNC_get_itemfilecont_RET =  $___TMP_MOD_instance9_FUNC_get_itemfilecont_RET;
			break; }
		}while(0);
		//======== End of contents from mod instance3 ========

$file = $__VAR_DUMP_MOD_instance11_VARS_file; $l = $__VAR_DUMP_MOD_instance11_VARS_l;  $___TMP_MOD_instance11_FUNC_get_itemfilecont_RET =  $___TMP_MOD_instance3_FUNC_get_itemfilecont_RET;
			break; }
		}while(0);
		//======== End of contents from mod instance11 ========

$file = $__VAR_DUMP_MOD_instance10_VARS_file; $l = $__VAR_DUMP_MOD_instance10_VARS_l;  return $___TMP_MOD_instance11_FUNC_get_itemfilecont_RET;}
	
	}
	
	function get_startingitemfilecont(){
		 
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;   } while (0);
		if (20 == $gametype){
			$file = 'D:\phpstudy_pro\WWW\dts\./include/modules/extra/instance/instance10_road'.'/config/stitem.config.php';
			$l = openfile($file);
			return $l;
		}else{
if(isset($file)) {$__VAR_DUMP_MOD_instance10_VARS_file = $file; unset($file); } else {$__VAR_DUMP_MOD_instance10_VARS_file = NULL;} if(isset($l)) {$__VAR_DUMP_MOD_instance10_VARS_l = $l; unset($l); } else {$__VAR_DUMP_MOD_instance10_VARS_l = NULL;} 
		//======== Start of contents from mod instance11 ========
		do{
			$___TMP_MOD_instance11_FUNC_get_startingitemfilecont_RET = NULL;

		 
		
		if (21 == $gametype){
			$file = 'D:\phpstudy_pro\WWW\dts\./include/modules/extra/instance/instance11_observe'.'/config/stitem.config.php';
			$l = openfile($file);
			$___TMP_MOD_instance11_FUNC_get_startingitemfilecont_RET =  $l;
			break; 
		}else{
if(isset($file)) {$__VAR_DUMP_MOD_instance11_VARS_file = $file; unset($file); } else {$__VAR_DUMP_MOD_instance11_VARS_file = NULL;} if(isset($l)) {$__VAR_DUMP_MOD_instance11_VARS_l = $l; unset($l); } else {$__VAR_DUMP_MOD_instance11_VARS_l = NULL;} 
		//======== Start of contents from mod instance9 ========
		do{
			$___TMP_MOD_instance9_FUNC_get_startingitemfilecont_RET = NULL;

		 
		
		if (19 == $gametype){
			$file = 'D:\phpstudy_pro\WWW\dts\./include/modules/extra/instance/instance9_rush'.'/config/stitem.config.php';
			$l = openfile($file);
			$___TMP_MOD_instance9_FUNC_get_startingitemfilecont_RET =  $l;
			break; 
		}else{
if(isset($file)) {$__VAR_DUMP_MOD_instance9_VARS_file = $file; unset($file); } else {$__VAR_DUMP_MOD_instance9_VARS_file = NULL;} if(isset($l)) {$__VAR_DUMP_MOD_instance9_VARS_l = $l; unset($l); } else {$__VAR_DUMP_MOD_instance9_VARS_l = NULL;} 
		//======== Start of contents from mod instance7 ========
		do{
			$___TMP_MOD_instance7_FUNC_get_startingitemfilecont_RET = NULL;

		 
		
		if (17 == $gametype){
			$file = 'D:\phpstudy_pro\WWW\dts\./include/modules/extra/instance/instance7_tutorial'.'/config/stitem.config.php';
			$l = openfile($file);
			$___TMP_MOD_instance7_FUNC_get_startingitemfilecont_RET =  $l;
			break; 
		}else{
if(isset($file)) {$__VAR_DUMP_MOD_instance7_VARS_file = $file; unset($file); } else {$__VAR_DUMP_MOD_instance7_VARS_file = NULL;} if(isset($l)) {$__VAR_DUMP_MOD_instance7_VARS_l = $l; unset($l); } else {$__VAR_DUMP_MOD_instance7_VARS_l = NULL;} 
		//======== Start of contents from mod instance8 ========
		do{
			$___TMP_MOD_instance8_FUNC_get_startingitemfilecont_RET = NULL;

		 
		
		if (18 == $gametype){
			$file = 'D:\phpstudy_pro\WWW\dts\./include/modules/extra/instance/instance8_proud'.'/config/stitem.config.php';
			$l = openfile($file);
			$___TMP_MOD_instance8_FUNC_get_startingitemfilecont_RET =  $l;
			break; 
		}else{
if(isset($file)) {$__VAR_DUMP_MOD_instance8_VARS_file = $file; unset($file); } else {$__VAR_DUMP_MOD_instance8_VARS_file = NULL;} if(isset($l)) {$__VAR_DUMP_MOD_instance8_VARS_l = $l; unset($l); } else {$__VAR_DUMP_MOD_instance8_VARS_l = NULL;} 
		//======== Start of contents from mod itemmain ========
		do{
			$___TMP_MOD_itemmain_FUNC_get_startingitemfilecont_RET = NULL;

		 
		$file = 'D:\phpstudy_pro\WWW\dts\./include/modules/base/itemmain'.'/config/stitem.config.php';
		$l = openfile($file);
		$___TMP_MOD_itemmain_FUNC_get_startingitemfilecont_RET =  $l;
			break; 
		}while(0);
		//======== End of contents from mod itemmain ========

$file = $__VAR_DUMP_MOD_instance8_VARS_file; $l = $__VAR_DUMP_MOD_instance8_VARS_l;  $___TMP_MOD_instance8_FUNC_get_startingitemfilecont_RET =  $___TMP_MOD_itemmain_FUNC_get_startingitemfilecont_RET;
			break; }
		}while(0);
		//======== End of contents from mod instance8 ========

$file = $__VAR_DUMP_MOD_instance7_VARS_file; $l = $__VAR_DUMP_MOD_instance7_VARS_l;  $___TMP_MOD_instance7_FUNC_get_startingitemfilecont_RET =  $___TMP_MOD_instance8_FUNC_get_startingitemfilecont_RET;
			break; }
		}while(0);
		//======== End of contents from mod instance7 ========

$file = $__VAR_DUMP_MOD_instance9_VARS_file; $l = $__VAR_DUMP_MOD_instance9_VARS_l;  $___TMP_MOD_instance9_FUNC_get_startingitemfilecont_RET =  $___TMP_MOD_instance7_FUNC_get_startingitemfilecont_RET;
			break; }
		}while(0);
		//======== End of contents from mod instance9 ========

$file = $__VAR_DUMP_MOD_instance11_VARS_file; $l = $__VAR_DUMP_MOD_instance11_VARS_l;  $___TMP_MOD_instance11_FUNC_get_startingitemfilecont_RET =  $___TMP_MOD_instance9_FUNC_get_startingitemfilecont_RET;
			break; }
		}while(0);
		//======== End of contents from mod instance11 ========

$file = $__VAR_DUMP_MOD_instance10_VARS_file; $l = $__VAR_DUMP_MOD_instance10_VARS_l;  return $___TMP_MOD_instance11_FUNC_get_startingitemfilecont_RET;}
	
	}
	
	function get_startingwepfilecont(){
		 
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;   } while (0);
		if (20 == $gametype){
			$file = 'D:\phpstudy_pro\WWW\dts\./include/modules/extra/instance/instance10_road'.'/config/stwep.config.php';
			$l = openfile($file);
			return $l;
		}else{
if(isset($file)) {$__VAR_DUMP_MOD_instance10_VARS_file = $file; unset($file); } else {$__VAR_DUMP_MOD_instance10_VARS_file = NULL;} if(isset($l)) {$__VAR_DUMP_MOD_instance10_VARS_l = $l; unset($l); } else {$__VAR_DUMP_MOD_instance10_VARS_l = NULL;} 
		//======== Start of contents from mod instance11 ========
		do{
			$___TMP_MOD_instance11_FUNC_get_startingwepfilecont_RET = NULL;

		 
		
		if (21 == $gametype){
			$file = 'D:\phpstudy_pro\WWW\dts\./include/modules/extra/instance/instance11_observe'.'/config/stwep.config.php';
			$l = openfile($file);
			$___TMP_MOD_instance11_FUNC_get_startingwepfilecont_RET =  $l;
			break; 
		}else{
if(isset($file)) {$__VAR_DUMP_MOD_instance11_VARS_file = $file; unset($file); } else {$__VAR_DUMP_MOD_instance11_VARS_file = NULL;} if(isset($l)) {$__VAR_DUMP_MOD_instance11_VARS_l = $l; unset($l); } else {$__VAR_DUMP_MOD_instance11_VARS_l = NULL;} 
		//======== Start of contents from mod instance9 ========
		do{
			$___TMP_MOD_instance9_FUNC_get_startingwepfilecont_RET = NULL;

		 
		
		if (19 == $gametype){
			$file = 'D:\phpstudy_pro\WWW\dts\./include/modules/extra/instance/instance9_rush'.'/config/stwep.config.php';
			$l = openfile($file);
			$___TMP_MOD_instance9_FUNC_get_startingwepfilecont_RET =  $l;
			break; 
		}else{
if(isset($file)) {$__VAR_DUMP_MOD_instance9_VARS_file = $file; unset($file); } else {$__VAR_DUMP_MOD_instance9_VARS_file = NULL;} if(isset($l)) {$__VAR_DUMP_MOD_instance9_VARS_l = $l; unset($l); } else {$__VAR_DUMP_MOD_instance9_VARS_l = NULL;} 
		//======== Start of contents from mod instance8 ========
		do{
			$___TMP_MOD_instance8_FUNC_get_startingwepfilecont_RET = NULL;

		 
		
		if (18 == $gametype){
			$file = 'D:\phpstudy_pro\WWW\dts\./include/modules/extra/instance/instance8_proud'.'/config/stwep.config.php';
			$l = openfile($file);
			$___TMP_MOD_instance8_FUNC_get_startingwepfilecont_RET =  $l;
			break; 
		}else{
if(isset($file)) {$__VAR_DUMP_MOD_instance8_VARS_file = $file; unset($file); } else {$__VAR_DUMP_MOD_instance8_VARS_file = NULL;} if(isset($l)) {$__VAR_DUMP_MOD_instance8_VARS_l = $l; unset($l); } else {$__VAR_DUMP_MOD_instance8_VARS_l = NULL;} 
		//======== Start of contents from mod itemmain ========
		do{
			$___TMP_MOD_itemmain_FUNC_get_startingwepfilecont_RET = NULL;

		 
		$file = 'D:\phpstudy_pro\WWW\dts\./include/modules/base/itemmain'.'/config/stwep.config.php';
		$l = openfile($file);
		$___TMP_MOD_itemmain_FUNC_get_startingwepfilecont_RET =  $l;
			break; 
		}while(0);
		//======== End of contents from mod itemmain ========

$file = $__VAR_DUMP_MOD_instance8_VARS_file; $l = $__VAR_DUMP_MOD_instance8_VARS_l;  $___TMP_MOD_instance8_FUNC_get_startingwepfilecont_RET =  $___TMP_MOD_itemmain_FUNC_get_startingwepfilecont_RET;
			break; }
		}while(0);
		//======== End of contents from mod instance8 ========

$file = $__VAR_DUMP_MOD_instance9_VARS_file; $l = $__VAR_DUMP_MOD_instance9_VARS_l;  $___TMP_MOD_instance9_FUNC_get_startingwepfilecont_RET =  $___TMP_MOD_instance8_FUNC_get_startingwepfilecont_RET;
			break; }
		}while(0);
		//======== End of contents from mod instance9 ========

$file = $__VAR_DUMP_MOD_instance11_VARS_file; $l = $__VAR_DUMP_MOD_instance11_VARS_l;  $___TMP_MOD_instance11_FUNC_get_startingwepfilecont_RET =  $___TMP_MOD_instance9_FUNC_get_startingwepfilecont_RET;
			break; }
		}while(0);
		//======== End of contents from mod instance11 ========

$file = $__VAR_DUMP_MOD_instance10_VARS_file; $l = $__VAR_DUMP_MOD_instance10_VARS_l;  return $___TMP_MOD_instance11_FUNC_get_startingwepfilecont_RET;}
	
	}
	
	function get_trapfilecont(){
		 
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;   } while (0);
		if (20 == $gametype){
			$file = 'D:\phpstudy_pro\WWW\dts\./include/modules/extra/instance/instance10_road'.'/config/trapitem.config.php';
			$l = openfile($file);
			return $l;
		}else{
if(isset($file)) {$__VAR_DUMP_MOD_instance10_VARS_file = $file; unset($file); } else {$__VAR_DUMP_MOD_instance10_VARS_file = NULL;} if(isset($l)) {$__VAR_DUMP_MOD_instance10_VARS_l = $l; unset($l); } else {$__VAR_DUMP_MOD_instance10_VARS_l = NULL;} 
		//======== Start of contents from mod instance11 ========
		do{
			$___TMP_MOD_instance11_FUNC_get_trapfilecont_RET = NULL;

		 
		
		if (21 == $gametype){
			$file = 'D:\phpstudy_pro\WWW\dts\./include/modules/extra/instance/instance11_observe'.'/config/trapitem.config.php';
			$l = openfile($file);
			$___TMP_MOD_instance11_FUNC_get_trapfilecont_RET =  $l;
			break; 
		}else{
if(isset($file)) {$__VAR_DUMP_MOD_instance11_VARS_file = $file; unset($file); } else {$__VAR_DUMP_MOD_instance11_VARS_file = NULL;} if(isset($l)) {$__VAR_DUMP_MOD_instance11_VARS_l = $l; unset($l); } else {$__VAR_DUMP_MOD_instance11_VARS_l = NULL;} 
		//======== Start of contents from mod instance9 ========
		do{
			$___TMP_MOD_instance9_FUNC_get_trapfilecont_RET = NULL;

		 
		
		if (19 == $gametype){
			$file = 'D:\phpstudy_pro\WWW\dts\./include/modules/extra/instance/instance9_rush'.'/config/trapitem.config.php';
			$l = openfile($file);
			$___TMP_MOD_instance9_FUNC_get_trapfilecont_RET =  $l;
			break; 
		}else{
if(isset($file)) {$__VAR_DUMP_MOD_instance9_VARS_file = $file; unset($file); } else {$__VAR_DUMP_MOD_instance9_VARS_file = NULL;} if(isset($l)) {$__VAR_DUMP_MOD_instance9_VARS_l = $l; unset($l); } else {$__VAR_DUMP_MOD_instance9_VARS_l = NULL;} 
		//======== Start of contents from mod instance7 ========
		do{
			$___TMP_MOD_instance7_FUNC_get_trapfilecont_RET = NULL;

		 
		
		if (17 == $gametype){
			$file = 'D:\phpstudy_pro\WWW\dts\./include/modules/extra/instance/instance7_tutorial'.'/config/trapitem.config.php';
			$l = openfile($file);
			$___TMP_MOD_instance7_FUNC_get_trapfilecont_RET =  $l;
			break; 
		}else{
if(isset($file)) {$__VAR_DUMP_MOD_instance7_VARS_file = $file; unset($file); } else {$__VAR_DUMP_MOD_instance7_VARS_file = NULL;} if(isset($l)) {$__VAR_DUMP_MOD_instance7_VARS_l = $l; unset($l); } else {$__VAR_DUMP_MOD_instance7_VARS_l = NULL;} 
		//======== Start of contents from mod instance8 ========
		do{
			$___TMP_MOD_instance8_FUNC_get_trapfilecont_RET = NULL;

		 
		
		if (18 == $gametype){
			$file = 'D:\phpstudy_pro\WWW\dts\./include/modules/extra/instance/instance8_proud'.'/config/trapitem.config.php';
			$l = openfile($file);
			$___TMP_MOD_instance8_FUNC_get_trapfilecont_RET =  $l;
			break; 
		}else{
if(isset($file)) {$__VAR_DUMP_MOD_instance8_VARS_file = $file; unset($file); } else {$__VAR_DUMP_MOD_instance8_VARS_file = NULL;} if(isset($l)) {$__VAR_DUMP_MOD_instance8_VARS_l = $l; unset($l); } else {$__VAR_DUMP_MOD_instance8_VARS_l = NULL;} 
		//======== Start of contents from mod trap ========
		do{
			$___TMP_MOD_trap_FUNC_get_trapfilecont_RET = NULL;

		 
		
		$file = 'D:\phpstudy_pro\WWW\dts\./include/modules/base/items/trap'.'/config/trapitem.config.php';
		$l = openfile($file);
		$___TMP_MOD_trap_FUNC_get_trapfilecont_RET =  $l;
			break; 
		}while(0);
		//======== End of contents from mod trap ========

$file = $__VAR_DUMP_MOD_instance8_VARS_file; $l = $__VAR_DUMP_MOD_instance8_VARS_l;  $___TMP_MOD_instance8_FUNC_get_trapfilecont_RET =  $___TMP_MOD_trap_FUNC_get_trapfilecont_RET;
			break; }
		}while(0);
		//======== End of contents from mod instance8 ========

$file = $__VAR_DUMP_MOD_instance7_VARS_file; $l = $__VAR_DUMP_MOD_instance7_VARS_l;  $___TMP_MOD_instance7_FUNC_get_trapfilecont_RET =  $___TMP_MOD_instance8_FUNC_get_trapfilecont_RET;
			break; }
		}while(0);
		//======== End of contents from mod instance7 ========

$file = $__VAR_DUMP_MOD_instance9_VARS_file; $l = $__VAR_DUMP_MOD_instance9_VARS_l;  $___TMP_MOD_instance9_FUNC_get_trapfilecont_RET =  $___TMP_MOD_instance7_FUNC_get_trapfilecont_RET;
			break; }
		}while(0);
		//======== End of contents from mod instance9 ========

$file = $__VAR_DUMP_MOD_instance11_VARS_file; $l = $__VAR_DUMP_MOD_instance11_VARS_l;  $___TMP_MOD_instance11_FUNC_get_trapfilecont_RET =  $___TMP_MOD_instance9_FUNC_get_trapfilecont_RET;
			break; }
		}while(0);
		//======== End of contents from mod instance11 ========

$file = $__VAR_DUMP_MOD_instance10_VARS_file; $l = $__VAR_DUMP_MOD_instance10_VARS_l;  return $___TMP_MOD_instance11_FUNC_get_trapfilecont_RET;}
	
	}
	
	
	function checkcombo($time){
		
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;  global $___LOCAL_MAP__VARS__all_plsno_cache,$___LOCAL_MAP__VARS__areainterval,$___LOCAL_MAP__VARS__areaadd,$___LOCAL_MAP__VARS__areawarntime,$___LOCAL_MAP__VARS__arealimit,$___LOCAL_MAP__VARS__areaesc,$___LOCAL_MAP__VARS__area_on_start,$___LOCAL_MAP__VARS__dangerous_zone,$___LOCAL_MAP__VARS__plsinfo,$___LOCAL_MAP__VARS__plsinfo_o, $___LOCAL_MAP__VARS__plsinfo_disp,$___LOCAL_MAP__VARS__plsinfo_for_short,$___LOCAL_MAP__VARS__xyinfo,$___LOCAL_MAP__VARS__areainfo; $all_plsno_cache=&$___LOCAL_MAP__VARS__all_plsno_cache; $areainterval=&$___LOCAL_MAP__VARS__areainterval; $areaadd=&$___LOCAL_MAP__VARS__areaadd; $areawarntime=&$___LOCAL_MAP__VARS__areawarntime; $arealimit=&$___LOCAL_MAP__VARS__arealimit; $areaesc=&$___LOCAL_MAP__VARS__areaesc; $area_on_start=&$___LOCAL_MAP__VARS__area_on_start; $dangerous_zone=&$___LOCAL_MAP__VARS__dangerous_zone; $plsinfo=&$___LOCAL_MAP__VARS__plsinfo; $plsinfo_o=&$___LOCAL_MAP__VARS__plsinfo_o;  $plsinfo_disp=&$___LOCAL_MAP__VARS__plsinfo_disp; $plsinfo_for_short=&$___LOCAL_MAP__VARS__plsinfo_for_short; $xyinfo=&$___LOCAL_MAP__VARS__xyinfo; $areainfo=&$___LOCAL_MAP__VARS__areainfo;  global $___LOCAL_GAMEFLOW_COMBO__VARS__combolimit,$___LOCAL_GAMEFLOW_COMBO__VARS__deathlimit,$___LOCAL_GAMEFLOW_COMBO__VARS__deathlimit_by_gtype,$___LOCAL_GAMEFLOW_COMBO__VARS__deathdeno,$___LOCAL_GAMEFLOW_COMBO__VARS__deathnume; $combolimit=&$___LOCAL_GAMEFLOW_COMBO__VARS__combolimit; $deathlimit=&$___LOCAL_GAMEFLOW_COMBO__VARS__deathlimit; $deathlimit_by_gtype=&$___LOCAL_GAMEFLOW_COMBO__VARS__deathlimit_by_gtype; $deathdeno=&$___LOCAL_GAMEFLOW_COMBO__VARS__deathdeno; $deathnume=&$___LOCAL_GAMEFLOW_COMBO__VARS__deathnume;   } while (0);
		if(20 == $gametype) return;
if(isset($time)) {$__VAR_DUMP_MOD_instance10_VARS_time = $time; } else {$__VAR_DUMP_MOD_instance10_VARS_time = NULL;} 
		//======== Start of contents from mod instance5 ========
		do{
			$___TMP_MOD_instance5_FUNC_checkcombo_RET = NULL;

		
		
		if(15 == $gametype){
			if(\map\get_area_wavenum() < 4 && $alivenum>0){
				$___TMP_MOD_instance5_FUNC_checkcombo_RET = NULL;
			break; 
			}
		}
if(isset($time)) {$__VAR_DUMP_MOD_instance5_VARS_time = $time; } else {$__VAR_DUMP_MOD_instance5_VARS_time = NULL;} 
		//======== Start of contents from mod instance11 ========
		do{
			$___TMP_MOD_instance11_FUNC_checkcombo_RET = NULL;

		
		
		if(21 == $gametype){ $___TMP_MOD_instance11_FUNC_checkcombo_RET = NULL;
			break; }
if(isset($time)) {$__VAR_DUMP_MOD_instance11_VARS_time = $time; } else {$__VAR_DUMP_MOD_instance11_VARS_time = NULL;} 
		//======== Start of contents from mod instance3 ========
		do{
			$___TMP_MOD_instance3_FUNC_checkcombo_RET = NULL;

		
		
		
		if ($gametype==13 && \map\get_area_wavenum() <= 2 && $alivenum>0 ){
			$___TMP_MOD_instance3_FUNC_checkcombo_RET = NULL;
			break; 
		}
if(isset($time)) {$__VAR_DUMP_MOD_instance3_VARS_time = $time; } else {$__VAR_DUMP_MOD_instance3_VARS_time = NULL;} 
		//======== Start of contents from mod tutorial ========
		do{
			$___TMP_MOD_tutorial_FUNC_checkcombo_RET = NULL;

		
		do { global $___LOCAL_TUTORIAL__VARS__tutorial_tough_hp,$___LOCAL_TUTORIAL__VARS__tutorial_areahour_augment,$___LOCAL_TUTORIAL__VARS__tutorial_disable_area_timing,$___LOCAL_TUTORIAL__VARS__tutorial_disable_combo,$___LOCAL_TUTORIAL__VARS__tutorial_force_teamer,$___LOCAL_TUTORIAL__VARS__tutorial_allowed_weather,$___LOCAL_TUTORIAL__VARS__tutorial_story,$___LOCAL_TUTORIAL__VARS__tutorial_npc; $tutorial_tough_hp=&$___LOCAL_TUTORIAL__VARS__tutorial_tough_hp; $tutorial_areahour_augment=&$___LOCAL_TUTORIAL__VARS__tutorial_areahour_augment; $tutorial_disable_area_timing=&$___LOCAL_TUTORIAL__VARS__tutorial_disable_area_timing; $tutorial_disable_combo=&$___LOCAL_TUTORIAL__VARS__tutorial_disable_combo; $tutorial_force_teamer=&$___LOCAL_TUTORIAL__VARS__tutorial_force_teamer; $tutorial_allowed_weather=&$___LOCAL_TUTORIAL__VARS__tutorial_allowed_weather; $tutorial_story=&$___LOCAL_TUTORIAL__VARS__tutorial_story; $tutorial_npc=&$___LOCAL_TUTORIAL__VARS__tutorial_npc;   } while (0);
		if (!$tutorial_disable_combo || $gametype!=17){
if(isset($time)) {$__VAR_DUMP_MOD_tutorial_VARS_time = $time; } else {$__VAR_DUMP_MOD_tutorial_VARS_time = NULL;} 
		//======== Start of contents from mod gtype1 ========
		do{
			$___TMP_MOD_gtype1_FUNC_checkcombo_RET = NULL;

		
		
		if ( $gametype==1 && \map\get_area_wavenum()<2 && $alivenum>0 ){
			$___TMP_MOD_gtype1_FUNC_checkcombo_RET = NULL;
			break; 
		}
if(isset($time)) {$__VAR_DUMP_MOD_gtype1_VARS_time = $time; } else {$__VAR_DUMP_MOD_gtype1_VARS_time = NULL;} 
		//======== Start of contents from mod instance6 ========
		do{
			$___TMP_MOD_instance6_FUNC_checkcombo_RET = NULL;

		
		
		if ( $gametype==16 && \map\get_area_wavenum() < 2 && $alivenum>0 ){
			$___TMP_MOD_instance6_FUNC_checkcombo_RET = NULL;
			break; 
		}
if(isset($time)) {$__VAR_DUMP_MOD_instance6_VARS_time = $time; } else {$__VAR_DUMP_MOD_instance6_VARS_time = NULL;} 
		//======== Start of contents from mod instance0 ========
		do{
			$___TMP_MOD_instance0_FUNC_checkcombo_RET = NULL;

		
		
		if(10 == $gametype || 14 == $gametype){
			if(\map\get_area_wavenum() <= 2 && $alivenum > 1 && $deathnum < $combonum){
				$___TMP_MOD_instance0_FUNC_checkcombo_RET = NULL;
			break; 
			}
		}
if(isset($time)) {$__VAR_DUMP_MOD_instance0_VARS_time = $time; } else {$__VAR_DUMP_MOD_instance0_VARS_time = NULL;} 
		//======== Start of contents from mod gameflow_combo ========
		do{
			$___TMP_MOD_gameflow_combo_FUNC_checkcombo_RET = NULL;

		
		
		if(!$time) $time = $now;
		if($gamestate < 40 && $gamestate >= 30 && $alivenum <= $combolimit) {
			$gamestate = 40;
			addnews($time,'combo');
			systemputchat($time,'combo');
		}elseif($gamestate < 40 && $gamestate >= 20 && $combonum && $deathnum >= $combonum){
			$real_combonum = \gameflow_combo\calculate_combonum ();
			if($deathnum >= $real_combonum){
				$gamestate = 40;
				addnews($time,'combo');
				systemputchat($time,'combo');
			}else{
				$combonum = $real_combonum;
				addnews($time,'comboupdate',$combonum,$deathnum);
				systemputchat($time,'comboupdate',$combonum);
			}		
		}
		}while(0);
		//======== End of contents from mod gameflow_combo ========

$time = $__VAR_DUMP_MOD_instance0_VARS_time; unset($__VAR_DUMP_MOD_instance0_VARS_time);
		$___TMP_MOD_gameflow_combo_FUNC_checkcombo_RET;
		}while(0);
		//======== End of contents from mod instance0 ========

$time = $__VAR_DUMP_MOD_instance6_VARS_time; unset($__VAR_DUMP_MOD_instance6_VARS_time);
		$___TMP_MOD_instance0_FUNC_checkcombo_RET;
		}while(0);
		//======== End of contents from mod instance6 ========

$time = $__VAR_DUMP_MOD_gtype1_VARS_time; unset($__VAR_DUMP_MOD_gtype1_VARS_time);
		$___TMP_MOD_instance6_FUNC_checkcombo_RET;
		}while(0);
		//======== End of contents from mod gtype1 ========

$time = $__VAR_DUMP_MOD_tutorial_VARS_time; unset($__VAR_DUMP_MOD_tutorial_VARS_time); $___TMP_MOD_gtype1_FUNC_checkcombo_RET;}
		}while(0);
		//======== End of contents from mod tutorial ========

$time = $__VAR_DUMP_MOD_instance3_VARS_time; unset($__VAR_DUMP_MOD_instance3_VARS_time);
		$___TMP_MOD_tutorial_FUNC_checkcombo_RET;
		}while(0);
		//======== End of contents from mod instance3 ========

$time = $__VAR_DUMP_MOD_instance11_VARS_time; unset($__VAR_DUMP_MOD_instance11_VARS_time);
		$___TMP_MOD_instance3_FUNC_checkcombo_RET;
		}while(0);
		//======== End of contents from mod instance11 ========

$time = $__VAR_DUMP_MOD_instance5_VARS_time; unset($__VAR_DUMP_MOD_instance5_VARS_time);
		$___TMP_MOD_instance11_FUNC_checkcombo_RET;
		}while(0);
		//======== End of contents from mod instance5 ========

$time = $__VAR_DUMP_MOD_instance10_VARS_time; unset($__VAR_DUMP_MOD_instance10_VARS_time);
		$___TMP_MOD_instance5_FUNC_checkcombo_RET;
	
	}
	
	
	function rs_game($xmode = 0)
	{
if(isset($xmode)) {$__VAR_DUMP_MOD_instance10_VARS_xmode = $xmode; } else {$__VAR_DUMP_MOD_instance10_VARS_xmode = NULL;} 
		//======== Start of contents from mod instance5 ========
		do{
			$___TMP_MOD_instance5_FUNC_rs_game_RET = NULL;
if(isset($xmode)) {$__VAR_DUMP_MOD_instance5_VARS_xmode = $xmode; } else {$__VAR_DUMP_MOD_instance5_VARS_xmode = NULL;} 
		//======== Start of contents from mod instance11 ========
		do{
			$___TMP_MOD_instance11_FUNC_rs_game_RET = NULL;

		
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;  global $___LOCAL_MAP__VARS__all_plsno_cache,$___LOCAL_MAP__VARS__areainterval,$___LOCAL_MAP__VARS__areaadd,$___LOCAL_MAP__VARS__areawarntime,$___LOCAL_MAP__VARS__arealimit,$___LOCAL_MAP__VARS__areaesc,$___LOCAL_MAP__VARS__area_on_start,$___LOCAL_MAP__VARS__dangerous_zone,$___LOCAL_MAP__VARS__plsinfo,$___LOCAL_MAP__VARS__plsinfo_o, $___LOCAL_MAP__VARS__plsinfo_disp,$___LOCAL_MAP__VARS__plsinfo_for_short,$___LOCAL_MAP__VARS__xyinfo,$___LOCAL_MAP__VARS__areainfo; $all_plsno_cache=&$___LOCAL_MAP__VARS__all_plsno_cache; $areainterval=&$___LOCAL_MAP__VARS__areainterval; $areaadd=&$___LOCAL_MAP__VARS__areaadd; $areawarntime=&$___LOCAL_MAP__VARS__areawarntime; $arealimit=&$___LOCAL_MAP__VARS__arealimit; $areaesc=&$___LOCAL_MAP__VARS__areaesc; $area_on_start=&$___LOCAL_MAP__VARS__area_on_start; $dangerous_zone=&$___LOCAL_MAP__VARS__dangerous_zone; $plsinfo=&$___LOCAL_MAP__VARS__plsinfo; $plsinfo_o=&$___LOCAL_MAP__VARS__plsinfo_o;  $plsinfo_disp=&$___LOCAL_MAP__VARS__plsinfo_disp; $plsinfo_for_short=&$___LOCAL_MAP__VARS__plsinfo_for_short; $xyinfo=&$___LOCAL_MAP__VARS__xyinfo; $areainfo=&$___LOCAL_MAP__VARS__areainfo;  global $___LOCAL_INSTANCE11__VARS__plsinfo11,$___LOCAL_INSTANCE11__VARS__npcinfo_instance11,$___LOCAL_INSTANCE11__VARS__shops11,$___LOCAL_INSTANCE11__VARS__shop_tag_list11; $plsinfo11=&$___LOCAL_INSTANCE11__VARS__plsinfo11; $npcinfo_instance11=&$___LOCAL_INSTANCE11__VARS__npcinfo_instance11; $shops11=&$___LOCAL_INSTANCE11__VARS__shops11; $shop_tag_list11=&$___LOCAL_INSTANCE11__VARS__shop_tag_list11;   } while (0);
		if((21 == $gametype)&&($xmode & 2)) {
			$area_on_start = Array();
		}
if(isset($xmode)) {$__VAR_DUMP_MOD_instance11_VARS_xmode = $xmode; } else {$__VAR_DUMP_MOD_instance11_VARS_xmode = NULL;} 
		//======== Start of contents from mod instance3 ========
		do{
			$___TMP_MOD_instance3_FUNC_rs_game_RET = NULL;
if(isset($xmode)) {$__VAR_DUMP_MOD_instance3_VARS_xmode = $xmode; } else {$__VAR_DUMP_MOD_instance3_VARS_xmode = NULL;} 
		//======== Start of contents from mod tutorial ========
		do{
			$___TMP_MOD_tutorial_FUNC_rs_game_RET = NULL;

				
		do { global $___LOCAL_TUTORIAL__VARS__tutorial_tough_hp,$___LOCAL_TUTORIAL__VARS__tutorial_areahour_augment,$___LOCAL_TUTORIAL__VARS__tutorial_disable_area_timing,$___LOCAL_TUTORIAL__VARS__tutorial_disable_combo,$___LOCAL_TUTORIAL__VARS__tutorial_force_teamer,$___LOCAL_TUTORIAL__VARS__tutorial_allowed_weather,$___LOCAL_TUTORIAL__VARS__tutorial_story,$___LOCAL_TUTORIAL__VARS__tutorial_npc; $tutorial_tough_hp=&$___LOCAL_TUTORIAL__VARS__tutorial_tough_hp; $tutorial_areahour_augment=&$___LOCAL_TUTORIAL__VARS__tutorial_areahour_augment; $tutorial_disable_area_timing=&$___LOCAL_TUTORIAL__VARS__tutorial_disable_area_timing; $tutorial_disable_combo=&$___LOCAL_TUTORIAL__VARS__tutorial_disable_combo; $tutorial_force_teamer=&$___LOCAL_TUTORIAL__VARS__tutorial_force_teamer; $tutorial_allowed_weather=&$___LOCAL_TUTORIAL__VARS__tutorial_allowed_weather; $tutorial_story=&$___LOCAL_TUTORIAL__VARS__tutorial_story; $tutorial_npc=&$___LOCAL_TUTORIAL__VARS__tutorial_npc;   } while (0);
if(isset($xmode)) {$__VAR_DUMP_MOD_tutorial_VARS_xmode = $xmode; } else {$__VAR_DUMP_MOD_tutorial_VARS_xmode = NULL;} 
		//======== Start of contents from mod gtype1 ========
		do{
			$___TMP_MOD_gtype1_FUNC_rs_game_RET = NULL;
if(isset($xmode)) {$__VAR_DUMP_MOD_gtype1_VARS_xmode = $xmode; } else {$__VAR_DUMP_MOD_gtype1_VARS_xmode = NULL;} 
		//======== Start of contents from mod instance6 ========
		do{
			$___TMP_MOD_instance6_FUNC_rs_game_RET = NULL;
if(isset($xmode)) {$__VAR_DUMP_MOD_instance6_VARS_xmode = $xmode; } else {$__VAR_DUMP_MOD_instance6_VARS_xmode = NULL;} 
		//======== Start of contents from mod weather ========
		do{
			$___TMP_MOD_weather_FUNC_rs_game_RET = NULL;
if(isset($xmode)) {$__VAR_DUMP_MOD_weather_VARS_xmode = $xmode; } else {$__VAR_DUMP_MOD_weather_VARS_xmode = NULL;} 
		//======== Start of contents from mod trap ========
		do{
			$___TMP_MOD_trap_FUNC_rs_game_RET = NULL;
if(isset($xmode)) {$__VAR_DUMP_MOD_trap_VARS_xmode = $xmode; } else {$__VAR_DUMP_MOD_trap_VARS_xmode = NULL;} 
		//======== Start of contents from mod itemshop ========
		do{
			$___TMP_MOD_itemshop_FUNC_rs_game_RET = NULL;
if(isset($xmode)) {$__VAR_DUMP_MOD_itemshop_VARS_xmode = $xmode; } else {$__VAR_DUMP_MOD_itemshop_VARS_xmode = NULL;} 
		//======== Start of contents from mod itemmain ========
		do{
			$___TMP_MOD_itemmain_FUNC_rs_game_RET = NULL;
if(isset($xmode)) {$__VAR_DUMP_MOD_itemmain_VARS_xmode = $xmode; } else {$__VAR_DUMP_MOD_itemmain_VARS_xmode = NULL;} 
		//======== Start of contents from mod npc ========
		do{
			$___TMP_MOD_npc_FUNC_rs_game_RET = NULL;
if(isset($xmode)) {$__VAR_DUMP_MOD_npc_VARS_xmode = $xmode; } else {$__VAR_DUMP_MOD_npc_VARS_xmode = NULL;} 
		//======== Start of contents from mod player ========
		do{
			$___TMP_MOD_player_FUNC_rs_game_RET = NULL;
if(isset($xmode)) {$__VAR_DUMP_MOD_player_VARS_xmode = $xmode; } else {$__VAR_DUMP_MOD_player_VARS_xmode = NULL;} 
		//======== Start of contents from mod map ========
		do{
			$___TMP_MOD_map_FUNC_rs_game_RET = NULL;
if(isset($xmode)) {$__VAR_DUMP_MOD_map_VARS_xmode = $xmode; } else {$__VAR_DUMP_MOD_map_VARS_xmode = NULL;} 
		//======== Start of contents from mod sys ========
		do{
			$___TMP_MOD_sys_FUNC_rs_game_RET = NULL;

		 
		}while(0);
		//======== End of contents from mod sys ========

$xmode = $__VAR_DUMP_MOD_map_VARS_xmode; unset($__VAR_DUMP_MOD_map_VARS_xmode);

		
		
		$___TMP_MOD_sys_FUNC_rs_game_RET;
		
		
		if ($xmode & 2) {
			
			list($sec,$min,$hour,$day,$month,$year,$wday,$yday,$isdst) = localtime($starttime);
			$areatime = \map\rs_areatime ();
			
			$areanum = sizeof($area_on_start);
			$all_plsno = \map\get_all_plsno (1);
			$arealist = array_diff($all_plsno, $area_on_start);
			shuffle($arealist);
			$arealist = array_merge($area_on_start, $arealist);
			$hack = 0;
			$areawarn = 0;
		}
		}while(0);
		//======== End of contents from mod map ========

$xmode = $__VAR_DUMP_MOD_player_VARS_xmode; unset($__VAR_DUMP_MOD_player_VARS_xmode);

		
		
		$___TMP_MOD_map_FUNC_rs_game_RET;
		
		
		$sqldir = GAME_ROOT.'./gamedata/sql/';
		
		if ($xmode & 4) {
			
			$sql = file_get_contents("{$sqldir}players.sql");
			$sql = str_replace("\r", "\n", str_replace(' bra_', ' '.$tablepre, $sql));
			$db->queries($sql);
			
			$validnum = $alivenum = $deathnum = 0;
		}
		
		
		}while(0);
		//======== End of contents from mod player ========

$xmode = $__VAR_DUMP_MOD_npc_VARS_xmode; unset($__VAR_DUMP_MOD_npc_VARS_xmode);

		 
		
		$___TMP_MOD_player_FUNC_rs_game_RET;
		
		do { global $___LOCAL_PLAYER__VARS__ss,$___LOCAL_PLAYER__VARS__db_player_structure,$___LOCAL_PLAYER__VARS__db_player_structure_types,$___LOCAL_PLAYER__VARS__gamedata,$___LOCAL_PLAYER__VARS__cmd,$___LOCAL_PLAYER__VARS__main,$___LOCAL_PLAYER__VARS__sdata,$___LOCAL_PLAYER__VARS__fog,$___LOCAL_PLAYER__VARS__upexp,$___LOCAL_PLAYER__VARS__lvlupexp, $___LOCAL_PLAYER__VARS__iconImg,$___LOCAL_PLAYER__VARS__iconImgB,$___LOCAL_PLAYER__VARS__iconImgBwidth,$___LOCAL_PLAYER__VARS__ardef,$___LOCAL_PLAYER__VARS__hpcolor,$___LOCAL_PLAYER__VARS__spcolor,$___LOCAL_PLAYER__VARS__newhpimg,$___LOCAL_PLAYER__VARS__newspimg,$___LOCAL_PLAYER__VARS__splt,$___LOCAL_PLAYER__VARS__hplt, $___LOCAL_PLAYER__VARS__tpldata,$___LOCAL_PLAYER__VARS__icon_list,$___LOCAL_PLAYER__VARS__icon_list_contents_to_frontend,$___LOCAL_PLAYER__VARS__typeinfo,$___LOCAL_PLAYER__VARS__killmsginfo,$___LOCAL_PLAYER__VARS__lwinfo,$___LOCAL_PLAYER__VARS__sexinfo,$___LOCAL_PLAYER__VARS__equip_list,$___LOCAL_PLAYER__VARS__battle_equip_list,$___LOCAL_PLAYER__VARS__pc_icon_range, $___LOCAL_PLAYER__VARS__pid,$___LOCAL_PLAYER__VARS__type,$___LOCAL_PLAYER__VARS__name,$___LOCAL_PLAYER__VARS__pass,$___LOCAL_PLAYER__VARS__ip,$___LOCAL_PLAYER__VARS__motto,$___LOCAL_PLAYER__VARS__killmsg,$___LOCAL_PLAYER__VARS__lastword,$___LOCAL_PLAYER__VARS__winner_flag,$___LOCAL_PLAYER__VARS__player_dead_flag, $___LOCAL_PLAYER__VARS__corpse_clear_flag,$___LOCAL_PLAYER__VARS__gd,$___LOCAL_PLAYER__VARS__sNo,$___LOCAL_PLAYER__VARS__club,$___LOCAL_PLAYER__VARS__validtime,$___LOCAL_PLAYER__VARS__endtime,$___LOCAL_PLAYER__VARS__cdsec,$___LOCAL_PLAYER__VARS__cdmsec,$___LOCAL_PLAYER__VARS__cdtime,$___LOCAL_PLAYER__VARS__action, $___LOCAL_PLAYER__VARS__a_actionnum,$___LOCAL_PLAYER__VARS__v_actionnum,$___LOCAL_PLAYER__VARS__hp,$___LOCAL_PLAYER__VARS__mhp,$___LOCAL_PLAYER__VARS__sp,$___LOCAL_PLAYER__VARS__msp,$___LOCAL_PLAYER__VARS__mss,$___LOCAL_PLAYER__VARS__att,$___LOCAL_PLAYER__VARS__def,$___LOCAL_PLAYER__VARS__pls, $___LOCAL_PLAYER__VARS__lvl,$___LOCAL_PLAYER__VARS__exp,$___LOCAL_PLAYER__VARS__money,$___LOCAL_PLAYER__VARS__rp,$___LOCAL_PLAYER__VARS__bid,$___LOCAL_PLAYER__VARS__inf,$___LOCAL_PLAYER__VARS__rage,$___LOCAL_PLAYER__VARS__pose,$___LOCAL_PLAYER__VARS__tactic,$___LOCAL_PLAYER__VARS__killnum, $___LOCAL_PLAYER__VARS__npckillnum,$___LOCAL_PLAYER__VARS__state,$___LOCAL_PLAYER__VARS__skillpoint,$___LOCAL_PLAYER__VARS__flare,$___LOCAL_PLAYER__VARS__wp,$___LOCAL_PLAYER__VARS__wk,$___LOCAL_PLAYER__VARS__wg,$___LOCAL_PLAYER__VARS__wc,$___LOCAL_PLAYER__VARS__wd,$___LOCAL_PLAYER__VARS__wf, $___LOCAL_PLAYER__VARS__icon,$___LOCAL_PLAYER__VARS__teamID,$___LOCAL_PLAYER__VARS__teamPass,$___LOCAL_PLAYER__VARS__card,$___LOCAL_PLAYER__VARS__cardname,$___LOCAL_PLAYER__VARS__wep,$___LOCAL_PLAYER__VARS__wepk,$___LOCAL_PLAYER__VARS__wepe,$___LOCAL_PLAYER__VARS__weps,$___LOCAL_PLAYER__VARS__wepsk, $___LOCAL_PLAYER__VARS__arb,$___LOCAL_PLAYER__VARS__arbk,$___LOCAL_PLAYER__VARS__arbe,$___LOCAL_PLAYER__VARS__arbs,$___LOCAL_PLAYER__VARS__arbsk,$___LOCAL_PLAYER__VARS__arh,$___LOCAL_PLAYER__VARS__arhk,$___LOCAL_PLAYER__VARS__arhe,$___LOCAL_PLAYER__VARS__arhs,$___LOCAL_PLAYER__VARS__arhsk, $___LOCAL_PLAYER__VARS__ara,$___LOCAL_PLAYER__VARS__arak,$___LOCAL_PLAYER__VARS__arae,$___LOCAL_PLAYER__VARS__aras,$___LOCAL_PLAYER__VARS__arask,$___LOCAL_PLAYER__VARS__arf,$___LOCAL_PLAYER__VARS__arfk,$___LOCAL_PLAYER__VARS__arfe,$___LOCAL_PLAYER__VARS__arfs,$___LOCAL_PLAYER__VARS__arfsk, $___LOCAL_PLAYER__VARS__art,$___LOCAL_PLAYER__VARS__artk,$___LOCAL_PLAYER__VARS__arte,$___LOCAL_PLAYER__VARS__arts,$___LOCAL_PLAYER__VARS__artsk,$___LOCAL_PLAYER__VARS__itm0,$___LOCAL_PLAYER__VARS__itmk0,$___LOCAL_PLAYER__VARS__itme0,$___LOCAL_PLAYER__VARS__itms0,$___LOCAL_PLAYER__VARS__itmsk0, $___LOCAL_PLAYER__VARS__itm1,$___LOCAL_PLAYER__VARS__itmk1,$___LOCAL_PLAYER__VARS__itme1,$___LOCAL_PLAYER__VARS__itms1,$___LOCAL_PLAYER__VARS__itmsk1,$___LOCAL_PLAYER__VARS__itm2,$___LOCAL_PLAYER__VARS__itmk2,$___LOCAL_PLAYER__VARS__itme2,$___LOCAL_PLAYER__VARS__itms2,$___LOCAL_PLAYER__VARS__itmsk2, $___LOCAL_PLAYER__VARS__itm3,$___LOCAL_PLAYER__VARS__itmk3,$___LOCAL_PLAYER__VARS__itme3,$___LOCAL_PLAYER__VARS__itms3,$___LOCAL_PLAYER__VARS__itmsk3,$___LOCAL_PLAYER__VARS__itm4,$___LOCAL_PLAYER__VARS__itmk4,$___LOCAL_PLAYER__VARS__itme4,$___LOCAL_PLAYER__VARS__itms4,$___LOCAL_PLAYER__VARS__itmsk4, $___LOCAL_PLAYER__VARS__itm5,$___LOCAL_PLAYER__VARS__itmk5,$___LOCAL_PLAYER__VARS__itme5,$___LOCAL_PLAYER__VARS__itms5,$___LOCAL_PLAYER__VARS__itmsk5,$___LOCAL_PLAYER__VARS__itm6,$___LOCAL_PLAYER__VARS__itmk6,$___LOCAL_PLAYER__VARS__itme6,$___LOCAL_PLAYER__VARS__itms6,$___LOCAL_PLAYER__VARS__itmsk6, $___LOCAL_PLAYER__VARS__searchmemory,$___LOCAL_PLAYER__VARS__nskill,$___LOCAL_PLAYER__VARS__nskillpara; $ss=&$___LOCAL_PLAYER__VARS__ss; $db_player_structure=&$___LOCAL_PLAYER__VARS__db_player_structure; $db_player_structure_types=&$___LOCAL_PLAYER__VARS__db_player_structure_types; $gamedata=&$___LOCAL_PLAYER__VARS__gamedata; $cmd=&$___LOCAL_PLAYER__VARS__cmd; $main=&$___LOCAL_PLAYER__VARS__main; $sdata=&$___LOCAL_PLAYER__VARS__sdata; $fog=&$___LOCAL_PLAYER__VARS__fog; $upexp=&$___LOCAL_PLAYER__VARS__upexp; $lvlupexp=&$___LOCAL_PLAYER__VARS__lvlupexp;  $iconImg=&$___LOCAL_PLAYER__VARS__iconImg; $iconImgB=&$___LOCAL_PLAYER__VARS__iconImgB; $iconImgBwidth=&$___LOCAL_PLAYER__VARS__iconImgBwidth; $ardef=&$___LOCAL_PLAYER__VARS__ardef; $hpcolor=&$___LOCAL_PLAYER__VARS__hpcolor; $spcolor=&$___LOCAL_PLAYER__VARS__spcolor; $newhpimg=&$___LOCAL_PLAYER__VARS__newhpimg; $newspimg=&$___LOCAL_PLAYER__VARS__newspimg; $splt=&$___LOCAL_PLAYER__VARS__splt; $hplt=&$___LOCAL_PLAYER__VARS__hplt;  $tpldata=&$___LOCAL_PLAYER__VARS__tpldata; $icon_list=&$___LOCAL_PLAYER__VARS__icon_list; $icon_list_contents_to_frontend=&$___LOCAL_PLAYER__VARS__icon_list_contents_to_frontend; $typeinfo=&$___LOCAL_PLAYER__VARS__typeinfo; $killmsginfo=&$___LOCAL_PLAYER__VARS__killmsginfo; $lwinfo=&$___LOCAL_PLAYER__VARS__lwinfo; $sexinfo=&$___LOCAL_PLAYER__VARS__sexinfo; $equip_list=&$___LOCAL_PLAYER__VARS__equip_list; $battle_equip_list=&$___LOCAL_PLAYER__VARS__battle_equip_list; $pc_icon_range=&$___LOCAL_PLAYER__VARS__pc_icon_range;  $pid=&$___LOCAL_PLAYER__VARS__pid; $type=&$___LOCAL_PLAYER__VARS__type; $name=&$___LOCAL_PLAYER__VARS__name; $pass=&$___LOCAL_PLAYER__VARS__pass; $ip=&$___LOCAL_PLAYER__VARS__ip; $motto=&$___LOCAL_PLAYER__VARS__motto; $killmsg=&$___LOCAL_PLAYER__VARS__killmsg; $lastword=&$___LOCAL_PLAYER__VARS__lastword; $winner_flag=&$___LOCAL_PLAYER__VARS__winner_flag; $player_dead_flag=&$___LOCAL_PLAYER__VARS__player_dead_flag;  $corpse_clear_flag=&$___LOCAL_PLAYER__VARS__corpse_clear_flag; $gd=&$___LOCAL_PLAYER__VARS__gd; $sNo=&$___LOCAL_PLAYER__VARS__sNo; $club=&$___LOCAL_PLAYER__VARS__club; $validtime=&$___LOCAL_PLAYER__VARS__validtime; $endtime=&$___LOCAL_PLAYER__VARS__endtime; $cdsec=&$___LOCAL_PLAYER__VARS__cdsec; $cdmsec=&$___LOCAL_PLAYER__VARS__cdmsec; $cdtime=&$___LOCAL_PLAYER__VARS__cdtime; $action=&$___LOCAL_PLAYER__VARS__action;  $a_actionnum=&$___LOCAL_PLAYER__VARS__a_actionnum; $v_actionnum=&$___LOCAL_PLAYER__VARS__v_actionnum; $hp=&$___LOCAL_PLAYER__VARS__hp; $mhp=&$___LOCAL_PLAYER__VARS__mhp; $sp=&$___LOCAL_PLAYER__VARS__sp; $msp=&$___LOCAL_PLAYER__VARS__msp; $mss=&$___LOCAL_PLAYER__VARS__mss; $att=&$___LOCAL_PLAYER__VARS__att; $def=&$___LOCAL_PLAYER__VARS__def; $pls=&$___LOCAL_PLAYER__VARS__pls;  $lvl=&$___LOCAL_PLAYER__VARS__lvl; $exp=&$___LOCAL_PLAYER__VARS__exp; $money=&$___LOCAL_PLAYER__VARS__money; $rp=&$___LOCAL_PLAYER__VARS__rp; $bid=&$___LOCAL_PLAYER__VARS__bid; $inf=&$___LOCAL_PLAYER__VARS__inf; $rage=&$___LOCAL_PLAYER__VARS__rage; $pose=&$___LOCAL_PLAYER__VARS__pose; $tactic=&$___LOCAL_PLAYER__VARS__tactic; $killnum=&$___LOCAL_PLAYER__VARS__killnum;  $npckillnum=&$___LOCAL_PLAYER__VARS__npckillnum; $state=&$___LOCAL_PLAYER__VARS__state; $skillpoint=&$___LOCAL_PLAYER__VARS__skillpoint; $flare=&$___LOCAL_PLAYER__VARS__flare; $wp=&$___LOCAL_PLAYER__VARS__wp; $wk=&$___LOCAL_PLAYER__VARS__wk; $wg=&$___LOCAL_PLAYER__VARS__wg; $wc=&$___LOCAL_PLAYER__VARS__wc; $wd=&$___LOCAL_PLAYER__VARS__wd; $wf=&$___LOCAL_PLAYER__VARS__wf;  $icon=&$___LOCAL_PLAYER__VARS__icon; $teamID=&$___LOCAL_PLAYER__VARS__teamID; $teamPass=&$___LOCAL_PLAYER__VARS__teamPass; $card=&$___LOCAL_PLAYER__VARS__card; $cardname=&$___LOCAL_PLAYER__VARS__cardname; $wep=&$___LOCAL_PLAYER__VARS__wep; $wepk=&$___LOCAL_PLAYER__VARS__wepk; $wepe=&$___LOCAL_PLAYER__VARS__wepe; $weps=&$___LOCAL_PLAYER__VARS__weps; $wepsk=&$___LOCAL_PLAYER__VARS__wepsk;  $arb=&$___LOCAL_PLAYER__VARS__arb; $arbk=&$___LOCAL_PLAYER__VARS__arbk; $arbe=&$___LOCAL_PLAYER__VARS__arbe; $arbs=&$___LOCAL_PLAYER__VARS__arbs; $arbsk=&$___LOCAL_PLAYER__VARS__arbsk; $arh=&$___LOCAL_PLAYER__VARS__arh; $arhk=&$___LOCAL_PLAYER__VARS__arhk; $arhe=&$___LOCAL_PLAYER__VARS__arhe; $arhs=&$___LOCAL_PLAYER__VARS__arhs; $arhsk=&$___LOCAL_PLAYER__VARS__arhsk;  $ara=&$___LOCAL_PLAYER__VARS__ara; $arak=&$___LOCAL_PLAYER__VARS__arak; $arae=&$___LOCAL_PLAYER__VARS__arae; $aras=&$___LOCAL_PLAYER__VARS__aras; $arask=&$___LOCAL_PLAYER__VARS__arask; $arf=&$___LOCAL_PLAYER__VARS__arf; $arfk=&$___LOCAL_PLAYER__VARS__arfk; $arfe=&$___LOCAL_PLAYER__VARS__arfe; $arfs=&$___LOCAL_PLAYER__VARS__arfs; $arfsk=&$___LOCAL_PLAYER__VARS__arfsk;  $art=&$___LOCAL_PLAYER__VARS__art; $artk=&$___LOCAL_PLAYER__VARS__artk; $arte=&$___LOCAL_PLAYER__VARS__arte; $arts=&$___LOCAL_PLAYER__VARS__arts; $artsk=&$___LOCAL_PLAYER__VARS__artsk; $itm0=&$___LOCAL_PLAYER__VARS__itm0; $itmk0=&$___LOCAL_PLAYER__VARS__itmk0; $itme0=&$___LOCAL_PLAYER__VARS__itme0; $itms0=&$___LOCAL_PLAYER__VARS__itms0; $itmsk0=&$___LOCAL_PLAYER__VARS__itmsk0;  $itm1=&$___LOCAL_PLAYER__VARS__itm1; $itmk1=&$___LOCAL_PLAYER__VARS__itmk1; $itme1=&$___LOCAL_PLAYER__VARS__itme1; $itms1=&$___LOCAL_PLAYER__VARS__itms1; $itmsk1=&$___LOCAL_PLAYER__VARS__itmsk1; $itm2=&$___LOCAL_PLAYER__VARS__itm2; $itmk2=&$___LOCAL_PLAYER__VARS__itmk2; $itme2=&$___LOCAL_PLAYER__VARS__itme2; $itms2=&$___LOCAL_PLAYER__VARS__itms2; $itmsk2=&$___LOCAL_PLAYER__VARS__itmsk2;  $itm3=&$___LOCAL_PLAYER__VARS__itm3; $itmk3=&$___LOCAL_PLAYER__VARS__itmk3; $itme3=&$___LOCAL_PLAYER__VARS__itme3; $itms3=&$___LOCAL_PLAYER__VARS__itms3; $itmsk3=&$___LOCAL_PLAYER__VARS__itmsk3; $itm4=&$___LOCAL_PLAYER__VARS__itm4; $itmk4=&$___LOCAL_PLAYER__VARS__itmk4; $itme4=&$___LOCAL_PLAYER__VARS__itme4; $itms4=&$___LOCAL_PLAYER__VARS__itms4; $itmsk4=&$___LOCAL_PLAYER__VARS__itmsk4;  $itm5=&$___LOCAL_PLAYER__VARS__itm5; $itmk5=&$___LOCAL_PLAYER__VARS__itmk5; $itme5=&$___LOCAL_PLAYER__VARS__itme5; $itms5=&$___LOCAL_PLAYER__VARS__itms5; $itmsk5=&$___LOCAL_PLAYER__VARS__itmsk5; $itm6=&$___LOCAL_PLAYER__VARS__itm6; $itmk6=&$___LOCAL_PLAYER__VARS__itmk6; $itme6=&$___LOCAL_PLAYER__VARS__itme6; $itms6=&$___LOCAL_PLAYER__VARS__itms6; $itmsk6=&$___LOCAL_PLAYER__VARS__itmsk6;  $searchmemory=&$___LOCAL_PLAYER__VARS__searchmemory; $nskill=&$___LOCAL_PLAYER__VARS__nskill; $nskillpara=&$___LOCAL_PLAYER__VARS__nskillpara;  global $___LOCAL_NPC__VARS__npcinit,$___LOCAL_NPC__VARS__npcinfo,$___LOCAL_NPC__VARS__killzone_resistant_typelist,$___LOCAL_NPC__VARS__npc_typeinfo,$___LOCAL_NPC__VARS__npc_killmsginfo,$___LOCAL_NPC__VARS__npc_lwinfo,$___LOCAL_NPC__VARS__npc_revive_info; $npcinit=&$___LOCAL_NPC__VARS__npcinit; $npcinfo=&$___LOCAL_NPC__VARS__npcinfo; $killzone_resistant_typelist=&$___LOCAL_NPC__VARS__killzone_resistant_typelist; $npc_typeinfo=&$___LOCAL_NPC__VARS__npc_typeinfo; $npc_killmsginfo=&$___LOCAL_NPC__VARS__npc_killmsginfo; $npc_lwinfo=&$___LOCAL_NPC__VARS__npc_lwinfo; $npc_revive_info=&$___LOCAL_NPC__VARS__npc_revive_info;  global $___LOCAL_LVLCTL__VARS__lvuphp,$___LOCAL_LVLCTL__VARS__lvupatt,$___LOCAL_LVLCTL__VARS__lvupdef,$___LOCAL_LVLCTL__VARS__lvupskill,$___LOCAL_LVLCTL__VARS__lvupsp,$___LOCAL_LVLCTL__VARS__lvupspref,$___LOCAL_LVLCTL__VARS__lvupskpt,$___LOCAL_LVLCTL__VARS__sklog,$___LOCAL_LVLCTL__VARS__baseexp; $lvuphp=&$___LOCAL_LVLCTL__VARS__lvuphp; $lvupatt=&$___LOCAL_LVLCTL__VARS__lvupatt; $lvupdef=&$___LOCAL_LVLCTL__VARS__lvupdef; $lvupskill=&$___LOCAL_LVLCTL__VARS__lvupskill; $lvupsp=&$___LOCAL_LVLCTL__VARS__lvupsp; $lvupspref=&$___LOCAL_LVLCTL__VARS__lvupspref; $lvupskpt=&$___LOCAL_LVLCTL__VARS__lvupskpt; $sklog=&$___LOCAL_LVLCTL__VARS__sklog; $baseexp=&$___LOCAL_LVLCTL__VARS__baseexp;  global $___LOCAL_SKILLBASE__VARS__acquired_list,$___LOCAL_SKILLBASE__VARS__parameter_list,$___LOCAL_SKILLBASE__VARS__ppid,$___LOCAL_SKILLBASE__VARS__valid_skills; $acquired_list=&$___LOCAL_SKILLBASE__VARS__acquired_list; $parameter_list=&$___LOCAL_SKILLBASE__VARS__parameter_list; $ppid=&$___LOCAL_SKILLBASE__VARS__ppid; $valid_skills=&$___LOCAL_SKILLBASE__VARS__valid_skills;   } while (0);
		if ($xmode & 8) {
			
			$db->query("DELETE FROM {$tablepre}players WHERE type>0 ");
			$npcqry = '';
			$ninfo = \npc\get_npclist ();
			
			$pls_available = \map\get_safe_plslist();
			
			$pls_available2 = \map\get_safe_plslist(1, 1);
			
			foreach ($ninfo as $i => $npcs){
				
				$tmp_sub = Array();
				if(!empty($npcs)) {
					
					if (!\npc\check_initnpcadd ($i)) continue;
					
					if(!empty($npcs['sub'])){
						$tmp_sub = $npcs['sub'];
						unset($npcs['sub']);
					}
					
					$subnum = sizeof($tmp_sub);
					$jarr = $jarr0 = array_keys($tmp_sub);
					
					if (!$subnum || !$npcs['num']) $jarr=array();
					
					elseif ($subnum > $npcs['num']) {
						$jarr = array_randompick($jarr, $npcs['num']);
					
					}elseif ($subnum < $npcs['num']) {
						while(sizeof($jarr) < $npcs['num']) {
							$jarr = array_merge($jarr,$jarr0);
						}
					}
					sort($jarr);
					
					foreach($jarr as $j){
						
						$npc = array_merge($npcinit,$npcs);
						
						if(!empty($tmp_sub) && is_array($tmp_sub)) $npc = array_merge($npc,$tmp_sub[$j]);
						
						$npc['type'] = $i;
						$npc['sNo'] = $j;
						
						$tmp_pls_available = 14 == $i ? $pls_available2 : $pls_available;
						
						$npc = \npc\init_npcdata ($npc, $tmp_pls_available);
						

						
						$npc=\player\player_format_with_db_structure($npc);
						$db->array_insert("{$tablepre}players", $npc);
						
						
						unset($npc);
					}
				}
			}
		}
		}while(0);
		//======== End of contents from mod npc ========

$xmode = $__VAR_DUMP_MOD_itemmain_VARS_xmode; unset($__VAR_DUMP_MOD_itemmain_VARS_xmode);

		
		
		$___TMP_MOD_npc_FUNC_rs_game_RET;
		
		do { global $___LOCAL_ITEMMAIN__VARS__tmp_itmsk_arr_pool,$___LOCAL_ITEMMAIN__VARS__itemfind_extra_log,$___LOCAL_ITEMMAIN__VARS__item_equip_list,$___LOCAL_ITEMMAIN__VARS__item_hotkey_id_list,$___LOCAL_ITEMMAIN__VARS__itemmain_drophint,$___LOCAL_ITEMMAIN__VARS__item_allow_find_and_use,$___LOCAL_ITEMMAIN__VARS__nosta,$___LOCAL_ITEMMAIN__VARS__nospk,$___LOCAL_ITEMMAIN__VARS__item_obbs,$___LOCAL_ITEMMAIN__VARS__map_noitemdrop_arealist, $___LOCAL_ITEMMAIN__VARS__itemkind_equipable,$___LOCAL_ITEMMAIN__VARS__iteminfo,$___LOCAL_ITEMMAIN__VARS__itemspkinfo,$___LOCAL_ITEMMAIN__VARS__itemspkdesc,$___LOCAL_ITEMMAIN__VARS__itemspkdesc_help,$___LOCAL_ITEMMAIN__VARS__itemspkremark; $tmp_itmsk_arr_pool=&$___LOCAL_ITEMMAIN__VARS__tmp_itmsk_arr_pool; $itemfind_extra_log=&$___LOCAL_ITEMMAIN__VARS__itemfind_extra_log; $item_equip_list=&$___LOCAL_ITEMMAIN__VARS__item_equip_list; $item_hotkey_id_list=&$___LOCAL_ITEMMAIN__VARS__item_hotkey_id_list; $itemmain_drophint=&$___LOCAL_ITEMMAIN__VARS__itemmain_drophint; $item_allow_find_and_use=&$___LOCAL_ITEMMAIN__VARS__item_allow_find_and_use; $nosta=&$___LOCAL_ITEMMAIN__VARS__nosta; $nospk=&$___LOCAL_ITEMMAIN__VARS__nospk; $item_obbs=&$___LOCAL_ITEMMAIN__VARS__item_obbs; $map_noitemdrop_arealist=&$___LOCAL_ITEMMAIN__VARS__map_noitemdrop_arealist;  $itemkind_equipable=&$___LOCAL_ITEMMAIN__VARS__itemkind_equipable; $iteminfo=&$___LOCAL_ITEMMAIN__VARS__iteminfo; $itemspkinfo=&$___LOCAL_ITEMMAIN__VARS__itemspkinfo; $itemspkdesc=&$___LOCAL_ITEMMAIN__VARS__itemspkdesc; $itemspkdesc_help=&$___LOCAL_ITEMMAIN__VARS__itemspkdesc_help; $itemspkremark=&$___LOCAL_ITEMMAIN__VARS__itemspkremark;   } while (0);
		if ($xmode & 16) {	
			\itemmain\lay_mapitem ();
		}
		}while(0);
		//======== End of contents from mod itemmain ========

$xmode = $__VAR_DUMP_MOD_itemshop_VARS_xmode; unset($__VAR_DUMP_MOD_itemshop_VARS_xmode);

		 
		
		$___TMP_MOD_itemmain_FUNC_rs_game_RET;
		
		$sqldir = GAME_ROOT.'./gamedata/sql/';
		
		
		if ($xmode & 32) {
			
			$sql = file_get_contents("{$sqldir}shopitem.sql");
			$sql = str_replace("\r", "\n", str_replace(' bra_', ' '.$tablepre, $sql));
			$db->queries($sql);
			
			$shopitem_list = \itemshop\get_shopitem_list (\itemshop\get_shopconfig ());
			
			$qry = '';
			foreach($shopitem_list as $lst){
				list($kind,$num,$price,$area,$item,$itmk,$itme,$itms,$itmsk)=$lst;
				$qry .= "('$kind','$num','$price','$area','$item','$itmk','$itme','$itms','$itmsk'),";	
			}
			if(!empty($qry)){
				$qry = "INSERT INTO {$tablepre}shopitem (kind,num,price,area,item,itmk,itme,itms,itmsk) VALUES ".substr($qry, 0, -1);
			}
			$db->query($qry);
		}
		}while(0);
		//======== End of contents from mod itemshop ========

$xmode = $__VAR_DUMP_MOD_trap_VARS_xmode; unset($__VAR_DUMP_MOD_trap_VARS_xmode);

		
		
		$___TMP_MOD_itemshop_FUNC_rs_game_RET;
		
		do { global $___LOCAL_ITEMMAIN__VARS__tmp_itmsk_arr_pool,$___LOCAL_ITEMMAIN__VARS__itemfind_extra_log,$___LOCAL_ITEMMAIN__VARS__item_equip_list,$___LOCAL_ITEMMAIN__VARS__item_hotkey_id_list,$___LOCAL_ITEMMAIN__VARS__itemmain_drophint,$___LOCAL_ITEMMAIN__VARS__item_allow_find_and_use,$___LOCAL_ITEMMAIN__VARS__nosta,$___LOCAL_ITEMMAIN__VARS__nospk,$___LOCAL_ITEMMAIN__VARS__item_obbs,$___LOCAL_ITEMMAIN__VARS__map_noitemdrop_arealist, $___LOCAL_ITEMMAIN__VARS__itemkind_equipable,$___LOCAL_ITEMMAIN__VARS__iteminfo,$___LOCAL_ITEMMAIN__VARS__itemspkinfo,$___LOCAL_ITEMMAIN__VARS__itemspkdesc,$___LOCAL_ITEMMAIN__VARS__itemspkdesc_help,$___LOCAL_ITEMMAIN__VARS__itemspkremark; $tmp_itmsk_arr_pool=&$___LOCAL_ITEMMAIN__VARS__tmp_itmsk_arr_pool; $itemfind_extra_log=&$___LOCAL_ITEMMAIN__VARS__itemfind_extra_log; $item_equip_list=&$___LOCAL_ITEMMAIN__VARS__item_equip_list; $item_hotkey_id_list=&$___LOCAL_ITEMMAIN__VARS__item_hotkey_id_list; $itemmain_drophint=&$___LOCAL_ITEMMAIN__VARS__itemmain_drophint; $item_allow_find_and_use=&$___LOCAL_ITEMMAIN__VARS__item_allow_find_and_use; $nosta=&$___LOCAL_ITEMMAIN__VARS__nosta; $nospk=&$___LOCAL_ITEMMAIN__VARS__nospk; $item_obbs=&$___LOCAL_ITEMMAIN__VARS__item_obbs; $map_noitemdrop_arealist=&$___LOCAL_ITEMMAIN__VARS__map_noitemdrop_arealist;  $itemkind_equipable=&$___LOCAL_ITEMMAIN__VARS__itemkind_equipable; $iteminfo=&$___LOCAL_ITEMMAIN__VARS__iteminfo; $itemspkinfo=&$___LOCAL_ITEMMAIN__VARS__itemspkinfo; $itemspkdesc=&$___LOCAL_ITEMMAIN__VARS__itemspkdesc; $itemspkdesc_help=&$___LOCAL_ITEMMAIN__VARS__itemspkdesc_help; $itemspkremark=&$___LOCAL_ITEMMAIN__VARS__itemspkremark;  global $___LOCAL_TRAP__VARS__playerflag,$___LOCAL_TRAP__VARS__selflag,$___LOCAL_TRAP__VARS__trname,$___LOCAL_TRAP__VARS__trtype,$___LOCAL_TRAP__VARS__trprefix,$___LOCAL_TRAP__VARS__trap_min_obbs,$___LOCAL_TRAP__VARS__trap_max_obbs; $playerflag=&$___LOCAL_TRAP__VARS__playerflag; $selflag=&$___LOCAL_TRAP__VARS__selflag; $trname=&$___LOCAL_TRAP__VARS__trname; $trtype=&$___LOCAL_TRAP__VARS__trtype; $trprefix=&$___LOCAL_TRAP__VARS__trprefix; $trap_min_obbs=&$___LOCAL_TRAP__VARS__trap_min_obbs; $trap_max_obbs=&$___LOCAL_TRAP__VARS__trap_max_obbs;   } while (0);
		if ($xmode & 16) {	
			$plsno_arr = \map\get_all_plsno();
			$iqry = '';
			$itemlist = \trap\get_trapfilecont ();
			$in = sizeof($itemlist);
			$an = \map\get_area_wavenum();
			for($i = 1; $i < $in; $i++) {
				if(!empty($itemlist[$i]) && strpos($itemlist[$i],',')!==false){
					list($iarea,$imap,$inum,$iname,$ikind,$ieff,$ista,$iskind) = explode(',',$itemlist[$i]);
					if(strpos($iskind,'=')===0){
						$tmp_pa_name = substr($iskind,1);
						$iskind = '';
						$result = $db->query("SELECT pid FROM {$tablepre}players WHERE name='$tmp_pa_name' AND type>0");
						if($db->num_rows($result)){
							$ipid = $db->fetch_array($result);
							$iskind = $ipid['pid'];
						}
					}
					if(($iarea == $an)||($iarea == 99)) {
						for($j = $inum; $j>0; $j--) {							
							if ($imap == 99)
							{
								do {
									$rmap = array_randompick($plsno_arr);
								} while (in_array($rmap,$map_noitemdrop_arealist));
							}
							else  $rmap = $imap;
							$iqry .= "('$iname', '$ikind','$ieff','$ista','$iskind','$rmap'),";
						}
					}
				}
			}
			if(!empty($iqry)){
				$iqry = "INSERT INTO {$tablepre}maptrap (itm,itmk,itme,itms,itmsk,pls) VALUES ".substr($iqry, 0, -1);
				$db->query($iqry);
			}
		}
		}while(0);
		//======== End of contents from mod trap ========

$xmode = $__VAR_DUMP_MOD_weather_VARS_xmode; unset($__VAR_DUMP_MOD_weather_VARS_xmode);

		
		
		$___TMP_MOD_trap_FUNC_rs_game_RET;
		
		
		if ($xmode & 2) 
		{
			$weather = array_randompick(array(0, 2, 3, 4, 7));
		}
		}while(0);
		//======== End of contents from mod weather ========

$xmode = $__VAR_DUMP_MOD_instance6_VARS_xmode; unset($__VAR_DUMP_MOD_instance6_VARS_xmode);

		
		
		$___TMP_MOD_weather_FUNC_rs_game_RET;
		
		
		if (($gametype==16)&&($xmode & 2)) 
		{
			$weather = 1;
		}
		}while(0);
		//======== End of contents from mod instance6 ========

$xmode = $__VAR_DUMP_MOD_gtype1_VARS_xmode; unset($__VAR_DUMP_MOD_gtype1_VARS_xmode);

		
		
		$___TMP_MOD_instance6_FUNC_rs_game_RET;
		
		
		if (($gametype==1)&&($xmode & 2)) 
		{
			$weather = 1;
			$hack=1;
			
		}
		
		}while(0);
		//======== End of contents from mod gtype1 ========

$xmode = $__VAR_DUMP_MOD_tutorial_VARS_xmode; unset($__VAR_DUMP_MOD_tutorial_VARS_xmode);
		$___TMP_MOD_gtype1_FUNC_rs_game_RET;
		
		if ($xmode & 2 && $gametype == 17) {
			
			if(isset($tutorial_areahour_augment)){
				list($sec,$min,$hour,$day,$month,$year,$wday,$yday,$isdst) = localtime($starttime);
				$areatime = $starttime + $tutorial_areahour_augment;
			}
			if(isset($tutorial_allowed_weather)){
				list($wmin,$wmax) = $tutorial_allowed_weather;
				$weather = rand($wmin,$wmax);
			}
			
			
		}
		}while(0);
		//======== End of contents from mod tutorial ========

$xmode = $__VAR_DUMP_MOD_instance3_VARS_xmode; unset($__VAR_DUMP_MOD_instance3_VARS_xmode);

		
		
		$___TMP_MOD_tutorial_FUNC_rs_game_RET;
		
		
		if (($gametype==13)&&($xmode & 2)) 
		{
			$weather = 1;
		}
		}while(0);
		//======== End of contents from mod instance3 ========

$xmode = $__VAR_DUMP_MOD_instance11_VARS_xmode; unset($__VAR_DUMP_MOD_instance11_VARS_xmode);
		$___TMP_MOD_instance3_FUNC_rs_game_RET;
		if ((21 == $gametype)&&($xmode & 2)) 
		{
			$weather = 18;
			$areatime = $starttime + 1919810;
			$gamevars['map_display_group'] = 1;
			$gamevars['plsinfo'] = $plsinfo11;
		}
		}while(0);
		//======== End of contents from mod instance11 ========

$xmode = $__VAR_DUMP_MOD_instance5_VARS_xmode; unset($__VAR_DUMP_MOD_instance5_VARS_xmode);

		
		
		$___TMP_MOD_instance11_FUNC_rs_game_RET;
		
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;   } while (0);
		if (($gametype==15)&&($xmode & 2)) 
		{
			$weather = 1;
		}
		}while(0);
		//======== End of contents from mod instance5 ========

$xmode = $__VAR_DUMP_MOD_instance10_VARS_xmode; unset($__VAR_DUMP_MOD_instance10_VARS_xmode);
		
		$___TMP_MOD_instance5_FUNC_rs_game_RET;
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;   } while (0);
		if ((20 == $gametype)&&($xmode & 2)) 
		{
			$weather = 1;
			
			
			$plsnum = sizeof($arealist);
			$areanum += $plsnum - 8 + 1;
		}
	
	}
	
	
	function rs_areatime(){
		
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;   } while (0);
		if(20 == $gametype){
			return $starttime + 60*120;
		}
		//======== Start of contents from mod instance5 ========
		do{
			$___TMP_MOD_instance5_FUNC_rs_areatime_RET = NULL;

		
		
		if(15==$gametype){
			$option = $roomvars['current_game_option'];
			if(isset($option['area-mode']) && 'extreme'==$option['area-mode'])	{
				$___TMP_MOD_instance5_FUNC_rs_areatime_RET =  $starttime + 60*40;
			break; 
			}
		}
		//======== Start of contents from mod instance3 ========
		do{
			$___TMP_MOD_instance3_FUNC_rs_areatime_RET = NULL;

		
		
		if(13==$gametype){
			$___TMP_MOD_instance3_FUNC_rs_areatime_RET =  $starttime + 60*40;
			break; 
		}
		//======== Start of contents from mod instance9 ========
		do{
			$___TMP_MOD_instance9_FUNC_rs_areatime_RET = NULL;

		
		
		if(19==$gametype){	$___TMP_MOD_instance9_FUNC_rs_areatime_RET =  $starttime + \map\get_area_interval() * 60;
			break; }
		//======== Start of contents from mod map ========
		do{
			$___TMP_MOD_map_FUNC_rs_areatime_RET = NULL;

		
		
		$___TMP_MOD_map_FUNC_rs_areatime_RET =  ceil(($starttime + \map\get_area_interval () * 60)/600) * 600;
			break;  
		}while(0);
		//======== End of contents from mod map ========
 
		$___TMP_MOD_instance9_FUNC_rs_areatime_RET =  $___TMP_MOD_map_FUNC_rs_areatime_RET;
			break; 
		}while(0);
		//======== End of contents from mod instance9 ========

		$___TMP_MOD_instance3_FUNC_rs_areatime_RET =  $___TMP_MOD_instance9_FUNC_rs_areatime_RET;
			break; 
		}while(0);
		//======== End of contents from mod instance3 ========

		$___TMP_MOD_instance5_FUNC_rs_areatime_RET =  $___TMP_MOD_instance3_FUNC_rs_areatime_RET;
			break; 
		}while(0);
		//======== End of contents from mod instance5 ========

		return $___TMP_MOD_instance5_FUNC_rs_areatime_RET;
	
	}
	
	
	function check_addarea_gameover($atime){
		
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;  global $___LOCAL_MAP__VARS__all_plsno_cache,$___LOCAL_MAP__VARS__areainterval,$___LOCAL_MAP__VARS__areaadd,$___LOCAL_MAP__VARS__areawarntime,$___LOCAL_MAP__VARS__arealimit,$___LOCAL_MAP__VARS__areaesc,$___LOCAL_MAP__VARS__area_on_start,$___LOCAL_MAP__VARS__dangerous_zone,$___LOCAL_MAP__VARS__plsinfo,$___LOCAL_MAP__VARS__plsinfo_o, $___LOCAL_MAP__VARS__plsinfo_disp,$___LOCAL_MAP__VARS__plsinfo_for_short,$___LOCAL_MAP__VARS__xyinfo,$___LOCAL_MAP__VARS__areainfo; $all_plsno_cache=&$___LOCAL_MAP__VARS__all_plsno_cache; $areainterval=&$___LOCAL_MAP__VARS__areainterval; $areaadd=&$___LOCAL_MAP__VARS__areaadd; $areawarntime=&$___LOCAL_MAP__VARS__areawarntime; $arealimit=&$___LOCAL_MAP__VARS__arealimit; $areaesc=&$___LOCAL_MAP__VARS__areaesc; $area_on_start=&$___LOCAL_MAP__VARS__area_on_start; $dangerous_zone=&$___LOCAL_MAP__VARS__dangerous_zone; $plsinfo=&$___LOCAL_MAP__VARS__plsinfo; $plsinfo_o=&$___LOCAL_MAP__VARS__plsinfo_o;  $plsinfo_disp=&$___LOCAL_MAP__VARS__plsinfo_disp; $plsinfo_for_short=&$___LOCAL_MAP__VARS__plsinfo_for_short; $xyinfo=&$___LOCAL_MAP__VARS__xyinfo; $areainfo=&$___LOCAL_MAP__VARS__areainfo;   } while (0);
		if (20 == $gametype){
			if($alivenum <= 0){
				\sys\gameover($atime,'end1');
			}
			elseif (\map\get_area_wavenum() >= 1){
				
				$result = $db->query("SELECT * FROM {$tablepre}players WHERE hp>0 AND type=0 ORDER BY card LIMIT 1");
				$wdata = $db->fetch_array($result);
				$winner = $wdata;
				\sys\gameover($atime,'end8',$winner);
			}
			return;
		}
if(isset($atime)) {$__VAR_DUMP_MOD_instance10_VARS_atime = $atime; } else {$__VAR_DUMP_MOD_instance10_VARS_atime = NULL;} if(isset($result)) {$__VAR_DUMP_MOD_instance10_VARS_result = $result; unset($result); } else {$__VAR_DUMP_MOD_instance10_VARS_result = NULL;} if(isset($wdata)) {$__VAR_DUMP_MOD_instance10_VARS_wdata = $wdata; unset($wdata); } else {$__VAR_DUMP_MOD_instance10_VARS_wdata = NULL;} 
		//======== Start of contents from mod instance5 ========
		do{
			$___TMP_MOD_instance5_FUNC_check_addarea_gameover_RET = NULL;

		
		
		if ($gametype==15){
			if($alivenum <= 0){
				\sys\gameover($atime,'end1');
				$___TMP_MOD_instance5_FUNC_check_addarea_gameover_RET = NULL;
			break; 
			}
			$alimit = 3;
			if(isset($roomvars['current_game_option'])){
				$option = $roomvars['current_game_option'];
				if(isset($option['area-mode']) && 'extreme'==$option['area-mode']){
					$alimit = 1;
				}
			}
			if (\map\get_area_wavenum() >= $alimit){
				$result = $db->query("SELECT * FROM {$tablepre}players WHERE hp>0 AND type=0");
				$wdata = $db->fetch_array($result);
				$winner = $wdata['name'];
				\sys\gameover($atime,'end8',$winner);
				
			}
			$___TMP_MOD_instance5_FUNC_check_addarea_gameover_RET = NULL;
			break; 
		}
if(isset($atime)) {$__VAR_DUMP_MOD_instance5_VARS_atime = $atime; } else {$__VAR_DUMP_MOD_instance5_VARS_atime = NULL;} if(isset($result)) {$__VAR_DUMP_MOD_instance5_VARS_result = $result; unset($result); } else {$__VAR_DUMP_MOD_instance5_VARS_result = NULL;} if(isset($wdata)) {$__VAR_DUMP_MOD_instance5_VARS_wdata = $wdata; unset($wdata); } else {$__VAR_DUMP_MOD_instance5_VARS_wdata = NULL;} 
		//======== Start of contents from mod instance3 ========
		do{
			$___TMP_MOD_instance3_FUNC_check_addarea_gameover_RET = NULL;

		
		
		if ($gametype==13){
			if($alivenum <= 0){
				\sys\gameover($atime,'end1');
			}
			elseif (\map\get_area_wavenum() >= 2){
				$result = $db->query("SELECT * FROM {$tablepre}players WHERE hp>0 AND type=0 ORDER BY card LIMIT 1");
				$wdata = $db->fetch_array($result);
				
				$wdata['state'] = 50;
				$wdata['sourceless'] = 1; 
				\player\kill($wdata,$wdata);
				\player\player_save($wdata);
				\sys\gameover($atime,'end1');
			}
			$___TMP_MOD_instance3_FUNC_check_addarea_gameover_RET = NULL;
			break; 
		}
if(isset($atime)) {$__VAR_DUMP_MOD_instance3_VARS_atime = $atime; } else {$__VAR_DUMP_MOD_instance3_VARS_atime = NULL;} if(isset($result)) {$__VAR_DUMP_MOD_instance3_VARS_result = $result; unset($result); } else {$__VAR_DUMP_MOD_instance3_VARS_result = NULL;} if(isset($wdata)) {$__VAR_DUMP_MOD_instance3_VARS_wdata = $wdata; unset($wdata); } else {$__VAR_DUMP_MOD_instance3_VARS_wdata = NULL;} 
		//======== Start of contents from mod gtype1 ========
		do{
			$___TMP_MOD_gtype1_FUNC_check_addarea_gameover_RET = NULL;

		
		
		if ($gametype==1){
			
			if (\map\get_area_wavenum() >= 2){
				$result = $db->query("SELECT * FROM {$tablepre}players WHERE type=0 ORDER BY pid DESC");
				$ml=-1;
				$winner='';
				$wl=array();
				$wc=0;
				while($pt = $db->fetch_array($result)) {
					$pa=\player\fetch_playerdata_by_pid($pt['pid']);
					$cl=(int)\skillbase\skill_getvalue(424,'lvl',$pa);
					
					if ($cl>$ml){
						$ml=$cl;
						$winner=$pa['name'];
					}
					$wc++;
					$wl[$wc]['n']=$pa['name'];
					$wl[$wc]['p']=$pa['pid'];
					$wl[$wc]['c']=$cl;
				}
				
				for ($i=1;$i<$wc;$i++){
					for ($j=$i+1;$j<=$wc;$j++){
						if (($wl[$i]['c']<$wl[$j]['c'])||($wl[$i]['c']==$wl[$j]['c'])&&($wl[$i]['p']<$wl[$j]['p'])){
							$tt=$wl[$i];
							$wl[$i]=$wl[$j];
							$wl[$j]=$tt;
						}
					}
				}
				$rk=0; 
				$max_announce_num = 3;	
				$bestlist = Array();	
				
				for ($rk=1;$rk<=$wc;$rk++){
					
					$kk=$wl[$rk]['n'];
					$v=$wl[$rk]['c'];
					$k=\player\fetch_playerdata($kk);
					$qiegao_prize = $v*10;
					$card_prize = array();
					if ($v>=20) $qiegao_prize += 200;
					if ($v>=30) $qiegao_prize += 500;
					if ($v>=40) $qiegao_prize += 700;
					if ($v>=50) $qiegao_prize += 900;
					if ($v>=60) $qiegao_prize += 1100;
					if ($v>=70) $qiegao_prize += 1200;
					if ($rk==1) $qiegao_prize += 1000;
					if ($rk<=2) $qiegao_prize += 500;
					if ($rk<=$max_announce_num){
						$qiegao_prize += 500;
						$bestlist[$rk] = Array(0=>$kk, 1=>$v);
					}	
					\skillbase\skill_setvalue(424,'rank',$rk,$k);
					if($qiegao_prize) {
						
						include_once './include/messages.func.php';
						message_create(
							$kk,
							'除错模式奖励',
							'感谢您为金龙通讯社所做的工作，这里是您的奖励，请查收。<br>',
							'getqiegao_'.$qiegao_prize
						);	
						\skillbase\skill_setvalue(424,'prize',$qiegao_prize,$k);
						\gtype1\gtype1_post_rank_event ($k, $v, $rk);
					}
				}
				
				for ($i=$max_announce_num; $i>=1; $i--) 
					if (isset($bestlist[$i]))
						addnews(0,'g1announce',$i,$bestlist[$i][0],$bestlist[$i][1]);
						
				\sys\gameover($atime,'end8',$winner);
			}
			$___TMP_MOD_gtype1_FUNC_check_addarea_gameover_RET = NULL;
			break; 
		}
if(isset($atime)) {$__VAR_DUMP_MOD_gtype1_VARS_atime = $atime; } else {$__VAR_DUMP_MOD_gtype1_VARS_atime = NULL;} if(isset($result)) {$__VAR_DUMP_MOD_gtype1_VARS_result = $result; unset($result); } else {$__VAR_DUMP_MOD_gtype1_VARS_result = NULL;} 
		//======== Start of contents from mod instance6 ========
		do{
			$___TMP_MOD_instance6_FUNC_check_addarea_gameover_RET = NULL;

		
		
		if ($gametype==16){
			if($alivenum <= 0){
				\sys\gameover($atime,'end1');
			}
			elseif (\map\get_area_wavenum() >= 4){
				$result = $db->query("SELECT * FROM {$tablepre}players WHERE hp>0 AND type=0 ORDER BY card LIMIT 1");
				$wdata = $db->fetch_array($result);
				$winner = $wdata['name'];
				\sys\gameover($atime,'end8',$winner);
			}
			$___TMP_MOD_instance6_FUNC_check_addarea_gameover_RET = NULL;
			break; 
		}
if(isset($atime)) {$__VAR_DUMP_MOD_instance6_VARS_atime = $atime; } else {$__VAR_DUMP_MOD_instance6_VARS_atime = NULL;} 
		//======== Start of contents from mod map ========
		do{
			$___TMP_MOD_map_FUNC_check_addarea_gameover_RET = NULL;

		
		
		if(empty(\map\get_current_not_area ())) 
		{
			\sys\gameover($atime,'end1');
			$___TMP_MOD_map_FUNC_check_addarea_gameover_RET = NULL;
			break; 
		}
			
		if( $alivenum == 1 && $gamestate >= 30 ) { 
			\sys\gameover($atime);
			$___TMP_MOD_map_FUNC_check_addarea_gameover_RET = NULL;
			break; 
		} elseif( $alivenum <= 0 && $gamestate >= 30 ) {
			\sys\gameover($atime,'end1');
		} 
		}while(0);
		//======== End of contents from mod map ========

$atime = $__VAR_DUMP_MOD_instance6_VARS_atime; unset($__VAR_DUMP_MOD_instance6_VARS_atime);
		$___TMP_MOD_map_FUNC_check_addarea_gameover_RET;	
		}while(0);
		//======== End of contents from mod instance6 ========

$atime = $__VAR_DUMP_MOD_gtype1_VARS_atime; unset($__VAR_DUMP_MOD_gtype1_VARS_atime);$result = $__VAR_DUMP_MOD_gtype1_VARS_result; 
		$___TMP_MOD_instance6_FUNC_check_addarea_gameover_RET;	
		}while(0);
		//======== End of contents from mod gtype1 ========

$atime = $__VAR_DUMP_MOD_instance3_VARS_atime; unset($__VAR_DUMP_MOD_instance3_VARS_atime);$result = $__VAR_DUMP_MOD_instance3_VARS_result; $wdata = $__VAR_DUMP_MOD_instance3_VARS_wdata; 
		$___TMP_MOD_gtype1_FUNC_check_addarea_gameover_RET;
		}while(0);
		//======== End of contents from mod instance3 ========

$atime = $__VAR_DUMP_MOD_instance5_VARS_atime; unset($__VAR_DUMP_MOD_instance5_VARS_atime);$result = $__VAR_DUMP_MOD_instance5_VARS_result; $wdata = $__VAR_DUMP_MOD_instance5_VARS_wdata; 
		$___TMP_MOD_instance3_FUNC_check_addarea_gameover_RET;	
		}while(0);
		//======== End of contents from mod instance5 ========

$atime = $__VAR_DUMP_MOD_instance10_VARS_atime; unset($__VAR_DUMP_MOD_instance10_VARS_atime);$result = $__VAR_DUMP_MOD_instance10_VARS_result; $wdata = $__VAR_DUMP_MOD_instance10_VARS_wdata; 
		$___TMP_MOD_instance5_FUNC_check_addarea_gameover_RET;
	
	}
	
	
	function check_in_shop_area($p)
	{
		
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;   } while (0);
		if (20 == $gametype)
		{
			if (!isset($gamevars['instance10_shops']))
			{
				$gamevars['instance10_shops'] = array_randompick(range(1, 33), 4);
				$gamevars['instance10_shops'][] = 0;
			}
			save_gameinfo();
			return in_array($p, $gamevars['instance10_shops']);
		}
		else{
if(isset($p)) {$__VAR_DUMP_MOD_instance10_VARS_p = $p; } else {$__VAR_DUMP_MOD_instance10_VARS_p = NULL;} 
		//======== Start of contents from mod skill68 ========
		do{
			$___TMP_MOD_skill68_FUNC_check_in_shop_area_RET = NULL;

		
		if (\skillbase\skill_query(68)){ $___TMP_MOD_skill68_FUNC_check_in_shop_area_RET =  1;
			break; }
if(isset($p)) {$__VAR_DUMP_MOD_skill68_VARS_p = $p; } else {$__VAR_DUMP_MOD_skill68_VARS_p = NULL;} 
		//======== Start of contents from mod instance11 ========
		do{
			$___TMP_MOD_instance11_FUNC_check_in_shop_area_RET = NULL;

		
		do { global $___LOCAL_INSTANCE11__VARS__plsinfo11,$___LOCAL_INSTANCE11__VARS__npcinfo_instance11,$___LOCAL_INSTANCE11__VARS__shops11,$___LOCAL_INSTANCE11__VARS__shop_tag_list11; $plsinfo11=&$___LOCAL_INSTANCE11__VARS__plsinfo11; $npcinfo_instance11=&$___LOCAL_INSTANCE11__VARS__npcinfo_instance11; $shops11=&$___LOCAL_INSTANCE11__VARS__shops11; $shop_tag_list11=&$___LOCAL_INSTANCE11__VARS__shop_tag_list11;   } while (0);
		if (21 == $gametype){
			$___TMP_MOD_instance11_FUNC_check_in_shop_area_RET =  in_array($p, $shops11);
			break; 
		}
if(isset($p)) {$__VAR_DUMP_MOD_instance11_VARS_p = $p; } else {$__VAR_DUMP_MOD_instance11_VARS_p = NULL;} 
		//======== Start of contents from mod itemshop ========
		do{
			$___TMP_MOD_itemshop_FUNC_check_in_shop_area_RET = NULL;

		
		do { global $___LOCAL_ITEMSHOP__VARS__shops,$___LOCAL_ITEMSHOP__VARS__shop_tag_list,$___LOCAL_ITEMSHOP__VARS__shop_allow_input_num; $shops=&$___LOCAL_ITEMSHOP__VARS__shops; $shop_tag_list=&$___LOCAL_ITEMSHOP__VARS__shop_tag_list; $shop_allow_input_num=&$___LOCAL_ITEMSHOP__VARS__shop_allow_input_num;   } while (0);
		$___TMP_MOD_itemshop_FUNC_check_in_shop_area_RET =  in_array($p,$shops);
			break; 
		}while(0);
		//======== End of contents from mod itemshop ========

$p = $__VAR_DUMP_MOD_instance11_VARS_p; unset($__VAR_DUMP_MOD_instance11_VARS_p);
		$___TMP_MOD_instance11_FUNC_check_in_shop_area_RET =  $___TMP_MOD_itemshop_FUNC_check_in_shop_area_RET;
			break; 
		}while(0);
		//======== End of contents from mod instance11 ========

$p = $__VAR_DUMP_MOD_skill68_VARS_p; unset($__VAR_DUMP_MOD_skill68_VARS_p);
		$___TMP_MOD_skill68_FUNC_check_in_shop_area_RET =  $___TMP_MOD_instance11_FUNC_check_in_shop_area_RET;
			break; 
		}while(0);
		//======== End of contents from mod skill68 ========

$p = $__VAR_DUMP_MOD_instance10_VARS_p; unset($__VAR_DUMP_MOD_instance10_VARS_p); return $___TMP_MOD_skill68_FUNC_check_in_shop_area_RET;}
	
	}
	
	
	function itemmix_success()
	{
		
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;  global $___LOCAL_PLAYER__VARS__ss,$___LOCAL_PLAYER__VARS__db_player_structure,$___LOCAL_PLAYER__VARS__db_player_structure_types,$___LOCAL_PLAYER__VARS__gamedata,$___LOCAL_PLAYER__VARS__cmd,$___LOCAL_PLAYER__VARS__main,$___LOCAL_PLAYER__VARS__sdata,$___LOCAL_PLAYER__VARS__fog,$___LOCAL_PLAYER__VARS__upexp,$___LOCAL_PLAYER__VARS__lvlupexp, $___LOCAL_PLAYER__VARS__iconImg,$___LOCAL_PLAYER__VARS__iconImgB,$___LOCAL_PLAYER__VARS__iconImgBwidth,$___LOCAL_PLAYER__VARS__ardef,$___LOCAL_PLAYER__VARS__hpcolor,$___LOCAL_PLAYER__VARS__spcolor,$___LOCAL_PLAYER__VARS__newhpimg,$___LOCAL_PLAYER__VARS__newspimg,$___LOCAL_PLAYER__VARS__splt,$___LOCAL_PLAYER__VARS__hplt, $___LOCAL_PLAYER__VARS__tpldata,$___LOCAL_PLAYER__VARS__icon_list,$___LOCAL_PLAYER__VARS__icon_list_contents_to_frontend,$___LOCAL_PLAYER__VARS__typeinfo,$___LOCAL_PLAYER__VARS__killmsginfo,$___LOCAL_PLAYER__VARS__lwinfo,$___LOCAL_PLAYER__VARS__sexinfo,$___LOCAL_PLAYER__VARS__equip_list,$___LOCAL_PLAYER__VARS__battle_equip_list,$___LOCAL_PLAYER__VARS__pc_icon_range, $___LOCAL_PLAYER__VARS__pid,$___LOCAL_PLAYER__VARS__type,$___LOCAL_PLAYER__VARS__name,$___LOCAL_PLAYER__VARS__pass,$___LOCAL_PLAYER__VARS__ip,$___LOCAL_PLAYER__VARS__motto,$___LOCAL_PLAYER__VARS__killmsg,$___LOCAL_PLAYER__VARS__lastword,$___LOCAL_PLAYER__VARS__winner_flag,$___LOCAL_PLAYER__VARS__player_dead_flag, $___LOCAL_PLAYER__VARS__corpse_clear_flag,$___LOCAL_PLAYER__VARS__gd,$___LOCAL_PLAYER__VARS__sNo,$___LOCAL_PLAYER__VARS__club,$___LOCAL_PLAYER__VARS__validtime,$___LOCAL_PLAYER__VARS__endtime,$___LOCAL_PLAYER__VARS__cdsec,$___LOCAL_PLAYER__VARS__cdmsec,$___LOCAL_PLAYER__VARS__cdtime,$___LOCAL_PLAYER__VARS__action, $___LOCAL_PLAYER__VARS__a_actionnum,$___LOCAL_PLAYER__VARS__v_actionnum,$___LOCAL_PLAYER__VARS__hp,$___LOCAL_PLAYER__VARS__mhp,$___LOCAL_PLAYER__VARS__sp,$___LOCAL_PLAYER__VARS__msp,$___LOCAL_PLAYER__VARS__mss,$___LOCAL_PLAYER__VARS__att,$___LOCAL_PLAYER__VARS__def,$___LOCAL_PLAYER__VARS__pls, $___LOCAL_PLAYER__VARS__lvl,$___LOCAL_PLAYER__VARS__exp,$___LOCAL_PLAYER__VARS__money,$___LOCAL_PLAYER__VARS__rp,$___LOCAL_PLAYER__VARS__bid,$___LOCAL_PLAYER__VARS__inf,$___LOCAL_PLAYER__VARS__rage,$___LOCAL_PLAYER__VARS__pose,$___LOCAL_PLAYER__VARS__tactic,$___LOCAL_PLAYER__VARS__killnum, $___LOCAL_PLAYER__VARS__npckillnum,$___LOCAL_PLAYER__VARS__state,$___LOCAL_PLAYER__VARS__skillpoint,$___LOCAL_PLAYER__VARS__flare,$___LOCAL_PLAYER__VARS__wp,$___LOCAL_PLAYER__VARS__wk,$___LOCAL_PLAYER__VARS__wg,$___LOCAL_PLAYER__VARS__wc,$___LOCAL_PLAYER__VARS__wd,$___LOCAL_PLAYER__VARS__wf, $___LOCAL_PLAYER__VARS__icon,$___LOCAL_PLAYER__VARS__teamID,$___LOCAL_PLAYER__VARS__teamPass,$___LOCAL_PLAYER__VARS__card,$___LOCAL_PLAYER__VARS__cardname,$___LOCAL_PLAYER__VARS__wep,$___LOCAL_PLAYER__VARS__wepk,$___LOCAL_PLAYER__VARS__wepe,$___LOCAL_PLAYER__VARS__weps,$___LOCAL_PLAYER__VARS__wepsk, $___LOCAL_PLAYER__VARS__arb,$___LOCAL_PLAYER__VARS__arbk,$___LOCAL_PLAYER__VARS__arbe,$___LOCAL_PLAYER__VARS__arbs,$___LOCAL_PLAYER__VARS__arbsk,$___LOCAL_PLAYER__VARS__arh,$___LOCAL_PLAYER__VARS__arhk,$___LOCAL_PLAYER__VARS__arhe,$___LOCAL_PLAYER__VARS__arhs,$___LOCAL_PLAYER__VARS__arhsk, $___LOCAL_PLAYER__VARS__ara,$___LOCAL_PLAYER__VARS__arak,$___LOCAL_PLAYER__VARS__arae,$___LOCAL_PLAYER__VARS__aras,$___LOCAL_PLAYER__VARS__arask,$___LOCAL_PLAYER__VARS__arf,$___LOCAL_PLAYER__VARS__arfk,$___LOCAL_PLAYER__VARS__arfe,$___LOCAL_PLAYER__VARS__arfs,$___LOCAL_PLAYER__VARS__arfsk, $___LOCAL_PLAYER__VARS__art,$___LOCAL_PLAYER__VARS__artk,$___LOCAL_PLAYER__VARS__arte,$___LOCAL_PLAYER__VARS__arts,$___LOCAL_PLAYER__VARS__artsk,$___LOCAL_PLAYER__VARS__itm0,$___LOCAL_PLAYER__VARS__itmk0,$___LOCAL_PLAYER__VARS__itme0,$___LOCAL_PLAYER__VARS__itms0,$___LOCAL_PLAYER__VARS__itmsk0, $___LOCAL_PLAYER__VARS__itm1,$___LOCAL_PLAYER__VARS__itmk1,$___LOCAL_PLAYER__VARS__itme1,$___LOCAL_PLAYER__VARS__itms1,$___LOCAL_PLAYER__VARS__itmsk1,$___LOCAL_PLAYER__VARS__itm2,$___LOCAL_PLAYER__VARS__itmk2,$___LOCAL_PLAYER__VARS__itme2,$___LOCAL_PLAYER__VARS__itms2,$___LOCAL_PLAYER__VARS__itmsk2, $___LOCAL_PLAYER__VARS__itm3,$___LOCAL_PLAYER__VARS__itmk3,$___LOCAL_PLAYER__VARS__itme3,$___LOCAL_PLAYER__VARS__itms3,$___LOCAL_PLAYER__VARS__itmsk3,$___LOCAL_PLAYER__VARS__itm4,$___LOCAL_PLAYER__VARS__itmk4,$___LOCAL_PLAYER__VARS__itme4,$___LOCAL_PLAYER__VARS__itms4,$___LOCAL_PLAYER__VARS__itmsk4, $___LOCAL_PLAYER__VARS__itm5,$___LOCAL_PLAYER__VARS__itmk5,$___LOCAL_PLAYER__VARS__itme5,$___LOCAL_PLAYER__VARS__itms5,$___LOCAL_PLAYER__VARS__itmsk5,$___LOCAL_PLAYER__VARS__itm6,$___LOCAL_PLAYER__VARS__itmk6,$___LOCAL_PLAYER__VARS__itme6,$___LOCAL_PLAYER__VARS__itms6,$___LOCAL_PLAYER__VARS__itmsk6, $___LOCAL_PLAYER__VARS__searchmemory,$___LOCAL_PLAYER__VARS__nskill,$___LOCAL_PLAYER__VARS__nskillpara; $ss=&$___LOCAL_PLAYER__VARS__ss; $db_player_structure=&$___LOCAL_PLAYER__VARS__db_player_structure; $db_player_structure_types=&$___LOCAL_PLAYER__VARS__db_player_structure_types; $gamedata=&$___LOCAL_PLAYER__VARS__gamedata; $cmd=&$___LOCAL_PLAYER__VARS__cmd; $main=&$___LOCAL_PLAYER__VARS__main; $sdata=&$___LOCAL_PLAYER__VARS__sdata; $fog=&$___LOCAL_PLAYER__VARS__fog; $upexp=&$___LOCAL_PLAYER__VARS__upexp; $lvlupexp=&$___LOCAL_PLAYER__VARS__lvlupexp;  $iconImg=&$___LOCAL_PLAYER__VARS__iconImg; $iconImgB=&$___LOCAL_PLAYER__VARS__iconImgB; $iconImgBwidth=&$___LOCAL_PLAYER__VARS__iconImgBwidth; $ardef=&$___LOCAL_PLAYER__VARS__ardef; $hpcolor=&$___LOCAL_PLAYER__VARS__hpcolor; $spcolor=&$___LOCAL_PLAYER__VARS__spcolor; $newhpimg=&$___LOCAL_PLAYER__VARS__newhpimg; $newspimg=&$___LOCAL_PLAYER__VARS__newspimg; $splt=&$___LOCAL_PLAYER__VARS__splt; $hplt=&$___LOCAL_PLAYER__VARS__hplt;  $tpldata=&$___LOCAL_PLAYER__VARS__tpldata; $icon_list=&$___LOCAL_PLAYER__VARS__icon_list; $icon_list_contents_to_frontend=&$___LOCAL_PLAYER__VARS__icon_list_contents_to_frontend; $typeinfo=&$___LOCAL_PLAYER__VARS__typeinfo; $killmsginfo=&$___LOCAL_PLAYER__VARS__killmsginfo; $lwinfo=&$___LOCAL_PLAYER__VARS__lwinfo; $sexinfo=&$___LOCAL_PLAYER__VARS__sexinfo; $equip_list=&$___LOCAL_PLAYER__VARS__equip_list; $battle_equip_list=&$___LOCAL_PLAYER__VARS__battle_equip_list; $pc_icon_range=&$___LOCAL_PLAYER__VARS__pc_icon_range;  $pid=&$___LOCAL_PLAYER__VARS__pid; $type=&$___LOCAL_PLAYER__VARS__type; $name=&$___LOCAL_PLAYER__VARS__name; $pass=&$___LOCAL_PLAYER__VARS__pass; $ip=&$___LOCAL_PLAYER__VARS__ip; $motto=&$___LOCAL_PLAYER__VARS__motto; $killmsg=&$___LOCAL_PLAYER__VARS__killmsg; $lastword=&$___LOCAL_PLAYER__VARS__lastword; $winner_flag=&$___LOCAL_PLAYER__VARS__winner_flag; $player_dead_flag=&$___LOCAL_PLAYER__VARS__player_dead_flag;  $corpse_clear_flag=&$___LOCAL_PLAYER__VARS__corpse_clear_flag; $gd=&$___LOCAL_PLAYER__VARS__gd; $sNo=&$___LOCAL_PLAYER__VARS__sNo; $club=&$___LOCAL_PLAYER__VARS__club; $validtime=&$___LOCAL_PLAYER__VARS__validtime; $endtime=&$___LOCAL_PLAYER__VARS__endtime; $cdsec=&$___LOCAL_PLAYER__VARS__cdsec; $cdmsec=&$___LOCAL_PLAYER__VARS__cdmsec; $cdtime=&$___LOCAL_PLAYER__VARS__cdtime; $action=&$___LOCAL_PLAYER__VARS__action;  $a_actionnum=&$___LOCAL_PLAYER__VARS__a_actionnum; $v_actionnum=&$___LOCAL_PLAYER__VARS__v_actionnum; $hp=&$___LOCAL_PLAYER__VARS__hp; $mhp=&$___LOCAL_PLAYER__VARS__mhp; $sp=&$___LOCAL_PLAYER__VARS__sp; $msp=&$___LOCAL_PLAYER__VARS__msp; $mss=&$___LOCAL_PLAYER__VARS__mss; $att=&$___LOCAL_PLAYER__VARS__att; $def=&$___LOCAL_PLAYER__VARS__def; $pls=&$___LOCAL_PLAYER__VARS__pls;  $lvl=&$___LOCAL_PLAYER__VARS__lvl; $exp=&$___LOCAL_PLAYER__VARS__exp; $money=&$___LOCAL_PLAYER__VARS__money; $rp=&$___LOCAL_PLAYER__VARS__rp; $bid=&$___LOCAL_PLAYER__VARS__bid; $inf=&$___LOCAL_PLAYER__VARS__inf; $rage=&$___LOCAL_PLAYER__VARS__rage; $pose=&$___LOCAL_PLAYER__VARS__pose; $tactic=&$___LOCAL_PLAYER__VARS__tactic; $killnum=&$___LOCAL_PLAYER__VARS__killnum;  $npckillnum=&$___LOCAL_PLAYER__VARS__npckillnum; $state=&$___LOCAL_PLAYER__VARS__state; $skillpoint=&$___LOCAL_PLAYER__VARS__skillpoint; $flare=&$___LOCAL_PLAYER__VARS__flare; $wp=&$___LOCAL_PLAYER__VARS__wp; $wk=&$___LOCAL_PLAYER__VARS__wk; $wg=&$___LOCAL_PLAYER__VARS__wg; $wc=&$___LOCAL_PLAYER__VARS__wc; $wd=&$___LOCAL_PLAYER__VARS__wd; $wf=&$___LOCAL_PLAYER__VARS__wf;  $icon=&$___LOCAL_PLAYER__VARS__icon; $teamID=&$___LOCAL_PLAYER__VARS__teamID; $teamPass=&$___LOCAL_PLAYER__VARS__teamPass; $card=&$___LOCAL_PLAYER__VARS__card; $cardname=&$___LOCAL_PLAYER__VARS__cardname; $wep=&$___LOCAL_PLAYER__VARS__wep; $wepk=&$___LOCAL_PLAYER__VARS__wepk; $wepe=&$___LOCAL_PLAYER__VARS__wepe; $weps=&$___LOCAL_PLAYER__VARS__weps; $wepsk=&$___LOCAL_PLAYER__VARS__wepsk;  $arb=&$___LOCAL_PLAYER__VARS__arb; $arbk=&$___LOCAL_PLAYER__VARS__arbk; $arbe=&$___LOCAL_PLAYER__VARS__arbe; $arbs=&$___LOCAL_PLAYER__VARS__arbs; $arbsk=&$___LOCAL_PLAYER__VARS__arbsk; $arh=&$___LOCAL_PLAYER__VARS__arh; $arhk=&$___LOCAL_PLAYER__VARS__arhk; $arhe=&$___LOCAL_PLAYER__VARS__arhe; $arhs=&$___LOCAL_PLAYER__VARS__arhs; $arhsk=&$___LOCAL_PLAYER__VARS__arhsk;  $ara=&$___LOCAL_PLAYER__VARS__ara; $arak=&$___LOCAL_PLAYER__VARS__arak; $arae=&$___LOCAL_PLAYER__VARS__arae; $aras=&$___LOCAL_PLAYER__VARS__aras; $arask=&$___LOCAL_PLAYER__VARS__arask; $arf=&$___LOCAL_PLAYER__VARS__arf; $arfk=&$___LOCAL_PLAYER__VARS__arfk; $arfe=&$___LOCAL_PLAYER__VARS__arfe; $arfs=&$___LOCAL_PLAYER__VARS__arfs; $arfsk=&$___LOCAL_PLAYER__VARS__arfsk;  $art=&$___LOCAL_PLAYER__VARS__art; $artk=&$___LOCAL_PLAYER__VARS__artk; $arte=&$___LOCAL_PLAYER__VARS__arte; $arts=&$___LOCAL_PLAYER__VARS__arts; $artsk=&$___LOCAL_PLAYER__VARS__artsk; $itm0=&$___LOCAL_PLAYER__VARS__itm0; $itmk0=&$___LOCAL_PLAYER__VARS__itmk0; $itme0=&$___LOCAL_PLAYER__VARS__itme0; $itms0=&$___LOCAL_PLAYER__VARS__itms0; $itmsk0=&$___LOCAL_PLAYER__VARS__itmsk0;  $itm1=&$___LOCAL_PLAYER__VARS__itm1; $itmk1=&$___LOCAL_PLAYER__VARS__itmk1; $itme1=&$___LOCAL_PLAYER__VARS__itme1; $itms1=&$___LOCAL_PLAYER__VARS__itms1; $itmsk1=&$___LOCAL_PLAYER__VARS__itmsk1; $itm2=&$___LOCAL_PLAYER__VARS__itm2; $itmk2=&$___LOCAL_PLAYER__VARS__itmk2; $itme2=&$___LOCAL_PLAYER__VARS__itme2; $itms2=&$___LOCAL_PLAYER__VARS__itms2; $itmsk2=&$___LOCAL_PLAYER__VARS__itmsk2;  $itm3=&$___LOCAL_PLAYER__VARS__itm3; $itmk3=&$___LOCAL_PLAYER__VARS__itmk3; $itme3=&$___LOCAL_PLAYER__VARS__itme3; $itms3=&$___LOCAL_PLAYER__VARS__itms3; $itmsk3=&$___LOCAL_PLAYER__VARS__itmsk3; $itm4=&$___LOCAL_PLAYER__VARS__itm4; $itmk4=&$___LOCAL_PLAYER__VARS__itmk4; $itme4=&$___LOCAL_PLAYER__VARS__itme4; $itms4=&$___LOCAL_PLAYER__VARS__itms4; $itmsk4=&$___LOCAL_PLAYER__VARS__itmsk4;  $itm5=&$___LOCAL_PLAYER__VARS__itm5; $itmk5=&$___LOCAL_PLAYER__VARS__itmk5; $itme5=&$___LOCAL_PLAYER__VARS__itme5; $itms5=&$___LOCAL_PLAYER__VARS__itms5; $itmsk5=&$___LOCAL_PLAYER__VARS__itmsk5; $itm6=&$___LOCAL_PLAYER__VARS__itm6; $itmk6=&$___LOCAL_PLAYER__VARS__itmk6; $itme6=&$___LOCAL_PLAYER__VARS__itme6; $itms6=&$___LOCAL_PLAYER__VARS__itms6; $itmsk6=&$___LOCAL_PLAYER__VARS__itmsk6;  $searchmemory=&$___LOCAL_PLAYER__VARS__searchmemory; $nskill=&$___LOCAL_PLAYER__VARS__nskill; $nskillpara=&$___LOCAL_PLAYER__VARS__nskillpara;   } while (0);
		if (20 == $gametype)
		{
			if (in_array($itmk0[0], array('W','D','M','V','H','P')))
			{
				$itme0 = max(round((80 + rand(0,40))/100 * $itme0), 1);
				if ($itms0 != $nosta) $itms0 = max(round((80 + rand(0,40))/100 * $itms0), 1);
				if ($itmk0[0] == 'W')
				{
					$dice = rand(0,99);
					if ($dice < 3)
					{
						$tmpsk = array_randompick(array('f','k','t','d','r','n','y'));
						if (!\itemmain\check_in_itmsk($tmpsk, $itmsk0)) $itmsk0 .= $tmpsk;
					}
					elseif ($dice < 30)
					{
						$tmpsk = array_randompick(array('u','e','i','w','p','N','H','z'));
						if (!\itemmain\check_in_itmsk($tmpsk, $itmsk0)) $itmsk0 .= $tmpsk;
					}
				}
				elseif ($itmk0[0] == 'D')
				{
					$dice = rand(0,99);
					if ($dice < 3)
					{
						$tmpsk = array_randompick(array('B','b','Z','h'));
						if (!\itemmain\check_in_itmsk($tmpsk, $itmsk0)) $itmsk0 .= $tmpsk;
					}
					elseif ($dice < 30)
					{
						$tmpsk = array_randompick(array('A','a','P','K','G','C','D','F','R','q','U','I','E','W','H','M','m','z'));
						if (!\itemmain\check_in_itmsk($tmpsk, $itmsk0)) $itmsk0 .= $tmpsk;
					}
				}
			}
		}
		//======== Start of contents from mod smartmix ========
		do{
			$___TMP_MOD_smartmix_FUNC_itemmix_success_RET = NULL;
		//======== Start of contents from mod skill373 ========
		do{
			$___TMP_MOD_skill373_FUNC_itemmix_success_RET = NULL;

		
		
		//======== Start of contents from mod skill358 ========
		do{
			$___TMP_MOD_skill358_FUNC_itemmix_success_RET = NULL;

		
		
		if ('cube' == $uip['mixcls'] && \skillbase\skill_query(358)){
			$cnt = (int)\skillbase\skill_getvalue(358,'cnt');
			\skillbase\skill_setvalue(358,'cnt',$cnt + 1);
		}
if(isset($cnt)) {$__VAR_DUMP_MOD_skill358_VARS_cnt = $cnt; unset($cnt); } else {$__VAR_DUMP_MOD_skill358_VARS_cnt = NULL;} 
		//======== Start of contents from mod skill357 ========
		do{
			$___TMP_MOD_skill357_FUNC_itemmix_success_RET = NULL;

		
		
		if ($itm0=='模式『EX』' && \skillbase\skill_query(357)){
			$cnt = (int)\skillbase\skill_getvalue(357,'cnt');
			\skillbase\skill_setvalue(357,'cnt',$cnt + 1);
		}
if(isset($cnt)) {$__VAR_DUMP_MOD_skill357_VARS_cnt = $cnt; unset($cnt); } else {$__VAR_DUMP_MOD_skill357_VARS_cnt = NULL;} 
		//======== Start of contents from mod skill355 ========
		do{
			$___TMP_MOD_skill355_FUNC_itemmix_success_RET = NULL;

		
		
		if ($itm0=='概念武装『破则』' && \skillbase\skill_query(355)){
			$cnt = (int)\skillbase\skill_getvalue(355,'cnt');
			\skillbase\skill_setvalue(355,'cnt',$cnt + 1);
		}
if(isset($cnt)) {$__VAR_DUMP_MOD_skill355_VARS_cnt = $cnt; unset($cnt); } else {$__VAR_DUMP_MOD_skill355_VARS_cnt = NULL;} 
		//======== Start of contents from mod skill354 ========
		do{
			$___TMP_MOD_skill354_FUNC_itemmix_success_RET = NULL;

		
		
		if ($itm0=='绝冲大剑【神威】' && \skillbase\skill_query(354)){
			$cnt = (int)\skillbase\skill_getvalue(354,'cnt');
			\skillbase\skill_setvalue(354,'cnt',$cnt + 1);
		}
if(isset($cnt)) {$__VAR_DUMP_MOD_skill354_VARS_cnt = $cnt; unset($cnt); } else {$__VAR_DUMP_MOD_skill354_VARS_cnt = NULL;} 
		//======== Start of contents from mod skill353 ========
		do{
			$___TMP_MOD_skill353_FUNC_itemmix_success_RET = NULL;

		
		
		if ($itm0=='★一发逆转神话★' && \skillbase\skill_query(353)){
			$cnt = (int)\skillbase\skill_getvalue(353,'cnt');
			\skillbase\skill_setvalue(353,'cnt',$cnt + 1);
		}
if(isset($cnt)) {$__VAR_DUMP_MOD_skill353_VARS_cnt = $cnt; unset($cnt); } else {$__VAR_DUMP_MOD_skill353_VARS_cnt = NULL;} 
		//======== Start of contents from mod skill304 ========
		do{
			$___TMP_MOD_skill304_FUNC_itemmix_success_RET = NULL;

		
		
		if (($itm0=="【KEY系生命弹】" || $itm0=="【KEY系未来弹】") && \skillbase\skill_query(304)){
			$cnt = (int)\skillbase\skill_getvalue(304,'cnt');
			\skillbase\skill_setvalue(304,'cnt',$cnt + 1);
		}
if(isset($cnt)) {$__VAR_DUMP_MOD_skill304_VARS_cnt = $cnt; unset($cnt); } else {$__VAR_DUMP_MOD_skill304_VARS_cnt = NULL;} 
		//======== Start of contents from mod skill303 ========
		do{
			$___TMP_MOD_skill303_FUNC_itemmix_success_RET = NULL;

		
		
		if ($itm0=='【KEY系燃烧弹】' && \skillbase\skill_query(303)){
			$cnt = (int)\skillbase\skill_getvalue(303,'cnt');
			\skillbase\skill_setvalue(303,'cnt',$cnt + 1);
		}
if(isset($cnt)) {$__VAR_DUMP_MOD_skill303_VARS_cnt = $cnt; unset($cnt); } else {$__VAR_DUMP_MOD_skill303_VARS_cnt = NULL;} 
		//======== Start of contents from mod skill302 ========
		do{
			$___TMP_MOD_skill302_FUNC_itemmix_success_RET = NULL;

		
		
		if ($itm0=='【KEY系催泪弹】' && \skillbase\skill_query(302)){
			$cnt = (int)\skillbase\skill_getvalue(302,'cnt');
			\skillbase\skill_setvalue(302,'cnt',$cnt + 1);
		}
		//======== Start of contents from mod skill97 ========
		do{
			$___TMP_MOD_skill97_FUNC_itemmix_success_RET = NULL;

		
		\skill97\skill97_check ();
		//======== Start of contents from mod skill99 ========
		do{
			$___TMP_MOD_skill99_FUNC_itemmix_success_RET = NULL;

		
		\skill99\skill99_check ();
		//======== Start of contents from mod skill98 ========
		do{
			$___TMP_MOD_skill98_FUNC_itemmix_success_RET = NULL;

		
		\skill98\skill98_check ();
		//======== Start of contents from mod skill101 ========
		do{
			$___TMP_MOD_skill101_FUNC_itemmix_success_RET = NULL;

		
		\skill101\skill101_check ();
		//======== Start of contents from mod skill100 ========
		do{
			$___TMP_MOD_skill100_FUNC_itemmix_success_RET = NULL;

		
		\skill100\skill100_check ();
		//======== Start of contents from mod tutorial ========
		do{
			$___TMP_MOD_tutorial_FUNC_itemmix_success_RET = NULL;

		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
		if($gametype == 17) {
			$ct = \tutorial\get_tutorial ();
			if($ct['object']=='itemmix' && $itm0 == $ct['obj2']['item']){
				\tutorial\tutorial_pushforward_process ();
			}
		}
		//======== Start of contents from mod ending ========
		do{
			$___TMP_MOD_ending_FUNC_itemmix_success_RET = NULL;

		
		if('『C.H.A.O.S』' == get_var_in_module('itm0','player') && defined('MOD_SKILL1003')) {
			\skillbase\skill_setvalue(1003,'chaos_success',1);
		}
		//======== Start of contents from mod attrbase ========
		do{
			$___TMP_MOD_attrbase_FUNC_itemmix_success_RET = NULL;

		
		
		$itmsk0 = \attrbase\config_process_encode_comp_itmsk ($itmsk0);
		//======== Start of contents from mod skill20 ========
		do{
			$___TMP_MOD_skill20_FUNC_itemmix_success_RET = NULL;

		
		
		if(\skillbase\skill_query(20) && (strpos($itmk0,'WD') === 0)&&($itms0 !== $nosta))
			$itms0 = ceil($itms0*1.5);
		//======== Start of contents from mod skill581 ========
		do{
			$___TMP_MOD_skill581_FUNC_itemmix_success_RET = NULL;

		
		
		
		if (\skillbase\skill_query(581,$sdata) && \skill581\check_unlocked581 ($sdata))
		{
			if ((strpos($wepk,'WK') === 0) && (strpos($itmk0,'H') === 0) && ($itms0 !== $nosta))
			{
				do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
				$itms0 = ceil($itms0 * 2);
				$log .= "<span class=\"yellow b\">在你精妙的刀工下，食材如同活了过来一般！</span><br>你制作的补给品数量增加了。<br>";
			}
		}
		//======== Start of contents from mod skill431 ========
		do{
			$___TMP_MOD_skill431_FUNC_itemmix_success_RET = NULL;

		
		if(\skillbase\skill_query(431)){
			do { global $___LOCAL_SKILL431__VARS__skill431_skillup,$___LOCAL_SKILL431__VARS__skill431_expup; $skill431_skillup=&$___LOCAL_SKILL431__VARS__skill431_skillup; $skill431_expup=&$___LOCAL_SKILL431__VARS__skill431_expup;   } while (0);
			foreach(Array('wp','wk','wc','wg','wd','wf') as $v){
				if('wd' == $v) ${$v} += $skill431_skillup - 1;
				else ${$v} += $skill431_skillup;
			}
			\lvlctl\getexp($skill431_expup);
		}
		//======== Start of contents from mod skill320 ========
		do{
			$___TMP_MOD_skill320_FUNC_itemmix_success_RET = NULL;

		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;  global $___LOCAL_MAP__VARS__all_plsno_cache,$___LOCAL_MAP__VARS__areainterval,$___LOCAL_MAP__VARS__areaadd,$___LOCAL_MAP__VARS__areawarntime,$___LOCAL_MAP__VARS__arealimit,$___LOCAL_MAP__VARS__areaesc,$___LOCAL_MAP__VARS__area_on_start,$___LOCAL_MAP__VARS__dangerous_zone,$___LOCAL_MAP__VARS__plsinfo,$___LOCAL_MAP__VARS__plsinfo_o, $___LOCAL_MAP__VARS__plsinfo_disp,$___LOCAL_MAP__VARS__plsinfo_for_short,$___LOCAL_MAP__VARS__xyinfo,$___LOCAL_MAP__VARS__areainfo; $all_plsno_cache=&$___LOCAL_MAP__VARS__all_plsno_cache; $areainterval=&$___LOCAL_MAP__VARS__areainterval; $areaadd=&$___LOCAL_MAP__VARS__areaadd; $areawarntime=&$___LOCAL_MAP__VARS__areawarntime; $arealimit=&$___LOCAL_MAP__VARS__arealimit; $areaesc=&$___LOCAL_MAP__VARS__areaesc; $area_on_start=&$___LOCAL_MAP__VARS__area_on_start; $dangerous_zone=&$___LOCAL_MAP__VARS__dangerous_zone; $plsinfo=&$___LOCAL_MAP__VARS__plsinfo; $plsinfo_o=&$___LOCAL_MAP__VARS__plsinfo_o;  $plsinfo_disp=&$___LOCAL_MAP__VARS__plsinfo_disp; $plsinfo_for_short=&$___LOCAL_MAP__VARS__plsinfo_for_short; $xyinfo=&$___LOCAL_MAP__VARS__xyinfo; $areainfo=&$___LOCAL_MAP__VARS__areainfo;   } while (0);
		if ($itm0=="【KEY系催泪弹】"){
			$x=(int)\skillbase\skill_getvalue(320,'cnt');
			$x++;
			\skillbase\skill_setvalue(320,'cnt',$x);
		}
if(isset($x)) {$__VAR_DUMP_MOD_skill320_VARS_x = $x; unset($x); } else {$__VAR_DUMP_MOD_skill320_VARS_x = NULL;} 
		//======== Start of contents from mod skill319 ========
		do{
			$___TMP_MOD_skill319_FUNC_itemmix_success_RET = NULL;

		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;  global $___LOCAL_MAP__VARS__all_plsno_cache,$___LOCAL_MAP__VARS__areainterval,$___LOCAL_MAP__VARS__areaadd,$___LOCAL_MAP__VARS__areawarntime,$___LOCAL_MAP__VARS__arealimit,$___LOCAL_MAP__VARS__areaesc,$___LOCAL_MAP__VARS__area_on_start,$___LOCAL_MAP__VARS__dangerous_zone,$___LOCAL_MAP__VARS__plsinfo,$___LOCAL_MAP__VARS__plsinfo_o, $___LOCAL_MAP__VARS__plsinfo_disp,$___LOCAL_MAP__VARS__plsinfo_for_short,$___LOCAL_MAP__VARS__xyinfo,$___LOCAL_MAP__VARS__areainfo; $all_plsno_cache=&$___LOCAL_MAP__VARS__all_plsno_cache; $areainterval=&$___LOCAL_MAP__VARS__areainterval; $areaadd=&$___LOCAL_MAP__VARS__areaadd; $areawarntime=&$___LOCAL_MAP__VARS__areawarntime; $arealimit=&$___LOCAL_MAP__VARS__arealimit; $areaesc=&$___LOCAL_MAP__VARS__areaesc; $area_on_start=&$___LOCAL_MAP__VARS__area_on_start; $dangerous_zone=&$___LOCAL_MAP__VARS__dangerous_zone; $plsinfo=&$___LOCAL_MAP__VARS__plsinfo; $plsinfo_o=&$___LOCAL_MAP__VARS__plsinfo_o;  $plsinfo_disp=&$___LOCAL_MAP__VARS__plsinfo_disp; $plsinfo_for_short=&$___LOCAL_MAP__VARS__plsinfo_for_short; $xyinfo=&$___LOCAL_MAP__VARS__xyinfo; $areainfo=&$___LOCAL_MAP__VARS__areainfo;   } while (0);
		if (strlen($itmk0)>=4){
			$x=(int)\skillbase\skill_getvalue(319,'cnt');
			$x++;
			\skillbase\skill_setvalue(319,'cnt',$x);
		}
if(isset($x)) {$__VAR_DUMP_MOD_skill319_VARS_x = $x; unset($x); } else {$__VAR_DUMP_MOD_skill319_VARS_x = NULL;} 
		//======== Start of contents from mod skill317 ========
		do{
			$___TMP_MOD_skill317_FUNC_itemmix_success_RET = NULL;

		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;  global $___LOCAL_MAP__VARS__all_plsno_cache,$___LOCAL_MAP__VARS__areainterval,$___LOCAL_MAP__VARS__areaadd,$___LOCAL_MAP__VARS__areawarntime,$___LOCAL_MAP__VARS__arealimit,$___LOCAL_MAP__VARS__areaesc,$___LOCAL_MAP__VARS__area_on_start,$___LOCAL_MAP__VARS__dangerous_zone,$___LOCAL_MAP__VARS__plsinfo,$___LOCAL_MAP__VARS__plsinfo_o, $___LOCAL_MAP__VARS__plsinfo_disp,$___LOCAL_MAP__VARS__plsinfo_for_short,$___LOCAL_MAP__VARS__xyinfo,$___LOCAL_MAP__VARS__areainfo; $all_plsno_cache=&$___LOCAL_MAP__VARS__all_plsno_cache; $areainterval=&$___LOCAL_MAP__VARS__areainterval; $areaadd=&$___LOCAL_MAP__VARS__areaadd; $areawarntime=&$___LOCAL_MAP__VARS__areawarntime; $arealimit=&$___LOCAL_MAP__VARS__arealimit; $areaesc=&$___LOCAL_MAP__VARS__areaesc; $area_on_start=&$___LOCAL_MAP__VARS__area_on_start; $dangerous_zone=&$___LOCAL_MAP__VARS__dangerous_zone; $plsinfo=&$___LOCAL_MAP__VARS__plsinfo; $plsinfo_o=&$___LOCAL_MAP__VARS__plsinfo_o;  $plsinfo_disp=&$___LOCAL_MAP__VARS__plsinfo_disp; $plsinfo_for_short=&$___LOCAL_MAP__VARS__plsinfo_for_short; $xyinfo=&$___LOCAL_MAP__VARS__xyinfo; $areainfo=&$___LOCAL_MAP__VARS__areainfo;   } while (0);
		if (\itemmain\check_in_itmsk('x', $itmsk0)){
			$x=(int)\skillbase\skill_getvalue(317,'cnt');
			$x++;
			\skillbase\skill_setvalue(317,'cnt',$x);
		}
		//======== Start of contents from mod skill309 ========
		do{
			$___TMP_MOD_skill309_FUNC_itemmix_success_RET = NULL;

		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;  global $___LOCAL_MAP__VARS__all_plsno_cache,$___LOCAL_MAP__VARS__areainterval,$___LOCAL_MAP__VARS__areaadd,$___LOCAL_MAP__VARS__areawarntime,$___LOCAL_MAP__VARS__arealimit,$___LOCAL_MAP__VARS__areaesc,$___LOCAL_MAP__VARS__area_on_start,$___LOCAL_MAP__VARS__dangerous_zone,$___LOCAL_MAP__VARS__plsinfo,$___LOCAL_MAP__VARS__plsinfo_o, $___LOCAL_MAP__VARS__plsinfo_disp,$___LOCAL_MAP__VARS__plsinfo_for_short,$___LOCAL_MAP__VARS__xyinfo,$___LOCAL_MAP__VARS__areainfo; $all_plsno_cache=&$___LOCAL_MAP__VARS__all_plsno_cache; $areainterval=&$___LOCAL_MAP__VARS__areainterval; $areaadd=&$___LOCAL_MAP__VARS__areaadd; $areawarntime=&$___LOCAL_MAP__VARS__areawarntime; $arealimit=&$___LOCAL_MAP__VARS__arealimit; $areaesc=&$___LOCAL_MAP__VARS__areaesc; $area_on_start=&$___LOCAL_MAP__VARS__area_on_start; $dangerous_zone=&$___LOCAL_MAP__VARS__dangerous_zone; $plsinfo=&$___LOCAL_MAP__VARS__plsinfo; $plsinfo_o=&$___LOCAL_MAP__VARS__plsinfo_o;  $plsinfo_disp=&$___LOCAL_MAP__VARS__plsinfo_disp; $plsinfo_for_short=&$___LOCAL_MAP__VARS__plsinfo_for_short; $xyinfo=&$___LOCAL_MAP__VARS__xyinfo; $areainfo=&$___LOCAL_MAP__VARS__areainfo;   } while (0);
		if ($itm0=="火水木金土符『贤者之石』"){
			if ((int)(\skillbase\skill_getvalue(309,'cnt'))==0)
				\skillbase\skill_setvalue(309,'cnt',$now-$starttime);
		}
		//======== Start of contents from mod skill308 ========
		do{
			$___TMP_MOD_skill308_FUNC_itemmix_success_RET = NULL;

		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;  global $___LOCAL_MAP__VARS__all_plsno_cache,$___LOCAL_MAP__VARS__areainterval,$___LOCAL_MAP__VARS__areaadd,$___LOCAL_MAP__VARS__areawarntime,$___LOCAL_MAP__VARS__arealimit,$___LOCAL_MAP__VARS__areaesc,$___LOCAL_MAP__VARS__area_on_start,$___LOCAL_MAP__VARS__dangerous_zone,$___LOCAL_MAP__VARS__plsinfo,$___LOCAL_MAP__VARS__plsinfo_o, $___LOCAL_MAP__VARS__plsinfo_disp,$___LOCAL_MAP__VARS__plsinfo_for_short,$___LOCAL_MAP__VARS__xyinfo,$___LOCAL_MAP__VARS__areainfo; $all_plsno_cache=&$___LOCAL_MAP__VARS__all_plsno_cache; $areainterval=&$___LOCAL_MAP__VARS__areainterval; $areaadd=&$___LOCAL_MAP__VARS__areaadd; $areawarntime=&$___LOCAL_MAP__VARS__areawarntime; $arealimit=&$___LOCAL_MAP__VARS__arealimit; $areaesc=&$___LOCAL_MAP__VARS__areaesc; $area_on_start=&$___LOCAL_MAP__VARS__area_on_start; $dangerous_zone=&$___LOCAL_MAP__VARS__dangerous_zone; $plsinfo=&$___LOCAL_MAP__VARS__plsinfo; $plsinfo_o=&$___LOCAL_MAP__VARS__plsinfo_o;  $plsinfo_disp=&$___LOCAL_MAP__VARS__plsinfo_disp; $plsinfo_for_short=&$___LOCAL_MAP__VARS__plsinfo_for_short; $xyinfo=&$___LOCAL_MAP__VARS__xyinfo; $areainfo=&$___LOCAL_MAP__VARS__areainfo;   } while (0);
		if ($itm0=="【KEY系催泪弹】"){
			if ((int)(\skillbase\skill_getvalue(308,'cnt'))==0)
				\skillbase\skill_setvalue(308,'cnt',$now-$starttime);
		}
		//======== Start of contents from mod skill413 ========
		do{
			$___TMP_MOD_skill413_FUNC_itemmix_success_RET = NULL;

		
		
		if(\skillbase\skill_query(413) && (strpos($itm0,'【KEY系') === 0)&&($itms0 !== $nosta))
			$itms0 = ceil($itms0*1.2);
		//======== Start of contents from mod itemmix ========
		do{
			$___TMP_MOD_itemmix_FUNC_itemmix_success_RET = NULL;

		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;  global $___LOCAL_ITEMMIX__VARS__mix_type,$___LOCAL_ITEMMIX__VARS__itmname_ignore,$___LOCAL_ITEMMIX__VARS__mixinfo; $mix_type=&$___LOCAL_ITEMMIX__VARS__mix_type; $itmname_ignore=&$___LOCAL_ITEMMIX__VARS__itmname_ignore; $mixinfo=&$___LOCAL_ITEMMIX__VARS__mixinfo;   } while (0);
		$itmstr = $uip['itmstr'];
		
		
		$tpstr = (empty($uip['mixtp']) || $uip['mixtp']==$mix_type['normal']) ? '' : $mix_type[$uip['mixtp']];
		
		$log .= "<span class=\"yellow b\">$itmstr</span>{$tpstr}合成了<span class=\"yellow b\">{$itm0}</span><br>";
		addnews($now,'itemmix',$name,$itm0,$tpstr);
	
		$wd+=1;
		if((strpos($itmk0,'H') === 0)&&($club == 16)&&($itms0 !== $nosta)){ $itms0 = ceil($itms0*2); }
		elseif(($itmk0 == 'EE' || $itmk0 == 'ER') && ($club == 7)){ $itme0 *= 5; }

		\itemmain\itemget();
		}while(0);
		//======== End of contents from mod itemmix ========
 
			
		$___TMP_MOD_itemmix_FUNC_itemmix_success_RET;
		}while(0);
		//======== End of contents from mod skill413 ========

		$___TMP_MOD_skill413_FUNC_itemmix_success_RET;	
		}while(0);
		//======== End of contents from mod skill308 ========

		$___TMP_MOD_skill308_FUNC_itemmix_success_RET;	
		}while(0);
		//======== End of contents from mod skill309 ========

		$___TMP_MOD_skill309_FUNC_itemmix_success_RET;	
		}while(0);
		//======== End of contents from mod skill317 ========

$x = $__VAR_DUMP_MOD_skill319_VARS_x; 
		$___TMP_MOD_skill317_FUNC_itemmix_success_RET;	
		}while(0);
		//======== End of contents from mod skill319 ========

$x = $__VAR_DUMP_MOD_skill320_VARS_x; 
		$___TMP_MOD_skill319_FUNC_itemmix_success_RET;	
		}while(0);
		//======== End of contents from mod skill320 ========

		$___TMP_MOD_skill320_FUNC_itemmix_success_RET;
		}while(0);
		//======== End of contents from mod skill431 ========

		$___TMP_MOD_skill431_FUNC_itemmix_success_RET;
		}while(0);
		//======== End of contents from mod skill581 ========
 
			
		$___TMP_MOD_skill581_FUNC_itemmix_success_RET;
		}while(0);
		//======== End of contents from mod skill20 ========

		$___TMP_MOD_skill20_FUNC_itemmix_success_RET;
		}while(0);
		//======== End of contents from mod attrbase ========

		$___TMP_MOD_attrbase_FUNC_itemmix_success_RET;
		}while(0);
		//======== End of contents from mod ending ========

		$___TMP_MOD_ending_FUNC_itemmix_success_RET;
		}while(0);
		//======== End of contents from mod tutorial ========

		$___TMP_MOD_tutorial_FUNC_itemmix_success_RET;
		}while(0);
		//======== End of contents from mod skill100 ========

		$___TMP_MOD_skill100_FUNC_itemmix_success_RET;
		}while(0);
		//======== End of contents from mod skill101 ========

		$___TMP_MOD_skill101_FUNC_itemmix_success_RET;
		}while(0);
		//======== End of contents from mod skill98 ========

		$___TMP_MOD_skill98_FUNC_itemmix_success_RET;
		}while(0);
		//======== End of contents from mod skill99 ========

		$___TMP_MOD_skill99_FUNC_itemmix_success_RET;
		}while(0);
		//======== End of contents from mod skill97 ========

		$___TMP_MOD_skill97_FUNC_itemmix_success_RET;	
		}while(0);
		//======== End of contents from mod skill302 ========

$cnt = $__VAR_DUMP_MOD_skill303_VARS_cnt; 
		$___TMP_MOD_skill302_FUNC_itemmix_success_RET;	
		}while(0);
		//======== End of contents from mod skill303 ========

$cnt = $__VAR_DUMP_MOD_skill304_VARS_cnt; 
		$___TMP_MOD_skill303_FUNC_itemmix_success_RET;	
		}while(0);
		//======== End of contents from mod skill304 ========

$cnt = $__VAR_DUMP_MOD_skill353_VARS_cnt; 
		$___TMP_MOD_skill304_FUNC_itemmix_success_RET;	
		}while(0);
		//======== End of contents from mod skill353 ========

$cnt = $__VAR_DUMP_MOD_skill354_VARS_cnt; 
		$___TMP_MOD_skill353_FUNC_itemmix_success_RET;	
		}while(0);
		//======== End of contents from mod skill354 ========

$cnt = $__VAR_DUMP_MOD_skill355_VARS_cnt; 
		$___TMP_MOD_skill354_FUNC_itemmix_success_RET;	
		}while(0);
		//======== End of contents from mod skill355 ========

$cnt = $__VAR_DUMP_MOD_skill357_VARS_cnt; 
		$___TMP_MOD_skill355_FUNC_itemmix_success_RET;	
		}while(0);
		//======== End of contents from mod skill357 ========

$cnt = $__VAR_DUMP_MOD_skill358_VARS_cnt; 
		$___TMP_MOD_skill357_FUNC_itemmix_success_RET;	
		}while(0);
		//======== End of contents from mod skill358 ========

		$___TMP_MOD_skill358_FUNC_itemmix_success_RET;
		if(\skillbase\skill_query(373)){
			$cnt = (int)\skillbase\skill_getvalue(373,'cnt') + 1;
			\skillbase\skill_setvalue(373,'cnt',$cnt);
		}
		}while(0);
		//======== End of contents from mod skill373 ========


		
		
		$___TMP_MOD_skill373_FUNC_itemmix_success_RET;
		do { global $___LOCAL_SMARTMIX__VARS__mix_successful_flag,$___LOCAL_SMARTMIX__VARS__tmp_itemselect; $mix_successful_flag=&$___LOCAL_SMARTMIX__VARS__mix_successful_flag; $tmp_itemselect=&$___LOCAL_SMARTMIX__VARS__tmp_itemselect;   } while (0);
		$mix_successful_flag = 1;
		}while(0);
		//======== End of contents from mod smartmix ========

		$___TMP_MOD_smartmix_FUNC_itemmix_success_RET;
	
	}
	
	
	function use_skcore_success(&$pa)
	{
		
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;   } while (0);
		if (20 == $gametype)
		{
			if (\skillbase\skill_query(951,$pa))
			{
				$sc_count = (int)\skillbase\skill_getvalue(951,'sc_count',$pa);
				\skillbase\skill_setvalue(951,'sc_count',$sc_count+1,$pa);
			}
		}
		//======== Start of contents from mod item_randskills ========
		do{
			$___TMP_MOD_item_randskills_FUNC_use_skcore_success_RET = NULL;

		
		}while(0);
		//======== End of contents from mod item_randskills ========

		$___TMP_MOD_item_randskills_FUNC_use_skcore_success_RET;
	
	}
	
	function itemuse(&$theitem)
	{
		
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;  global $___LOCAL_PLAYER__VARS__ss,$___LOCAL_PLAYER__VARS__db_player_structure,$___LOCAL_PLAYER__VARS__db_player_structure_types,$___LOCAL_PLAYER__VARS__gamedata,$___LOCAL_PLAYER__VARS__cmd,$___LOCAL_PLAYER__VARS__main,$___LOCAL_PLAYER__VARS__sdata,$___LOCAL_PLAYER__VARS__fog,$___LOCAL_PLAYER__VARS__upexp,$___LOCAL_PLAYER__VARS__lvlupexp, $___LOCAL_PLAYER__VARS__iconImg,$___LOCAL_PLAYER__VARS__iconImgB,$___LOCAL_PLAYER__VARS__iconImgBwidth,$___LOCAL_PLAYER__VARS__ardef,$___LOCAL_PLAYER__VARS__hpcolor,$___LOCAL_PLAYER__VARS__spcolor,$___LOCAL_PLAYER__VARS__newhpimg,$___LOCAL_PLAYER__VARS__newspimg,$___LOCAL_PLAYER__VARS__splt,$___LOCAL_PLAYER__VARS__hplt, $___LOCAL_PLAYER__VARS__tpldata,$___LOCAL_PLAYER__VARS__icon_list,$___LOCAL_PLAYER__VARS__icon_list_contents_to_frontend,$___LOCAL_PLAYER__VARS__typeinfo,$___LOCAL_PLAYER__VARS__killmsginfo,$___LOCAL_PLAYER__VARS__lwinfo,$___LOCAL_PLAYER__VARS__sexinfo,$___LOCAL_PLAYER__VARS__equip_list,$___LOCAL_PLAYER__VARS__battle_equip_list,$___LOCAL_PLAYER__VARS__pc_icon_range, $___LOCAL_PLAYER__VARS__pid,$___LOCAL_PLAYER__VARS__type,$___LOCAL_PLAYER__VARS__name,$___LOCAL_PLAYER__VARS__pass,$___LOCAL_PLAYER__VARS__ip,$___LOCAL_PLAYER__VARS__motto,$___LOCAL_PLAYER__VARS__killmsg,$___LOCAL_PLAYER__VARS__lastword,$___LOCAL_PLAYER__VARS__winner_flag,$___LOCAL_PLAYER__VARS__player_dead_flag, $___LOCAL_PLAYER__VARS__corpse_clear_flag,$___LOCAL_PLAYER__VARS__gd,$___LOCAL_PLAYER__VARS__sNo,$___LOCAL_PLAYER__VARS__club,$___LOCAL_PLAYER__VARS__validtime,$___LOCAL_PLAYER__VARS__endtime,$___LOCAL_PLAYER__VARS__cdsec,$___LOCAL_PLAYER__VARS__cdmsec,$___LOCAL_PLAYER__VARS__cdtime,$___LOCAL_PLAYER__VARS__action, $___LOCAL_PLAYER__VARS__a_actionnum,$___LOCAL_PLAYER__VARS__v_actionnum,$___LOCAL_PLAYER__VARS__hp,$___LOCAL_PLAYER__VARS__mhp,$___LOCAL_PLAYER__VARS__sp,$___LOCAL_PLAYER__VARS__msp,$___LOCAL_PLAYER__VARS__mss,$___LOCAL_PLAYER__VARS__att,$___LOCAL_PLAYER__VARS__def,$___LOCAL_PLAYER__VARS__pls, $___LOCAL_PLAYER__VARS__lvl,$___LOCAL_PLAYER__VARS__exp,$___LOCAL_PLAYER__VARS__money,$___LOCAL_PLAYER__VARS__rp,$___LOCAL_PLAYER__VARS__bid,$___LOCAL_PLAYER__VARS__inf,$___LOCAL_PLAYER__VARS__rage,$___LOCAL_PLAYER__VARS__pose,$___LOCAL_PLAYER__VARS__tactic,$___LOCAL_PLAYER__VARS__killnum, $___LOCAL_PLAYER__VARS__npckillnum,$___LOCAL_PLAYER__VARS__state,$___LOCAL_PLAYER__VARS__skillpoint,$___LOCAL_PLAYER__VARS__flare,$___LOCAL_PLAYER__VARS__wp,$___LOCAL_PLAYER__VARS__wk,$___LOCAL_PLAYER__VARS__wg,$___LOCAL_PLAYER__VARS__wc,$___LOCAL_PLAYER__VARS__wd,$___LOCAL_PLAYER__VARS__wf, $___LOCAL_PLAYER__VARS__icon,$___LOCAL_PLAYER__VARS__teamID,$___LOCAL_PLAYER__VARS__teamPass,$___LOCAL_PLAYER__VARS__card,$___LOCAL_PLAYER__VARS__cardname,$___LOCAL_PLAYER__VARS__wep,$___LOCAL_PLAYER__VARS__wepk,$___LOCAL_PLAYER__VARS__wepe,$___LOCAL_PLAYER__VARS__weps,$___LOCAL_PLAYER__VARS__wepsk, $___LOCAL_PLAYER__VARS__arb,$___LOCAL_PLAYER__VARS__arbk,$___LOCAL_PLAYER__VARS__arbe,$___LOCAL_PLAYER__VARS__arbs,$___LOCAL_PLAYER__VARS__arbsk,$___LOCAL_PLAYER__VARS__arh,$___LOCAL_PLAYER__VARS__arhk,$___LOCAL_PLAYER__VARS__arhe,$___LOCAL_PLAYER__VARS__arhs,$___LOCAL_PLAYER__VARS__arhsk, $___LOCAL_PLAYER__VARS__ara,$___LOCAL_PLAYER__VARS__arak,$___LOCAL_PLAYER__VARS__arae,$___LOCAL_PLAYER__VARS__aras,$___LOCAL_PLAYER__VARS__arask,$___LOCAL_PLAYER__VARS__arf,$___LOCAL_PLAYER__VARS__arfk,$___LOCAL_PLAYER__VARS__arfe,$___LOCAL_PLAYER__VARS__arfs,$___LOCAL_PLAYER__VARS__arfsk, $___LOCAL_PLAYER__VARS__art,$___LOCAL_PLAYER__VARS__artk,$___LOCAL_PLAYER__VARS__arte,$___LOCAL_PLAYER__VARS__arts,$___LOCAL_PLAYER__VARS__artsk,$___LOCAL_PLAYER__VARS__itm0,$___LOCAL_PLAYER__VARS__itmk0,$___LOCAL_PLAYER__VARS__itme0,$___LOCAL_PLAYER__VARS__itms0,$___LOCAL_PLAYER__VARS__itmsk0, $___LOCAL_PLAYER__VARS__itm1,$___LOCAL_PLAYER__VARS__itmk1,$___LOCAL_PLAYER__VARS__itme1,$___LOCAL_PLAYER__VARS__itms1,$___LOCAL_PLAYER__VARS__itmsk1,$___LOCAL_PLAYER__VARS__itm2,$___LOCAL_PLAYER__VARS__itmk2,$___LOCAL_PLAYER__VARS__itme2,$___LOCAL_PLAYER__VARS__itms2,$___LOCAL_PLAYER__VARS__itmsk2, $___LOCAL_PLAYER__VARS__itm3,$___LOCAL_PLAYER__VARS__itmk3,$___LOCAL_PLAYER__VARS__itme3,$___LOCAL_PLAYER__VARS__itms3,$___LOCAL_PLAYER__VARS__itmsk3,$___LOCAL_PLAYER__VARS__itm4,$___LOCAL_PLAYER__VARS__itmk4,$___LOCAL_PLAYER__VARS__itme4,$___LOCAL_PLAYER__VARS__itms4,$___LOCAL_PLAYER__VARS__itmsk4, $___LOCAL_PLAYER__VARS__itm5,$___LOCAL_PLAYER__VARS__itmk5,$___LOCAL_PLAYER__VARS__itme5,$___LOCAL_PLAYER__VARS__itms5,$___LOCAL_PLAYER__VARS__itmsk5,$___LOCAL_PLAYER__VARS__itm6,$___LOCAL_PLAYER__VARS__itmk6,$___LOCAL_PLAYER__VARS__itme6,$___LOCAL_PLAYER__VARS__itms6,$___LOCAL_PLAYER__VARS__itmsk6, $___LOCAL_PLAYER__VARS__searchmemory,$___LOCAL_PLAYER__VARS__nskill,$___LOCAL_PLAYER__VARS__nskillpara; $ss=&$___LOCAL_PLAYER__VARS__ss; $db_player_structure=&$___LOCAL_PLAYER__VARS__db_player_structure; $db_player_structure_types=&$___LOCAL_PLAYER__VARS__db_player_structure_types; $gamedata=&$___LOCAL_PLAYER__VARS__gamedata; $cmd=&$___LOCAL_PLAYER__VARS__cmd; $main=&$___LOCAL_PLAYER__VARS__main; $sdata=&$___LOCAL_PLAYER__VARS__sdata; $fog=&$___LOCAL_PLAYER__VARS__fog; $upexp=&$___LOCAL_PLAYER__VARS__upexp; $lvlupexp=&$___LOCAL_PLAYER__VARS__lvlupexp;  $iconImg=&$___LOCAL_PLAYER__VARS__iconImg; $iconImgB=&$___LOCAL_PLAYER__VARS__iconImgB; $iconImgBwidth=&$___LOCAL_PLAYER__VARS__iconImgBwidth; $ardef=&$___LOCAL_PLAYER__VARS__ardef; $hpcolor=&$___LOCAL_PLAYER__VARS__hpcolor; $spcolor=&$___LOCAL_PLAYER__VARS__spcolor; $newhpimg=&$___LOCAL_PLAYER__VARS__newhpimg; $newspimg=&$___LOCAL_PLAYER__VARS__newspimg; $splt=&$___LOCAL_PLAYER__VARS__splt; $hplt=&$___LOCAL_PLAYER__VARS__hplt;  $tpldata=&$___LOCAL_PLAYER__VARS__tpldata; $icon_list=&$___LOCAL_PLAYER__VARS__icon_list; $icon_list_contents_to_frontend=&$___LOCAL_PLAYER__VARS__icon_list_contents_to_frontend; $typeinfo=&$___LOCAL_PLAYER__VARS__typeinfo; $killmsginfo=&$___LOCAL_PLAYER__VARS__killmsginfo; $lwinfo=&$___LOCAL_PLAYER__VARS__lwinfo; $sexinfo=&$___LOCAL_PLAYER__VARS__sexinfo; $equip_list=&$___LOCAL_PLAYER__VARS__equip_list; $battle_equip_list=&$___LOCAL_PLAYER__VARS__battle_equip_list; $pc_icon_range=&$___LOCAL_PLAYER__VARS__pc_icon_range;  $pid=&$___LOCAL_PLAYER__VARS__pid; $type=&$___LOCAL_PLAYER__VARS__type; $name=&$___LOCAL_PLAYER__VARS__name; $pass=&$___LOCAL_PLAYER__VARS__pass; $ip=&$___LOCAL_PLAYER__VARS__ip; $motto=&$___LOCAL_PLAYER__VARS__motto; $killmsg=&$___LOCAL_PLAYER__VARS__killmsg; $lastword=&$___LOCAL_PLAYER__VARS__lastword; $winner_flag=&$___LOCAL_PLAYER__VARS__winner_flag; $player_dead_flag=&$___LOCAL_PLAYER__VARS__player_dead_flag;  $corpse_clear_flag=&$___LOCAL_PLAYER__VARS__corpse_clear_flag; $gd=&$___LOCAL_PLAYER__VARS__gd; $sNo=&$___LOCAL_PLAYER__VARS__sNo; $club=&$___LOCAL_PLAYER__VARS__club; $validtime=&$___LOCAL_PLAYER__VARS__validtime; $endtime=&$___LOCAL_PLAYER__VARS__endtime; $cdsec=&$___LOCAL_PLAYER__VARS__cdsec; $cdmsec=&$___LOCAL_PLAYER__VARS__cdmsec; $cdtime=&$___LOCAL_PLAYER__VARS__cdtime; $action=&$___LOCAL_PLAYER__VARS__action;  $a_actionnum=&$___LOCAL_PLAYER__VARS__a_actionnum; $v_actionnum=&$___LOCAL_PLAYER__VARS__v_actionnum; $hp=&$___LOCAL_PLAYER__VARS__hp; $mhp=&$___LOCAL_PLAYER__VARS__mhp; $sp=&$___LOCAL_PLAYER__VARS__sp; $msp=&$___LOCAL_PLAYER__VARS__msp; $mss=&$___LOCAL_PLAYER__VARS__mss; $att=&$___LOCAL_PLAYER__VARS__att; $def=&$___LOCAL_PLAYER__VARS__def; $pls=&$___LOCAL_PLAYER__VARS__pls;  $lvl=&$___LOCAL_PLAYER__VARS__lvl; $exp=&$___LOCAL_PLAYER__VARS__exp; $money=&$___LOCAL_PLAYER__VARS__money; $rp=&$___LOCAL_PLAYER__VARS__rp; $bid=&$___LOCAL_PLAYER__VARS__bid; $inf=&$___LOCAL_PLAYER__VARS__inf; $rage=&$___LOCAL_PLAYER__VARS__rage; $pose=&$___LOCAL_PLAYER__VARS__pose; $tactic=&$___LOCAL_PLAYER__VARS__tactic; $killnum=&$___LOCAL_PLAYER__VARS__killnum;  $npckillnum=&$___LOCAL_PLAYER__VARS__npckillnum; $state=&$___LOCAL_PLAYER__VARS__state; $skillpoint=&$___LOCAL_PLAYER__VARS__skillpoint; $flare=&$___LOCAL_PLAYER__VARS__flare; $wp=&$___LOCAL_PLAYER__VARS__wp; $wk=&$___LOCAL_PLAYER__VARS__wk; $wg=&$___LOCAL_PLAYER__VARS__wg; $wc=&$___LOCAL_PLAYER__VARS__wc; $wd=&$___LOCAL_PLAYER__VARS__wd; $wf=&$___LOCAL_PLAYER__VARS__wf;  $icon=&$___LOCAL_PLAYER__VARS__icon; $teamID=&$___LOCAL_PLAYER__VARS__teamID; $teamPass=&$___LOCAL_PLAYER__VARS__teamPass; $card=&$___LOCAL_PLAYER__VARS__card; $cardname=&$___LOCAL_PLAYER__VARS__cardname; $wep=&$___LOCAL_PLAYER__VARS__wep; $wepk=&$___LOCAL_PLAYER__VARS__wepk; $wepe=&$___LOCAL_PLAYER__VARS__wepe; $weps=&$___LOCAL_PLAYER__VARS__weps; $wepsk=&$___LOCAL_PLAYER__VARS__wepsk;  $arb=&$___LOCAL_PLAYER__VARS__arb; $arbk=&$___LOCAL_PLAYER__VARS__arbk; $arbe=&$___LOCAL_PLAYER__VARS__arbe; $arbs=&$___LOCAL_PLAYER__VARS__arbs; $arbsk=&$___LOCAL_PLAYER__VARS__arbsk; $arh=&$___LOCAL_PLAYER__VARS__arh; $arhk=&$___LOCAL_PLAYER__VARS__arhk; $arhe=&$___LOCAL_PLAYER__VARS__arhe; $arhs=&$___LOCAL_PLAYER__VARS__arhs; $arhsk=&$___LOCAL_PLAYER__VARS__arhsk;  $ara=&$___LOCAL_PLAYER__VARS__ara; $arak=&$___LOCAL_PLAYER__VARS__arak; $arae=&$___LOCAL_PLAYER__VARS__arae; $aras=&$___LOCAL_PLAYER__VARS__aras; $arask=&$___LOCAL_PLAYER__VARS__arask; $arf=&$___LOCAL_PLAYER__VARS__arf; $arfk=&$___LOCAL_PLAYER__VARS__arfk; $arfe=&$___LOCAL_PLAYER__VARS__arfe; $arfs=&$___LOCAL_PLAYER__VARS__arfs; $arfsk=&$___LOCAL_PLAYER__VARS__arfsk;  $art=&$___LOCAL_PLAYER__VARS__art; $artk=&$___LOCAL_PLAYER__VARS__artk; $arte=&$___LOCAL_PLAYER__VARS__arte; $arts=&$___LOCAL_PLAYER__VARS__arts; $artsk=&$___LOCAL_PLAYER__VARS__artsk; $itm0=&$___LOCAL_PLAYER__VARS__itm0; $itmk0=&$___LOCAL_PLAYER__VARS__itmk0; $itme0=&$___LOCAL_PLAYER__VARS__itme0; $itms0=&$___LOCAL_PLAYER__VARS__itms0; $itmsk0=&$___LOCAL_PLAYER__VARS__itmsk0;  $itm1=&$___LOCAL_PLAYER__VARS__itm1; $itmk1=&$___LOCAL_PLAYER__VARS__itmk1; $itme1=&$___LOCAL_PLAYER__VARS__itme1; $itms1=&$___LOCAL_PLAYER__VARS__itms1; $itmsk1=&$___LOCAL_PLAYER__VARS__itmsk1; $itm2=&$___LOCAL_PLAYER__VARS__itm2; $itmk2=&$___LOCAL_PLAYER__VARS__itmk2; $itme2=&$___LOCAL_PLAYER__VARS__itme2; $itms2=&$___LOCAL_PLAYER__VARS__itms2; $itmsk2=&$___LOCAL_PLAYER__VARS__itmsk2;  $itm3=&$___LOCAL_PLAYER__VARS__itm3; $itmk3=&$___LOCAL_PLAYER__VARS__itmk3; $itme3=&$___LOCAL_PLAYER__VARS__itme3; $itms3=&$___LOCAL_PLAYER__VARS__itms3; $itmsk3=&$___LOCAL_PLAYER__VARS__itmsk3; $itm4=&$___LOCAL_PLAYER__VARS__itm4; $itmk4=&$___LOCAL_PLAYER__VARS__itmk4; $itme4=&$___LOCAL_PLAYER__VARS__itme4; $itms4=&$___LOCAL_PLAYER__VARS__itms4; $itmsk4=&$___LOCAL_PLAYER__VARS__itmsk4;  $itm5=&$___LOCAL_PLAYER__VARS__itm5; $itmk5=&$___LOCAL_PLAYER__VARS__itmk5; $itme5=&$___LOCAL_PLAYER__VARS__itme5; $itms5=&$___LOCAL_PLAYER__VARS__itms5; $itmsk5=&$___LOCAL_PLAYER__VARS__itmsk5; $itm6=&$___LOCAL_PLAYER__VARS__itm6; $itmk6=&$___LOCAL_PLAYER__VARS__itmk6; $itme6=&$___LOCAL_PLAYER__VARS__itme6; $itms6=&$___LOCAL_PLAYER__VARS__itms6; $itmsk6=&$___LOCAL_PLAYER__VARS__itmsk6;  $searchmemory=&$___LOCAL_PLAYER__VARS__searchmemory; $nskill=&$___LOCAL_PLAYER__VARS__nskill; $nskillpara=&$___LOCAL_PLAYER__VARS__nskillpara;  global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
		$itm=&$theitem['itm']; $itmk=&$theitem['itmk'];
		$itme=&$theitem['itme']; $itms=&$theitem['itms']; $itmsk=&$theitem['itmsk'];	
		if (20 == $gametype)
		{
			
			if (strpos($itmk, 'EE') === 0)
			{
				$log .= "你使用了{$itm}，却发现没有可以连接上的网络。怎么会这样？<br>";
				return;
			}
			
			elseif (strpos($itmk, 'SC') === 0)
			{
				$sc_count = (int)\skillbase\skill_getvalue(951,'sc_count',$sdata);
				if ($sc_count >= 7)
				{
					$log .= "<span class=\"yellow b\">你已经使用过7个技能核心，无法再使用了。</span><br>";
					return;
				}
			}
		}
		//======== Start of contents from mod skill709 ========
		do{
			$___TMP_MOD_skill709_FUNC_itemuse_RET = NULL;

		
		if (709 === (int)\itemmain\check_in_itmsk('^wepflag', $theitem['itmsk']))
		{
			
			$temp_log = $log;
			\skill505\itemuse($theitem);
			$log = $temp_log;
			$log .= '你找回了你丢失的武器。<br>';
		}
		else \skill505\itemuse($theitem);
		}while(0);
		//======== End of contents from mod skill709 ========

		$___TMP_MOD_skill709_FUNC_itemuse_RET;
	
	}
	
	
	function post_enterbattlefield_events(&$pa)
	{
		return \skill714\post_enterbattlefield_events($pa);
	}
	
	
	function remove_task(&$pa, $taskid)
	{
if(isset($taskid)) {$__VAR_DUMP_MOD_instance10_VARS_taskid = $taskid; } else {$__VAR_DUMP_MOD_instance10_VARS_taskid = NULL;} 
		//======== Start of contents from mod skill960 ========
		do{
			$___TMP_MOD_skill960_FUNC_remove_task_RET = NULL;

		
		$taskarr = \skill960\get_taskarr ($pa);
		$taskprog = \skill960\get_taskprog ($pa);
		
		$i = array_search($taskid, $taskarr);
		if ($i !== false)
		{
			unset($taskarr[$i]);
			$taskarr = array_values($taskarr);
			$taskarr = implode('_',$taskarr);
			\skillbase\skill_setvalue(960,'taskarr',$taskarr,$pa);
			unset($taskprog[$i]);
			$taskprog = array_values($taskprog);
			$taskprog = implode('_',$taskprog);
			\skillbase\skill_setvalue(960,'taskprog',$taskprog,$pa);
		}
		}while(0);
		//======== End of contents from mod skill960 ========

$taskid = $__VAR_DUMP_MOD_instance10_VARS_taskid; unset($__VAR_DUMP_MOD_instance10_VARS_taskid);
		
		$___TMP_MOD_skill960_FUNC_remove_task_RET;
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;   } while (0);
		if (20 == $gametype)
		{
			\skill960\get_rand_task($pa, \instance10\get_newtask_rank ($pa), 1);
		}
	
	}
	
	
	function get_task_reward(&$pa, $taskid)
	{
if(isset($taskid)) {$__VAR_DUMP_MOD_instance10_VARS_taskid = $taskid; } else {$__VAR_DUMP_MOD_instance10_VARS_taskid = NULL;} 
		//======== Start of contents from mod skill960 ========
		do{
			$___TMP_MOD_skill960_FUNC_get_task_reward_RET = NULL;

		
		do { global $___LOCAL_SKILL960__VARS__invscore_available_mode,$___LOCAL_SKILL960__VARS__tasks_index,$___LOCAL_SKILL960__VARS__tasks_info; $invscore_available_mode=&$___LOCAL_SKILL960__VARS__invscore_available_mode; $tasks_index=&$___LOCAL_SKILL960__VARS__tasks_index; $tasks_info=&$___LOCAL_SKILL960__VARS__tasks_info;  global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
		if (!isset($tasks_info[$taskid]['reward'])){ $___TMP_MOD_skill960_FUNC_get_task_reward_RET = NULL;
			break; }
		foreach ($tasks_info[$taskid]['reward'] as $k => $v)
		{
			if ($k === 'money')
			{
				$pa['money'] += $v;
				$log .= "<span class=\"yellow b\">你获得了{$v}元金钱。</span><br>";
			}
			elseif ($k === 'exp')
			{		
				$log .= "<span class=\"yellow b\">你获得了{$v}点经验值。</span><br>";
				\lvlctl\getexp($v, $pa);
			}
			elseif ($k === 'invscore')
			{		
				$log .= "<span class=\"yellow b\">你获得了{$v}点调查度。</span><br>";
				$invscore = (int)\skillbase\skill_getvalue(960,'invscore',$pa);
				$invscore += $v;
				\skillbase\skill_setvalue(960,'invscore',$invscore,$pa);
			}
			elseif ($k === 'item')
			{
				if (\skillbase\skill_query(952,$pa))
				{
					foreach ($v as $theitem)
					{
						\skill952\skill952_sendin_core($theitem, $pa);
						$log .= "你获得了<span class=\"yellow b\">{$theitem['itm']}</span>。<br>";
					}
					$log .= "道具被送到了你的奖励箱中。<br>";
				}
				elseif (\searchmemory\searchmemory_available())
				{
					foreach ($v as $theitem)
					{
						$dropid = \itemmain\itemdrop_query($theitem['itm'], $theitem['itmk'], $theitem['itme'], $theitem['itms'], $theitem['itmsk'], $pa['pls']);
						$amarr = array('iid' => $dropid, 'itm' => $theitem['itm'], 'pls' => $pa['pls'], 'unseen' => 0);
						\skill1006\add_beacon($amarr, $pa);
						\player\player_save($pa);
						$log .= "<span class=\"yellow b\">{$theitem['itm']}</span>掉到了你的身旁。<br>";
					}
					$log .= "<span class=\"yellow b\">究竟是从哪儿送来的？</span><br>";
				}
			}
		}
		}while(0);
		//======== End of contents from mod skill960 ========

$taskid = $__VAR_DUMP_MOD_instance10_VARS_taskid; unset($__VAR_DUMP_MOD_instance10_VARS_taskid);
		
		$___TMP_MOD_skill960_FUNC_get_task_reward_RET;
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;   } while (0);
		if (20 == $gametype)
		{
			if (!isset($gamevars['instance10_topinv'])) $gamevars['instance10_topinv'] = 0;
			$invscore = (int)\skillbase\skill_getvalue(960,'invscore',$pa);
			if ($invscore > $gamevars['instance10_topinv'])
			{
				
				$map_unlock = floor($invscore/10) - floor($gamevars['instance10_topinv']/10);
				if ($map_unlock > 0)
				{
					do { global $___LOCAL_MAP__VARS__all_plsno_cache,$___LOCAL_MAP__VARS__areainterval,$___LOCAL_MAP__VARS__areaadd,$___LOCAL_MAP__VARS__areawarntime,$___LOCAL_MAP__VARS__arealimit,$___LOCAL_MAP__VARS__areaesc,$___LOCAL_MAP__VARS__area_on_start,$___LOCAL_MAP__VARS__dangerous_zone,$___LOCAL_MAP__VARS__plsinfo,$___LOCAL_MAP__VARS__plsinfo_o, $___LOCAL_MAP__VARS__plsinfo_disp,$___LOCAL_MAP__VARS__plsinfo_for_short,$___LOCAL_MAP__VARS__xyinfo,$___LOCAL_MAP__VARS__areainfo; $all_plsno_cache=&$___LOCAL_MAP__VARS__all_plsno_cache; $areainterval=&$___LOCAL_MAP__VARS__areainterval; $areaadd=&$___LOCAL_MAP__VARS__areaadd; $areawarntime=&$___LOCAL_MAP__VARS__areawarntime; $arealimit=&$___LOCAL_MAP__VARS__arealimit; $areaesc=&$___LOCAL_MAP__VARS__areaesc; $area_on_start=&$___LOCAL_MAP__VARS__area_on_start; $dangerous_zone=&$___LOCAL_MAP__VARS__dangerous_zone; $plsinfo=&$___LOCAL_MAP__VARS__plsinfo; $plsinfo_o=&$___LOCAL_MAP__VARS__plsinfo_o;  $plsinfo_disp=&$___LOCAL_MAP__VARS__plsinfo_disp; $plsinfo_for_short=&$___LOCAL_MAP__VARS__plsinfo_for_short; $xyinfo=&$___LOCAL_MAP__VARS__xyinfo; $areainfo=&$___LOCAL_MAP__VARS__areainfo;  global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
					$log .= "<span class=\"yellow b\">你发现了新的地点！</span><br>";
					$areanum -= 4 * $map_unlock;
					$areanum = max($areanum, 0);
				}
				$gamevars['instance10_topinv'] = $invscore;
			}
			save_gameinfo();
		}
	
	}
	
	
	function get_newtask_rank(&$pa)
	{
		
		$invscore = (int)\skillbase\skill_getvalue(960,'invscore',$pa);
		
		if ($invscore < 10) return 1;
		elseif ($invscore < 20) return 2;
		elseif ($invscore < 30) return 3;
		elseif ($invscore < 40) return 4;
		elseif ($invscore < 50) return 5;
		elseif ($invscore < 60) return 6;
		else return 7;
	}
	
}

?>