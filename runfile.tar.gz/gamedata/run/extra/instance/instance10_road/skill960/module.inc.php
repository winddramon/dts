<?php

namespace skill960
{
	////////// MODULE HEADER START ///////////////
	$___MODULE_dependency = 'skillbase clubbase sys player logger itemmain input attack npc itemmix';
	$___MODULE_dependency_optional = 'skill952 searchmemory skill1006';
	$___MODULE_conflict = '';
	$___MODULE_codelist = 'main.php config/task.config.php';
	$___MODULE_templatelist = 'profilecmd castsk960 desc';
	////////// MODULE HEADER END /////////////////
	require __INIT_MODULE__(__NAMESPACE__,__DIR__);
}

?>