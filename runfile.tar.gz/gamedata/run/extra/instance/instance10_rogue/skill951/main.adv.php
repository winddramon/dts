<?php

//记录肉鸽模式杂项数据的技能

namespace skill951
{
	
	function init() 
	{
		define('MOD_SKILL951_INFO','hidden;');
	}
	
	function acquire951(&$pa)
	{
		
	}
	
	function lost951(&$pa)
	{
		
	}
	
	function check_unlocked951(&$pa)
	{
		
		return 1;
	}
	
}

?>