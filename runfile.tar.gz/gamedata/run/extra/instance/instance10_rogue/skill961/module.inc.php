<?php

namespace skill961
{
	////////// MODULE HEADER START ///////////////
	$___MODULE_dependency = 'sys player skillbase clubbase attack weapon logger addnpc explore metman enemy team';
	$___MODULE_dependency_optional = '';
	$___MODULE_conflict = '';
	$___MODULE_codelist = 'main.php config/vipnpc.config.php';
	$___MODULE_templatelist = 'desc';
	////////// MODULE HEADER END /////////////////
	require __INIT_MODULE__(__NAMESPACE__,__DIR__);
}

?>
