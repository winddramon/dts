<?php

namespace randrecipe
{
	////////// MODULE HEADER START ///////////////
	$___MODULE_dependency = 'sys player skillbase npc item_recipe';
	$___MODULE_dependency_optional = 'itemmain';
	$___MODULE_conflict = '';
	$___MODULE_codelist = 'main.php config/randrecipe.config.php';
	$___MODULE_templatelist = '';
	////////// MODULE HEADER END /////////////////
	require __INIT_MODULE__(__NAMESPACE__,__DIR__);
}

?>
