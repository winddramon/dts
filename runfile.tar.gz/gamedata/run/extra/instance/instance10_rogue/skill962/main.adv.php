<?php

namespace skill962
{
	$skill962_cd = 180;
	$skill962_base_cost = 200;
	
	function init()
	{
		define('MOD_SKILL962_INFO','card;upgrade;');
		do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;  global $___LOCAL_BUFFICONS__VARS__bufficons_list,$___LOCAL_BUFFICONS__VARS__tmp_totsec,$___LOCAL_BUFFICONS__VARS__tmp_nowsec; $bufficons_list=&$___LOCAL_BUFFICONS__VARS__bufficons_list; $tmp_totsec=&$___LOCAL_BUFFICONS__VARS__tmp_totsec; $tmp_nowsec=&$___LOCAL_BUFFICONS__VARS__tmp_nowsec;   } while (0);
		$clubskillname[962] = '寻路';
		$bufficons_list[962] = Array(
			'onclick' => "$('mode').value='special';$('command').value='skill960_special';$('subcmd').value='show';postCmd('gamecmd','command.php');this.disabled=true;",
			'activate_hint' => '打开任务界面以更换任务',
		);
	}
	
	function acquire962(&$pa)
	{
		
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;  global $___LOCAL_SKILL962__VARS__skill962_cd,$___LOCAL_SKILL962__VARS__skill962_base_cost; $skill962_cd=&$___LOCAL_SKILL962__VARS__skill962_cd; $skill962_base_cost=&$___LOCAL_SKILL962__VARS__skill962_base_cost;   } while (0);
		\skillbase\skill_setvalue(962,'end_ts',$now-1,$pa);	
		\skillbase\skill_setvalue(962,'cd_ts',$now+$skill962_cd,$pa);
	}
	
	function lost962(&$pa)
	{
		
	}
	
	function check_unlocked962(&$pa)
	{
		
		return 1;
	}
	
	
	function check_skill962_state(&$pa){
		
		$st = \bufficons\bufficons_check_buff_state(962, $pa);
		if(!$st) return 0;
		
		$skill962_cost = get_skill962_cost($pa);
		if (2 == $st){
			if ($pa['money'] < $skill962_cost) return 1;
			return 2;
		}
		return 3;
	}
	
	function act()
	{
		
		
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;  global $___LOCAL_PLAYER__VARS__ss,$___LOCAL_PLAYER__VARS__db_player_structure,$___LOCAL_PLAYER__VARS__db_player_structure_types,$___LOCAL_PLAYER__VARS__gamedata,$___LOCAL_PLAYER__VARS__cmd,$___LOCAL_PLAYER__VARS__main,$___LOCAL_PLAYER__VARS__sdata,$___LOCAL_PLAYER__VARS__fog,$___LOCAL_PLAYER__VARS__upexp,$___LOCAL_PLAYER__VARS__lvlupexp, $___LOCAL_PLAYER__VARS__iconImg,$___LOCAL_PLAYER__VARS__iconImgB,$___LOCAL_PLAYER__VARS__iconImgBwidth,$___LOCAL_PLAYER__VARS__ardef,$___LOCAL_PLAYER__VARS__hpcolor,$___LOCAL_PLAYER__VARS__spcolor,$___LOCAL_PLAYER__VARS__newhpimg,$___LOCAL_PLAYER__VARS__newspimg,$___LOCAL_PLAYER__VARS__splt,$___LOCAL_PLAYER__VARS__hplt, $___LOCAL_PLAYER__VARS__tpldata,$___LOCAL_PLAYER__VARS__icon_list,$___LOCAL_PLAYER__VARS__icon_list_contents_to_frontend,$___LOCAL_PLAYER__VARS__typeinfo,$___LOCAL_PLAYER__VARS__killmsginfo,$___LOCAL_PLAYER__VARS__lwinfo,$___LOCAL_PLAYER__VARS__sexinfo,$___LOCAL_PLAYER__VARS__equip_list,$___LOCAL_PLAYER__VARS__battle_equip_list,$___LOCAL_PLAYER__VARS__pc_icon_range, $___LOCAL_PLAYER__VARS__pid,$___LOCAL_PLAYER__VARS__type,$___LOCAL_PLAYER__VARS__name,$___LOCAL_PLAYER__VARS__pass,$___LOCAL_PLAYER__VARS__ip,$___LOCAL_PLAYER__VARS__motto,$___LOCAL_PLAYER__VARS__killmsg,$___LOCAL_PLAYER__VARS__lastword,$___LOCAL_PLAYER__VARS__winner_flag,$___LOCAL_PLAYER__VARS__player_dead_flag, $___LOCAL_PLAYER__VARS__corpse_clear_flag,$___LOCAL_PLAYER__VARS__gd,$___LOCAL_PLAYER__VARS__sNo,$___LOCAL_PLAYER__VARS__club,$___LOCAL_PLAYER__VARS__validtime,$___LOCAL_PLAYER__VARS__endtime,$___LOCAL_PLAYER__VARS__cdsec,$___LOCAL_PLAYER__VARS__cdmsec,$___LOCAL_PLAYER__VARS__cdtime,$___LOCAL_PLAYER__VARS__action, $___LOCAL_PLAYER__VARS__a_actionnum,$___LOCAL_PLAYER__VARS__v_actionnum,$___LOCAL_PLAYER__VARS__hp,$___LOCAL_PLAYER__VARS__mhp,$___LOCAL_PLAYER__VARS__sp,$___LOCAL_PLAYER__VARS__msp,$___LOCAL_PLAYER__VARS__mss,$___LOCAL_PLAYER__VARS__att,$___LOCAL_PLAYER__VARS__def,$___LOCAL_PLAYER__VARS__pls, $___LOCAL_PLAYER__VARS__lvl,$___LOCAL_PLAYER__VARS__exp,$___LOCAL_PLAYER__VARS__money,$___LOCAL_PLAYER__VARS__rp,$___LOCAL_PLAYER__VARS__bid,$___LOCAL_PLAYER__VARS__inf,$___LOCAL_PLAYER__VARS__rage,$___LOCAL_PLAYER__VARS__pose,$___LOCAL_PLAYER__VARS__tactic,$___LOCAL_PLAYER__VARS__killnum, $___LOCAL_PLAYER__VARS__npckillnum,$___LOCAL_PLAYER__VARS__state,$___LOCAL_PLAYER__VARS__skillpoint,$___LOCAL_PLAYER__VARS__flare,$___LOCAL_PLAYER__VARS__wp,$___LOCAL_PLAYER__VARS__wk,$___LOCAL_PLAYER__VARS__wg,$___LOCAL_PLAYER__VARS__wc,$___LOCAL_PLAYER__VARS__wd,$___LOCAL_PLAYER__VARS__wf, $___LOCAL_PLAYER__VARS__icon,$___LOCAL_PLAYER__VARS__teamID,$___LOCAL_PLAYER__VARS__teamPass,$___LOCAL_PLAYER__VARS__card,$___LOCAL_PLAYER__VARS__cardname,$___LOCAL_PLAYER__VARS__wep,$___LOCAL_PLAYER__VARS__wepk,$___LOCAL_PLAYER__VARS__wepe,$___LOCAL_PLAYER__VARS__weps,$___LOCAL_PLAYER__VARS__wepsk, $___LOCAL_PLAYER__VARS__arb,$___LOCAL_PLAYER__VARS__arbk,$___LOCAL_PLAYER__VARS__arbe,$___LOCAL_PLAYER__VARS__arbs,$___LOCAL_PLAYER__VARS__arbsk,$___LOCAL_PLAYER__VARS__arh,$___LOCAL_PLAYER__VARS__arhk,$___LOCAL_PLAYER__VARS__arhe,$___LOCAL_PLAYER__VARS__arhs,$___LOCAL_PLAYER__VARS__arhsk, $___LOCAL_PLAYER__VARS__ara,$___LOCAL_PLAYER__VARS__arak,$___LOCAL_PLAYER__VARS__arae,$___LOCAL_PLAYER__VARS__aras,$___LOCAL_PLAYER__VARS__arask,$___LOCAL_PLAYER__VARS__arf,$___LOCAL_PLAYER__VARS__arfk,$___LOCAL_PLAYER__VARS__arfe,$___LOCAL_PLAYER__VARS__arfs,$___LOCAL_PLAYER__VARS__arfsk, $___LOCAL_PLAYER__VARS__art,$___LOCAL_PLAYER__VARS__artk,$___LOCAL_PLAYER__VARS__arte,$___LOCAL_PLAYER__VARS__arts,$___LOCAL_PLAYER__VARS__artsk,$___LOCAL_PLAYER__VARS__itm0,$___LOCAL_PLAYER__VARS__itmk0,$___LOCAL_PLAYER__VARS__itme0,$___LOCAL_PLAYER__VARS__itms0,$___LOCAL_PLAYER__VARS__itmsk0, $___LOCAL_PLAYER__VARS__itm1,$___LOCAL_PLAYER__VARS__itmk1,$___LOCAL_PLAYER__VARS__itme1,$___LOCAL_PLAYER__VARS__itms1,$___LOCAL_PLAYER__VARS__itmsk1,$___LOCAL_PLAYER__VARS__itm2,$___LOCAL_PLAYER__VARS__itmk2,$___LOCAL_PLAYER__VARS__itme2,$___LOCAL_PLAYER__VARS__itms2,$___LOCAL_PLAYER__VARS__itmsk2, $___LOCAL_PLAYER__VARS__itm3,$___LOCAL_PLAYER__VARS__itmk3,$___LOCAL_PLAYER__VARS__itme3,$___LOCAL_PLAYER__VARS__itms3,$___LOCAL_PLAYER__VARS__itmsk3,$___LOCAL_PLAYER__VARS__itm4,$___LOCAL_PLAYER__VARS__itmk4,$___LOCAL_PLAYER__VARS__itme4,$___LOCAL_PLAYER__VARS__itms4,$___LOCAL_PLAYER__VARS__itmsk4, $___LOCAL_PLAYER__VARS__itm5,$___LOCAL_PLAYER__VARS__itmk5,$___LOCAL_PLAYER__VARS__itme5,$___LOCAL_PLAYER__VARS__itms5,$___LOCAL_PLAYER__VARS__itmsk5,$___LOCAL_PLAYER__VARS__itm6,$___LOCAL_PLAYER__VARS__itmk6,$___LOCAL_PLAYER__VARS__itme6,$___LOCAL_PLAYER__VARS__itms6,$___LOCAL_PLAYER__VARS__itmsk6, $___LOCAL_PLAYER__VARS__searchmemory,$___LOCAL_PLAYER__VARS__nskill,$___LOCAL_PLAYER__VARS__nskillpara; $ss=&$___LOCAL_PLAYER__VARS__ss; $db_player_structure=&$___LOCAL_PLAYER__VARS__db_player_structure; $db_player_structure_types=&$___LOCAL_PLAYER__VARS__db_player_structure_types; $gamedata=&$___LOCAL_PLAYER__VARS__gamedata; $cmd=&$___LOCAL_PLAYER__VARS__cmd; $main=&$___LOCAL_PLAYER__VARS__main; $sdata=&$___LOCAL_PLAYER__VARS__sdata; $fog=&$___LOCAL_PLAYER__VARS__fog; $upexp=&$___LOCAL_PLAYER__VARS__upexp; $lvlupexp=&$___LOCAL_PLAYER__VARS__lvlupexp;  $iconImg=&$___LOCAL_PLAYER__VARS__iconImg; $iconImgB=&$___LOCAL_PLAYER__VARS__iconImgB; $iconImgBwidth=&$___LOCAL_PLAYER__VARS__iconImgBwidth; $ardef=&$___LOCAL_PLAYER__VARS__ardef; $hpcolor=&$___LOCAL_PLAYER__VARS__hpcolor; $spcolor=&$___LOCAL_PLAYER__VARS__spcolor; $newhpimg=&$___LOCAL_PLAYER__VARS__newhpimg; $newspimg=&$___LOCAL_PLAYER__VARS__newspimg; $splt=&$___LOCAL_PLAYER__VARS__splt; $hplt=&$___LOCAL_PLAYER__VARS__hplt;  $tpldata=&$___LOCAL_PLAYER__VARS__tpldata; $icon_list=&$___LOCAL_PLAYER__VARS__icon_list; $icon_list_contents_to_frontend=&$___LOCAL_PLAYER__VARS__icon_list_contents_to_frontend; $typeinfo=&$___LOCAL_PLAYER__VARS__typeinfo; $killmsginfo=&$___LOCAL_PLAYER__VARS__killmsginfo; $lwinfo=&$___LOCAL_PLAYER__VARS__lwinfo; $sexinfo=&$___LOCAL_PLAYER__VARS__sexinfo; $equip_list=&$___LOCAL_PLAYER__VARS__equip_list; $battle_equip_list=&$___LOCAL_PLAYER__VARS__battle_equip_list; $pc_icon_range=&$___LOCAL_PLAYER__VARS__pc_icon_range;  $pid=&$___LOCAL_PLAYER__VARS__pid; $type=&$___LOCAL_PLAYER__VARS__type; $name=&$___LOCAL_PLAYER__VARS__name; $pass=&$___LOCAL_PLAYER__VARS__pass; $ip=&$___LOCAL_PLAYER__VARS__ip; $motto=&$___LOCAL_PLAYER__VARS__motto; $killmsg=&$___LOCAL_PLAYER__VARS__killmsg; $lastword=&$___LOCAL_PLAYER__VARS__lastword; $winner_flag=&$___LOCAL_PLAYER__VARS__winner_flag; $player_dead_flag=&$___LOCAL_PLAYER__VARS__player_dead_flag;  $corpse_clear_flag=&$___LOCAL_PLAYER__VARS__corpse_clear_flag; $gd=&$___LOCAL_PLAYER__VARS__gd; $sNo=&$___LOCAL_PLAYER__VARS__sNo; $club=&$___LOCAL_PLAYER__VARS__club; $validtime=&$___LOCAL_PLAYER__VARS__validtime; $endtime=&$___LOCAL_PLAYER__VARS__endtime; $cdsec=&$___LOCAL_PLAYER__VARS__cdsec; $cdmsec=&$___LOCAL_PLAYER__VARS__cdmsec; $cdtime=&$___LOCAL_PLAYER__VARS__cdtime; $action=&$___LOCAL_PLAYER__VARS__action;  $a_actionnum=&$___LOCAL_PLAYER__VARS__a_actionnum; $v_actionnum=&$___LOCAL_PLAYER__VARS__v_actionnum; $hp=&$___LOCAL_PLAYER__VARS__hp; $mhp=&$___LOCAL_PLAYER__VARS__mhp; $sp=&$___LOCAL_PLAYER__VARS__sp; $msp=&$___LOCAL_PLAYER__VARS__msp; $mss=&$___LOCAL_PLAYER__VARS__mss; $att=&$___LOCAL_PLAYER__VARS__att; $def=&$___LOCAL_PLAYER__VARS__def; $pls=&$___LOCAL_PLAYER__VARS__pls;  $lvl=&$___LOCAL_PLAYER__VARS__lvl; $exp=&$___LOCAL_PLAYER__VARS__exp; $money=&$___LOCAL_PLAYER__VARS__money; $rp=&$___LOCAL_PLAYER__VARS__rp; $bid=&$___LOCAL_PLAYER__VARS__bid; $inf=&$___LOCAL_PLAYER__VARS__inf; $rage=&$___LOCAL_PLAYER__VARS__rage; $pose=&$___LOCAL_PLAYER__VARS__pose; $tactic=&$___LOCAL_PLAYER__VARS__tactic; $killnum=&$___LOCAL_PLAYER__VARS__killnum;  $npckillnum=&$___LOCAL_PLAYER__VARS__npckillnum; $state=&$___LOCAL_PLAYER__VARS__state; $skillpoint=&$___LOCAL_PLAYER__VARS__skillpoint; $flare=&$___LOCAL_PLAYER__VARS__flare; $wp=&$___LOCAL_PLAYER__VARS__wp; $wk=&$___LOCAL_PLAYER__VARS__wk; $wg=&$___LOCAL_PLAYER__VARS__wg; $wc=&$___LOCAL_PLAYER__VARS__wc; $wd=&$___LOCAL_PLAYER__VARS__wd; $wf=&$___LOCAL_PLAYER__VARS__wf;  $icon=&$___LOCAL_PLAYER__VARS__icon; $teamID=&$___LOCAL_PLAYER__VARS__teamID; $teamPass=&$___LOCAL_PLAYER__VARS__teamPass; $card=&$___LOCAL_PLAYER__VARS__card; $cardname=&$___LOCAL_PLAYER__VARS__cardname; $wep=&$___LOCAL_PLAYER__VARS__wep; $wepk=&$___LOCAL_PLAYER__VARS__wepk; $wepe=&$___LOCAL_PLAYER__VARS__wepe; $weps=&$___LOCAL_PLAYER__VARS__weps; $wepsk=&$___LOCAL_PLAYER__VARS__wepsk;  $arb=&$___LOCAL_PLAYER__VARS__arb; $arbk=&$___LOCAL_PLAYER__VARS__arbk; $arbe=&$___LOCAL_PLAYER__VARS__arbe; $arbs=&$___LOCAL_PLAYER__VARS__arbs; $arbsk=&$___LOCAL_PLAYER__VARS__arbsk; $arh=&$___LOCAL_PLAYER__VARS__arh; $arhk=&$___LOCAL_PLAYER__VARS__arhk; $arhe=&$___LOCAL_PLAYER__VARS__arhe; $arhs=&$___LOCAL_PLAYER__VARS__arhs; $arhsk=&$___LOCAL_PLAYER__VARS__arhsk;  $ara=&$___LOCAL_PLAYER__VARS__ara; $arak=&$___LOCAL_PLAYER__VARS__arak; $arae=&$___LOCAL_PLAYER__VARS__arae; $aras=&$___LOCAL_PLAYER__VARS__aras; $arask=&$___LOCAL_PLAYER__VARS__arask; $arf=&$___LOCAL_PLAYER__VARS__arf; $arfk=&$___LOCAL_PLAYER__VARS__arfk; $arfe=&$___LOCAL_PLAYER__VARS__arfe; $arfs=&$___LOCAL_PLAYER__VARS__arfs; $arfsk=&$___LOCAL_PLAYER__VARS__arfsk;  $art=&$___LOCAL_PLAYER__VARS__art; $artk=&$___LOCAL_PLAYER__VARS__artk; $arte=&$___LOCAL_PLAYER__VARS__arte; $arts=&$___LOCAL_PLAYER__VARS__arts; $artsk=&$___LOCAL_PLAYER__VARS__artsk; $itm0=&$___LOCAL_PLAYER__VARS__itm0; $itmk0=&$___LOCAL_PLAYER__VARS__itmk0; $itme0=&$___LOCAL_PLAYER__VARS__itme0; $itms0=&$___LOCAL_PLAYER__VARS__itms0; $itmsk0=&$___LOCAL_PLAYER__VARS__itmsk0;  $itm1=&$___LOCAL_PLAYER__VARS__itm1; $itmk1=&$___LOCAL_PLAYER__VARS__itmk1; $itme1=&$___LOCAL_PLAYER__VARS__itme1; $itms1=&$___LOCAL_PLAYER__VARS__itms1; $itmsk1=&$___LOCAL_PLAYER__VARS__itmsk1; $itm2=&$___LOCAL_PLAYER__VARS__itm2; $itmk2=&$___LOCAL_PLAYER__VARS__itmk2; $itme2=&$___LOCAL_PLAYER__VARS__itme2; $itms2=&$___LOCAL_PLAYER__VARS__itms2; $itmsk2=&$___LOCAL_PLAYER__VARS__itmsk2;  $itm3=&$___LOCAL_PLAYER__VARS__itm3; $itmk3=&$___LOCAL_PLAYER__VARS__itmk3; $itme3=&$___LOCAL_PLAYER__VARS__itme3; $itms3=&$___LOCAL_PLAYER__VARS__itms3; $itmsk3=&$___LOCAL_PLAYER__VARS__itmsk3; $itm4=&$___LOCAL_PLAYER__VARS__itm4; $itmk4=&$___LOCAL_PLAYER__VARS__itmk4; $itme4=&$___LOCAL_PLAYER__VARS__itme4; $itms4=&$___LOCAL_PLAYER__VARS__itms4; $itmsk4=&$___LOCAL_PLAYER__VARS__itmsk4;  $itm5=&$___LOCAL_PLAYER__VARS__itm5; $itmk5=&$___LOCAL_PLAYER__VARS__itmk5; $itme5=&$___LOCAL_PLAYER__VARS__itme5; $itms5=&$___LOCAL_PLAYER__VARS__itms5; $itmsk5=&$___LOCAL_PLAYER__VARS__itmsk5; $itm6=&$___LOCAL_PLAYER__VARS__itm6; $itmk6=&$___LOCAL_PLAYER__VARS__itmk6; $itme6=&$___LOCAL_PLAYER__VARS__itme6; $itms6=&$___LOCAL_PLAYER__VARS__itms6; $itmsk6=&$___LOCAL_PLAYER__VARS__itmsk6;  $searchmemory=&$___LOCAL_PLAYER__VARS__searchmemory; $nskill=&$___LOCAL_PLAYER__VARS__nskill; $nskillpara=&$___LOCAL_PLAYER__VARS__nskillpara;   } while (0);
	
		if ($mode == 'special' && $command == 'skill962_special') 
		{
			\skill962\activate962 ();
			return;
		}
		//======== Start of contents from mod skill737 ========
		do{
			$___TMP_MOD_skill737_FUNC_act_RET = NULL;

		
		
		if ($mode == 'special' && $command == 'skill737_special' && get_var_input('subcmd')=='castsk737') 
		{
			\skill737\cast_skill737 ();
			$___TMP_MOD_skill737_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod skill505 ========
		do{
			$___TMP_MOD_skill505_FUNC_act_RET = NULL;
		//======== Start of contents from mod skill746 ========
		do{
			$___TMP_MOD_skill746_FUNC_act_RET = NULL;

		
		
		if ($mode == 'special' && $command == 'skill746_special' && get_var_input('subcmd')=='castsk746')
		{
			\skill746\cast_skill746 ();
			$___TMP_MOD_skill746_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod skill733 ========
		do{
			$___TMP_MOD_skill733_FUNC_act_RET = NULL;

		
		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
	
		if ($mode == 'special' && $command == 'skill733_special') 
		{
			\skill733\cast_skill733 ();
			$___TMP_MOD_skill733_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod skill960 ========
		do{
			$___TMP_MOD_skill960_FUNC_act_RET = NULL;

		
		
		
	
		if ($mode == 'special' && $command == 'skill960_special') 
		{
			\skill960\cast_skill960 ();
			$___TMP_MOD_skill960_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod skill597 ========
		do{
			$___TMP_MOD_skill597_FUNC_act_RET = NULL;

		
		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
		
		if ($mode == 'special' && $command == 'skill597_special') 
		{
			\skill597\cast_skill597 ();
			$___TMP_MOD_skill597_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod skill272 ========
		do{
			$___TMP_MOD_skill272_FUNC_act_RET = NULL;

		
		
		
	
		if ($mode == 'special' && $command == 'skill272_special') 
		{
			\skill272\skill272_command ();
			$___TMP_MOD_skill272_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod item_armor_empower ========
		do{
			$___TMP_MOD_item_armor_empower_FUNC_act_RET = NULL;

		
		
		
		if ($mode == 'item' && get_var_in_module('usemode','input') == 'armor_empower')
		{
			$item = substr($command, 3);
			\item_armor_empower\use_armor_empower ($item);
			$___TMP_MOD_item_armor_empower_FUNC_act_RET = NULL;
			break; 
		}
if(isset($item)) {$__VAR_DUMP_MOD_item_armor_empower_VARS_item = $item; unset($item); } else {$__VAR_DUMP_MOD_item_armor_empower_VARS_item = NULL;} 
		//======== Start of contents from mod ex_storage ========
		do{
			$___TMP_MOD_ex_storage_FUNC_act_RET = NULL;

		
		
		
	
		if ($mode == 'special' && $command == 'storage') 
		{
			\ex_storage\use_storage ();
			$___TMP_MOD_ex_storage_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod skill1006 ========
		do{
			$___TMP_MOD_skill1006_FUNC_act_RET = NULL;

		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
		
		if(\searchmemory\searchmemory_available()){
			
			if ($mode == 'command' && strpos($command,'beacon')===0){
				$bn = substr($command,6);
				\skill1006\beacon_discover ($bn);
			}
		}
		//======== Start of contents from mod blessstone ========
		do{
			$___TMP_MOD_blessstone_FUNC_act_RET = NULL;

		
		
		
		$usemode = get_var_input('usemode');
		if($mode == 'item' && $usemode == 'blessstone') 
		{
			$item = substr($command,3);
			\blessstone\use_blessstone ($item);
			$___TMP_MOD_blessstone_FUNC_act_RET = NULL;
			break; 
		}
if(isset($usemode)) {$__VAR_DUMP_MOD_blessstone_VARS_usemode = $usemode; unset($usemode); } else {$__VAR_DUMP_MOD_blessstone_VARS_usemode = NULL;} if(isset($item)) {$__VAR_DUMP_MOD_blessstone_VARS_item = $item; unset($item); } else {$__VAR_DUMP_MOD_blessstone_VARS_item = NULL;} 
		//======== Start of contents from mod skill94 ========
		do{
			$___TMP_MOD_skill94_FUNC_act_RET = NULL;

		
		
		if ($mode == 'special' && $command == 'skill94_special' && get_var_input('subcmd')=='castsk94') 
		{
			\skill94\cast_skill94 ();
			$___TMP_MOD_skill94_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod searchmemory ========
		do{
			$___TMP_MOD_searchmemory_FUNC_act_RET = NULL;

		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
		$tmp_pls = $pls;
		$tmp_eid = 0;
		$tmp_eid_mode = '';
		if(\searchmemory\searchmemory_available ()){
			
			if ($mode == 'command' && strpos($command,'memory')===0){
				$smn = substr($command,6);
				\searchmemory\searchmemory_discover ($smn);
			
			}elseif('enemy' == substr($action,0,5) && 'back' == $command)
			{
				$tmp_eid = (int)substr($action, 5);
				$tmp_eid_mode = 'enemy';
			}
			
			elseif('corpse' == substr($action,0,6) && !\gameflow_combo\is_gamestate_combo() && ('menu' == $command || (\searchmemory\check_keep_corpse_in_searchmemory () && 'destroy' != $command)))
			{
				$tmp_eid = (int)substr($action, 6);
				$tmp_eid_mode = 'corpse';
			}
		}
		//======== Start of contents from mod item_uys ========
		do{
			$___TMP_MOD_item_uys_FUNC_act_RET = NULL;

		
		
		
		$usemode = get_var_input('usemode');
		if ($mode == 'item' && $usemode == 'sewingkit' && substr($command, 0, 3) == 'itm') 
		{
			$item = substr($command, 3);
			\item_uys\autosewingkit ($item);
			$___TMP_MOD_item_uys_FUNC_act_RET = NULL;
			break; 
		}
if(isset($usemode)) {$__VAR_DUMP_MOD_item_uys_VARS_usemode = $usemode; unset($usemode); } else {$__VAR_DUMP_MOD_item_uys_VARS_usemode = NULL;} if(isset($item)) {$__VAR_DUMP_MOD_item_uys_VARS_item = $item; unset($item); } else {$__VAR_DUMP_MOD_item_uys_VARS_item = NULL;} 
		//======== Start of contents from mod logistics ========
		do{
			$___TMP_MOD_logistics_FUNC_act_RET = NULL;

		
		
		$usemode = get_var_input('usemode');
		if ($mode == 'item' && $usemode == 'gameitemrecorder') 
		{
			$itmn = (int)substr($command, 3);
			$itmp = (int)get_var_input('itmp');
			$pos = (int)get_var_input('pos');
			\logistics\set_showcase_gameitem ($itmp, $itmn, $pos);
			$___TMP_MOD_logistics_FUNC_act_RET = NULL;
			break; 
		}
if(isset($usemode)) {$__VAR_DUMP_MOD_logistics_VARS_usemode = $usemode; unset($usemode); } else {$__VAR_DUMP_MOD_logistics_VARS_usemode = NULL;} if(isset($itmp)) {$__VAR_DUMP_MOD_logistics_VARS_itmp = $itmp; unset($itmp); } else {$__VAR_DUMP_MOD_logistics_VARS_itmp = NULL;} 
		//======== Start of contents from mod smartmix ========
		do{
			$___TMP_MOD_smartmix_FUNC_act_RET = NULL;

		
		
		if ($mode == 'command' && $command == 'itemmain' && get_var_input('itemcmd')=='itemmix'){
			\smartmix\smartmix_show ();
			if(!empty($uip['mixhint'])) {
				$main = MOD_SMARTMIX_MIXHINT_MAIN;
			}
		}
		//======== Start of contents from mod wepchange ========
		do{
			$___TMP_MOD_wepchange_FUNC_act_RET = NULL;

		
		
		
		$sp_cmd = get_var_input('sp_cmd');
		if ($mode == 'command' && $command=='special' && $sp_cmd == 'sp_weapon')
		{
			\wepchange\weaponswap ();
			$mode = 'command';
			$___TMP_MOD_wepchange_FUNC_act_RET = NULL;
			break; 
		}
if(isset($sp_cmd)) {$__VAR_DUMP_MOD_wepchange_VARS_sp_cmd = $sp_cmd; unset($sp_cmd); } else {$__VAR_DUMP_MOD_wepchange_VARS_sp_cmd = NULL;} 
		//======== Start of contents from mod instance11 ========
		do{
			$___TMP_MOD_instance11_FUNC_act_RET = NULL;

		
		
		

		if('observe_jump' == substr($command, 0, 12)) {
			\instance11\observe_jump_to_room ((int)substr($command, 12));
			$___TMP_MOD_instance11_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod skill381 ========
		do{
			$___TMP_MOD_skill381_FUNC_act_RET = NULL;

		
		
		//======== Start of contents from mod skill458 ========
		do{
			$___TMP_MOD_skill458_FUNC_act_RET = NULL;

		
		
		
		if ($mode == 'special' && $command == 'skill458_special' && get_var_input('subcmd')=='castsk458') 
		{
			\skill458\cast_skill458 ();
			$___TMP_MOD_skill458_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod skill182 ========
		do{
			$___TMP_MOD_skill182_FUNC_act_RET = NULL;
		//======== Start of contents from mod skill504 ========
		do{
			$___TMP_MOD_skill504_FUNC_act_RET = NULL;

		
		
		if($mode == 'special_skill504') {
			if($command == 'skill504_complete') {
				\skill504\skill504_popko_anime_complete ();
				$___TMP_MOD_skill504_FUNC_act_RET = NULL;
			break; 
			}
		}
		//======== Start of contents from mod skill372 ========
		do{
			$___TMP_MOD_skill372_FUNC_act_RET = NULL;

		
		
		//======== Start of contents from mod skill530 ========
		do{
			$___TMP_MOD_skill530_FUNC_act_RET = NULL;

		
		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
	
		if ($mode == 'special' && $command == 'skill530_special') 
		{
			if (!\skillbase\skill_query(530)) 
			{
				$log.='你没有这个技能。';
				$mode = 'command';
				$command = '';
				$___TMP_MOD_skill530_FUNC_act_RET = NULL;
			break; 
			}
			\skill530\process_530 ();
			$___TMP_MOD_skill530_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod skill338 ========
		do{
			$___TMP_MOD_skill338_FUNC_act_RET = NULL;

		
		
		//======== Start of contents from mod skill337 ========
		do{
			$___TMP_MOD_skill337_FUNC_act_RET = NULL;

		
		
		//======== Start of contents from mod skill336 ========
		do{
			$___TMP_MOD_skill336_FUNC_act_RET = NULL;

		
		
		//======== Start of contents from mod skill335 ========
		do{
			$___TMP_MOD_skill335_FUNC_act_RET = NULL;

		
		
		//======== Start of contents from mod skill334 ========
		do{
			$___TMP_MOD_skill334_FUNC_act_RET = NULL;

		
		
		//======== Start of contents from mod skill333 ========
		do{
			$___TMP_MOD_skill333_FUNC_act_RET = NULL;

		
		
		//======== Start of contents from mod skill332 ========
		do{
			$___TMP_MOD_skill332_FUNC_act_RET = NULL;

		
		
		//======== Start of contents from mod skill313 ========
		do{
			$___TMP_MOD_skill313_FUNC_act_RET = NULL;

		
		do { global $___LOCAL_MAP__VARS__all_plsno_cache,$___LOCAL_MAP__VARS__areainterval,$___LOCAL_MAP__VARS__areaadd,$___LOCAL_MAP__VARS__areawarntime,$___LOCAL_MAP__VARS__arealimit,$___LOCAL_MAP__VARS__areaesc,$___LOCAL_MAP__VARS__area_on_start,$___LOCAL_MAP__VARS__dangerous_zone,$___LOCAL_MAP__VARS__plsinfo,$___LOCAL_MAP__VARS__plsinfo_o, $___LOCAL_MAP__VARS__plsinfo_disp,$___LOCAL_MAP__VARS__plsinfo_for_short,$___LOCAL_MAP__VARS__xyinfo,$___LOCAL_MAP__VARS__areainfo; $all_plsno_cache=&$___LOCAL_MAP__VARS__all_plsno_cache; $areainterval=&$___LOCAL_MAP__VARS__areainterval; $areaadd=&$___LOCAL_MAP__VARS__areaadd; $areawarntime=&$___LOCAL_MAP__VARS__areawarntime; $arealimit=&$___LOCAL_MAP__VARS__arealimit; $areaesc=&$___LOCAL_MAP__VARS__areaesc; $area_on_start=&$___LOCAL_MAP__VARS__area_on_start; $dangerous_zone=&$___LOCAL_MAP__VARS__dangerous_zone; $plsinfo=&$___LOCAL_MAP__VARS__plsinfo; $plsinfo_o=&$___LOCAL_MAP__VARS__plsinfo_o;  $plsinfo_disp=&$___LOCAL_MAP__VARS__plsinfo_disp; $plsinfo_for_short=&$___LOCAL_MAP__VARS__plsinfo_for_short; $xyinfo=&$___LOCAL_MAP__VARS__xyinfo; $areainfo=&$___LOCAL_MAP__VARS__areainfo;   } while (0);
		//======== Start of contents from mod tutorial ========
		do{
			$___TMP_MOD_tutorial_FUNC_act_RET = NULL;

		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;  global $___LOCAL_MAP__VARS__all_plsno_cache,$___LOCAL_MAP__VARS__areainterval,$___LOCAL_MAP__VARS__areaadd,$___LOCAL_MAP__VARS__areawarntime,$___LOCAL_MAP__VARS__arealimit,$___LOCAL_MAP__VARS__areaesc,$___LOCAL_MAP__VARS__area_on_start,$___LOCAL_MAP__VARS__dangerous_zone,$___LOCAL_MAP__VARS__plsinfo,$___LOCAL_MAP__VARS__plsinfo_o, $___LOCAL_MAP__VARS__plsinfo_disp,$___LOCAL_MAP__VARS__plsinfo_for_short,$___LOCAL_MAP__VARS__xyinfo,$___LOCAL_MAP__VARS__areainfo; $all_plsno_cache=&$___LOCAL_MAP__VARS__all_plsno_cache; $areainterval=&$___LOCAL_MAP__VARS__areainterval; $areaadd=&$___LOCAL_MAP__VARS__areaadd; $areawarntime=&$___LOCAL_MAP__VARS__areawarntime; $arealimit=&$___LOCAL_MAP__VARS__arealimit; $areaesc=&$___LOCAL_MAP__VARS__areaesc; $area_on_start=&$___LOCAL_MAP__VARS__area_on_start; $dangerous_zone=&$___LOCAL_MAP__VARS__dangerous_zone; $plsinfo=&$___LOCAL_MAP__VARS__plsinfo; $plsinfo_o=&$___LOCAL_MAP__VARS__plsinfo_o;  $plsinfo_disp=&$___LOCAL_MAP__VARS__plsinfo_disp; $plsinfo_for_short=&$___LOCAL_MAP__VARS__plsinfo_for_short; $xyinfo=&$___LOCAL_MAP__VARS__xyinfo; $areainfo=&$___LOCAL_MAP__VARS__areainfo;   } while (0);
		if($gametype == 17) {
			$ct = \tutorial\get_tutorial ();
			list($tno, $tstep, $tprog) = \tutorial\get_current_tutorial_step ();
			if(isset($ct['obj2']['addnpc'])){
				$atype = $ct['obj2']['addnpc'];
				$asub = $ct['obj2']['asub'];
				$ateam = $pid;
				\tutorial\tutorial_checknpc ($atype,$asub,$ateam,1);
			}
			if(isset($ct['obj2']['addchat']) && $ct['obj2']['addchat']['type'] == 'IMMEDIATLY' && !$tprog){
				\tutorial\tutorial_addchat ($ct['obj2']['addchat']['cont']);
			}
			$push_flag = NULL;
			$itemcmd = get_var_input('itemcmd');
			$sp_cmd = get_var_input('sp_cmd');
			if(in_array($command, Array('team','destroy'))) {
				$log .= '<span class="red b">教程模式不能做出这一指令，请按教程提示操作！<span><br>';
				$push_flag = 'PROG';
				$command = '';$mode = 'command';
			} elseif($ct['object'] != $command && $ct['object'] !=  'any' && $ct['object'] != 'back' && $ct['object'] != 'itemget'){
				
			}
			if (($sp_cmd == 'sp_shop' && $ct['object'] == 'sp_shop') || ($command == 'shop4' && $ct['object'] == 'shop4') || ($command == 'itemmain' && $itemcmd == 'itemmix' && $ct['object'] == 'itemmain' && in_array('itemmix',$ct['obj2']))){
				$push_flag = 'OK';
			}elseif ($command == 'continue' || $ct['object'] ==  'any'){
				$push_flag = 'OK';
			}elseif (\tutorial\tutorial_fail_safing ($ct)){
				$log .= '<span class="ltvermilion b">“看来你比较熟练呢，我们继续。”</span><br>';
				$push_flag = 'OK';
			}else{
				$push_flag = 'PROG';
			}
			if('OK' === $push_flag) \tutorial\tutorial_pushforward_process ();
			elseif('PROG' === $push_flag) \tutorial\tutorial_pushforward_process ('PROG');
		}
if(isset($itemcmd)) {$__VAR_DUMP_MOD_tutorial_VARS_itemcmd = $itemcmd; unset($itemcmd); } else {$__VAR_DUMP_MOD_tutorial_VARS_itemcmd = NULL;} if(isset($sp_cmd)) {$__VAR_DUMP_MOD_tutorial_VARS_sp_cmd = $sp_cmd; unset($sp_cmd); } else {$__VAR_DUMP_MOD_tutorial_VARS_sp_cmd = NULL;} 
		//======== Start of contents from mod skill220 ========
		do{
			$___TMP_MOD_skill220_FUNC_act_RET = NULL;

		
		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
		
		if ($mode == 'special' && $command == 'skill220_special' && get_var_input('subcmd')=='pcheck') 
		{
			\skill220\do_pcheck ();
			$___TMP_MOD_skill220_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod ex_mhp_temp_up ========
		do{
			$___TMP_MOD_ex_mhp_temp_up_FUNC_act_RET = NULL;

		
		if(\attrbase\check_itmsk('^hu')) $tmp_hp_up_flag = 1;
		//======== Start of contents from mod news_observe ========
		do{
			$___TMP_MOD_news_observe_FUNC_act_RET = NULL;

		
		
		

		if($mode == 'obsv_select' && 'obsv' == substr($command, 0, 4)) {
			\news_observe\observe_main ((int)substr($command, 4));
			$___TMP_MOD_news_observe_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod extra_event ========
		do{
			$___TMP_MOD_extra_event_FUNC_act_RET = NULL;

		
		
		if('event' == $command && \extra_event\is_extra_event_available ()) {
			\extra_event\extra_event_main ();
			$___TMP_MOD_extra_event_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod song ========
		do{
			$___TMP_MOD_song_FUNC_act_RET = NULL;

			
		
		if ($mode == 'command' && $command == 'song')
		{
			do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;  global $___LOCAL_SONG__VARS__ef_type,$___LOCAL_SONG__VARS__ef_type2,$___LOCAL_SONG__VARS__songlist,$___LOCAL_SONG__VARS__songchatlimit,$___LOCAL_SONG__VARS__song_font_size,$___LOCAL_SONG__VARS__song_line_height; $ef_type=&$___LOCAL_SONG__VARS__ef_type; $ef_type2=&$___LOCAL_SONG__VARS__ef_type2; $songlist=&$___LOCAL_SONG__VARS__songlist; $songchatlimit=&$___LOCAL_SONG__VARS__songchatlimit; $song_font_size=&$___LOCAL_SONG__VARS__song_font_size; $song_line_height=&$___LOCAL_SONG__VARS__song_line_height;   } while (0);
			$song_choice = get_var_in_module('song_choice', 'input');
			if (!empty($song_choice))
			{
				$z = (int)$song_choice;
				if (isset($songlist[$z]['songname']))
				{
					\song\ss_sing ($songlist[$z]['songname']);
					$mode = 'command';
					$___TMP_MOD_song_FUNC_act_RET = NULL;
			break; 
				}
				else
				{
					$log .= '参数不合法。<br>';
				}
			}
			else
			{
				$songkind = get_var_in_module('songkind', 'input');
				if (!empty($songkind))
				{
					\song\ss_sing ($songkind);
					$mode = 'command';
					$___TMP_MOD_song_FUNC_act_RET = NULL;
			break; 
				}
			}
			include template(MOD_SONG_SING);
			$cmd = ob_get_contents();
			ob_clean();
			$___TMP_MOD_song_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod opening ========
		do{
			$___TMP_MOD_opening_FUNC_act_RET = NULL;

		
		
		
		if($hp > 0 && \skillbase\skill_query(1003) && !\skillbase\skill_getvalue(1003,'opening_skip')) {
			if ($command != 'enter') 
			{
				\skillbase\skill_setvalue(1003,'opening_skip',1);
			}elseif(\opening\opening_by_shootings_available ()){
				do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
				$log .= '<br><span class="yellow b">点击以下任意按钮皆可跳过开场剧情。</span><br>';
			}
		}
		//======== Start of contents from mod skill580 ========
		do{
			$___TMP_MOD_skill580_FUNC_act_RET = NULL;

		
		$sid = \skillbase\skill_getvalue(1003,'sk580_sid');
		if (!empty($sid))
		{
			
			if (($mode == 'itemmain' && $command == 'itemget') || ($mode == 'command' && $command == 'itm0'))
			{
				
				if(!empty($itms0)) {
					$itm0 = $itmk0 = $itmsk0 = '';
					$itme0 = $itms0 = 0;
				}
				\metman\meetman($sid);
				$___TMP_MOD_skill580_FUNC_act_RET = NULL;
			break; 
			}
			elseif ($mode == 'itemmain' && $command == 'dropitm0')
			{
				do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
				$log .= "<span class=\"yellow b\">{$itm0}</span>发出唉的一声，然后不见了。<br>";
				$itm0 = $itmk0 = $itmsk0 = '';
				$itme0 = $itms0 = 0;
				\skillbase\skill_delvalue(1003,'sk580_sid',$sdata);
				$___TMP_MOD_skill580_FUNC_act_RET = NULL;
			break; 
			}
		}
		//======== Start of contents from mod item_recipe ========
		do{
			$___TMP_MOD_item_recipe_FUNC_act_RET = NULL;

		
		
		
		$usemode = get_var_input('usemode');
		$itmp = get_var_input('itmp');
		if ($mode == 'item' && $usemode == 'recipe') 
		{
			if ($command == 'menu')
			{
				$mode = 'command';
				$___TMP_MOD_item_recipe_FUNC_act_RET = NULL;
			break; 
			} 
			$mixlist = array();
			for($i=1; $i<=6; $i++)
			{
				if(!empty(get_var_input('mitm'.$i)))
					$mixlist[] = $i;
			}
			$recipe_mixinfo = \item_recipe\get_recipe_mixinfo ();
			$minfo = $recipe_mixinfo[${'itmsk'.(int)$itmp}];
			
			$minfo['key'] = ${'itmsk'.(int)$itmp};
			\item_recipe\recipe_mix ($mixlist, $itmp, $minfo);
			$command = 'menu';
		}
		if ($mode == 'command' && $command == 'recipe')
		{
			
			$recipe_choice = get_var_input('recipe_choice');
			if (!empty($recipe_choice))
			{
				$rkey = (int)$recipe_choice;
				ob_start();
				include template(MOD_ITEM_RECIPE_USE_LEARNED_RECIPE);
				$cmd = ob_get_contents();
				ob_end_clean();
				$___TMP_MOD_item_recipe_FUNC_act_RET = NULL;
			break; 
			}
			include template(MOD_ITEM_RECIPE_CHOOSE_RECIPE);
			$cmd = ob_get_contents();
			ob_clean();
			$___TMP_MOD_item_recipe_FUNC_act_RET = NULL;
			break; 
		}
		if ($mode == 'recipe' && $command == 'recipe')
		{
			if ($command == 'menu')
			{
				$mode = 'command';
				$___TMP_MOD_item_recipe_FUNC_act_RET = NULL;
			break; 
			} 
			$mixlist = array();
			for($i=1; $i<=6; $i++)
			{
				if(!empty(get_var_input('mitm'.$i)))
					$mixlist[] = $i;
			}
			$recipe_mixinfo = \item_recipe\get_recipe_mixinfo ();
			$rkey = get_var_input('rkey');
			$minfo = $recipe_mixinfo[$rkey];
			$ls = \item_recipe\get_learned_recipes ();
			if (empty($minfo) || !in_array($rkey, $ls))
			{
				do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
				$log .= '输入参数不正确！';
				$mode = 'command';
				$___TMP_MOD_item_recipe_FUNC_act_RET = NULL;
			break; 
			}
			\item_recipe\recipe_mix ($mixlist, 0, $minfo);
		}
if(isset($mixlist)) {$__VAR_DUMP_MOD_item_recipe_VARS_mixlist = $mixlist; unset($mixlist); } else {$__VAR_DUMP_MOD_item_recipe_VARS_mixlist = NULL;} if(isset($i)) {$__VAR_DUMP_MOD_item_recipe_VARS_i = $i; unset($i); } else {$__VAR_DUMP_MOD_item_recipe_VARS_i = NULL;} 
		//======== Start of contents from mod item_umb ========
		do{
			$___TMP_MOD_item_umb_FUNC_act_RET = NULL;
		//======== Start of contents from mod skill219 ========
		do{
			$___TMP_MOD_skill219_FUNC_act_RET = NULL;

		
		
		
	
		if ($mode == 'special' && $command == 'skill219_special' && get_var_input('subcmd')=='wpoison') 
		{
			\skill219\wpoison ();
			$___TMP_MOD_skill219_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod skill230 ========
		do{
			$___TMP_MOD_skill230_FUNC_act_RET = NULL;

		
		
		
	

		if ($mode == 'special' && $command == 'skill230_special' && get_var_input('subcmd')=='wele') 
		{
			\skill230\wele ();
			$___TMP_MOD_skill230_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod dualwep ========
		do{
			$___TMP_MOD_dualwep_FUNC_act_RET = NULL;

		
		
		
		
		$sp_cmd = get_var_input('sp_cmd');
		if ($mode == 'command' && $command=='special' && $sp_cmd == 'sp_dualwep_am')
		{
			\dualwep\dualwep_change_am ();
			$mode = 'command';
			$___TMP_MOD_dualwep_FUNC_act_RET = NULL;
			break; 
		}
if(isset($sp_cmd)) {$__VAR_DUMP_MOD_dualwep_VARS_sp_cmd = $sp_cmd; unset($sp_cmd); } else {$__VAR_DUMP_MOD_dualwep_VARS_sp_cmd = NULL;} 
		//======== Start of contents from mod skill104 ========
		do{
			$___TMP_MOD_skill104_FUNC_act_RET = NULL;

		
		
		if ($mode == 'special' && $command == 'skill104_special' && get_var_input('subcmd')=='castsk104') 
		{
			\skill104\cast_skill104 ();
			$___TMP_MOD_skill104_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod skill103 ========
		do{
			$___TMP_MOD_skill103_FUNC_act_RET = NULL;

		
		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
		if ($mode == 'special' && $command == 'skill103_special' && get_var_input('subcmd')=='castsk103') 
		{
			\skill103\cast_skill103 ();
			$___TMP_MOD_skill103_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod skill731 ========
		do{
			$___TMP_MOD_skill731_FUNC_act_RET = NULL;

		
		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;  eval(import_module('input')); eval(import_module('input'));  } while (0);
	
		if ($mode == 'special' && $command == 'skill731_special') 
		{
			\skill731\cast_skill731 ();
			$___TMP_MOD_skill731_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod skill435 ========
		do{
			$___TMP_MOD_skill435_FUNC_act_RET = NULL;

		
		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
		$subcmd = get_var_input('subcmd');
		if ($mode == 'special' && $command == 'skill435_special' && $subcmd=='summon') 
		{
			ob_clean();
			include template('MOD_SKILL435_MERCPANEL');
			$cmd=ob_get_contents();
			ob_clean();
			$___TMP_MOD_skill435_FUNC_act_RET = NULL;
			break; 
		}
		
		if ($mode == 'special' && $command == 'skill435_special' && $subcmd=='action435') 
		{
			\skill435\action435 ();
			ob_clean();
			include template('MOD_SKILL435_MERCPANEL');
			$cmd=ob_get_contents();
			ob_clean();
			$___TMP_MOD_skill435_FUNC_act_RET = NULL;
			break; 
		}
if(isset($subcmd)) {$__VAR_DUMP_MOD_skill435_VARS_subcmd = $subcmd; unset($subcmd); } else {$__VAR_DUMP_MOD_skill435_VARS_subcmd = NULL;} 
		//======== Start of contents from mod skill56 ========
		do{
			$___TMP_MOD_skill56_FUNC_act_RET = NULL;

		
		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
		$subcmd = get_var_input('subcmd');
		if ($mode == 'special' && $command == 'skill56_special' && $subcmd=='summon') 
		{
			ob_clean();
			include template('MOD_SKILL56_MERCPANEL');
			$cmd=ob_get_contents();
			ob_clean();
			$___TMP_MOD_skill56_FUNC_act_RET = NULL;
			break; 
		}
		
		if ($mode == 'special' && $command == 'skill56_special' && $subcmd=='action56') 
		{
			\skill56\action56 ();
			ob_clean();
			include template('MOD_SKILL56_MERCPANEL');
			$cmd=ob_get_contents();
			ob_clean();
			$___TMP_MOD_skill56_FUNC_act_RET = NULL;
			break; 
		}
if(isset($subcmd)) {$__VAR_DUMP_MOD_skill56_VARS_subcmd = $subcmd; unset($subcmd); } else {$__VAR_DUMP_MOD_skill56_VARS_subcmd = NULL;} 
		//======== Start of contents from mod skill734 ========
		do{
			$___TMP_MOD_skill734_FUNC_act_RET = NULL;

		
		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
	
		if ($mode == 'special' && $command == 'skill734_special') 
		{
			\skill734\cast_skill734 ();
			$___TMP_MOD_skill734_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod skill588 ========
		do{
			$___TMP_MOD_skill588_FUNC_act_RET = NULL;

				
		
		if (get_var_in_module('mode', 'sys') == 'special' && get_var_in_module('command', 'sys') == 'skill588_special' && get_var_in_module('subcmd', 'input') == 'castsk588') 
		{
			\skill588\cast_skill588 ();
			$___TMP_MOD_skill588_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod skill599 ========
		do{
			$___TMP_MOD_skill599_FUNC_act_RET = NULL;

		
		
		
		if ($mode == 'special' && $command == 'skill599_special' && get_var_in_module('subcmd','input') == 'castsk599') 
		{
			\skill599\cast_skill599 ();
			$___TMP_MOD_skill599_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod tactic ========
		do{
			$___TMP_MOD_tactic_FUNC_act_RET = NULL;

		
		
		do { global $___LOCAL_TACTIC__VARS__tacinfo,$___LOCAL_TACTIC__VARS__tacticdesc,$___LOCAL_TACTIC__VARS__tacticremark,$___LOCAL_TACTIC__VARS__tactic_player_usable,$___LOCAL_TACTIC__VARS__tactic_hide_obbs,$___LOCAL_TACTIC__VARS__tactic_meetman_obbs,$___LOCAL_TACTIC__VARS__tactic_attack_modifier,$___LOCAL_TACTIC__VARS__tactic_defend_modifier; $tacinfo=&$___LOCAL_TACTIC__VARS__tacinfo; $tacticdesc=&$___LOCAL_TACTIC__VARS__tacticdesc; $tacticremark=&$___LOCAL_TACTIC__VARS__tacticremark; $tactic_player_usable=&$___LOCAL_TACTIC__VARS__tactic_player_usable; $tactic_hide_obbs=&$___LOCAL_TACTIC__VARS__tactic_hide_obbs; $tactic_meetman_obbs=&$___LOCAL_TACTIC__VARS__tactic_meetman_obbs; $tactic_attack_modifier=&$___LOCAL_TACTIC__VARS__tactic_attack_modifier; $tactic_defend_modifier=&$___LOCAL_TACTIC__VARS__tactic_defend_modifier;   } while (0);
		
		if($mode == 'special' && strpos($command,'tac') === 0)
		{
			\tactic\tactic_change (substr($command,3,1));
			$mode = 'command';
			$___TMP_MOD_tactic_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod skill579 ========
		do{
			$___TMP_MOD_skill579_FUNC_act_RET = NULL;

		
		
		
		if ($mode == 'command' && ($command=='rest1' || $command=='rest2' || $command=='rest3'))
		{
			if (\skillbase\skill_query(579,$sdata) && \skill579\check_unlocked579 ($sdata))
			{
				do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
				$log .= "<span class=\"yellow b\">你立于原地，摆好架势！</span><br>";
				$pose = 2;
			}
		}
		//======== Start of contents from mod skill487 ========
		do{
			$___TMP_MOD_skill487_FUNC_act_RET = NULL;

		
		
		//======== Start of contents from mod skill562 ========
		do{
			$___TMP_MOD_skill562_FUNC_act_RET = NULL;

			
		if (get_var_in_module('mode','sys') == 'rest' && get_var_in_module('command','sys') == 'back' && \skillbase\skill_query(562))
		{
			do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
			$log = "<span class=\"yellow b\">刚才好像做了个奇怪的梦……咦我这是在哪？</span><br><br>……<br><br>";
			\skillbase\skill_lost(562);
		}
		//======== Start of contents from mod pose ========
		do{
			$___TMP_MOD_pose_FUNC_act_RET = NULL;

		
		do { global $___LOCAL_POSE__VARS__poseinfo,$___LOCAL_POSE__VARS__posedesc,$___LOCAL_POSE__VARS__poseremark,$___LOCAL_POSE__VARS__pose_player_usable,$___LOCAL_POSE__VARS__pose_itemfind_obbs,$___LOCAL_POSE__VARS__pose_findman_obbs,$___LOCAL_POSE__VARS__pose_hide_obbs,$___LOCAL_POSE__VARS__pose_active_obbs,$___LOCAL_POSE__VARS__pose_dactive_obbs,$___LOCAL_POSE__VARS__pose_attack_modifier, $___LOCAL_POSE__VARS__pose_defend_modifier,$___LOCAL_POSE__VARS__pose_edible_modifier; $poseinfo=&$___LOCAL_POSE__VARS__poseinfo; $posedesc=&$___LOCAL_POSE__VARS__posedesc; $poseremark=&$___LOCAL_POSE__VARS__poseremark; $pose_player_usable=&$___LOCAL_POSE__VARS__pose_player_usable; $pose_itemfind_obbs=&$___LOCAL_POSE__VARS__pose_itemfind_obbs; $pose_findman_obbs=&$___LOCAL_POSE__VARS__pose_findman_obbs; $pose_hide_obbs=&$___LOCAL_POSE__VARS__pose_hide_obbs; $pose_active_obbs=&$___LOCAL_POSE__VARS__pose_active_obbs; $pose_dactive_obbs=&$___LOCAL_POSE__VARS__pose_dactive_obbs; $pose_attack_modifier=&$___LOCAL_POSE__VARS__pose_attack_modifier;  $pose_defend_modifier=&$___LOCAL_POSE__VARS__pose_defend_modifier; $pose_edible_modifier=&$___LOCAL_POSE__VARS__pose_edible_modifier;   } while (0);
		if ($mode == 'special' && strpos($command,'pose') === 0) 
		{
			\pose\pose_change (substr($command,4,1));
			$mode = 'command';
			$___TMP_MOD_pose_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod skill23 ========
		do{
			$___TMP_MOD_skill23_FUNC_act_RET = NULL;

		
		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
	
		if ($mode == 'special' && $command == 'skill23_special' && get_var_input('subcmd')=='gemming') 
		{
			\skill23\do_gemming ();
			$___TMP_MOD_skill23_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod skill12 ========
		do{
			$___TMP_MOD_skill12_FUNC_act_RET = NULL;

				
		
		if ($mode == 'special' && $command == 'skill12_special' && get_var_in_module('subcmd', 'input') == 'castsk12') 
		{
			\skill12\cast_skill12 ();
			$___TMP_MOD_skill12_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod rest ========
		do{
			$___TMP_MOD_rest_FUNC_act_RET = NULL;

		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
		
		if ($mode == 'command' && ($command=='rest1' || $command=='rest2' || $command=='rest3'))
		{
			do { global $___LOCAL_REST__VARS__rest_sleep_time,$___LOCAL_REST__VARS__rest_heal_time,$___LOCAL_REST__VARS__rest_recover_time,$___LOCAL_REST__VARS__restinfo,$___LOCAL_REST__VARS__rest_hospital_list; $rest_sleep_time=&$___LOCAL_REST__VARS__rest_sleep_time; $rest_heal_time=&$___LOCAL_REST__VARS__rest_heal_time; $rest_recover_time=&$___LOCAL_REST__VARS__rest_recover_time; $restinfo=&$___LOCAL_REST__VARS__restinfo; $rest_hospital_list=&$___LOCAL_REST__VARS__rest_hospital_list;   } while (0);
			if($command=='rest3' && !in_array($pls,$rest_hospital_list)){
				$log .= '<span class="yellow b">你所在的位置并非医院，不能静养！</span><br>';
			}else{
				$state = substr($command,4,1);
				$mode = 'rest';
				$log .= '你开始了'.$restinfo[$state].'…';
			}
			$___TMP_MOD_rest_FUNC_act_RET = NULL;
			break; 
		}
		
		if($mode == 'rest')
		{
			\rest\rest ($command);
			if ($command != 'rest') {
				$state = 0;
				$endtime = $now;
				$mode = 'command';
			}
			$___TMP_MOD_rest_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod poison ========
		do{
			$___TMP_MOD_poison_FUNC_act_RET = NULL;

		
		
		
		if($mode == 'item' && get_var_input('usemode') == 'poison') 
		{
			if ($command=='menu'){
				$mode = 'command';
				$___TMP_MOD_poison_FUNC_act_RET = NULL;
			break; 
			}
			$item = substr($command,3);
			\poison\poison ($item);
			$___TMP_MOD_poison_FUNC_act_RET = NULL;
			break; 
		}
if(isset($item)) {$__VAR_DUMP_MOD_poison_VARS_item = $item; unset($item); } else {$__VAR_DUMP_MOD_poison_VARS_item = NULL;} 
		//======== Start of contents from mod skill1013 ========
		do{
			$___TMP_MOD_skill1013_FUNC_act_RET = NULL;

		
		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
	
		if ($mode == 'special' && $command == 'skill1013_special') 
		{
			if (!\skillbase\skill_query(1013)) 
			{
				$log.='你没有这个技能。';
				$mode = 'command';$command = '';
				$___TMP_MOD_skill1013_FUNC_act_RET = NULL;
			break; 
			}
			$subcmd = get_var_input('subcmd');
			if(!isset($subcmd)){
				$mode = 'command';$command = '';
				$___TMP_MOD_skill1013_FUNC_act_RET = NULL;
			break; 
			}elseif($subcmd == 'sub_page') {
				\skill1013\skill1013_sub_page ();
				$___TMP_MOD_skill1013_FUNC_act_RET = NULL;
			break; 
			}elseif($subcmd == 'acquire'){
				$skillid = get_var_input('skillid');
				\skill1013\skill1013_acquire_skill ($skillid);
				$___TMP_MOD_skill1013_FUNC_act_RET = NULL;
			break; 
			}else{
				$log .= '命令参数错误。';
				$mode = 'command';$command = '';
				$___TMP_MOD_skill1013_FUNC_act_RET = NULL;
			break; 
			}
		}
if(isset($subcmd)) {$__VAR_DUMP_MOD_skill1013_VARS_subcmd = $subcmd; unset($subcmd); } else {$__VAR_DUMP_MOD_skill1013_VARS_subcmd = NULL;} 
		//======== Start of contents from mod skill110 ========
		do{
			$___TMP_MOD_skill110_FUNC_act_RET = NULL;

		
		
		if ($mode == 'special' && $command == 'skill110_special' && get_var_input('subcmd')=='castsk110') 
		{
			\skill110\cast_skill110 ();
			$___TMP_MOD_skill110_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod skill728 ========
		do{
			$___TMP_MOD_skill728_FUNC_act_RET = NULL;

		
		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
		if ($mode == 'special' && $command == 'skill728_special' && get_var_input('subcmd')=='castsk728') 
		{
			\skill728\cast_skill728 ();
			$___TMP_MOD_skill728_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod skill952 ========
		do{
			$___TMP_MOD_skill952_FUNC_act_RET = NULL;

		
		
		
	
		if ($mode == 'special' && $command == 'skill952_special') 
		{
			\skill952\cast_skill952 ();
			$___TMP_MOD_skill952_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod skill717 ========
		do{
			$___TMP_MOD_skill717_FUNC_act_RET = NULL;

		
		
		if (\skillbase\skill_query(717,$sdata) && ($mode == 'combat')) 
		{
			$pls_temp = \skillbase\skill_getvalue(717,'pls',$sdata);
			if (!empty($pls_temp)) swap($pls, $pls_temp);
		}
		//======== Start of contents from mod skill716 ========
		do{
			$___TMP_MOD_skill716_FUNC_act_RET = NULL;

		
		
		
		if ($mode == 'special' && $command == 'skill716_special') 
		{
			$subcmd = get_var_in_module('subcmd','input');
			if ($subcmd == 'castsk716_1') \skill716\cast_skill716 (1);
			if ($subcmd == 'castsk716_2') \skill716\cast_skill716 (2);
			$___TMP_MOD_skill716_FUNC_act_RET = NULL;
			break; 
		}
if(isset($subcmd)) {$__VAR_DUMP_MOD_skill716_VARS_subcmd = $subcmd; unset($subcmd); } else {$__VAR_DUMP_MOD_skill716_VARS_subcmd = NULL;} 
		//======== Start of contents from mod skill586 ========
		do{
			$___TMP_MOD_skill586_FUNC_act_RET = NULL;

		
		
		
	
		if ($mode == 'special' && $command == 'skill586_special') 
		{
			\skill586\cast_skill586 ();
			$___TMP_MOD_skill586_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod skill589 ========
		do{
			$___TMP_MOD_skill589_FUNC_act_RET = NULL;

		
		if (get_var_in_module('mode', 'sys') == 'special' && get_var_in_module('command', 'sys') == 'skill589_special' && get_var_in_module('subcmd', 'input') == 'castsk589') 
		{
			\skill589\cast_skill589 ();
			$___TMP_MOD_skill589_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod skill534 ========
		do{
			$___TMP_MOD_skill534_FUNC_act_RET = NULL;

		
		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
	
		if ($mode == 'special' && $command == 'skill534_special') 
		{
			\skill534\cast_skill534 ();
			$___TMP_MOD_skill534_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod skill1012 ========
		do{
			$___TMP_MOD_skill1012_FUNC_act_RET = NULL;

		
		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
	
		if ($mode == 'special' && $command == 'skill1012_special') 
		{
			if (!\skillbase\skill_query(1012)) 
			{
				$log.='你没有这个技能。';
				$mode = 'command';$command = '';
				$___TMP_MOD_skill1012_FUNC_act_RET = NULL;
			break; 
			}
			$subcmd = get_var_input('subcmd');
			if(!isset($subcmd)){
				$mode = 'command';$command = '';
				$___TMP_MOD_skill1012_FUNC_act_RET = NULL;
			break; 
			}elseif($subcmd == 'sub_page') {
				\skill1012\skill1012_sub_page ();
				$___TMP_MOD_skill1012_FUNC_act_RET = NULL;
			break; 
			}elseif($subcmd == 'show_var'){
				$show_ns = get_var_input('show_ns');
				$show_vn = get_var_input('show_vn');
				\skill1012\skill1012_show_var ($show_ns, $show_vn);
				$___TMP_MOD_skill1012_FUNC_act_RET = NULL;
			break; 
			}else{
				$log .= '命令参数错误。';
				$mode = 'command';$command = '';
				$___TMP_MOD_skill1012_FUNC_act_RET = NULL;
			break; 
			}
		}
if(isset($subcmd)) {$__VAR_DUMP_MOD_skill1012_VARS_subcmd = $subcmd; unset($subcmd); } else {$__VAR_DUMP_MOD_skill1012_VARS_subcmd = NULL;} 
		//======== Start of contents from mod skill552 ========
		do{
			$___TMP_MOD_skill552_FUNC_act_RET = NULL;

				
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
		if ($mode == 'special' && $command == 'skill552_special' && get_var_input('subcmd')=='castsk552') 
		{
			\skill552\cast_skill552 ();
			$___TMP_MOD_skill552_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod skill518 ========
		do{
			$___TMP_MOD_skill518_FUNC_act_RET = NULL;

		
		if(\skillbase\skill_query(518) && \skill518\check_unlocked518 ()){
			\skill518\check_time_add518 ();
		}
		//======== Start of contents from mod skill424 ========
		do{
			$___TMP_MOD_skill424_FUNC_act_RET = NULL;

		
		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
	
		if ($mode == 'special' && $command == 'skill424_special' && get_var_input('subcmd')=='wdebug') 
		{
			\skill424\wdebug ();
			$___TMP_MOD_skill424_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod skill235 ========
		do{
			$___TMP_MOD_skill235_FUNC_act_RET = NULL;

		
		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
	
		if ($mode == 'special' && $command == 'skill235_special' && get_var_input('subcmd')=='wscan') 
		{
			\skill235\wscan ();
			$___TMP_MOD_skill235_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod skill234 ========
		do{
			$___TMP_MOD_skill234_FUNC_act_RET = NULL;

		
		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
	
		if ($mode == 'special' && $command == 'skill234_special' && get_var_input('subcmd')=='wdecode') 
		{
			\skill234\wdecode ();
			$___TMP_MOD_skill234_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod skill1010 ========
		do{
			$___TMP_MOD_skill1010_FUNC_act_RET = NULL;

		
		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
	
		if ($mode == 'special' && $command == 'skill1010_special') 
		{
			$subcmd = get_var_input('subcmd');
			$mpid = get_var_input('mpid');
			if (!\skillbase\skill_query(1010)) 
			{
				$log.='你没有这个技能。';
				$mode = 'command';$command = '';
				$___TMP_MOD_skill1010_FUNC_act_RET = NULL;
			break; 
			}
			if(!isset($subcmd)){
				$mode = 'command';$command = '';
				$___TMP_MOD_skill1010_FUNC_act_RET = NULL;
			break; 
			}elseif($subcmd == 'mani_page') {
				\skill1010\skill1010_mani_page ();
				$___TMP_MOD_skill1010_FUNC_act_RET = NULL;
			break; 
			}elseif($subcmd == 'meet' || $subcmd == 'exma'){
				$mpid = (int)$mpid;
				$pcs = \skill1010\skill1010_mani_load_pcs ($pls);
				if(!isset($pcs[$mpid])) {
					$log .= '该角色不在当前地图。';
					$mode = 'command';$command = '';
					$___TMP_MOD_skill1010_FUNC_act_RET = NULL;
			break; 
				}
				if($subcmd == 'meet'){
					addnews (0, 'admin_mani', $name, $pcs[$mpid]['name'] );
					\metman\meetman($mpid);
				}else{
					if(!$pcs[$mpid]['type']) {
						$log .= '只能与NPC交换装备。';
					}else{
						addnews (0, 'admin_exma', $name, $pcs[$mpid]['name'] );
						\skill1010\skill1010_exma ($mpid);
					}
					$mode = 'command';$command = '';
					$___TMP_MOD_skill1010_FUNC_act_RET = NULL;
			break; 
				}
			}else{
				$log .= '命令参数错误。';
				$mode = 'command';$command = '';
				$___TMP_MOD_skill1010_FUNC_act_RET = NULL;
			break; 
			}
		}
if(isset($subcmd)) {$__VAR_DUMP_MOD_skill1010_VARS_subcmd = $subcmd; unset($subcmd); } else {$__VAR_DUMP_MOD_skill1010_VARS_subcmd = NULL;} 
		//======== Start of contents from mod skill1011 ========
		do{
			$___TMP_MOD_skill1011_FUNC_act_RET = NULL;

		
		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
	
		if ($mode == 'special' && $command == 'skill1011_special') 
		{
			if (!\skillbase\skill_query(1011)) 
			{
				$log.='你没有这个技能。';
				$mode = 'command';$command = '';
				$___TMP_MOD_skill1011_FUNC_act_RET = NULL;
			break; 
			}
			$subcmd = get_var_input('subcmd');
			if(empty($subcmd)){
				$mode = 'command';$command = '';
				$___TMP_MOD_skill1011_FUNC_act_RET = NULL;
			break; 
			}elseif(strpos($subcmd,'cons_page')===0) {
				$page = (int)str_replace('cons_page','',$subcmd);
				if(!$page) $page = 1;
				\skill1011\skill1011_cons_page ($page);
				$___TMP_MOD_skill1011_FUNC_act_RET = NULL;
			break; 
			}elseif(strpos($subcmd,'cons')===0){
				$cons_pls = get_var_input('cons_pls');
				$ciid = (int)str_replace('cons','',$subcmd);
				$itemlist = \skill1011\skill1011_load_itemlist ($cons_pls);
				if(isset($itemlist[$ciid])){
					$item = $itemlist[$ciid];
					$itm0=$item['itm'];
					$itmk0=$item['itmk'];
					$itme0=$item['itme'];
					$itms0=$item['itms'];
					$itmsk0=$item['itmsk'];
					if(defined('MOD_ATTRBASE')) {
						$itmsk0=\attrbase\config_process_encode_comp_itmsk($itmsk0);
					}
					addnews (0, 'admin_cons', $name, $itm0 );
					\itemmain\itemget();
				}else{
					$log .= '道具参数错误。';
					$mode = 'command';$command = '';
					$___TMP_MOD_skill1011_FUNC_act_RET = NULL;
			break; 
				}
			}else{
				$log .= '命令参数错误。';
				$mode = 'command';$command = '';
				$___TMP_MOD_skill1011_FUNC_act_RET = NULL;
			break; 
			}
		}
if(isset($subcmd)) {$__VAR_DUMP_MOD_skill1011_VARS_subcmd = $subcmd; unset($subcmd); } else {$__VAR_DUMP_MOD_skill1011_VARS_subcmd = NULL;} if(isset($item)) {$__VAR_DUMP_MOD_skill1011_VARS_item = $item; unset($item); } else {$__VAR_DUMP_MOD_skill1011_VARS_item = NULL;} 
		//======== Start of contents from mod skill480 ========
		do{
			$___TMP_MOD_skill480_FUNC_act_RET = NULL;

		
		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
	
		if ($mode == 'special' && $command == 'skill480_activate') 
		{
			if (!\skillbase\skill_query(480)) 
			{
				$log.='你没有这个技能。';
				$mode = 'command';$command = '';
				$___TMP_MOD_skill480_FUNC_act_RET = NULL;
			break; 
			}
			\skill480\skill480_activate ();
		}
		//======== Start of contents from mod skill1001 ========
		do{
			$___TMP_MOD_skill1001_FUNC_act_RET = NULL;

		
		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
		
		if ($mode == 'special' && $command == 'skill1001_special') 
		{
			if (!\skillbase\skill_query(1001)) 
			{
				$log.='你没有这个技能。';
				$mode = 'command';$command = '';
				$___TMP_MOD_skill1001_FUNC_act_RET = NULL;
			break; 
			}
			$subcmd = get_var_input('subcmd');
			if(empty($subcmd)){
				$log.='技能参数丢失。';
				$mode = 'command';$command = '';
				$___TMP_MOD_skill1001_FUNC_act_RET = NULL;
			break; 
			}
			\skill1001\process_1001 ($subcmd);
			$___TMP_MOD_skill1001_FUNC_act_RET = NULL;
			break; 
		}
if(isset($subcmd)) {$__VAR_DUMP_MOD_skill1001_VARS_subcmd = $subcmd; unset($subcmd); } else {$__VAR_DUMP_MOD_skill1001_VARS_subcmd = NULL;} 
		//======== Start of contents from mod skill437 ========
		do{
			$___TMP_MOD_skill437_FUNC_act_RET = NULL;

		
		
		
		if($mode == 'combat' && $command == 'back' && strpos($action, 'enemy')===0) 
		{
			do { global $___LOCAL_WEAPON__VARS__nowep,$___LOCAL_WEAPON__VARS__nosta,$___LOCAL_WEAPON__VARS__skilltypeinfo,$___LOCAL_WEAPON__VARS__attinfo,$___LOCAL_WEAPON__VARS__attinfo2,$___LOCAL_WEAPON__VARS__skillinfo,$___LOCAL_WEAPON__VARS__wep_equip_list,$___LOCAL_WEAPON__VARS__counter_obbs,$___LOCAL_WEAPON__VARS__rangeinfo,$___LOCAL_WEAPON__VARS__hitrate_obbs, $___LOCAL_WEAPON__VARS__hitrate_max_obbs,$___LOCAL_WEAPON__VARS__hitrate_r,$___LOCAL_WEAPON__VARS__dmg_fluc,$___LOCAL_WEAPON__VARS__skill_dmg,$___LOCAL_WEAPON__VARS__wepimprate,$___LOCAL_WEAPON__VARS__wepdeathstate; $nowep=&$___LOCAL_WEAPON__VARS__nowep; $nosta=&$___LOCAL_WEAPON__VARS__nosta; $skilltypeinfo=&$___LOCAL_WEAPON__VARS__skilltypeinfo; $attinfo=&$___LOCAL_WEAPON__VARS__attinfo; $attinfo2=&$___LOCAL_WEAPON__VARS__attinfo2; $skillinfo=&$___LOCAL_WEAPON__VARS__skillinfo; $wep_equip_list=&$___LOCAL_WEAPON__VARS__wep_equip_list; $counter_obbs=&$___LOCAL_WEAPON__VARS__counter_obbs; $rangeinfo=&$___LOCAL_WEAPON__VARS__rangeinfo; $hitrate_obbs=&$___LOCAL_WEAPON__VARS__hitrate_obbs;  $hitrate_max_obbs=&$___LOCAL_WEAPON__VARS__hitrate_max_obbs; $hitrate_r=&$___LOCAL_WEAPON__VARS__hitrate_r; $dmg_fluc=&$___LOCAL_WEAPON__VARS__dmg_fluc; $skill_dmg=&$___LOCAL_WEAPON__VARS__skill_dmg; $wepimprate=&$___LOCAL_WEAPON__VARS__wepimprate; $wepdeathstate=&$___LOCAL_WEAPON__VARS__wepdeathstate;   } while (0);
			if ((\skillbase\skill_query(437))&&(\skill437\check_unlocked437 ())){
				${$skillinfo[substr($wepk,1,1)]}+=3;
				\lvlctl\getexp(2);
				
			}
		}
		//======== Start of contents from mod wound ========
		do{
			$___TMP_MOD_wound_FUNC_act_RET = NULL;

		
		
		
		if ($mode == 'special' && strpos($command,'inf') === 0) 
		{
			$infpos = substr($command,3,1);
			\wound\chginf ($infpos);
			$___TMP_MOD_wound_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod clubbase ========
		do{
			$___TMP_MOD_clubbase_FUNC_act_RET = NULL;

		
		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
		if($mode == 'special' && strpos($command,'clubsel') === 0) 
		{
			$clubchosen = (int)substr($command,7);
			$retval = \clubbase\player_selectclub ($clubchosen);
			if ($retval==0)
				$log.="称号选择成功。<br>";
			else if ($retval==1)
				$log.="称号选择失败，称号一旦被选择便无法更改。<br>";
			else if ($retval==2)
				$log.="未选择称号。<br>";
			else  $log.="称号选择非法！<br>";
			$mode = 'command';
			$___TMP_MOD_clubbase_FUNC_act_RET = NULL;
			break; 
		}
		
		if ($mode == 'special' && $command == 'viewskills') 
		{
			$mode = MOD_CLUBBASE_SKILLPAGE;
			$___TMP_MOD_clubbase_FUNC_act_RET = NULL;
			break; 
		}
		$subcmd = get_var_input('subcmd');
		if ($mode == 'special' && substr($command,0,5) == 'skill' && substr($command,-8)=='_special' && ($subcmd=='upgrade' || $subcmd=='activate')) 
		{
			$id=substr($command,5,-8); $id=(int)$id;
			
			if (\skillbase\check_skill_info($id,'upgrade') && \skillbase\skill_query($id))
			{
				$func='skill'.$id.'\\'.$subcmd.$id;
				$func();
			}
			else
			{
				$log.='你不能发动这个技能。<br>';
			}
			if ($subcmd=='activate')
				$mode = 'command';
			else  $mode = MOD_CLUBBASE_SKILLPAGE;
			$___TMP_MOD_clubbase_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod advteam ========
		do{
			$___TMP_MOD_advteam_FUNC_act_RET = NULL;

		
		do { global $___LOCAL_MAP__VARS__all_plsno_cache,$___LOCAL_MAP__VARS__areainterval,$___LOCAL_MAP__VARS__areaadd,$___LOCAL_MAP__VARS__areawarntime,$___LOCAL_MAP__VARS__arealimit,$___LOCAL_MAP__VARS__areaesc,$___LOCAL_MAP__VARS__area_on_start,$___LOCAL_MAP__VARS__dangerous_zone,$___LOCAL_MAP__VARS__plsinfo,$___LOCAL_MAP__VARS__plsinfo_o, $___LOCAL_MAP__VARS__plsinfo_disp,$___LOCAL_MAP__VARS__plsinfo_for_short,$___LOCAL_MAP__VARS__xyinfo,$___LOCAL_MAP__VARS__areainfo; $all_plsno_cache=&$___LOCAL_MAP__VARS__all_plsno_cache; $areainterval=&$___LOCAL_MAP__VARS__areainterval; $areaadd=&$___LOCAL_MAP__VARS__areaadd; $areawarntime=&$___LOCAL_MAP__VARS__areawarntime; $arealimit=&$___LOCAL_MAP__VARS__arealimit; $areaesc=&$___LOCAL_MAP__VARS__areaesc; $area_on_start=&$___LOCAL_MAP__VARS__area_on_start; $dangerous_zone=&$___LOCAL_MAP__VARS__dangerous_zone; $plsinfo=&$___LOCAL_MAP__VARS__plsinfo; $plsinfo_o=&$___LOCAL_MAP__VARS__plsinfo_o;  $plsinfo_disp=&$___LOCAL_MAP__VARS__plsinfo_disp; $plsinfo_for_short=&$___LOCAL_MAP__VARS__plsinfo_for_short; $xyinfo=&$___LOCAL_MAP__VARS__xyinfo; $areainfo=&$___LOCAL_MAP__VARS__areainfo;  global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
		if ($mode == "advteamspecial") 
		{
			if (!in_array($gametype,$teamwin_mode)) 
			{ 
				$log.="此命令在本游戏模式下不可用。<br>"; 
				$mode = 'command';
			}
			else
			{
				if ($command=="sendflare")
				{
					$log.="发出支援请求成功。<br>";
					$flare=1;
					$mode='command';
				}
				else  if ($command=="stopflare")
				{
					$log.="取消支援请求成功。<br>";
					$flare=0;
					$mode='command';
				}
				else  if (strpos($command,'findteam') === 0)
				{
					$which=(int)substr($command,8);
					$edata = \player\fetch_playerdata_by_pid($which);
					if ($edata === NULL)
					{
						$log.="队友不存在。<br>";
						$mode='command';
					}
					else
					{
						if (!$teamID || $edata['teamID']!=$teamID)
						{
							$log.="对方不是你的队友！<br>";
							$mode='command';
						}
						else  if ($edata['hp']<=0)
						{
							$log.="对方已经死亡！<br>";
							$mode=='command';
						}
						else  if ($edata['pls']!=$pls)
						{
							$log.="对方与你不在同一个地图！<br>";
							$mode=='command';
						}
						else
						{
							\team\findteam($edata);
						}	
					}
				}
			}
			$___TMP_MOD_advteam_FUNC_act_RET = NULL;
			break; 
		}
if(isset($edata)) {$__VAR_DUMP_MOD_advteam_VARS_edata = $edata; unset($edata); } else {$__VAR_DUMP_MOD_advteam_VARS_edata = NULL;} 
		//======== Start of contents from mod item_misc ========
		do{
			$___TMP_MOD_item_misc_FUNC_act_RET = NULL;

		
		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
		
		if($mode == 'deathnote') {
			$dnname = get_var_input('dnname');
			if($dnname){
				list($item, $dndeath, $dngender, $dnicon) = get_var_input('item', 'dndeath', 'dngender', 'dnicon');
				\item_misc\deathnote ($item, $dnname, $dndeath, $dngender, $dnicon);
			} else {
				$log .= '嗯，暂时还不想杀人。<br>你合上了■DeathNote■。<br>';
				$mode = 'command';
			}
			$___TMP_MOD_item_misc_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod team ========
		do{
			$___TMP_MOD_team_FUNC_act_RET = NULL;

		
		
		
		if($mode == 'senditem') 
		{
			\team\senditem ();
			$___TMP_MOD_team_FUNC_act_RET = NULL;
			break; 
		}
		
		if($mode == 'command' && $command == 'team') {
			$teamcmd = get_var_input('teamcmd');
			if($teamcmd == 'teamquit') {				
				\team\teamquit ();
			} else{
				\team\teamcheck ();
			}
			$___TMP_MOD_team_FUNC_act_RET = NULL;
			break; 
		}
		
		if($mode == 'team') {
			list($nteamID,$nteamPass) = get_var_input('nteamID','nteamPass');
			if ($command=='teammake') 
			{
				\team\teammake ($nteamID,$nteamPass);
				$___TMP_MOD_team_FUNC_act_RET = NULL;
			break;  
			}
			if ($command=='teamjoin')
			{
				\team\teamjoin ($nteamID,$nteamPass);
				$___TMP_MOD_team_FUNC_act_RET = NULL;
			break; 
			}
		}
		//======== Start of contents from mod enemy ========
		do{
			$___TMP_MOD_enemy_FUNC_act_RET = NULL;

		
		
		do { global $___LOCAL_MAP__VARS__all_plsno_cache,$___LOCAL_MAP__VARS__areainterval,$___LOCAL_MAP__VARS__areaadd,$___LOCAL_MAP__VARS__areawarntime,$___LOCAL_MAP__VARS__arealimit,$___LOCAL_MAP__VARS__areaesc,$___LOCAL_MAP__VARS__area_on_start,$___LOCAL_MAP__VARS__dangerous_zone,$___LOCAL_MAP__VARS__plsinfo,$___LOCAL_MAP__VARS__plsinfo_o, $___LOCAL_MAP__VARS__plsinfo_disp,$___LOCAL_MAP__VARS__plsinfo_for_short,$___LOCAL_MAP__VARS__xyinfo,$___LOCAL_MAP__VARS__areainfo; $all_plsno_cache=&$___LOCAL_MAP__VARS__all_plsno_cache; $areainterval=&$___LOCAL_MAP__VARS__areainterval; $areaadd=&$___LOCAL_MAP__VARS__areaadd; $areawarntime=&$___LOCAL_MAP__VARS__areawarntime; $arealimit=&$___LOCAL_MAP__VARS__arealimit; $areaesc=&$___LOCAL_MAP__VARS__areaesc; $area_on_start=&$___LOCAL_MAP__VARS__area_on_start; $dangerous_zone=&$___LOCAL_MAP__VARS__dangerous_zone; $plsinfo=&$___LOCAL_MAP__VARS__plsinfo; $plsinfo_o=&$___LOCAL_MAP__VARS__plsinfo_o;  $plsinfo_disp=&$___LOCAL_MAP__VARS__plsinfo_disp; $plsinfo_for_short=&$___LOCAL_MAP__VARS__plsinfo_for_short; $xyinfo=&$___LOCAL_MAP__VARS__xyinfo; $areainfo=&$___LOCAL_MAP__VARS__areainfo;  global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;  global $___LOCAL_METMAN__VARS__tdata,$___LOCAL_METMAN__VARS__w_upexp,$___LOCAL_METMAN__VARS__battle_title,$___LOCAL_METMAN__VARS__hideflag,$___LOCAL_METMAN__VARS__hidelog,$___LOCAL_METMAN__VARS__hpinfo,$___LOCAL_METMAN__VARS__spinfo,$___LOCAL_METMAN__VARS__rageinfo,$___LOCAL_METMAN__VARS__wepeinfo,$___LOCAL_METMAN__VARS__metman_obbs, $___LOCAL_METMAN__VARS__w_pid,$___LOCAL_METMAN__VARS__w_type,$___LOCAL_METMAN__VARS__w_name,$___LOCAL_METMAN__VARS__w_pass,$___LOCAL_METMAN__VARS__w_ip,$___LOCAL_METMAN__VARS__w_motto,$___LOCAL_METMAN__VARS__w_killmsg,$___LOCAL_METMAN__VARS__w_lastword,$___LOCAL_METMAN__VARS__w_winner_flag,$___LOCAL_METMAN__VARS__w_player_dead_flag, $___LOCAL_METMAN__VARS__w_corpse_clear_flag,$___LOCAL_METMAN__VARS__w_gd,$___LOCAL_METMAN__VARS__w_sNo,$___LOCAL_METMAN__VARS__w_club,$___LOCAL_METMAN__VARS__w_validtime,$___LOCAL_METMAN__VARS__w_endtime,$___LOCAL_METMAN__VARS__w_cdsec,$___LOCAL_METMAN__VARS__w_cdmsec,$___LOCAL_METMAN__VARS__w_cdtime,$___LOCAL_METMAN__VARS__w_action, $___LOCAL_METMAN__VARS__w_a_actionnum,$___LOCAL_METMAN__VARS__w_v_actionnum,$___LOCAL_METMAN__VARS__w_hp,$___LOCAL_METMAN__VARS__w_mhp,$___LOCAL_METMAN__VARS__w_sp,$___LOCAL_METMAN__VARS__w_msp,$___LOCAL_METMAN__VARS__w_ss,$___LOCAL_METMAN__VARS__w_mss,$___LOCAL_METMAN__VARS__w_att,$___LOCAL_METMAN__VARS__w_def, $___LOCAL_METMAN__VARS__w_pls,$___LOCAL_METMAN__VARS__w_lvl,$___LOCAL_METMAN__VARS__w_exp,$___LOCAL_METMAN__VARS__w_money,$___LOCAL_METMAN__VARS__w_rp,$___LOCAL_METMAN__VARS__w_bid,$___LOCAL_METMAN__VARS__w_inf,$___LOCAL_METMAN__VARS__w_rage,$___LOCAL_METMAN__VARS__w_pose,$___LOCAL_METMAN__VARS__w_tactic, $___LOCAL_METMAN__VARS__w_killnum,$___LOCAL_METMAN__VARS__w_npckillnum,$___LOCAL_METMAN__VARS__w_state,$___LOCAL_METMAN__VARS__w_skillpoint,$___LOCAL_METMAN__VARS__w_flare,$___LOCAL_METMAN__VARS__w_wp,$___LOCAL_METMAN__VARS__w_wk,$___LOCAL_METMAN__VARS__w_wg,$___LOCAL_METMAN__VARS__w_wc,$___LOCAL_METMAN__VARS__w_wd, $___LOCAL_METMAN__VARS__w_wf,$___LOCAL_METMAN__VARS__w_icon,$___LOCAL_METMAN__VARS__w_teamID,$___LOCAL_METMAN__VARS__w_teamPass,$___LOCAL_METMAN__VARS__w_card,$___LOCAL_METMAN__VARS__w_cardname,$___LOCAL_METMAN__VARS__w_wep,$___LOCAL_METMAN__VARS__w_wepk,$___LOCAL_METMAN__VARS__w_wepe,$___LOCAL_METMAN__VARS__w_weps, $___LOCAL_METMAN__VARS__w_wepsk,$___LOCAL_METMAN__VARS__w_arb,$___LOCAL_METMAN__VARS__w_arbk,$___LOCAL_METMAN__VARS__w_arbe,$___LOCAL_METMAN__VARS__w_arbs,$___LOCAL_METMAN__VARS__w_arbsk,$___LOCAL_METMAN__VARS__w_arh,$___LOCAL_METMAN__VARS__w_arhk,$___LOCAL_METMAN__VARS__w_arhe,$___LOCAL_METMAN__VARS__w_arhs, $___LOCAL_METMAN__VARS__w_arhsk,$___LOCAL_METMAN__VARS__w_ara,$___LOCAL_METMAN__VARS__w_arak,$___LOCAL_METMAN__VARS__w_arae,$___LOCAL_METMAN__VARS__w_aras,$___LOCAL_METMAN__VARS__w_arask,$___LOCAL_METMAN__VARS__w_arf,$___LOCAL_METMAN__VARS__w_arfk,$___LOCAL_METMAN__VARS__w_arfe,$___LOCAL_METMAN__VARS__w_arfs, $___LOCAL_METMAN__VARS__w_arfsk,$___LOCAL_METMAN__VARS__w_art,$___LOCAL_METMAN__VARS__w_artk,$___LOCAL_METMAN__VARS__w_arte,$___LOCAL_METMAN__VARS__w_arts,$___LOCAL_METMAN__VARS__w_artsk,$___LOCAL_METMAN__VARS__w_itm0,$___LOCAL_METMAN__VARS__w_itmk0,$___LOCAL_METMAN__VARS__w_itme0,$___LOCAL_METMAN__VARS__w_itms0, $___LOCAL_METMAN__VARS__w_itmsk0,$___LOCAL_METMAN__VARS__w_itm1,$___LOCAL_METMAN__VARS__w_itmk1,$___LOCAL_METMAN__VARS__w_itme1,$___LOCAL_METMAN__VARS__w_itms1,$___LOCAL_METMAN__VARS__w_itmsk1,$___LOCAL_METMAN__VARS__w_itm2,$___LOCAL_METMAN__VARS__w_itmk2,$___LOCAL_METMAN__VARS__w_itme2,$___LOCAL_METMAN__VARS__w_itms2, $___LOCAL_METMAN__VARS__w_itmsk2,$___LOCAL_METMAN__VARS__w_itm3,$___LOCAL_METMAN__VARS__w_itmk3,$___LOCAL_METMAN__VARS__w_itme3,$___LOCAL_METMAN__VARS__w_itms3,$___LOCAL_METMAN__VARS__w_itmsk3,$___LOCAL_METMAN__VARS__w_itm4,$___LOCAL_METMAN__VARS__w_itmk4,$___LOCAL_METMAN__VARS__w_itme4,$___LOCAL_METMAN__VARS__w_itms4, $___LOCAL_METMAN__VARS__w_itmsk4,$___LOCAL_METMAN__VARS__w_itm5,$___LOCAL_METMAN__VARS__w_itmk5,$___LOCAL_METMAN__VARS__w_itme5,$___LOCAL_METMAN__VARS__w_itms5,$___LOCAL_METMAN__VARS__w_itmsk5,$___LOCAL_METMAN__VARS__w_itm6,$___LOCAL_METMAN__VARS__w_itmk6,$___LOCAL_METMAN__VARS__w_itme6,$___LOCAL_METMAN__VARS__w_itms6, $___LOCAL_METMAN__VARS__w_itmsk6,$___LOCAL_METMAN__VARS__w_searchmemory,$___LOCAL_METMAN__VARS__w_nskill,$___LOCAL_METMAN__VARS__w_nskillpara; $tdata=&$___LOCAL_METMAN__VARS__tdata; $w_upexp=&$___LOCAL_METMAN__VARS__w_upexp; $battle_title=&$___LOCAL_METMAN__VARS__battle_title; $hideflag=&$___LOCAL_METMAN__VARS__hideflag; $hidelog=&$___LOCAL_METMAN__VARS__hidelog; $hpinfo=&$___LOCAL_METMAN__VARS__hpinfo; $spinfo=&$___LOCAL_METMAN__VARS__spinfo; $rageinfo=&$___LOCAL_METMAN__VARS__rageinfo; $wepeinfo=&$___LOCAL_METMAN__VARS__wepeinfo; $metman_obbs=&$___LOCAL_METMAN__VARS__metman_obbs;  $w_pid=&$___LOCAL_METMAN__VARS__w_pid; $w_type=&$___LOCAL_METMAN__VARS__w_type; $w_name=&$___LOCAL_METMAN__VARS__w_name; $w_pass=&$___LOCAL_METMAN__VARS__w_pass; $w_ip=&$___LOCAL_METMAN__VARS__w_ip; $w_motto=&$___LOCAL_METMAN__VARS__w_motto; $w_killmsg=&$___LOCAL_METMAN__VARS__w_killmsg; $w_lastword=&$___LOCAL_METMAN__VARS__w_lastword; $w_winner_flag=&$___LOCAL_METMAN__VARS__w_winner_flag; $w_player_dead_flag=&$___LOCAL_METMAN__VARS__w_player_dead_flag;  $w_corpse_clear_flag=&$___LOCAL_METMAN__VARS__w_corpse_clear_flag; $w_gd=&$___LOCAL_METMAN__VARS__w_gd; $w_sNo=&$___LOCAL_METMAN__VARS__w_sNo; $w_club=&$___LOCAL_METMAN__VARS__w_club; $w_validtime=&$___LOCAL_METMAN__VARS__w_validtime; $w_endtime=&$___LOCAL_METMAN__VARS__w_endtime; $w_cdsec=&$___LOCAL_METMAN__VARS__w_cdsec; $w_cdmsec=&$___LOCAL_METMAN__VARS__w_cdmsec; $w_cdtime=&$___LOCAL_METMAN__VARS__w_cdtime; $w_action=&$___LOCAL_METMAN__VARS__w_action;  $w_a_actionnum=&$___LOCAL_METMAN__VARS__w_a_actionnum; $w_v_actionnum=&$___LOCAL_METMAN__VARS__w_v_actionnum; $w_hp=&$___LOCAL_METMAN__VARS__w_hp; $w_mhp=&$___LOCAL_METMAN__VARS__w_mhp; $w_sp=&$___LOCAL_METMAN__VARS__w_sp; $w_msp=&$___LOCAL_METMAN__VARS__w_msp; $w_ss=&$___LOCAL_METMAN__VARS__w_ss; $w_mss=&$___LOCAL_METMAN__VARS__w_mss; $w_att=&$___LOCAL_METMAN__VARS__w_att; $w_def=&$___LOCAL_METMAN__VARS__w_def;  $w_pls=&$___LOCAL_METMAN__VARS__w_pls; $w_lvl=&$___LOCAL_METMAN__VARS__w_lvl; $w_exp=&$___LOCAL_METMAN__VARS__w_exp; $w_money=&$___LOCAL_METMAN__VARS__w_money; $w_rp=&$___LOCAL_METMAN__VARS__w_rp; $w_bid=&$___LOCAL_METMAN__VARS__w_bid; $w_inf=&$___LOCAL_METMAN__VARS__w_inf; $w_rage=&$___LOCAL_METMAN__VARS__w_rage; $w_pose=&$___LOCAL_METMAN__VARS__w_pose; $w_tactic=&$___LOCAL_METMAN__VARS__w_tactic;  $w_killnum=&$___LOCAL_METMAN__VARS__w_killnum; $w_npckillnum=&$___LOCAL_METMAN__VARS__w_npckillnum; $w_state=&$___LOCAL_METMAN__VARS__w_state; $w_skillpoint=&$___LOCAL_METMAN__VARS__w_skillpoint; $w_flare=&$___LOCAL_METMAN__VARS__w_flare; $w_wp=&$___LOCAL_METMAN__VARS__w_wp; $w_wk=&$___LOCAL_METMAN__VARS__w_wk; $w_wg=&$___LOCAL_METMAN__VARS__w_wg; $w_wc=&$___LOCAL_METMAN__VARS__w_wc; $w_wd=&$___LOCAL_METMAN__VARS__w_wd;  $w_wf=&$___LOCAL_METMAN__VARS__w_wf; $w_icon=&$___LOCAL_METMAN__VARS__w_icon; $w_teamID=&$___LOCAL_METMAN__VARS__w_teamID; $w_teamPass=&$___LOCAL_METMAN__VARS__w_teamPass; $w_card=&$___LOCAL_METMAN__VARS__w_card; $w_cardname=&$___LOCAL_METMAN__VARS__w_cardname; $w_wep=&$___LOCAL_METMAN__VARS__w_wep; $w_wepk=&$___LOCAL_METMAN__VARS__w_wepk; $w_wepe=&$___LOCAL_METMAN__VARS__w_wepe; $w_weps=&$___LOCAL_METMAN__VARS__w_weps;  $w_wepsk=&$___LOCAL_METMAN__VARS__w_wepsk; $w_arb=&$___LOCAL_METMAN__VARS__w_arb; $w_arbk=&$___LOCAL_METMAN__VARS__w_arbk; $w_arbe=&$___LOCAL_METMAN__VARS__w_arbe; $w_arbs=&$___LOCAL_METMAN__VARS__w_arbs; $w_arbsk=&$___LOCAL_METMAN__VARS__w_arbsk; $w_arh=&$___LOCAL_METMAN__VARS__w_arh; $w_arhk=&$___LOCAL_METMAN__VARS__w_arhk; $w_arhe=&$___LOCAL_METMAN__VARS__w_arhe; $w_arhs=&$___LOCAL_METMAN__VARS__w_arhs;  $w_arhsk=&$___LOCAL_METMAN__VARS__w_arhsk; $w_ara=&$___LOCAL_METMAN__VARS__w_ara; $w_arak=&$___LOCAL_METMAN__VARS__w_arak; $w_arae=&$___LOCAL_METMAN__VARS__w_arae; $w_aras=&$___LOCAL_METMAN__VARS__w_aras; $w_arask=&$___LOCAL_METMAN__VARS__w_arask; $w_arf=&$___LOCAL_METMAN__VARS__w_arf; $w_arfk=&$___LOCAL_METMAN__VARS__w_arfk; $w_arfe=&$___LOCAL_METMAN__VARS__w_arfe; $w_arfs=&$___LOCAL_METMAN__VARS__w_arfs;  $w_arfsk=&$___LOCAL_METMAN__VARS__w_arfsk; $w_art=&$___LOCAL_METMAN__VARS__w_art; $w_artk=&$___LOCAL_METMAN__VARS__w_artk; $w_arte=&$___LOCAL_METMAN__VARS__w_arte; $w_arts=&$___LOCAL_METMAN__VARS__w_arts; $w_artsk=&$___LOCAL_METMAN__VARS__w_artsk; $w_itm0=&$___LOCAL_METMAN__VARS__w_itm0; $w_itmk0=&$___LOCAL_METMAN__VARS__w_itmk0; $w_itme0=&$___LOCAL_METMAN__VARS__w_itme0; $w_itms0=&$___LOCAL_METMAN__VARS__w_itms0;  $w_itmsk0=&$___LOCAL_METMAN__VARS__w_itmsk0; $w_itm1=&$___LOCAL_METMAN__VARS__w_itm1; $w_itmk1=&$___LOCAL_METMAN__VARS__w_itmk1; $w_itme1=&$___LOCAL_METMAN__VARS__w_itme1; $w_itms1=&$___LOCAL_METMAN__VARS__w_itms1; $w_itmsk1=&$___LOCAL_METMAN__VARS__w_itmsk1; $w_itm2=&$___LOCAL_METMAN__VARS__w_itm2; $w_itmk2=&$___LOCAL_METMAN__VARS__w_itmk2; $w_itme2=&$___LOCAL_METMAN__VARS__w_itme2; $w_itms2=&$___LOCAL_METMAN__VARS__w_itms2;  $w_itmsk2=&$___LOCAL_METMAN__VARS__w_itmsk2; $w_itm3=&$___LOCAL_METMAN__VARS__w_itm3; $w_itmk3=&$___LOCAL_METMAN__VARS__w_itmk3; $w_itme3=&$___LOCAL_METMAN__VARS__w_itme3; $w_itms3=&$___LOCAL_METMAN__VARS__w_itms3; $w_itmsk3=&$___LOCAL_METMAN__VARS__w_itmsk3; $w_itm4=&$___LOCAL_METMAN__VARS__w_itm4; $w_itmk4=&$___LOCAL_METMAN__VARS__w_itmk4; $w_itme4=&$___LOCAL_METMAN__VARS__w_itme4; $w_itms4=&$___LOCAL_METMAN__VARS__w_itms4;  $w_itmsk4=&$___LOCAL_METMAN__VARS__w_itmsk4; $w_itm5=&$___LOCAL_METMAN__VARS__w_itm5; $w_itmk5=&$___LOCAL_METMAN__VARS__w_itmk5; $w_itme5=&$___LOCAL_METMAN__VARS__w_itme5; $w_itms5=&$___LOCAL_METMAN__VARS__w_itms5; $w_itmsk5=&$___LOCAL_METMAN__VARS__w_itmsk5; $w_itm6=&$___LOCAL_METMAN__VARS__w_itm6; $w_itmk6=&$___LOCAL_METMAN__VARS__w_itmk6; $w_itme6=&$___LOCAL_METMAN__VARS__w_itme6; $w_itms6=&$___LOCAL_METMAN__VARS__w_itms6;  $w_itmsk6=&$___LOCAL_METMAN__VARS__w_itmsk6; $w_searchmemory=&$___LOCAL_METMAN__VARS__w_searchmemory; $w_nskill=&$___LOCAL_METMAN__VARS__w_nskill; $w_nskillpara=&$___LOCAL_METMAN__VARS__w_nskillpara;   } while (0);
		
		if($command == 'enter')
			$sdata['keep_enemy'] = 1;
		if($mode == 'combat') 
		{
			if ($command == 'back') 
			{
				$log .= "你逃跑了。";
				$mode = 'command';
				$___TMP_MOD_enemy_FUNC_act_RET = NULL;
			break; 
			}
			
			$enemyid = str_replace('enemy','',$action);
			
			if(!$enemyid || strpos($action,'enemy')===false){
				$log .= "<span class=\"yellow b\">你没有遇到敌人，或已经离开战场！</span><br>";
				$mode = 'command';
				$___TMP_MOD_enemy_FUNC_act_RET = NULL;
			break; 
			}
		
			$result = $db->query ( "SELECT * FROM {$tablepre}players WHERE pid='$enemyid'" );
			if (! $db->num_rows ( $result )) {
				$log .= "对方不存在！<br>";
				
				$mode = 'command';
				$___TMP_MOD_enemy_FUNC_act_RET = NULL;
			break; 
			}
		
			$edata=\player\fetch_playerdata_by_pid($enemyid);
			extract($edata,EXTR_PREFIX_ALL,'w');
			
			if ($edata ['pls'] != $pls) {
				$log .= "<span class=\"yellow b\">" . $edata ['name'] . "</span>已经离开了<span class=\"yellow b\">$plsinfo[$pls]</span>。<br>";
				
				$mode = 'command';
				$___TMP_MOD_enemy_FUNC_act_RET = NULL;
			break; 
			} elseif ($edata ['hp'] <= 0) {
				$log .= "<span class=\"red b\">" . $edata ['name'] . "</span>已经死亡，不能被攻击。<br>";
				if(\corpse\check_corpse_discover($edata))
				{
					$action = 'corpse'.$edata['pid'];
					$sdata['keep_enemy'] = 1;
					\corpse\findcorpse ( $edata );
				}
				$___TMP_MOD_enemy_FUNC_act_RET = NULL;
			break; 
			}
			
			\player\update_sdata();
			
			
			
			
			
			
			
			
			
			\enemy\battle_wrapper ($sdata,$edata,1);
			$___TMP_MOD_enemy_FUNC_act_RET = NULL;
			break; 
		}
if(isset($result)) {$__VAR_DUMP_MOD_enemy_VARS_result = $result; unset($result); } else {$__VAR_DUMP_MOD_enemy_VARS_result = NULL;} if(isset($edata)) {$__VAR_DUMP_MOD_enemy_VARS_edata = $edata; unset($edata); } else {$__VAR_DUMP_MOD_enemy_VARS_edata = NULL;} 
		//======== Start of contents from mod corpse ========
		do{
			$___TMP_MOD_corpse_FUNC_act_RET = NULL;

		
		
		
		if($command == 'enter')
			$sdata['keep_corpse'] = 1;
		if($mode == 'corpse') {
			\corpse\getcorpse ($command);
			$___TMP_MOD_corpse_FUNC_act_RET = NULL;
			break; 
		}
		
		if (strpos($action,'pacorpse')===0 || ($command == 'enter' && strpos($action,'corpse')===0))
		{
			$cid = str_replace('corpse','',str_replace('pacorpse','',$action));
			if($cid){
				$result = $db->query("SELECT * FROM {$tablepre}players WHERE pid='$cid' AND hp=0");
				if($db->num_rows($result)>0){
					$edata = \player\fetch_playerdata_by_pid($cid);
					\corpse\findcorpse ($edata);
					$___TMP_MOD_corpse_FUNC_act_RET = NULL;
			break; 
				}	
			}	
		}
		//======== Start of contents from mod apm ========
		do{
			$___TMP_MOD_apm_FUNC_act_RET = NULL;
		//======== Start of contents from mod itemshop ========
		do{
			$___TMP_MOD_itemshop_FUNC_act_RET = NULL;

		
		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;  global $___LOCAL_ITEMMAIN__VARS__tmp_itmsk_arr_pool,$___LOCAL_ITEMMAIN__VARS__itemfind_extra_log,$___LOCAL_ITEMMAIN__VARS__item_equip_list,$___LOCAL_ITEMMAIN__VARS__item_hotkey_id_list,$___LOCAL_ITEMMAIN__VARS__itemmain_drophint,$___LOCAL_ITEMMAIN__VARS__item_allow_find_and_use,$___LOCAL_ITEMMAIN__VARS__nosta,$___LOCAL_ITEMMAIN__VARS__nospk,$___LOCAL_ITEMMAIN__VARS__item_obbs,$___LOCAL_ITEMMAIN__VARS__map_noitemdrop_arealist, $___LOCAL_ITEMMAIN__VARS__itemkind_equipable,$___LOCAL_ITEMMAIN__VARS__iteminfo,$___LOCAL_ITEMMAIN__VARS__itemspkinfo,$___LOCAL_ITEMMAIN__VARS__itemspkdesc,$___LOCAL_ITEMMAIN__VARS__itemspkdesc_help,$___LOCAL_ITEMMAIN__VARS__itemspkremark; $tmp_itmsk_arr_pool=&$___LOCAL_ITEMMAIN__VARS__tmp_itmsk_arr_pool; $itemfind_extra_log=&$___LOCAL_ITEMMAIN__VARS__itemfind_extra_log; $item_equip_list=&$___LOCAL_ITEMMAIN__VARS__item_equip_list; $item_hotkey_id_list=&$___LOCAL_ITEMMAIN__VARS__item_hotkey_id_list; $itemmain_drophint=&$___LOCAL_ITEMMAIN__VARS__itemmain_drophint; $item_allow_find_and_use=&$___LOCAL_ITEMMAIN__VARS__item_allow_find_and_use; $nosta=&$___LOCAL_ITEMMAIN__VARS__nosta; $nospk=&$___LOCAL_ITEMMAIN__VARS__nospk; $item_obbs=&$___LOCAL_ITEMMAIN__VARS__item_obbs; $map_noitemdrop_arealist=&$___LOCAL_ITEMMAIN__VARS__map_noitemdrop_arealist;  $itemkind_equipable=&$___LOCAL_ITEMMAIN__VARS__itemkind_equipable; $iteminfo=&$___LOCAL_ITEMMAIN__VARS__iteminfo; $itemspkinfo=&$___LOCAL_ITEMMAIN__VARS__itemspkinfo; $itemspkdesc=&$___LOCAL_ITEMMAIN__VARS__itemspkdesc; $itemspkdesc_help=&$___LOCAL_ITEMMAIN__VARS__itemspkdesc_help; $itemspkremark=&$___LOCAL_ITEMMAIN__VARS__itemspkremark;  global $___LOCAL_ITEMSHOP__VARS__shops,$___LOCAL_ITEMSHOP__VARS__shop_tag_list,$___LOCAL_ITEMSHOP__VARS__shop_allow_input_num; $shops=&$___LOCAL_ITEMSHOP__VARS__shops; $shop_tag_list=&$___LOCAL_ITEMSHOP__VARS__shop_tag_list; $shop_allow_input_num=&$___LOCAL_ITEMSHOP__VARS__shop_allow_input_num;   } while (0);
		$sp_cmd = get_var_input('sp_cmd');
		if ($mode == 'command' && $command == 'special' && $sp_cmd == 'sp_shop')	
		{
			ob_clean();
			include template(\itemshop\get_sp_shop_filename ());
			$cmd = ob_get_contents();
			ob_clean();
			$___TMP_MOD_itemshop_FUNC_act_RET = NULL;
			break; 
		}
		
		if($mode == 'special' && strpos($command,'shop') === 0)	
		{
			$shop = substr($command,4,2);
			\itemshop\shoplist ($shop);
			$___TMP_MOD_itemshop_FUNC_act_RET = NULL;
			break; 
		}
		
		if($mode == 'shop') 	
		{
			if(\itemshop\check_in_shop_area ($pls)){
				if ($command == 'menu') {	
					$mode = 'command';
				} 
				elseif($command == 'shop') {	
					ob_clean();
					include template(\itemshop\get_sp_shop_filename ());
					$cmd = ob_get_contents();
					ob_clean();
				} else {
					list($shoptype,$buynum) = get_var_input('shoptype','buynum');
					\itemshop\itembuy ($command,$shoptype,$buynum);
				}
			}else{
				$log .= '<span class="yellow b">你所在的地区没有商店。</span><br />';
				$mode = 'command';
			}
			$___TMP_MOD_itemshop_FUNC_act_RET = NULL;
			break; 
		}
		//======== Start of contents from mod itemmix ========
		do{
			$___TMP_MOD_itemmix_FUNC_act_RET = NULL;

		
		
		$itemcmd = get_var_input('itemcmd');
		if($mode == 'itemmain') {
			if($command == 'itemmix') {
				
				list($itemselect, $mixmask) = get_var_input('itemselect', 'mixmask');
				if (999 == $itemselect)
					$mode='command';
				else
				{
					$mixlist = array();
					if (NULL === $mixmask)
					{
						for($i=1;$i<=6;$i++)
							if(!empty(get_var_input('mitm'.$i)))
								$mixlist[] = $i;
					}
					else
					{
						for($i=1;$i<=6;$i++)
							if ($mixmask&(1<<($i-1)))
								$mixlist[] = $i;
					}
					if (NULL !== $itemselect)
						\itemmix\itemmix ($mixlist,$itemselect);
					else \itemmix\itemmix ($mixlist);
					
					if(!empty($uip['itemmix_option_show'])) {
						ob_start();
						
						include template(MOD_ITEMMIX_ITEMMIX_OPTION_START);
						echo $cmd;
						include template(MOD_ITEMMIX_ITEMMIX_OPTION_END);
						$cmd = ob_get_contents();
						ob_end_clean();
					}
				}
			}
		}
		elseif ($mode == 'command' && $command == 'itemmain' && $itemcmd=='itemmix')
		{
			do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
			$log .= '你想要合成什么？';
			ob_clean();
			include template(\itemmix\get_itemmix_filename ());
			$cmd = ob_get_contents();
			ob_clean();
		}
if(isset($itemcmd)) {$__VAR_DUMP_MOD_itemmix_VARS_itemcmd = $itemcmd; unset($itemcmd); } else {$__VAR_DUMP_MOD_itemmix_VARS_itemcmd = NULL;} 
		//======== Start of contents from mod itemmain ========
		do{
			$___TMP_MOD_itemmain_FUNC_act_RET = NULL;

		
		
		$itemcmd = get_var_input('itemcmd');
		if ($mode == 'command' && strpos($command,'itm') === 0) 
		{
			$item = substr($command,3);
			\itemmain\itemuse_wrapper ($item);
			$___TMP_MOD_itemmain_FUNC_act_RET = NULL;
			break; 
		} 
		if ($mode == 'command' && $command == 'itemmain' && 
			($itemcmd=='itemmerge' || $itemcmd=='itemmove' || $itemcmd=='itemdrop'))
		{
			ob_clean();
			if ($itemcmd=='itemmerge') include template(MOD_ITEMMAIN_ITEMMERGE);
			elseif ($itemcmd=='itemmove') include template(MOD_ITEMMAIN_ITEMMOVE);
			elseif ($itemcmd=='itemdrop') include template(MOD_ITEMMAIN_ITEMDROP);
			$cmd = ob_get_contents();
			ob_clean();
		}
		if($mode == 'itemmain') {
			if($command == 'itemget') {
				\itemmain\itemget_process ();
			} elseif($command == 'itemadd') {
				\itemmain\itemadd ();
			} elseif($command == 'itemmerge') {
				list($merge1, $merge2) = get_var_input('merge1', 'merge2');
				if($merge2 == 'n'){\itemmain\itemadd ();}
				else{
					$merge_ret = \itemmain\itemmerge ($merge1,$merge2);
					if(!$merge_ret && ${'itm'.$merge1} != ${'itm'.$merge2}) {
						do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
						$log .= '<br>系统将你的命令自动识别为道具移动。';
						\itemmain\itemmove ($merge1,$merge2);
					}
				}
			} elseif($command == 'itemmove') {
				list($from, $to) = get_var_input('from', 'to');
				\itemmain\itemmove ($from,$to);
			} elseif(strpos($command,'drop') === 0) {
				$drop_item = substr($command,4);
				\itemmain\itemdrop ($drop_item);
			} elseif(strpos($command,'off') === 0) {
				$off_item = substr($command,3);
				\itemmain\itemoff ($off_item);
			} elseif(strpos($command,'swap') === 0) {
				$swap_item = substr($command,4);
				if(strpos($swap_item,'itm')===0) {
					if(${str_replace('itm','itms',$swap_item)}) \itemmain\itemdrop ($swap_item);
					\itemmain\itemadd (substr($swap_item,3,1));
				}
			} 
		}
		//======== Start of contents from mod explore ========
		do{
			$___TMP_MOD_explore_FUNC_act_RET = NULL;

		
		
		

		if($mode == 'command') 
		{
			if ($command == 'move') 
			{
				\explore\move (get_var_input('moveto'));
			} 
			elseif ($command == 'search') 
			{
				\explore\search ();
			} 
		}
		//======== Start of contents from mod player ========
		do{
			$___TMP_MOD_player_FUNC_act_RET = NULL;

		
		
		

		if($command == 'menu') {
			$mode = 'command';
		} elseif($mode == 'command') {
			if($command == 'special') {
				$mode = get_var_input('sp_cmd');
			} 
		} 
		}while(0);
		//======== End of contents from mod player ========

		
		$___TMP_MOD_player_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod explore ========

		$___TMP_MOD_explore_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod itemmain ========

$itemcmd = $__VAR_DUMP_MOD_itemmix_VARS_itemcmd; 
		$___TMP_MOD_itemmain_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod itemmix ========

		$___TMP_MOD_itemmix_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod itemshop ========


		
		$___TMP_MOD_itemshop_FUNC_act_RET;
		\apm\add_a_actionnum ();
		}while(0);
		//======== End of contents from mod apm ========

		
		$___TMP_MOD_apm_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod corpse ========

$result = $__VAR_DUMP_MOD_enemy_VARS_result; $edata = $__VAR_DUMP_MOD_enemy_VARS_edata; 
		$___TMP_MOD_corpse_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod enemy ========

				
		$___TMP_MOD_enemy_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod team ========

		$___TMP_MOD_team_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod item_misc ========

$edata = $__VAR_DUMP_MOD_advteam_VARS_edata; 
		$___TMP_MOD_item_misc_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod advteam ========

			
		$___TMP_MOD_advteam_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod clubbase ========
 
		$___TMP_MOD_clubbase_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod wound ========

		
		$___TMP_MOD_wound_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill437 ========

$subcmd = $__VAR_DUMP_MOD_skill1001_VARS_subcmd; 
		$___TMP_MOD_skill437_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill1001 ========

		$___TMP_MOD_skill1001_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill480 ========

$subcmd = $__VAR_DUMP_MOD_skill1011_VARS_subcmd; $item = $__VAR_DUMP_MOD_skill1011_VARS_item; 
		$___TMP_MOD_skill480_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill1011 ========

$subcmd = $__VAR_DUMP_MOD_skill1010_VARS_subcmd; 
		$___TMP_MOD_skill1011_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill1010 ========

			
		$___TMP_MOD_skill1010_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill234 ========

			
		$___TMP_MOD_skill234_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill235 ========

			
		$___TMP_MOD_skill235_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill424 ========

		$___TMP_MOD_skill424_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill518 ========

		$___TMP_MOD_skill518_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill552 ========

$subcmd = $__VAR_DUMP_MOD_skill1012_VARS_subcmd; 
		$___TMP_MOD_skill552_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill1012 ========

			
		$___TMP_MOD_skill1012_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill534 ========

		$___TMP_MOD_skill534_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill589 ========

		
		$___TMP_MOD_skill589_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill586 ========

$subcmd = $__VAR_DUMP_MOD_skill716_VARS_subcmd; 
		$___TMP_MOD_skill586_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill716 ========

		$___TMP_MOD_skill716_FUNC_act_RET;
		if (\skillbase\skill_query(717,$sdata) && !empty($pls_temp))
		{
			$pls = $pls_temp;
		}
		}while(0);
		//======== End of contents from mod skill717 ========

			
		$___TMP_MOD_skill717_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill952 ========

		$___TMP_MOD_skill952_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill728 ========

		$___TMP_MOD_skill728_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill110 ========

$subcmd = $__VAR_DUMP_MOD_skill1013_VARS_subcmd; 
		$___TMP_MOD_skill110_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill1013 ========

$item = $__VAR_DUMP_MOD_poison_VARS_item; 
		
		$___TMP_MOD_skill1013_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod poison ========

		
		$___TMP_MOD_poison_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod rest ========

		$___TMP_MOD_rest_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill12 ========

			
		$___TMP_MOD_skill12_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill23 ========

		$___TMP_MOD_skill23_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod pose ========

		$___TMP_MOD_pose_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill562 ========

		$___TMP_MOD_skill562_FUNC_act_RET;
		if(\skillbase\skill_query(487,$sdata)) \skill487\check_hlist487 ($sdata);
		}while(0);
		//======== End of contents from mod skill487 ========

		
		$___TMP_MOD_skill487_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill579 ========

		$___TMP_MOD_skill579_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod tactic ========

		$___TMP_MOD_tactic_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill599 ========

		$___TMP_MOD_skill599_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill588 ========

		
		$___TMP_MOD_skill588_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill734 ========

$subcmd = $__VAR_DUMP_MOD_skill56_VARS_subcmd; 
		
		$___TMP_MOD_skill734_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill56 ========

$subcmd = $__VAR_DUMP_MOD_skill435_VARS_subcmd; 
		
		$___TMP_MOD_skill56_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill435 ========

			
		$___TMP_MOD_skill435_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill731 ========

		$___TMP_MOD_skill731_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill103 ========

		$___TMP_MOD_skill103_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill104 ========

$sp_cmd = $__VAR_DUMP_MOD_dualwep_VARS_sp_cmd; 
		
		$___TMP_MOD_skill104_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod dualwep ========

			
		$___TMP_MOD_dualwep_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill230 ========

			
		$___TMP_MOD_skill230_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill219 ========


		
		$___TMP_MOD_skill219_FUNC_act_RET;
		
		$arr = \skillbase\get_acquired_skill_array($sdata);
		foreach ($arr as $key)
		{
			if (defined('MOD_SKILL'.$key.'_INFO') && (strpos(constant('MOD_SKILL'.$key.'_INFO'),'club;')!==false || strpos(constant('MOD_SKILL'.$key.'_INFO'),'card;')!==false))
			{
				$tsk_expire = \skillbase\skill_getvalue($key, 'tsk_expire', $pa);
				if(!empty($tsk_expire))	\item_umb\init_buff_timing ($key, $tsk_expire - $now);
			}
		}
		}while(0);
		//======== End of contents from mod item_umb ========

$mixlist = $__VAR_DUMP_MOD_item_recipe_VARS_mixlist; $i = $__VAR_DUMP_MOD_item_recipe_VARS_i; 
		$___TMP_MOD_item_umb_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod item_recipe ========

		$___TMP_MOD_item_recipe_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill580 ========

		
		$___TMP_MOD_skill580_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod opening ========

		$___TMP_MOD_opening_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod song ========

		$___TMP_MOD_song_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod extra_event ========


		$___TMP_MOD_extra_event_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod news_observe ========

		$___TMP_MOD_news_observe_FUNC_act_RET;
		if(!empty($tmp_hp_up_flag) && !\attrbase\check_itmsk('^hu')) \ex_mhp_temp_up\ex_mhp_temp_lose ();
		}while(0);
		//======== End of contents from mod ex_mhp_temp_up ========

			
		$___TMP_MOD_ex_mhp_temp_up_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill220 ========

$itemcmd = $__VAR_DUMP_MOD_tutorial_VARS_itemcmd; $sp_cmd = $__VAR_DUMP_MOD_tutorial_VARS_sp_cmd; 
		$___TMP_MOD_skill220_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod tutorial ========

		$___TMP_MOD_tutorial_FUNC_act_RET;
		if(\skillbase\skill_query(313) && !\map\get_area_wavenum()){
			if($money > \skillbase\skill_getvalue(313,'max_money')) 
				\skillbase\skill_setvalue(313,'max_money',$money);
		}
		}while(0);
		//======== End of contents from mod skill313 ========

		$___TMP_MOD_skill313_FUNC_act_RET;
		
		if(\skillbase\skill_query(332) && $wp > \skillbase\skill_getvalue(332,'cnt')){
			\skillbase\skill_setvalue(332,'cnt',$wp);
		}
		}while(0);
		//======== End of contents from mod skill332 ========

		$___TMP_MOD_skill332_FUNC_act_RET;
		
		if(\skillbase\skill_query(333) && $wk > \skillbase\skill_getvalue(333,'cnt')){
			\skillbase\skill_setvalue(333,'cnt',$wk);
		}
		}while(0);
		//======== End of contents from mod skill333 ========

		$___TMP_MOD_skill333_FUNC_act_RET;
		
		if(\skillbase\skill_query(334) && $wg > \skillbase\skill_getvalue(334,'cnt')){
			\skillbase\skill_setvalue(334,'cnt',$wg);
		}
		}while(0);
		//======== End of contents from mod skill334 ========

		$___TMP_MOD_skill334_FUNC_act_RET;
		
		if(\skillbase\skill_query(335) && $wc > \skillbase\skill_getvalue(335,'cnt')){
			\skillbase\skill_setvalue(335,'cnt',$wc);
		}
		}while(0);
		//======== End of contents from mod skill335 ========

		$___TMP_MOD_skill335_FUNC_act_RET;
		
		if(\skillbase\skill_query(336) && $wd > \skillbase\skill_getvalue(336,'cnt')){
			\skillbase\skill_setvalue(336,'cnt',$wd);
		}
		}while(0);
		//======== End of contents from mod skill336 ========

		$___TMP_MOD_skill336_FUNC_act_RET;
		
		if(\skillbase\skill_query(337) && $wf > \skillbase\skill_getvalue(337,'cnt')){
			\skillbase\skill_setvalue(337,'cnt',$wf);
		}
		}while(0);
		//======== End of contents from mod skill337 ========

		$___TMP_MOD_skill337_FUNC_act_RET;
		
		if(\skillbase\skill_query(338) && $mhp > \skillbase\skill_getvalue(338,'cnt')){
			\skillbase\skill_setvalue(338,'cnt',$mhp);
		}
		}while(0);
		//======== End of contents from mod skill338 ========

		$___TMP_MOD_skill338_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill530 ========

		$___TMP_MOD_skill530_FUNC_act_RET;
		
		if(\skillbase\skill_query(372) && $money > \skillbase\skill_getvalue(372,'cnt')){
			\skillbase\skill_setvalue(372,'cnt',$money);
		}
		}while(0);
		//======== End of contents from mod skill372 ========

		$___TMP_MOD_skill372_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill504 ========


		
		$___TMP_MOD_skill504_FUNC_act_RET;
		\skill182\init_songbuff_timing_process ();
		}while(0);
		//======== End of contents from mod skill182 ========

			
		$___TMP_MOD_skill182_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill458 ========

		$___TMP_MOD_skill458_FUNC_act_RET;
		
		if(\skillbase\skill_query(381) && $mss > \skillbase\skill_getvalue(381,'cnt')){
			\skillbase\skill_setvalue(381,'cnt',$mss);
		}
		}while(0);
		//======== End of contents from mod skill381 ========


		$___TMP_MOD_skill381_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod instance11 ========

$sp_cmd = $__VAR_DUMP_MOD_wepchange_VARS_sp_cmd; 
		
		$___TMP_MOD_instance11_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod wepchange ========

		$___TMP_MOD_wepchange_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod smartmix ========

$usemode = $__VAR_DUMP_MOD_logistics_VARS_usemode; $itmp = $__VAR_DUMP_MOD_logistics_VARS_itmp; 
		$___TMP_MOD_smartmix_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod logistics ========

$usemode = $__VAR_DUMP_MOD_item_uys_VARS_usemode; $item = $__VAR_DUMP_MOD_item_uys_VARS_item; 		
		$___TMP_MOD_logistics_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod item_uys ========

		
		$___TMP_MOD_item_uys_FUNC_act_RET;

		
		if(empty($tmp_eid) && \searchmemory\check_keep_enemy_in_searchmemory ()) {
			if(!empty(get_var_in_module('o_edata', 'battle'))) {
				$o_edata = get_var_in_module('o_edata', 'battle');
				$tmp_eid = (int)$o_edata['pid'];
				$tmp_eid_mode = 'enemy';
			}
		}

		if(!empty($tmp_eid)) {
			$smedata = \player\fetch_playerdata_by_pid($tmp_eid);
			if(empty($smedata)) {
				$log .= '视野或记忆数据有误。<br>';
			}elseif(('enemy' == $tmp_eid_mode && $smedata['hp'] > 0) || ('corpse' == $tmp_eid_mode && $smedata['hp'] <= 0)) {
				if('corpse' == $tmp_eid_mode && !\metman\discover_player_filter_corpse($smedata)) {
					$log .= $smedata['name'].'的尸体上已经不剩什么了。<br>';
				}else{
					$amarr = array(
						'pid' => $smedata['pid'],
						'Pname' => $smedata['name'],
						'pls' => $smedata['pls'],
						'smtype' => 'corpse' == $tmp_eid_mode ? 'corpse' : ($fog ? 'unknown' : 'enemy'),
						'unseen' => 0
					);
					\searchmemory\add_memory ($amarr);
				}
			}else{
				
			}
		}	
		
		if($pls != $tmp_pls && 'move' != $command) {
			\searchmemory\change_memory_unseen ('ALL');
		}
		}while(0);
		//======== End of contents from mod searchmemory ========

		$___TMP_MOD_searchmemory_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill94 ========

$usemode = $__VAR_DUMP_MOD_blessstone_VARS_usemode; $item = $__VAR_DUMP_MOD_blessstone_VARS_item; 
		
		$___TMP_MOD_skill94_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod blessstone ========

		
		$___TMP_MOD_blessstone_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill1006 ========

		
		$___TMP_MOD_skill1006_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod ex_storage ========

$item = $__VAR_DUMP_MOD_item_armor_empower_VARS_item; 		
		$___TMP_MOD_ex_storage_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod item_armor_empower ========

			
		$___TMP_MOD_item_armor_empower_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill272 ========

		
		$___TMP_MOD_skill272_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill597 ========

			
		$___TMP_MOD_skill597_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill960 ========

		
		$___TMP_MOD_skill960_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill733 ========

		$___TMP_MOD_skill733_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill746 ========


		
		$___TMP_MOD_skill746_FUNC_act_RET;
		
		if(\skillbase\skill_query(505,$sdata) && \skill505\check_unlocked505 ($sdata) && $hp > 0){
			if(!\skill505\skill505_check_keyitm_exists ($sdata)) {
				$hp = 0;
				$state = 45;
				\skill505\skill505_clear_corpse ($sdata);
				\player\update_sdata();
				$sdata['sourceless'] = 1;
				\player\kill($sdata,$sdata);


			}
		}
		}while(0);
		//======== End of contents from mod skill505 ========

		$___TMP_MOD_skill505_FUNC_act_RET;
		}while(0);
		//======== End of contents from mod skill737 ========

		
		$___TMP_MOD_skill737_FUNC_act_RET;
	
	}
	
	function activate962()
	{
		
		do { global $___LOCAL_SKILL960__VARS__invscore_available_mode,$___LOCAL_SKILL960__VARS__tasks_index,$___LOCAL_SKILL960__VARS__tasks_info; $invscore_available_mode=&$___LOCAL_SKILL960__VARS__invscore_available_mode; $tasks_index=&$___LOCAL_SKILL960__VARS__tasks_index; $tasks_info=&$___LOCAL_SKILL960__VARS__tasks_info;  global $___LOCAL_SKILL962__VARS__skill962_cd,$___LOCAL_SKILL962__VARS__skill962_base_cost; $skill962_cd=&$___LOCAL_SKILL962__VARS__skill962_cd; $skill962_base_cost=&$___LOCAL_SKILL962__VARS__skill962_base_cost;  global $___LOCAL_PLAYER__VARS__ss,$___LOCAL_PLAYER__VARS__db_player_structure,$___LOCAL_PLAYER__VARS__db_player_structure_types,$___LOCAL_PLAYER__VARS__gamedata,$___LOCAL_PLAYER__VARS__cmd,$___LOCAL_PLAYER__VARS__main,$___LOCAL_PLAYER__VARS__sdata,$___LOCAL_PLAYER__VARS__fog,$___LOCAL_PLAYER__VARS__upexp,$___LOCAL_PLAYER__VARS__lvlupexp, $___LOCAL_PLAYER__VARS__iconImg,$___LOCAL_PLAYER__VARS__iconImgB,$___LOCAL_PLAYER__VARS__iconImgBwidth,$___LOCAL_PLAYER__VARS__ardef,$___LOCAL_PLAYER__VARS__hpcolor,$___LOCAL_PLAYER__VARS__spcolor,$___LOCAL_PLAYER__VARS__newhpimg,$___LOCAL_PLAYER__VARS__newspimg,$___LOCAL_PLAYER__VARS__splt,$___LOCAL_PLAYER__VARS__hplt, $___LOCAL_PLAYER__VARS__tpldata,$___LOCAL_PLAYER__VARS__icon_list,$___LOCAL_PLAYER__VARS__icon_list_contents_to_frontend,$___LOCAL_PLAYER__VARS__typeinfo,$___LOCAL_PLAYER__VARS__killmsginfo,$___LOCAL_PLAYER__VARS__lwinfo,$___LOCAL_PLAYER__VARS__sexinfo,$___LOCAL_PLAYER__VARS__equip_list,$___LOCAL_PLAYER__VARS__battle_equip_list,$___LOCAL_PLAYER__VARS__pc_icon_range, $___LOCAL_PLAYER__VARS__pid,$___LOCAL_PLAYER__VARS__type,$___LOCAL_PLAYER__VARS__name,$___LOCAL_PLAYER__VARS__pass,$___LOCAL_PLAYER__VARS__ip,$___LOCAL_PLAYER__VARS__motto,$___LOCAL_PLAYER__VARS__killmsg,$___LOCAL_PLAYER__VARS__lastword,$___LOCAL_PLAYER__VARS__winner_flag,$___LOCAL_PLAYER__VARS__player_dead_flag, $___LOCAL_PLAYER__VARS__corpse_clear_flag,$___LOCAL_PLAYER__VARS__gd,$___LOCAL_PLAYER__VARS__sNo,$___LOCAL_PLAYER__VARS__club,$___LOCAL_PLAYER__VARS__validtime,$___LOCAL_PLAYER__VARS__endtime,$___LOCAL_PLAYER__VARS__cdsec,$___LOCAL_PLAYER__VARS__cdmsec,$___LOCAL_PLAYER__VARS__cdtime,$___LOCAL_PLAYER__VARS__action, $___LOCAL_PLAYER__VARS__a_actionnum,$___LOCAL_PLAYER__VARS__v_actionnum,$___LOCAL_PLAYER__VARS__hp,$___LOCAL_PLAYER__VARS__mhp,$___LOCAL_PLAYER__VARS__sp,$___LOCAL_PLAYER__VARS__msp,$___LOCAL_PLAYER__VARS__mss,$___LOCAL_PLAYER__VARS__att,$___LOCAL_PLAYER__VARS__def,$___LOCAL_PLAYER__VARS__pls, $___LOCAL_PLAYER__VARS__lvl,$___LOCAL_PLAYER__VARS__exp,$___LOCAL_PLAYER__VARS__money,$___LOCAL_PLAYER__VARS__rp,$___LOCAL_PLAYER__VARS__bid,$___LOCAL_PLAYER__VARS__inf,$___LOCAL_PLAYER__VARS__rage,$___LOCAL_PLAYER__VARS__pose,$___LOCAL_PLAYER__VARS__tactic,$___LOCAL_PLAYER__VARS__killnum, $___LOCAL_PLAYER__VARS__npckillnum,$___LOCAL_PLAYER__VARS__state,$___LOCAL_PLAYER__VARS__skillpoint,$___LOCAL_PLAYER__VARS__flare,$___LOCAL_PLAYER__VARS__wp,$___LOCAL_PLAYER__VARS__wk,$___LOCAL_PLAYER__VARS__wg,$___LOCAL_PLAYER__VARS__wc,$___LOCAL_PLAYER__VARS__wd,$___LOCAL_PLAYER__VARS__wf, $___LOCAL_PLAYER__VARS__icon,$___LOCAL_PLAYER__VARS__teamID,$___LOCAL_PLAYER__VARS__teamPass,$___LOCAL_PLAYER__VARS__card,$___LOCAL_PLAYER__VARS__cardname,$___LOCAL_PLAYER__VARS__wep,$___LOCAL_PLAYER__VARS__wepk,$___LOCAL_PLAYER__VARS__wepe,$___LOCAL_PLAYER__VARS__weps,$___LOCAL_PLAYER__VARS__wepsk, $___LOCAL_PLAYER__VARS__arb,$___LOCAL_PLAYER__VARS__arbk,$___LOCAL_PLAYER__VARS__arbe,$___LOCAL_PLAYER__VARS__arbs,$___LOCAL_PLAYER__VARS__arbsk,$___LOCAL_PLAYER__VARS__arh,$___LOCAL_PLAYER__VARS__arhk,$___LOCAL_PLAYER__VARS__arhe,$___LOCAL_PLAYER__VARS__arhs,$___LOCAL_PLAYER__VARS__arhsk, $___LOCAL_PLAYER__VARS__ara,$___LOCAL_PLAYER__VARS__arak,$___LOCAL_PLAYER__VARS__arae,$___LOCAL_PLAYER__VARS__aras,$___LOCAL_PLAYER__VARS__arask,$___LOCAL_PLAYER__VARS__arf,$___LOCAL_PLAYER__VARS__arfk,$___LOCAL_PLAYER__VARS__arfe,$___LOCAL_PLAYER__VARS__arfs,$___LOCAL_PLAYER__VARS__arfsk, $___LOCAL_PLAYER__VARS__art,$___LOCAL_PLAYER__VARS__artk,$___LOCAL_PLAYER__VARS__arte,$___LOCAL_PLAYER__VARS__arts,$___LOCAL_PLAYER__VARS__artsk,$___LOCAL_PLAYER__VARS__itm0,$___LOCAL_PLAYER__VARS__itmk0,$___LOCAL_PLAYER__VARS__itme0,$___LOCAL_PLAYER__VARS__itms0,$___LOCAL_PLAYER__VARS__itmsk0, $___LOCAL_PLAYER__VARS__itm1,$___LOCAL_PLAYER__VARS__itmk1,$___LOCAL_PLAYER__VARS__itme1,$___LOCAL_PLAYER__VARS__itms1,$___LOCAL_PLAYER__VARS__itmsk1,$___LOCAL_PLAYER__VARS__itm2,$___LOCAL_PLAYER__VARS__itmk2,$___LOCAL_PLAYER__VARS__itme2,$___LOCAL_PLAYER__VARS__itms2,$___LOCAL_PLAYER__VARS__itmsk2, $___LOCAL_PLAYER__VARS__itm3,$___LOCAL_PLAYER__VARS__itmk3,$___LOCAL_PLAYER__VARS__itme3,$___LOCAL_PLAYER__VARS__itms3,$___LOCAL_PLAYER__VARS__itmsk3,$___LOCAL_PLAYER__VARS__itm4,$___LOCAL_PLAYER__VARS__itmk4,$___LOCAL_PLAYER__VARS__itme4,$___LOCAL_PLAYER__VARS__itms4,$___LOCAL_PLAYER__VARS__itmsk4, $___LOCAL_PLAYER__VARS__itm5,$___LOCAL_PLAYER__VARS__itmk5,$___LOCAL_PLAYER__VARS__itme5,$___LOCAL_PLAYER__VARS__itms5,$___LOCAL_PLAYER__VARS__itmsk5,$___LOCAL_PLAYER__VARS__itm6,$___LOCAL_PLAYER__VARS__itmk6,$___LOCAL_PLAYER__VARS__itme6,$___LOCAL_PLAYER__VARS__itms6,$___LOCAL_PLAYER__VARS__itmsk6, $___LOCAL_PLAYER__VARS__searchmemory,$___LOCAL_PLAYER__VARS__nskill,$___LOCAL_PLAYER__VARS__nskillpara; $ss=&$___LOCAL_PLAYER__VARS__ss; $db_player_structure=&$___LOCAL_PLAYER__VARS__db_player_structure; $db_player_structure_types=&$___LOCAL_PLAYER__VARS__db_player_structure_types; $gamedata=&$___LOCAL_PLAYER__VARS__gamedata; $cmd=&$___LOCAL_PLAYER__VARS__cmd; $main=&$___LOCAL_PLAYER__VARS__main; $sdata=&$___LOCAL_PLAYER__VARS__sdata; $fog=&$___LOCAL_PLAYER__VARS__fog; $upexp=&$___LOCAL_PLAYER__VARS__upexp; $lvlupexp=&$___LOCAL_PLAYER__VARS__lvlupexp;  $iconImg=&$___LOCAL_PLAYER__VARS__iconImg; $iconImgB=&$___LOCAL_PLAYER__VARS__iconImgB; $iconImgBwidth=&$___LOCAL_PLAYER__VARS__iconImgBwidth; $ardef=&$___LOCAL_PLAYER__VARS__ardef; $hpcolor=&$___LOCAL_PLAYER__VARS__hpcolor; $spcolor=&$___LOCAL_PLAYER__VARS__spcolor; $newhpimg=&$___LOCAL_PLAYER__VARS__newhpimg; $newspimg=&$___LOCAL_PLAYER__VARS__newspimg; $splt=&$___LOCAL_PLAYER__VARS__splt; $hplt=&$___LOCAL_PLAYER__VARS__hplt;  $tpldata=&$___LOCAL_PLAYER__VARS__tpldata; $icon_list=&$___LOCAL_PLAYER__VARS__icon_list; $icon_list_contents_to_frontend=&$___LOCAL_PLAYER__VARS__icon_list_contents_to_frontend; $typeinfo=&$___LOCAL_PLAYER__VARS__typeinfo; $killmsginfo=&$___LOCAL_PLAYER__VARS__killmsginfo; $lwinfo=&$___LOCAL_PLAYER__VARS__lwinfo; $sexinfo=&$___LOCAL_PLAYER__VARS__sexinfo; $equip_list=&$___LOCAL_PLAYER__VARS__equip_list; $battle_equip_list=&$___LOCAL_PLAYER__VARS__battle_equip_list; $pc_icon_range=&$___LOCAL_PLAYER__VARS__pc_icon_range;  $pid=&$___LOCAL_PLAYER__VARS__pid; $type=&$___LOCAL_PLAYER__VARS__type; $name=&$___LOCAL_PLAYER__VARS__name; $pass=&$___LOCAL_PLAYER__VARS__pass; $ip=&$___LOCAL_PLAYER__VARS__ip; $motto=&$___LOCAL_PLAYER__VARS__motto; $killmsg=&$___LOCAL_PLAYER__VARS__killmsg; $lastword=&$___LOCAL_PLAYER__VARS__lastword; $winner_flag=&$___LOCAL_PLAYER__VARS__winner_flag; $player_dead_flag=&$___LOCAL_PLAYER__VARS__player_dead_flag;  $corpse_clear_flag=&$___LOCAL_PLAYER__VARS__corpse_clear_flag; $gd=&$___LOCAL_PLAYER__VARS__gd; $sNo=&$___LOCAL_PLAYER__VARS__sNo; $club=&$___LOCAL_PLAYER__VARS__club; $validtime=&$___LOCAL_PLAYER__VARS__validtime; $endtime=&$___LOCAL_PLAYER__VARS__endtime; $cdsec=&$___LOCAL_PLAYER__VARS__cdsec; $cdmsec=&$___LOCAL_PLAYER__VARS__cdmsec; $cdtime=&$___LOCAL_PLAYER__VARS__cdtime; $action=&$___LOCAL_PLAYER__VARS__action;  $a_actionnum=&$___LOCAL_PLAYER__VARS__a_actionnum; $v_actionnum=&$___LOCAL_PLAYER__VARS__v_actionnum; $hp=&$___LOCAL_PLAYER__VARS__hp; $mhp=&$___LOCAL_PLAYER__VARS__mhp; $sp=&$___LOCAL_PLAYER__VARS__sp; $msp=&$___LOCAL_PLAYER__VARS__msp; $mss=&$___LOCAL_PLAYER__VARS__mss; $att=&$___LOCAL_PLAYER__VARS__att; $def=&$___LOCAL_PLAYER__VARS__def; $pls=&$___LOCAL_PLAYER__VARS__pls;  $lvl=&$___LOCAL_PLAYER__VARS__lvl; $exp=&$___LOCAL_PLAYER__VARS__exp; $money=&$___LOCAL_PLAYER__VARS__money; $rp=&$___LOCAL_PLAYER__VARS__rp; $bid=&$___LOCAL_PLAYER__VARS__bid; $inf=&$___LOCAL_PLAYER__VARS__inf; $rage=&$___LOCAL_PLAYER__VARS__rage; $pose=&$___LOCAL_PLAYER__VARS__pose; $tactic=&$___LOCAL_PLAYER__VARS__tactic; $killnum=&$___LOCAL_PLAYER__VARS__killnum;  $npckillnum=&$___LOCAL_PLAYER__VARS__npckillnum; $state=&$___LOCAL_PLAYER__VARS__state; $skillpoint=&$___LOCAL_PLAYER__VARS__skillpoint; $flare=&$___LOCAL_PLAYER__VARS__flare; $wp=&$___LOCAL_PLAYER__VARS__wp; $wk=&$___LOCAL_PLAYER__VARS__wk; $wg=&$___LOCAL_PLAYER__VARS__wg; $wc=&$___LOCAL_PLAYER__VARS__wc; $wd=&$___LOCAL_PLAYER__VARS__wd; $wf=&$___LOCAL_PLAYER__VARS__wf;  $icon=&$___LOCAL_PLAYER__VARS__icon; $teamID=&$___LOCAL_PLAYER__VARS__teamID; $teamPass=&$___LOCAL_PLAYER__VARS__teamPass; $card=&$___LOCAL_PLAYER__VARS__card; $cardname=&$___LOCAL_PLAYER__VARS__cardname; $wep=&$___LOCAL_PLAYER__VARS__wep; $wepk=&$___LOCAL_PLAYER__VARS__wepk; $wepe=&$___LOCAL_PLAYER__VARS__wepe; $weps=&$___LOCAL_PLAYER__VARS__weps; $wepsk=&$___LOCAL_PLAYER__VARS__wepsk;  $arb=&$___LOCAL_PLAYER__VARS__arb; $arbk=&$___LOCAL_PLAYER__VARS__arbk; $arbe=&$___LOCAL_PLAYER__VARS__arbe; $arbs=&$___LOCAL_PLAYER__VARS__arbs; $arbsk=&$___LOCAL_PLAYER__VARS__arbsk; $arh=&$___LOCAL_PLAYER__VARS__arh; $arhk=&$___LOCAL_PLAYER__VARS__arhk; $arhe=&$___LOCAL_PLAYER__VARS__arhe; $arhs=&$___LOCAL_PLAYER__VARS__arhs; $arhsk=&$___LOCAL_PLAYER__VARS__arhsk;  $ara=&$___LOCAL_PLAYER__VARS__ara; $arak=&$___LOCAL_PLAYER__VARS__arak; $arae=&$___LOCAL_PLAYER__VARS__arae; $aras=&$___LOCAL_PLAYER__VARS__aras; $arask=&$___LOCAL_PLAYER__VARS__arask; $arf=&$___LOCAL_PLAYER__VARS__arf; $arfk=&$___LOCAL_PLAYER__VARS__arfk; $arfe=&$___LOCAL_PLAYER__VARS__arfe; $arfs=&$___LOCAL_PLAYER__VARS__arfs; $arfsk=&$___LOCAL_PLAYER__VARS__arfsk;  $art=&$___LOCAL_PLAYER__VARS__art; $artk=&$___LOCAL_PLAYER__VARS__artk; $arte=&$___LOCAL_PLAYER__VARS__arte; $arts=&$___LOCAL_PLAYER__VARS__arts; $artsk=&$___LOCAL_PLAYER__VARS__artsk; $itm0=&$___LOCAL_PLAYER__VARS__itm0; $itmk0=&$___LOCAL_PLAYER__VARS__itmk0; $itme0=&$___LOCAL_PLAYER__VARS__itme0; $itms0=&$___LOCAL_PLAYER__VARS__itms0; $itmsk0=&$___LOCAL_PLAYER__VARS__itmsk0;  $itm1=&$___LOCAL_PLAYER__VARS__itm1; $itmk1=&$___LOCAL_PLAYER__VARS__itmk1; $itme1=&$___LOCAL_PLAYER__VARS__itme1; $itms1=&$___LOCAL_PLAYER__VARS__itms1; $itmsk1=&$___LOCAL_PLAYER__VARS__itmsk1; $itm2=&$___LOCAL_PLAYER__VARS__itm2; $itmk2=&$___LOCAL_PLAYER__VARS__itmk2; $itme2=&$___LOCAL_PLAYER__VARS__itme2; $itms2=&$___LOCAL_PLAYER__VARS__itms2; $itmsk2=&$___LOCAL_PLAYER__VARS__itmsk2;  $itm3=&$___LOCAL_PLAYER__VARS__itm3; $itmk3=&$___LOCAL_PLAYER__VARS__itmk3; $itme3=&$___LOCAL_PLAYER__VARS__itme3; $itms3=&$___LOCAL_PLAYER__VARS__itms3; $itmsk3=&$___LOCAL_PLAYER__VARS__itmsk3; $itm4=&$___LOCAL_PLAYER__VARS__itm4; $itmk4=&$___LOCAL_PLAYER__VARS__itmk4; $itme4=&$___LOCAL_PLAYER__VARS__itme4; $itms4=&$___LOCAL_PLAYER__VARS__itms4; $itmsk4=&$___LOCAL_PLAYER__VARS__itmsk4;  $itm5=&$___LOCAL_PLAYER__VARS__itm5; $itmk5=&$___LOCAL_PLAYER__VARS__itmk5; $itme5=&$___LOCAL_PLAYER__VARS__itme5; $itms5=&$___LOCAL_PLAYER__VARS__itms5; $itmsk5=&$___LOCAL_PLAYER__VARS__itmsk5; $itm6=&$___LOCAL_PLAYER__VARS__itm6; $itmk6=&$___LOCAL_PLAYER__VARS__itmk6; $itme6=&$___LOCAL_PLAYER__VARS__itme6; $itms6=&$___LOCAL_PLAYER__VARS__itms6; $itmsk6=&$___LOCAL_PLAYER__VARS__itmsk6;  $searchmemory=&$___LOCAL_PLAYER__VARS__searchmemory; $nskill=&$___LOCAL_PLAYER__VARS__nskill; $nskillpara=&$___LOCAL_PLAYER__VARS__nskillpara;  global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
		\player\update_sdata();
		
		$st = check_skill962_state($sdata);
		if (!$st)
		{
			$log.='你没有这个技能！<br>';
			return;
		}elseif (!\skillbase\skill_query(960, $sdata)){
			$log.='你没有任务技能！<br>';
			return;
		}elseif ($st==1){
			$log.='你的金钱不足！<br>';
			return;
		}
		
		$taskid = get_var_input('taskid_submit');
		$taskarr = \skill960\get_taskarr($sdata);
		if (!isset($tasks_info[$taskid]) || (isset($tasks_info[$taskid]['rank']) && $tasks_info[$taskid]['rank'] > 10) || !in_array($taskid, $taskarr))
		{
			$log .= '输入参数错误。<br>';
			return;
		}
		if ($st==2)
		{
			$skill962_cost = get_skill962_cost($sdata);
			$money -= $skill962_cost;
			$log .= '<span class="lime b">消耗了'.$skill962_cost.'元，</span>';
		}
		$log .= '<span class="lime b">技能「寻路」发动成功。</span><br>';
		$flag = \bufficons\bufficons_set_timestamp(962, 0, $skill962_cd);
		if (!$flag)
		{
			$log.='发动失败！<br>';
			return;
		}
		\skill960\remove_task($sdata, $taskid);
		if(empty($itms0)) {
			ob_start();
			include template(MOD_SKILL960_CASTSK960);
			$cmd=ob_get_contents();
			ob_end_clean();
		}
	}
	
	function get_skill962_cost(&$pa)
	{
		
		do { global $___LOCAL_SKILL962__VARS__skill962_cd,$___LOCAL_SKILL962__VARS__skill962_base_cost; $skill962_cd=&$___LOCAL_SKILL962__VARS__skill962_cd; $skill962_base_cost=&$___LOCAL_SKILL962__VARS__skill962_base_cost;   } while (0);
		$invscore = (int)\skillbase\skill_getvalue(960,'invscore',$pa);
		$stage = \instance10\get_stage($invscore);
		$skill962_cost = $skill962_base_cost * pow(2, $stage);
		return $skill962_cost;
	}
	
	function show_extra_task_cmds(&$pa, $taskid)
	{
if(isset($taskid)) {$__VAR_DUMP_MOD_skill962_VARS_taskid = $taskid; } else {$__VAR_DUMP_MOD_skill962_VARS_taskid = NULL;} 
		//======== Start of contents from mod skill960 ========
		do{
			$___TMP_MOD_skill960_FUNC_show_extra_task_cmds_RET = NULL;

		
		$___TMP_MOD_skill960_FUNC_show_extra_task_cmds_RET =  '';
			break; 
		}while(0);
		//======== End of contents from mod skill960 ========

$taskid = $__VAR_DUMP_MOD_skill962_VARS_taskid; unset($__VAR_DUMP_MOD_skill962_VARS_taskid);
		
		$ret = $___TMP_MOD_skill960_FUNC_show_extra_task_cmds_RET;
		$st = \skill962\check_skill962_state ($pa);
		do { global $___LOCAL_SKILL960__VARS__invscore_available_mode,$___LOCAL_SKILL960__VARS__tasks_index,$___LOCAL_SKILL960__VARS__tasks_info; $invscore_available_mode=&$___LOCAL_SKILL960__VARS__invscore_available_mode; $tasks_index=&$___LOCAL_SKILL960__VARS__tasks_index; $tasks_info=&$___LOCAL_SKILL960__VARS__tasks_info;   } while (0);
		
		if ($st > 0 && isset($tasks_info[$taskid]['rank']) && $tasks_info[$taskid]['rank'] > 10)
		{
			$ret .= '<input type="button" class="cmdbutton"  title="<span class=\'yellow b\'>此任务无法更换</span>" disabled="true" value="更换">';
			return $ret;
		}
		if ($st == 2)
		{
			$skill962_cost = \skill962\get_skill962_cost ($pa);
			$ret .= '<input type="button" class="cmdbutton" value="更换" title="<span class=\'red b\'>需要支付'.$skill962_cost.'元</span>" onclick="$(\'taskid_submit\').value=\''.$taskid.'\';$(\'command\').value=\'skill962_special\';postCmd(\'gamecmd\',\'command.php\');this.disabled=true;">';
		}
		elseif ($st == 3)
		{
			$ret .= '<input type="button" class="cmdbutton" value="更换" onclick="$(\'taskid_submit\').value=\''.$taskid.'\';$(\'command\').value=\'skill962_special\';postCmd(\'gamecmd\',\'command.php\');this.disabled=true;">';
		}
		elseif ($st == 1)
		{
			$ret .= '<input type="button" class="cmdbutton" disabled="true" value="更换">';
		}
		return $ret;
	
	}

}

?>