<?php

namespace instance10
{
	$npcinfo_instance10 = array
	(
		20 => array
		(
			'mode' => 2,
			'num' => 10,
			'pass' => 'gbauibg2',
			'club' => 0,
			'bid' => 0,
			'inf' => '',
			'rage' => 88,
			'pose'=> 1,
			'tactic' => 3,
			'killnum' => 0,
			'teamID' => '',
			'teamPass' => '',
			'gd' => 'r',
			'pls' => 34,
			'mhp' => 3000,
			'msp' => 400,
			'att' => 200,
			'def' => 200,
			'lvl' => 40,
			'skill' => 300,
			'money' => 800,
			'arb' => '英雄战甲B',
			'arbk' => 'DB',
			'arbe' => 1000,
			'arbs' => 300,
			'arbsk' => 'A',
			'arh' => '英雄战甲H',
			'arhk' => 'DH',
			'arhe' => 600,
			'arhs' => 300,
			'arhsk' => 'DF',
			'arf' => '英雄战甲F',
			'arfk' => 'DF',
			'arfe' => 500,
			'arfs' => 300,
			'arfsk' => 'a',
			'ara' => '英雄战甲A',
			'arak' => 'DA',
			'arae' => 600,
			'aras' => 300,
			'arask' => 'H',
			'art' => '英雄之力',
			'artk' => 'A',
			'arte' => 9,
			'arts' => 9,
			'artsk' => 'c',
			'sub' => array
			(
				0 => array
				(
					'name' => '霜火协奏曲',
					'icon' => 0,
					'club' => 6,
					'wep' => '『看吧，你的死兆星正在天上闪耀！』',
					'wepk' => 'WC',
					'wepe' => 333,
					'weps' => 600,
					'wepsk' => 'w',
				),
				1 => array
				(
					'name' => '脸骑士-菜包',
					'club' => 98,
					'icon' => 0,
					'wep' => '脸',
					'wepk' => 'WP',
					'wepe' => 300,
					'weps' => 600,
					'wepsk' => 'N',
				),
				2 => array
				(
					'name' => '枪毙的某神',
					'icon' => 0,
					'club' => 3,
					'wep' => '《小黄的时间球》',
					'wepk' => 'WC',
					'wepe' => 180,
					'weps' => 600,
					'wepsk' => 'r',
				),
				3 => array
				(
					'name' => '我是高达',
					'icon' => 0,
					'club' => 8,
					'wep' => '毒性凸眼鱼',
					'wepk' => 'WF',
					'wepe' => 200,
					'weps' => 600,
					'wepsk' => 'pd',
				),
				4 => array
				(
					'name' => '一旦接受这种设定',
					'icon' => 0,
					'club' => 10,
					'wep' => '『一瞬千击』',
					'wepk' => 'WP',
					'wepe' => 190,
					'weps' => 600,
					'wepsk' => 'r',
				),
				5 => array
				(
					'name' => '一方通行',
					'icon' => 0,
					'club' => 9,
					'wep' => '【矢量操作】',
					'wepk' => 'WG',
					'wepe' => 300,
					'weps' => 600,
					'wepsk' => 'N',
				),
				6 => array
				(
					'name' => '晓魂之歌',
					'icon' => 0,
					'club' => 2,
					'wep' => '锋利的电气毒性晓魂之歌-改[+4]',
					'wepk' => 'WK',
					'wepe' => 300,
					'weps' => 600,
					'wepsk' => 'pew',
				),
				7 => array
				(
					'name' => '卡',
					'icon' => 0,
					'club' => 13,
					'wep' => '【不屈的意志】',
					'wepk' => 'WF',
					'wepe' => 140,
					'weps' => 600,
					'wepsk' => 'r',
				),
				8 => array
				(
					'name' => 'Exocet',
					'icon' => 0,
					'club' => 9,
					'wep' => '『微型火箭加速噴射單輪車』',
					'wepk' => 'WP',
					'wepe' => 110,
					'weps' => 600,
					'wepsk' => 'ru',
				),
				9 => array
				(
					'name' => '中西醫',
					'icon' => 0,
					'club' => 1,
					'wep' => '《衷中參西錄》',
					'wepk' => 'WP',
					'wepe' => 250,
					'weps' => 600,
					'wepsk' => 'p',
				),
				10 => array
				(
					'name' => '黑猫',
					'icon' => 0,
					'club' => 6,
					'wep' => '阔剑地雷吸附器',
					'wepk' => 'WP',
					'wepe' => 400,
					'weps' => 600,
					'wepsk' => 'Mm',
				),
				11 => array
				(
					'name' => '水羊',
					'icon' => 0,
					'club' => 2,
					'wep' => '■Darthnote■',
					'wepk' => 'WK',
					'wepe' => 400,
					'weps' => 600,
					'wepsk' => 'c',
				),
				12 => array
				(
					'name' => '上帝的左手',
					'icon' => 0,
					'club' => 2,
					'wep' => '胡来的左手',
					'wepk' => 'WK',
					'wepe' => 270,
					'weps' => 600,
					'wepsk' => 'd',
				),
				13 => array
				(
					'name' => '半人半灵半吊子',
					'icon' => 0,
					'club' => 98,
					'wep' => '楼观剑',
					'wepk' => 'WK',
					'wepe' => 200,
					'weps' => 600,
					'wepsk' => 'd',
					'itm1' => '白楼剑',
					'itmk1' => 'WK',
					'itme1' => 130,
					'itms1' => 600,
					'itmsk1' => 'r',
				),
				14 => array
				(
					'name' => '死亡荆棘',
					'icon' => 0,
					'club' => 7,
					'wep' => '【荆棘式电子地雷】',
					'wepk' => 'WK',
					'wepe' => 210,
					'weps' => 600,
					'wepsk' => 'd',
				),
				15 => array
				(
					'name' => '超魔理沙-电子',
					'icon' => 0,
					'club' => 14,
					'wep' => '【荆棘式电子地雷】',
					'wepk' => 'WP',
					'wepe' => 240,
					'weps' => 600,
					'wepsk' => 'd',
				),
				16 => array
				(
					'name' => '东方地雷殿',
					'icon' => 0,
					'club' => 7,
					'wep' => '【荆棘式电子地雷】',
					'wepk' => 'WD',
					'wepe' => 210,
					'weps' => 600,
					'wepsk' => 'd',
				),
				17 => array
				(
					'name' => 'fossil',
					'icon' => 0,
					'club' => 1,
					'wep' => '大钉棍棒',
					'wepk' => 'WP',
					'wepe' => 250,
					'weps' => 600,
					'wepsk' => 'Nn',
				),
				18 => array
				(
					'name' => '流风之念',
					'icon' => 0,
					'club' => 4,
					'wep' => '连击烧输尿管~☆',
					'wepk' => 'WG',
					'wepe' => 150,
					'weps' => 600,
					'wepsk' => 'ru',
				),
				19 => array
				(
					'name' => 'MESSIAH',
					'icon' => 0,
					'club' => 4,
					'wep' => '本格的嘴炮',
					'wepk' => 'WG',
					'wepe' => 240,
					'weps' => 600,
					'wepsk' => 'd',
				),
				20 => array
				(
					'name' => '帕秋莉诺蕾姬',
					'icon' => 0,
					'club' => 9,
					'wep' => '水&火符「Phlogistic Rain」',
					'wepk' => 'WF',
					'wepe' => 260,
					'weps' => 600,
					'wepsk' => 'ui',
				),
				21 => array
				(
					'name' => '坂田铜时',
					'icon' => 0,
					'club' => 1,
					'wep' => '无毁的受王拳',
					'wepk' => 'WP',
					'wepe' => 380,
					'weps' => 600,
				),
				22 => array
				(
					'name' => '耶和华',
					'icon' => 0,
					'club' => 15,
					'wep' => 'L5爆发！',
					'wepk' => 'WF',
					'wepe' => 250,
					'weps' => 600,
					'wepsk' => 'd',
				),
				23 => array
				(
					'name' => '闹球肾',
					'icon' => 0,
					'club' => 1,
					'wep' => '一个半角符号',
					'wepk' => 'WF',
					'wepe' => 150,
					'weps' => 600,
					'wepsk' => 'rd',
				),
				24 => array
				(
					'name' => '初音ミク',
					'icon' => 0,
					'club' => 4,
					'wep' => '「Falchion Rider」模样的杏仁豆腐',
					'wepk' => 'WG',
					'wepe' => 190,
					'weps' => 600,
					'wepsk' => 'r',
					'arb' => '英雄战甲B模样的杏仁豆腐',
					'arh' => '英雄战甲H模样的杏仁豆腐',
					'arf' => '英雄战甲F模样的杏仁豆腐',
					'ara' => '英雄战甲A模样的杏仁豆腐',
					'art' => '英雄之力模样的杏仁豆腐',
				),
				25 => array
				(
					'name' => 'Abyss混沌',
					'icon' => 0,
					'club' => 1,
					'wep' => '混乱邪恶之塔',
					'wepk' => 'WF',
					'wepe' => 1,
					'weps' => 1,
					'wepsk' => 'r',
				),
				26 => array
				(
					'name' => '飞雪大大',
					'icon' => 0,
					'club' => 9,
					'wep' => '魔王の剑',
					'wepk' => 'WK',
					'wepe' => 300,
					'weps' => 300,
					'wepsk' => 'u',
				),
				27 => array
				(
					'name' => '微笑的疯子',
					'icon' => 0,
					'club' => 1,
					'wep' => '把妹の手',
					'wepk' => 'WP',
					'wepe' => 100,
					'weps' => 600,
					'wepsk' => 'Nnr',
				),
				28 => array
				(
					'name' => '挂机中的灰尘',
					'icon' => 0,
					'club' => 9,
					'wep' => '★挂机の萌力★',
					'wepk' => 'WF',
					'wepe' => 250,
					'weps' => 600,
					'wepsk' => 'ni',
				),
				29 => array
				(
					'name' => '西园寺世界酱',
					'icon' => 0,
					'club' => 5,
					'wep' => '节操炸弹G',
					'wepk' => 'WD',
					'wepe' => 300,
					'weps' => 600,
					'wepsk' => 'id',
				),
				30 => array
				(
					'name' => '索非亚小傻鸟',
					'icon' => 0,
					'club' => 8,
					'wep' => 'COCO☆酱',
					'wepk' => 'WC',
					'wepe' => 280,
					'weps' => 600,
					'wepsk' => 'lu',
				),
				31 => array
				(
					'name' => '浮云_小坏',
					'icon' => 0,
					'club' => 9,
					'wep' => '向日葵妖精',
					'wepk' => 'WG',
					'wepe' => 251,
					'weps' => 600,
					'wepsk' => 'ud',
					'itm1' => 'YES♂SIR',
					'itmk1' => 'Z',
					'itme1' => 1,
					'itms1' => 1,
				),
				32 => array
				(
					'name' => '人形蚂蚁α',
					'icon' => 0,
					'club' => 9,
					'wep' => '纸条■■■■',
					'wepk' => 'WC',
					'wepe' => 280,
					'weps' => 600,
					'wepsk' => 'Ne',
				),
				33 => array
				(
					'name' => 'tabris',
					'icon' => 0,
					'club' => 13,
					'wep' => '十二试炼',
					'wepk' => 'WC',
					'wepe' => 400,
					'weps' => 600,
					'wepsk' => 'r',
				),
				34 => array
				(
					'name' => '吔姐蕉',
					'icon' => 0,
					'club' => 1,
					'wep' => '无毁的受王拳',
					'wepk' => 'WP',
					'wepe' => 410,
					'weps' => 600,
				),
				35 => array
				(
					'name' => 'ad53123426',
					'icon' => 0,
					'club' => 9,
					'wep' => '无毁的受王拳',
					'wepk' => 'WP',
					'wepe' => 530,
					'weps' => 600,
				),
			),
		),
	
		21 => array
			(
			'mode' => 2,
			'num' => 7,
			'pass' => 'wei42bg',
			'club' => 0,
			'bid' => 0,
			'inf' => '',
			'rage' => 250,
			'pose'=> 2,
			'tactic' => 3,
			'killnum' => 0,
			'teamID' => '',
			'teamPass' => '',
			'gd' => 'r',
			'pls' => 34,
			'mhp' => 12900,
			'msp' => 800,
			'att' => 4000,
			'def' => 4000,
			'lvl' => 65,
			'skill' => 800,
			'money' => 40000,
			'arb' => '武神战甲B',
			'arbk' => 'DB',
			'arbe' => 3000,
			'arbs' => 300,
			'arbsk' => 'A',
			'arh' => '武神战甲H',
			'arhk' => 'DH',
			'arhe' => 2000,
			'arhs' => 300,
			'arhsk' => 'b',
			'arf' => '武神战甲F',
			'arfk' => 'DF',
			'arfe' => 2000,
			'arfs' => 300,
			'arfsk' => 'a',
			'ara' => '武神战甲A',
			'arak' => 'DA',
			'arae' => 2000,
			'aras' => 300,
			'arask' => 'H',
			'art' => '武神之魂',
			'artk' => 'A',
			'arte' => 9,
			'arts' => 9,
			'artsk' => 'ch',
	
	
	
	
			'sub' => array
			(
				0 => array
				(
					'name' => '黑熊',
					'gd' => 'm',
					'icon' => 210,
					'club' => 18,
					'mhp' => 8932,
					'att' => 5120,
					'skill' => 1919,
					'skills' => array('400'=>'5','401'=>'5','402'=>'1','403'=>'5','461'=>'1','422'=>'0'),
					'wep' => 'Solidarity',
					'wepk' => 'WG',
					'wepe' => 3000,
					'weps' => 3000,
					'wepsk' => 'Nnrd',
					'arb' => 'NATO',
					'arbk' => 'DB',
					'arbe' => 2333,
					'arbs' => 300,
					'arbsk' => 'ZA',
					'arh' => 'Voice of America',
					'arhk' => 'DH',
					'arhe' => 2333,
					'arhs' => 300,
					'arhsk' => 'ZB',
					'arf' => 'One small step',
					'arfk' => 'DF',
					'arfe' => 2333,
					'arfs' => 300,
					'arfsk' => 'Za',
					'ara' => 'Tear down this WALL',
					'arak' => 'DA',
					'arae' => 2333,
					'aras' => 300,
					'arask' => 'ZH',
					'art' => 'Bear Trap',
					'artk' => 'A',
					'arte' => 1,
					'arts' => 1,
					'artsk' => 'Zch',
					'itm1' => '『黑熊刀』',
					'itmk1' => 'WK',
					'itme1' => 90,
					'itms1' => 350,
					'itmsk1' => 'Nnrd',
					'itm2' => '超重型黑熊列车 古斯塔夫最大炮',
					'itmk2' => 'WG',
					'itme2' => 3000,
					'itms2' => 3000,
					'itmsk2' => 'Nnrd',
					'itm3' => '《黑熊语录》',
					'itmk3' => 'VV',
					'itme3' => 153,
					'itms3' => 1,
					'itmsk3' => 'Z',
					'itm4' => '这个是什么按钮',
					'itmk4' => 'Y',
					'itme4' => 1,
					'itms4' => 1,
					'description' => '武神 黑熊，<span class="yellow b">旧英灵四天王之首，被称为英灵殿唯一的良心。（咦？）<br>附带很不要脸的<span class="red b">【直死1】</span>和<span class="red b">【暴风】</span>技能</span>',
				),
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
				2 => array
				(
					'name' => '水月',
					'gd' => 'f',
					'icon' => 99,
					'club' => 9,
					'mode' => 2,
					'mhp' => 14000,
					'skill' => 1200,
					'skills' => array('81'=>'0', '461'=>'0'),
					'wep' => '「饭纲权现降临」',
					'wepk' => 'WC',
					'wepe' => 1,
					'weps' => 9999,
					'wepsk' => 'Bbx',
					'arb' => 'Reality marble',
					'arbk' => 'DB',
					'arbe' => 3000,
					'arbs' => 500,
					'arbsk' => 'Ax',
					'arh' => 'Torah',
					'arhk' => 'DH',
					'arhe' => 3000,
					'arhs' => 300,
					'arhsk' => 'bx',
					'arf' => 'Nevi’im',
					'arfk' => 'DF',
					'arfe' => 3000,
					'arfs' => 300,
					'arfsk' => 'ax',
					'ara' => 'Fantasm',
					'arak' => 'DA',
					'arae' => 3000,
					'aras' => 300,
					'arask' => 'Hx',
					'art' => '《Dead Sea Scrolls》',
					'artk' => 'Ah',
					'arte' => 3000,
					'arts' => 233,
					'artsk' => 'cx',
					'itm1' => 'EX火&金符『St. Elmo Pillar』',
					'itmk1' => 'WF',
					'itme1' => 800,
					'itms1' => '∞',
					'itmsk1' => 'nrdf',
					'itm2' => 'Barrett M95',
					'itmk2' => 'WG',
					'itme2' => 1500,
					'itms2' => 500,
					'itmsk2' => 'rnfS',
					'itm3' => '圣光啊!你有看到那个敌人吗！',
					'itmk3' => 'Z',
					'itme3' => 1,
					'itms3' => 1,
					'description' => '武神 水月，<span class="yellow b">旧英灵四天王之一。</span>身上的火金符对玩家威胁很大，称号为换装迷宫，台词来源于圣经。初始武器自带双抹，但威力不足。',
				),
				3 => array
				(
					'name' => '芬里爾《黑曲》',
					'gd' => 'f',
					'mode' => 3,
					'icon' => 104,
					'club' => 99,
					'mhp' => 10000,
					'att' => 100,
					'def' => 400,
					'rage' => 10,
					'lvl' => 20, 
					'skill' => 100,
					'skills' => array('461'=>'1'),
					'wep' => '超⑨武神斩',
					'wepk' => 'WK',
					'wepe' => 200,
					'weps' => 100,
					'wepsk' => 'z',
					'arb' => '黑曲装备B',
					'arbk' => 'DB',
					'arbe' => 400,
					'arbs' => 300,
					'arbsk' => 'zh',
					'arh' => '黑曲装备H',
					'arhk' => 'DH',
					'arhe' => 233,
					'arhs' => 300,
					'arhsk' => 'z',
					'arf' => '黑曲装备F',
					'arfk' => 'DF',
					'arfe' => 233,
					'arfs' => 300,
					'arfsk' => 'z',
					'ara' => '黑曲装备A',
					'arak' => 'DA',
					'arae' => 233,
					'aras' => 300,
					'arask' => 'z',
					'art' => '黑曲装备T',
					'artk' => 'Ah',
					'arte' => 233,
					'arts' => 233,
					'artsk' => 'z',
					'description' => '武神 黑色奪魂曲，<span class="yellow b">英灵殿吉祥物。</span>攻击力低，二形态血量为1000W，自带双抹，同时武器拥有贯穿属性，具有一定威胁。',
				),
				4 => array
				(
					'name' => '北京推倒你',
					'gd' => 'm',
					'icon' => 102,
					'club' => 14,
					'skill' => 6000,
					'skills' => array('461'=>'0'),
					'wep' => '拳头',
					'wepk' => 'WN',
					'wepe' => 400,
					'weps' => 998,
					'wepsk' => 'hrden',
					'arb' => 'Microsoft Visual Studio 2010',
					'arbk' => 'DB',
					'arbe' => 2333,
					'arbs' => 300,
					'arbsk' => 'A',
					'arh' => 'GoldWave',
					'arhk' => 'DH',
					'arhe' => 2333,
					'arhs' => 300,
					'arhsk' => 'b',
					'arf' => 'MeGUI',
					'arfk' => 'DF',
					'arfe' => 2333,
					'arfs' => 300,
					'arfsk' => 'a',
					'ara' => 'Micorsoft AppLocale',
					'arak' => 'DA',
					'arae' => 2333,
					'aras' => 300,
					'arask' => 'H',
					'itm1' => '肉○器“北京”型',
					'itmk1' => 'WP',
					'itme1' => 4000,
					'itms1' => '∞',
					'itmsk1' => 'g',
					'description' => '武神 北京推倒你，<span class="yellow b">曾经被誉为最弱武神，经过BUFF后变的丧心病狂起来。</span>武器为空手，但拥有6000点的基础熟练，隐隐有成为小黑熊的架势。',
				),
				5 => array
				(
					'name' => 'BorisX',
					'gd' => 'm',
					'icon' => 105,
					'hp' => 9400,
					'club' => 4,
					'skill' => 1150,
					'skills' => array('461'=>'1'),
					'wep' => 'AKM改二',
					'wepk' => 'WJ',
					'wepe' => 2600,
					'weps' => 4000,
					'wepsk' => 'n',
					'description' => '武神 BorisX，<span class="yellow b">旧英灵四天王之一，经过BUFF后变的更加丧心病狂。</span>武器为重枪，同时具有1150点的基础熟练，而且血量也有所提升，大家看见之后绕着走就行了。',
				),
				6 => array
				(
					'name' => 'Renamon',
					'gd' => 'f',
					'mhp' => 14000,
					'icon' => 98,
					'club' => 2,
					'skill' => 1100,
					'skills' => array('461'=>'0'),
					'wep' => '画(ping)笔(ru)',
					'wepk' => 'WK',
					'wepe' => 1900,
					'weps' => 999,
					'wepsk' => 'rdn',
					'description' => '武神 Renamon，<span class="yellow b">旧时代毫无存在感的武神之一，被BUFF能拯救她阿卡林的命运吗？</span>血量为武神中最高，同时武器基础效和全熟在被BUFF后隐隐有与当年黄鸡寻星比肩的势头。',
				),
				7 => array
				(
					'name' => 'beijuzhu',
					'gd' => 'm',
					'icon' => 0,
					'club' => 7,
					'skill' => 3000,
					'skills' => array('461'=>'0'),
					'wep' => '破解的PSP-3000',
					'wepk' => 'WP',
					'wepe' => 2100,
					'weps' => 999,
					'wepsk' => 'rne',
					'description' => '武神 beijuzhu，<span class="yellow b">旧时代毫无存在感的武神之一，被BUFF能拯救他阿卡林的命运吗？</span>虽然和小狐一样，武器基础效得到了BUFF，但看起来还是很弱小。',
				),
				8 => array
				(
					'name' => '捂脸姬',
					'gd' => 'f',
					'pose' => 4,
					'att' => 4000,
					'icon' => 0,
					'club' => 8,
					'skill' => 850,
					'skills' => array('461'=>'0'),
					'wep' => '超级☆无敌辰音LILY',
					'wepk' => 'WD',
					'wepe' => 10000,
					'weps' => 999,
					'wepsk' => 'cdn',
					'description' => '武神 捂脸姬，<span class="yellow b">旧时代毫无存在感的武神之一，被BUFF能拯救她阿卡林的命运吗？</span>少数没有强袭姿态的武神之一，但是武器基础效直接被提高了十倍，看起来很危险的样子。',
				),
				9 => array
				(
					'name' => 'Yoshiko-G',
					'gd' => 'f',
					'def' => 30250,
					'icon' => 4,
					'club' => 18,
					'skill' => 900,
					'skills' => array('461'=>'0'),
					'wep' => '光翼型近接支援残酷戦闘機銃',
					'wepk' => 'WG',
					'wepe' => 2000,
					'weps' => 999,
					'wepsk' => 'nre',
					'description' => '武神 Yoshiko-G，<span class="yellow b">四面衍生物，特征是毒舌与傲娇。</span>武神中基础防御力仅低于lemon，在得到BUFF后翻身农奴把歌唱，自带迅疾和静息技能，同时称号变为天赋，要被耀西子教做人了吗！？',
				),
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
			),
		),
		
		22 => array
		(
			'mode' => 1,
			'num' => 4,
			'club' => 0,
			'bid' => 0,
			'inf' => '',
			'rage' => 255,
			'pose'=> 4,
			'tactic' => 3,
			'killnum' => 99,
			'teamID' => '',
			'teamPass' => '',
			'pls' => 34,
			'mhp' => 23333,
			'msp' => 2333,
			'def' => 2333,
			'lvl' => 97,
			'skill' => 444,
			'money' => 100000,
			'arb' => '天神的威光',
			'arbk' => 'DB',
			'arbe' => 6000,
			'arbs' => 400,
			'arbsk' => 'ab',
			'arh' => '天神的极光',
			'arhk' => 'DH',
			'arhe' => 4000,
			'arhs' => 300,
			'arhsk' => 'h',
			'arf' => '天神的霞光',
			'arfk' => 'DF',
			'arfe' => 4000,
			'arfs' => 300,
			'arfsk' => 'A',
			'ara' => '天神的寒光',
			'arak' => 'DA',
			'arae' => 4000,
			'aras' => 300,
			'arask' => 'c',
			'art' => '天神的曙光',
			'artk' => 'A',
			'arte' => 200,
			'arts' => 300,
			'artsk' => 'H',
			'sub' => array
			(
				0 => array
				(
					'name' => '冴月麟MK-II',
					'gd' => 'f',
					'icon' => 3,
					'club' => 9,
					'mss' => 50,
					'att' => 23333,
					'skill' => array('wp' => 1600, 'wk' => 2300, 'wc' => 2700, 'wg' => 1900, 'wd' => 1500, 'wf' => 2800),
					'skills' => array('81' => '0', '461'=>'0'),
					'wep' => '键 希望弹',
					'wepk' => 'WC',
					'wepe' => 50000,
					'weps' => 998,
					'wepsk' => 'zdfkc',
					'arb' => '真 - 桔黄色的大衣',
					'arh' => '真 - 红色的发圈',
					'arf' => '真 - 橙黄学生鞋',
					'ara' => '真 - 带翅膀的书包',
					'art' => '真 - 奇迹之愿',
					'itm1' => '键 燃烧弹',
					'itmk1' => 'WF',
					'itme1' => 48000,
					'itms1' => '∞',
					'itmsk1' => 'Nfzr',
					'itm2' => '键 生命弹',
					'itmk2' => 'WG',
					'itme2' => 50000,
					'itms2' => 998,
					'itmsk2' => 'zdrfk',
					'itm3' => '键 未来弹',
					'itmk3' => 'WP',
					'itme3' => 50000,
					'itms3' => '∞',
					'itmsk3' => 'rcdfN',
		




					'itm5' => '键 旅途弹',
					'itmk5' => 'WK',
					'itme5' => 50000,
					'itms5' => 998,
					'itmsk5' => 'zdNkc',
					'itm6' => '键 审判弹',
					'itmk6' => 'WF',
					'itme6' => 100000,
					'itms6' => '∞',
					'itmsk6' => 'nrfkx',
					'description' => '天神 冴月麟MK-II，ACFUN大逃杀的最初创作者。KEY社的铁杆粉丝。会切换武器。（没有键 催泪弹是刻意的）',
				),
				1 => array
				(
					'name' => '星莲船四面BOSS',
					'gd' => 'm',
					'icon' => 163,
					'club' => 18,
					'att' => 233,
					'mhp' => 4444,
					'skill' => 120,
					'skills' => array('461'=>'0'),
					'wep' => '【黑暗童话】',
					'wepk' => 'WJ',
					'wepe' => 1,
					'weps' => 9999,
					'wepsk' => 'rdpn^ac1',
					'arb' => '可爱标记拼成的披风',
					'arh' => '天马经理的面罩',
					'arf' => '刀锋般的后腿',
					'ara' => '研究员的笔记本',
					'art' => 'S.M.I.L.E.!',
					'itm2' => '四面的腿',
					'itmk2' => 'PB2',
					'itme2' => 1,
					'itms2' => 1,
					'itmsk2' => 'x',
					'itm1' => '武器师安雅的奖赏',
					'itmk1' => 'Y',
					'itme1' => 1,
					'itms1' => 3,
					'itmsk1' => 'z',
					'description' => '天神 星莲船四面BOSS，AC大逃杀程序员、抖M，本体已经变成了马。虽然武器的攻击力是1，但由于重型枪械的百分比伤害设定，实际上对玩家拥有即死效果。',
				),
				2 => array
				(
					'name' => '虚子',
					'gd' => 'f',
					'icon' => 161,
					'club' => 18,
					'mhp' => 8932,
					'att' => 5120,
					'skill' => 1919,
					'skills' => array('400'=>'5','401'=>'5','402'=>'4','461'=>'1'),
					'wep' => 'WE will BURY YOU',
					'wepk' => 'WG',
					'wepe' => 3000,
					'weps' => 3000,
					'wepsk' => 'Nnrd',
					'arb' => 'Warsaw Pact',
					'arh' => 'De-Stalinization',
					'arf' => 'Muslim Revolution',
					'ara' => 'Flower Power',
					'art' => 'Glasnost',
					'itm1' => '『寻星者』',
					'itmk1' => 'WK',
					'itme1' => 90,
					'itms1' => 350,
					'itmsk1' => 'Nnrd',
					'itm2' => '超重型炮塔列车 古斯塔夫最大炮',
					'itmk2' => 'WG',
					'itme2' => 3000,
					'itms2' => 3000,
					'itmsk2' => 'Nnrd',
					'itm3' => '《董子语录》',
					'itmk3' => 'VV',
					'itme3' => 153,
					'itms3' => 1,
					'itmsk3' => 'Z',
					'description' => '天神 虚子，AC大逃杀程序员，毒舌属性。<br>附带很不要脸的<span class="red b">【直死4】</span>技能，命中抬走送往印度，现在订购还附赠美味香蕉一串。pong友，今天你被直死了吗？',
				),
				3 => array
				(
					'name' => 'lemon',
					'gd' => 'r',
					'icon' => 162,
					'club' => 7,
					'lvl' => 0,
					'rage' => 0,
					'mhp' => 9800,
					'att' => 32767,
					'def' => 32767,
					'skill' => 1150,
					'skills'=>array('412'=>'0','461'=>'1'),	
					'wep' => '电气火绳枪',
					'wepk' => 'WG',
					'wepe' => 30,
					'weps' => 60,
					'wepsk' => 'en',
					'arb' => '工作装',
					'arh' => '防灾头巾',
					'ara' => '垫肩',
					'arf' => '钉鞋',
					'art' => 'Untainted Glory',
					'itm1' => 'ACDTS Farming Helper',
					'itmk1' => 'ME',
					'itme1' => 20,
					'itms1' => 200,
					'itmsk1' => 'z',
					'description' => '天神 lemon，AC大逃杀程序员，代码力深不见底。<br>拥有全英灵殿最高的基础攻击与防御，而更吓人的是其拥有的<span class="red b">【反演】</span>技能，让无数屠殿老司机铩羽而归。',
				),
			),
		),
		
		88 => array
		(
			'mode' => 1,
			'num' => 4,
			'pass' => 'bra',
			'club' => 17,
			'bid' => 0,
			'inf' => '',
			'rage' => 188,
			'pose'=> 2,
			'tactic' => 3,
			'killnum' => 88,
			'teamID' => '',
			'teamPass' => '',
			'gd' => 'm',
			'pls' => 32,
			'mhp' => 8888888,
			'msp' => 888,
			'att' => 88888,
			'def' => 88888,
			'lvl' => 88,
			'skill' => 88888,
			'money' => 88888,
			'arb' => '[数据删除]',
			'arbk' => 'DB',
			'arbe' => 8888,
			'arbs' => 8888,
			'arbsk' => 'Aa',
			'arh' => '[数据删除]',
			'arhk' => 'DH',
			'arhe' => 8888,
			'arhs' => 8888,
			'arhsk' => 'Bb',
			'arf' => '[数据删除]',
			'arfk' => 'DF',
			'arfe' => 8888,
			'arfs' => 8888,
			'arfsk' => 'Mm',
			'ara' => '[数据删除]',
			'arak' => 'DA',
			'arae' => 8888,
			'aras' => 8888,
			'arask' => 'Hc',
			'art' => '[数据删除]',
			'artk' => 'A',
			'arte' => 1,
			'arts' => 1,
			'artsk' => 'xH',
			'sub' => array
			(
				0 => array
				(
					'name' => 'SCP-682',
					'icon' => 103,
					'wep' => '[数据删除]',
					'wepk' => 'WN',
					'wepe' => 8888,
					'weps' => 8888,
					'wepsk' => 'nrd',
					'description' => 'SCP-682，坐镇于SCP研究设施，完全无敌的存在，要是不幸被打到的话，必死无疑。最好的避免方法，就是<span class="yellow b">永远不要去SCP研究设施</span>。',
				),
				1 => array
				(
					'name' => 'SCP-173',
					'icon' => 106,
					'wep' => '[数据删除]',
					'wepk' => 'WF',
					'wepe' => 8888,
					'weps' => 8888,
					'wepsk' => 'nrd',
					'description' => 'SCP-173，坐镇于SCP研究设施，完全无敌的存在，要是不幸被打到的话，必死无疑。最好的避免方法，就是<span class="yellow b">永远不要去SCP研究设施</span>。',
				),
				2 => array
				(
					'name' => 'SCP-076',
					'icon' => 107,
					'wep' => '[数据删除]',
					'wepk' => 'WK',
					'wepe' => 8888,
					'weps' => 8888,
					'wepsk' => 'nrd',
					'description' => 'SCP-076，坐镇于SCP研究设施，完全无敌的存在，要是不幸被打到的话，必死无疑。最好的避免方法，就是<span class="yellow b">永远不要去SCP研究设施</span>。',
				),
				3 => array
				(
					'name' => 'SCP-958',
					'icon' => 108,
					'wep' => '[数据删除]',
					'wepk' => 'WG',
					'wepe' => 8888,
					'weps' => 8888,
					'wepsk' => 'nrd',
					'description' => 'SCP-958，坐镇于SCP研究设施，完全无敌的存在，要是不幸被打到的话，必死无疑。最好的避免方法，就是<span class="yellow b">永远不要去SCP研究设施</span>。',
				),
			),
		),
		
		90 => array
		(
			'mode' => 2,
			'num' => 80,
			'pass' => 'bra',
			'club' => 0,
			'bid' => 0,
			'inf' => '',
			'rage' => 0,
			'pose'=> 0,
			'tactic' => 0,
			'killnum' => 0,
			'teamID' => '',
			'teamPass' => '',
			'gd' => 'r',
			'pls' => 99,
			'mhp' => 500,
			'msp' => 200,
			'att' => 130,
			'def' => 150,
			'lvl' => 10,
			'skill' => 40,
			'money' => 220,
			'arb' => '跟风群皮',
			'arbk' => 'DB',
			'arbe' => 35,
			'arbs' => 30,
			
			'arh' => '萌豚头像',
			'arhk' => 'DH',
			'arhe' => 25,
			'arhs' => 30,
			
			'arf' => '女装丝袜',
			'arfk' => 'DF',
			'arfe' => 25,
			'arfs' => 30,
			
			'ara' => '发送按钮',
			'arak' => 'DA',
			'arae' => 25,
			'aras' => 30,
			
			'art' => '键盘侠之证',
			'artk' => 'A',
			'arte' => 20,
			'arts' => 10,
			
	
	
	
	

			'itm1' => '压缩饼干',
			'itmk1' => 'HB',
			'itme1' => 35,
			'itms1' => 10,
			'itm2' => '紧急药剂',
			'itmk2' => 'Ca',
			'itme2' => 1,
			'itms2' => 1,
			
			'sub' => array
			(
				0 => array
				(
					'name' => '复读机',
					'icon' => 25,
					'wep' => '水群之枪',
					'wepk' => 'WG',
					'wepe' => 50,
					'weps' => 50,
					'description' => '“人类的本质就是复读机。”<br>无威胁的杂兵，也是数目最多的NPC之一，碰见了就上去给他一击吧。',
				),
				1 => array
				(
					'name' => '秦国人',
					'icon' => 26,
					'wep' => '丢人之摸',
					'wepk' => 'WP',
					'wepe' => 50,
					'weps' => 50,
					'description' => '“真鸡儿丢人！”<br>无威胁的杂兵，也是数目最多的NPC之一，碰见了就上去给他一击吧。',
				),
				2 => array
				(
					'name' => '白学家',
					'icon' => 29,
					'mss' => 30,
					'wep' => '雪碧之罐',
					'wepk' => 'WC',
					'wepe' => 50,
					'weps' => 50,
					'description' => '“又到了那个寒冷的季节……”<br>无威胁的杂兵，也是数目最多的NPC之一，碰见了就上去给他一击吧。',
				),
				3 => array
				(
					'name' => '膜触党',
					'icon' => 28,
					'wep' => '捧杀之钩',
					'wepk' => 'WK',
					'wepe' => 50,
					'weps' => 50,
					'description' => '“这服就我不是触手了。”<br>无威胁的杂兵，也是数目最多的NPC之一，碰见了就上去给他一击吧。',
				),
			),
		),
	);
}
?>