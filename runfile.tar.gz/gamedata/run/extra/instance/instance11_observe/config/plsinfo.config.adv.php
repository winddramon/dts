<?php

namespace instance11
{
	
	$plsinfo11 = Array(
		101 => '作战会议室',
		102 => '蓝凝的卧室',
		103 => '蓝凝的展示室',
		104 => '洗手间',
	);

	
	
	
	

	

	
	
	
	
}

?>