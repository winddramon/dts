<? if(!defined('IN_GAME')) exit('Access Denied'); ?>
礼品盒,p,1,1,,
游戏王卡包,ygo,1,10,,
奇怪的液体,HB,265,11,,
★奇怪的盒子★,prd,1,1,,
最强-バカ⑨制冰块,HB,99,99,,
棱镜八面体,Z,1,1,x,