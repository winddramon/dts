<?php

namespace instance11
{
	$npcinfo_instance11 = array
	( 
		9 => array
		(
			'mode' => 3,
			'num' => 1,
			'pass' => 'bra',
			'club' => 17,
			'bid' => 0,
			'inf' => '',
			'rage' => 0,
			'pose'=> 2,
			'tactic' => 3,
			'killnum' => 99,
			'teamID' => '',
			'teamPass' => '',
			'gd' => 'f',
			'pls' => 103,
			'mhp' => 3000000,
			'msp' => 4000,
			'att' => 200000,
			'def' => 22000,
			'lvl' => 97,
			'skill' => 2400,
			'money' => 1,
			'arb' => '蓝色睡衣',
			'arbk' => 'DB',
			'arbe' => 60,
			'arbs' => 150,
			'arh' => '蓬松睡帽',
			'arhk' => 'DH',
			'arhe' => 40,
			'arhs' => 150,
			'ara' => '粉色枕头',
			'arak' => 'DA',
			'arae' => 40,
			'aras' => 150,
			'arf' => '泡泡拖鞋',
			'arfk' => 'DF',
			'arfe' => 40,
			'arfs' => 150,
			'art' => '绯红色的龙虎挂坠',
			'artk' => 'A',
			'arte' => 1,
			'arts' => 1,
			'artsk' => 'AaH',
			'sub' => array
			(
				0 => array
				(
					'name' => '蓝凝 MUDDY',
					'mss' => 40,
					'skills' => array('406'=>'0','432'=>'0','459'=>'0','461'=>'0'),
					'icon' => 213,
					'wep' => '『AZURE RONDO』模样的抱枕',
					'wepk' => 'WP',
					'wepe' => 2000,
					'weps' => 360,
					'wepsk' => 'rkdNny',
					'itm1' => '好想按这个按钮',
					'itmk1' => 'Y',
					'itme1' => 1,
					'itms1' => 1,
					'itm2' => '★神秘遥控器★',
					'itmk2' => 'EW',
					'itme2' => 1,
					'itms2' => 100,
					'itmsk2' => '^wid19^ahid1^alt_<:comp_itmsk:>{^wid18^ahid1}1^atype2',
					'description' => '坐镇于冰封墓场的NPC，几乎无敌的存在。<span class="yellow b">没事还是不要惹她好了……</span>',
				),
			),
		),
	);
}
?>