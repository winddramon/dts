<?php

namespace gtype6
{
	function init() {}
	
	
	function get_enter_battlefield_card($card){
		return \instance10\get_enter_battlefield_card($card);
	}
	
	
	function card_validate_get_forbidden_cards($card_disabledlist, $card_ownlist){
		return \instance10\card_validate_get_forbidden_cards($card_disabledlist,$card_ownlist);
	}
	
	
	function card_validate_display($cardChosen, $card_ownlist, $packlist, $hideDisableButton){
		return \instance10\card_validate_display($cardChosen,$card_ownlist,$packlist,$hideDisableButton);
	}
}

?>