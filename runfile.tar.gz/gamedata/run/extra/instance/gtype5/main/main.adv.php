<?php

namespace gtype5
{
	function init() {}
	


















	
	function get_npclist(){
		return \instance5\get_npclist();
	}
	
	function get_enpcinfo()
	{
		return \gtype1\get_enpcinfo();
	}
	
	function get_shopconfig(){
		return \instance5\get_shopconfig();
	}
	
	function get_itemfilecont(){
		return \instance9\get_itemfilecont();
	}
	
		function get_trapfilecont(){
		return \instance9\get_trapfilecont();
	}
	
	function get_startingitemfilecont(){
		return \instance9\get_startingitemfilecont();
	}
	
	function get_startingwepfilecont(){
		return \instance9\get_startingwepfilecont();
	}
}

?>