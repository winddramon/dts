<?php

namespace skill1004
{
	function init() 
	{
		define('MOD_SKILL1004_INFO','unique;');
		do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;   } while (0);
		$clubskillname[1004] = '难度';
	}
	
	function acquire1004(&$pa)
	{
		
		\skillbase\skill_setvalue(1004,'lvl',0,$pa);
	}
	
	function lost1004(&$pa)
	{
		
	}
	
	function check_unlocked1004(&$pa)
	{
		
		return 1;
	}
	
	function get_skill1004_lvl(&$pa=NULL)
	{
		
		if($pa == NULL) {
			do { global $___LOCAL_PLAYER__VARS__ss,$___LOCAL_PLAYER__VARS__db_player_structure,$___LOCAL_PLAYER__VARS__db_player_structure_types,$___LOCAL_PLAYER__VARS__gamedata,$___LOCAL_PLAYER__VARS__cmd,$___LOCAL_PLAYER__VARS__main,$___LOCAL_PLAYER__VARS__sdata,$___LOCAL_PLAYER__VARS__fog,$___LOCAL_PLAYER__VARS__upexp,$___LOCAL_PLAYER__VARS__lvlupexp, $___LOCAL_PLAYER__VARS__iconImg,$___LOCAL_PLAYER__VARS__iconImgB,$___LOCAL_PLAYER__VARS__iconImgBwidth,$___LOCAL_PLAYER__VARS__ardef,$___LOCAL_PLAYER__VARS__hpcolor,$___LOCAL_PLAYER__VARS__spcolor,$___LOCAL_PLAYER__VARS__newhpimg,$___LOCAL_PLAYER__VARS__newspimg,$___LOCAL_PLAYER__VARS__splt,$___LOCAL_PLAYER__VARS__hplt, $___LOCAL_PLAYER__VARS__tpldata,$___LOCAL_PLAYER__VARS__typeinfo,$___LOCAL_PLAYER__VARS__killmsginfo,$___LOCAL_PLAYER__VARS__lwinfo,$___LOCAL_PLAYER__VARS__sexinfo,$___LOCAL_PLAYER__VARS__equip_list,$___LOCAL_PLAYER__VARS__battle_equip_list,$___LOCAL_PLAYER__VARS__pid,$___LOCAL_PLAYER__VARS__type,$___LOCAL_PLAYER__VARS__name, $___LOCAL_PLAYER__VARS__pass,$___LOCAL_PLAYER__VARS__ip,$___LOCAL_PLAYER__VARS__motto,$___LOCAL_PLAYER__VARS__killmsg,$___LOCAL_PLAYER__VARS__lastword,$___LOCAL_PLAYER__VARS__player_dead_flag,$___LOCAL_PLAYER__VARS__corpse_clear_flag,$___LOCAL_PLAYER__VARS__gd,$___LOCAL_PLAYER__VARS__sNo,$___LOCAL_PLAYER__VARS__club, $___LOCAL_PLAYER__VARS__validtime,$___LOCAL_PLAYER__VARS__endtime,$___LOCAL_PLAYER__VARS__cdsec,$___LOCAL_PLAYER__VARS__cdmsec,$___LOCAL_PLAYER__VARS__cdtime,$___LOCAL_PLAYER__VARS__action,$___LOCAL_PLAYER__VARS__a_actionnum,$___LOCAL_PLAYER__VARS__v_actionnum,$___LOCAL_PLAYER__VARS__hp,$___LOCAL_PLAYER__VARS__mhp, $___LOCAL_PLAYER__VARS__sp,$___LOCAL_PLAYER__VARS__msp,$___LOCAL_PLAYER__VARS__mss,$___LOCAL_PLAYER__VARS__att,$___LOCAL_PLAYER__VARS__def,$___LOCAL_PLAYER__VARS__pls,$___LOCAL_PLAYER__VARS__lvl,$___LOCAL_PLAYER__VARS__exp,$___LOCAL_PLAYER__VARS__money,$___LOCAL_PLAYER__VARS__rp, $___LOCAL_PLAYER__VARS__bid,$___LOCAL_PLAYER__VARS__inf,$___LOCAL_PLAYER__VARS__rage,$___LOCAL_PLAYER__VARS__pose,$___LOCAL_PLAYER__VARS__tactic,$___LOCAL_PLAYER__VARS__killnum,$___LOCAL_PLAYER__VARS__npckillnum,$___LOCAL_PLAYER__VARS__state,$___LOCAL_PLAYER__VARS__skillpoint,$___LOCAL_PLAYER__VARS__flare, $___LOCAL_PLAYER__VARS__wp,$___LOCAL_PLAYER__VARS__wk,$___LOCAL_PLAYER__VARS__wg,$___LOCAL_PLAYER__VARS__wc,$___LOCAL_PLAYER__VARS__wd,$___LOCAL_PLAYER__VARS__wf,$___LOCAL_PLAYER__VARS__icon,$___LOCAL_PLAYER__VARS__teamID,$___LOCAL_PLAYER__VARS__teamPass,$___LOCAL_PLAYER__VARS__card, $___LOCAL_PLAYER__VARS__cardname,$___LOCAL_PLAYER__VARS__wep,$___LOCAL_PLAYER__VARS__wepk,$___LOCAL_PLAYER__VARS__wepe,$___LOCAL_PLAYER__VARS__weps,$___LOCAL_PLAYER__VARS__wepsk,$___LOCAL_PLAYER__VARS__arb,$___LOCAL_PLAYER__VARS__arbk,$___LOCAL_PLAYER__VARS__arbe,$___LOCAL_PLAYER__VARS__arbs, $___LOCAL_PLAYER__VARS__arbsk,$___LOCAL_PLAYER__VARS__arh,$___LOCAL_PLAYER__VARS__arhk,$___LOCAL_PLAYER__VARS__arhe,$___LOCAL_PLAYER__VARS__arhs,$___LOCAL_PLAYER__VARS__arhsk,$___LOCAL_PLAYER__VARS__ara,$___LOCAL_PLAYER__VARS__arak,$___LOCAL_PLAYER__VARS__arae,$___LOCAL_PLAYER__VARS__aras, $___LOCAL_PLAYER__VARS__arask,$___LOCAL_PLAYER__VARS__arf,$___LOCAL_PLAYER__VARS__arfk,$___LOCAL_PLAYER__VARS__arfe,$___LOCAL_PLAYER__VARS__arfs,$___LOCAL_PLAYER__VARS__arfsk,$___LOCAL_PLAYER__VARS__art,$___LOCAL_PLAYER__VARS__artk,$___LOCAL_PLAYER__VARS__arte,$___LOCAL_PLAYER__VARS__arts, $___LOCAL_PLAYER__VARS__artsk,$___LOCAL_PLAYER__VARS__itm0,$___LOCAL_PLAYER__VARS__itmk0,$___LOCAL_PLAYER__VARS__itme0,$___LOCAL_PLAYER__VARS__itms0,$___LOCAL_PLAYER__VARS__itmsk0,$___LOCAL_PLAYER__VARS__itm1,$___LOCAL_PLAYER__VARS__itmk1,$___LOCAL_PLAYER__VARS__itme1,$___LOCAL_PLAYER__VARS__itms1, $___LOCAL_PLAYER__VARS__itmsk1,$___LOCAL_PLAYER__VARS__itm2,$___LOCAL_PLAYER__VARS__itmk2,$___LOCAL_PLAYER__VARS__itme2,$___LOCAL_PLAYER__VARS__itms2,$___LOCAL_PLAYER__VARS__itmsk2,$___LOCAL_PLAYER__VARS__itm3,$___LOCAL_PLAYER__VARS__itmk3,$___LOCAL_PLAYER__VARS__itme3,$___LOCAL_PLAYER__VARS__itms3, $___LOCAL_PLAYER__VARS__itmsk3,$___LOCAL_PLAYER__VARS__itm4,$___LOCAL_PLAYER__VARS__itmk4,$___LOCAL_PLAYER__VARS__itme4,$___LOCAL_PLAYER__VARS__itms4,$___LOCAL_PLAYER__VARS__itmsk4,$___LOCAL_PLAYER__VARS__itm5,$___LOCAL_PLAYER__VARS__itmk5,$___LOCAL_PLAYER__VARS__itme5,$___LOCAL_PLAYER__VARS__itms5, $___LOCAL_PLAYER__VARS__itmsk5,$___LOCAL_PLAYER__VARS__itm6,$___LOCAL_PLAYER__VARS__itmk6,$___LOCAL_PLAYER__VARS__itme6,$___LOCAL_PLAYER__VARS__itms6,$___LOCAL_PLAYER__VARS__itmsk6,$___LOCAL_PLAYER__VARS__searchmemory,$___LOCAL_PLAYER__VARS__nskill,$___LOCAL_PLAYER__VARS__nskillpara; $ss=&$___LOCAL_PLAYER__VARS__ss; $db_player_structure=&$___LOCAL_PLAYER__VARS__db_player_structure; $db_player_structure_types=&$___LOCAL_PLAYER__VARS__db_player_structure_types; $gamedata=&$___LOCAL_PLAYER__VARS__gamedata; $cmd=&$___LOCAL_PLAYER__VARS__cmd; $main=&$___LOCAL_PLAYER__VARS__main; $sdata=&$___LOCAL_PLAYER__VARS__sdata; $fog=&$___LOCAL_PLAYER__VARS__fog; $upexp=&$___LOCAL_PLAYER__VARS__upexp; $lvlupexp=&$___LOCAL_PLAYER__VARS__lvlupexp;  $iconImg=&$___LOCAL_PLAYER__VARS__iconImg; $iconImgB=&$___LOCAL_PLAYER__VARS__iconImgB; $iconImgBwidth=&$___LOCAL_PLAYER__VARS__iconImgBwidth; $ardef=&$___LOCAL_PLAYER__VARS__ardef; $hpcolor=&$___LOCAL_PLAYER__VARS__hpcolor; $spcolor=&$___LOCAL_PLAYER__VARS__spcolor; $newhpimg=&$___LOCAL_PLAYER__VARS__newhpimg; $newspimg=&$___LOCAL_PLAYER__VARS__newspimg; $splt=&$___LOCAL_PLAYER__VARS__splt; $hplt=&$___LOCAL_PLAYER__VARS__hplt;  $tpldata=&$___LOCAL_PLAYER__VARS__tpldata; $typeinfo=&$___LOCAL_PLAYER__VARS__typeinfo; $killmsginfo=&$___LOCAL_PLAYER__VARS__killmsginfo; $lwinfo=&$___LOCAL_PLAYER__VARS__lwinfo; $sexinfo=&$___LOCAL_PLAYER__VARS__sexinfo; $equip_list=&$___LOCAL_PLAYER__VARS__equip_list; $battle_equip_list=&$___LOCAL_PLAYER__VARS__battle_equip_list; $pid=&$___LOCAL_PLAYER__VARS__pid; $type=&$___LOCAL_PLAYER__VARS__type; $name=&$___LOCAL_PLAYER__VARS__name;  $pass=&$___LOCAL_PLAYER__VARS__pass; $ip=&$___LOCAL_PLAYER__VARS__ip; $motto=&$___LOCAL_PLAYER__VARS__motto; $killmsg=&$___LOCAL_PLAYER__VARS__killmsg; $lastword=&$___LOCAL_PLAYER__VARS__lastword; $player_dead_flag=&$___LOCAL_PLAYER__VARS__player_dead_flag; $corpse_clear_flag=&$___LOCAL_PLAYER__VARS__corpse_clear_flag; $gd=&$___LOCAL_PLAYER__VARS__gd; $sNo=&$___LOCAL_PLAYER__VARS__sNo; $club=&$___LOCAL_PLAYER__VARS__club;  $validtime=&$___LOCAL_PLAYER__VARS__validtime; $endtime=&$___LOCAL_PLAYER__VARS__endtime; $cdsec=&$___LOCAL_PLAYER__VARS__cdsec; $cdmsec=&$___LOCAL_PLAYER__VARS__cdmsec; $cdtime=&$___LOCAL_PLAYER__VARS__cdtime; $action=&$___LOCAL_PLAYER__VARS__action; $a_actionnum=&$___LOCAL_PLAYER__VARS__a_actionnum; $v_actionnum=&$___LOCAL_PLAYER__VARS__v_actionnum; $hp=&$___LOCAL_PLAYER__VARS__hp; $mhp=&$___LOCAL_PLAYER__VARS__mhp;  $sp=&$___LOCAL_PLAYER__VARS__sp; $msp=&$___LOCAL_PLAYER__VARS__msp; $mss=&$___LOCAL_PLAYER__VARS__mss; $att=&$___LOCAL_PLAYER__VARS__att; $def=&$___LOCAL_PLAYER__VARS__def; $pls=&$___LOCAL_PLAYER__VARS__pls; $lvl=&$___LOCAL_PLAYER__VARS__lvl; $exp=&$___LOCAL_PLAYER__VARS__exp; $money=&$___LOCAL_PLAYER__VARS__money; $rp=&$___LOCAL_PLAYER__VARS__rp;  $bid=&$___LOCAL_PLAYER__VARS__bid; $inf=&$___LOCAL_PLAYER__VARS__inf; $rage=&$___LOCAL_PLAYER__VARS__rage; $pose=&$___LOCAL_PLAYER__VARS__pose; $tactic=&$___LOCAL_PLAYER__VARS__tactic; $killnum=&$___LOCAL_PLAYER__VARS__killnum; $npckillnum=&$___LOCAL_PLAYER__VARS__npckillnum; $state=&$___LOCAL_PLAYER__VARS__state; $skillpoint=&$___LOCAL_PLAYER__VARS__skillpoint; $flare=&$___LOCAL_PLAYER__VARS__flare;  $wp=&$___LOCAL_PLAYER__VARS__wp; $wk=&$___LOCAL_PLAYER__VARS__wk; $wg=&$___LOCAL_PLAYER__VARS__wg; $wc=&$___LOCAL_PLAYER__VARS__wc; $wd=&$___LOCAL_PLAYER__VARS__wd; $wf=&$___LOCAL_PLAYER__VARS__wf; $icon=&$___LOCAL_PLAYER__VARS__icon; $teamID=&$___LOCAL_PLAYER__VARS__teamID; $teamPass=&$___LOCAL_PLAYER__VARS__teamPass; $card=&$___LOCAL_PLAYER__VARS__card;  $cardname=&$___LOCAL_PLAYER__VARS__cardname; $wep=&$___LOCAL_PLAYER__VARS__wep; $wepk=&$___LOCAL_PLAYER__VARS__wepk; $wepe=&$___LOCAL_PLAYER__VARS__wepe; $weps=&$___LOCAL_PLAYER__VARS__weps; $wepsk=&$___LOCAL_PLAYER__VARS__wepsk; $arb=&$___LOCAL_PLAYER__VARS__arb; $arbk=&$___LOCAL_PLAYER__VARS__arbk; $arbe=&$___LOCAL_PLAYER__VARS__arbe; $arbs=&$___LOCAL_PLAYER__VARS__arbs;  $arbsk=&$___LOCAL_PLAYER__VARS__arbsk; $arh=&$___LOCAL_PLAYER__VARS__arh; $arhk=&$___LOCAL_PLAYER__VARS__arhk; $arhe=&$___LOCAL_PLAYER__VARS__arhe; $arhs=&$___LOCAL_PLAYER__VARS__arhs; $arhsk=&$___LOCAL_PLAYER__VARS__arhsk; $ara=&$___LOCAL_PLAYER__VARS__ara; $arak=&$___LOCAL_PLAYER__VARS__arak; $arae=&$___LOCAL_PLAYER__VARS__arae; $aras=&$___LOCAL_PLAYER__VARS__aras;  $arask=&$___LOCAL_PLAYER__VARS__arask; $arf=&$___LOCAL_PLAYER__VARS__arf; $arfk=&$___LOCAL_PLAYER__VARS__arfk; $arfe=&$___LOCAL_PLAYER__VARS__arfe; $arfs=&$___LOCAL_PLAYER__VARS__arfs; $arfsk=&$___LOCAL_PLAYER__VARS__arfsk; $art=&$___LOCAL_PLAYER__VARS__art; $artk=&$___LOCAL_PLAYER__VARS__artk; $arte=&$___LOCAL_PLAYER__VARS__arte; $arts=&$___LOCAL_PLAYER__VARS__arts;  $artsk=&$___LOCAL_PLAYER__VARS__artsk; $itm0=&$___LOCAL_PLAYER__VARS__itm0; $itmk0=&$___LOCAL_PLAYER__VARS__itmk0; $itme0=&$___LOCAL_PLAYER__VARS__itme0; $itms0=&$___LOCAL_PLAYER__VARS__itms0; $itmsk0=&$___LOCAL_PLAYER__VARS__itmsk0; $itm1=&$___LOCAL_PLAYER__VARS__itm1; $itmk1=&$___LOCAL_PLAYER__VARS__itmk1; $itme1=&$___LOCAL_PLAYER__VARS__itme1; $itms1=&$___LOCAL_PLAYER__VARS__itms1;  $itmsk1=&$___LOCAL_PLAYER__VARS__itmsk1; $itm2=&$___LOCAL_PLAYER__VARS__itm2; $itmk2=&$___LOCAL_PLAYER__VARS__itmk2; $itme2=&$___LOCAL_PLAYER__VARS__itme2; $itms2=&$___LOCAL_PLAYER__VARS__itms2; $itmsk2=&$___LOCAL_PLAYER__VARS__itmsk2; $itm3=&$___LOCAL_PLAYER__VARS__itm3; $itmk3=&$___LOCAL_PLAYER__VARS__itmk3; $itme3=&$___LOCAL_PLAYER__VARS__itme3; $itms3=&$___LOCAL_PLAYER__VARS__itms3;  $itmsk3=&$___LOCAL_PLAYER__VARS__itmsk3; $itm4=&$___LOCAL_PLAYER__VARS__itm4; $itmk4=&$___LOCAL_PLAYER__VARS__itmk4; $itme4=&$___LOCAL_PLAYER__VARS__itme4; $itms4=&$___LOCAL_PLAYER__VARS__itms4; $itmsk4=&$___LOCAL_PLAYER__VARS__itmsk4; $itm5=&$___LOCAL_PLAYER__VARS__itm5; $itmk5=&$___LOCAL_PLAYER__VARS__itmk5; $itme5=&$___LOCAL_PLAYER__VARS__itme5; $itms5=&$___LOCAL_PLAYER__VARS__itms5;  $itmsk5=&$___LOCAL_PLAYER__VARS__itmsk5; $itm6=&$___LOCAL_PLAYER__VARS__itm6; $itmk6=&$___LOCAL_PLAYER__VARS__itmk6; $itme6=&$___LOCAL_PLAYER__VARS__itme6; $itms6=&$___LOCAL_PLAYER__VARS__itms6; $itmsk6=&$___LOCAL_PLAYER__VARS__itmsk6; $searchmemory=&$___LOCAL_PLAYER__VARS__searchmemory; $nskill=&$___LOCAL_PLAYER__VARS__nskill; $nskillpara=&$___LOCAL_PLAYER__VARS__nskillpara;   } while (0);
			$pa = &$sdata;
		}
		if(!\skillbase\skill_query(1004, $pa)) return 0; 
		return \skillbase\skill_getvalue(1004,'lvl',$pa);
	}
	
	function get_attacker_factor(&$pa, &$pd, $active){
		
		if (!\skillbase\skill_query(1004, $pa) || !check_unlocked1004($pa)) return 1;
		do { global $___LOCAL_SKILL1004__VARS__skill1004_title,$___LOCAL_SKILL1004__VARS__skill1004_dmg_factor_a_pc,$___LOCAL_SKILL1004__VARS__skill1004_dmg_factor_d_pc,$___LOCAL_SKILL1004__VARS__skill1004_dmg_factor_a_npc,$___LOCAL_SKILL1004__VARS__skill1004_dmg_factor_d_npc; $skill1004_title=&$___LOCAL_SKILL1004__VARS__skill1004_title; $skill1004_dmg_factor_a_pc=&$___LOCAL_SKILL1004__VARS__skill1004_dmg_factor_a_pc; $skill1004_dmg_factor_d_pc=&$___LOCAL_SKILL1004__VARS__skill1004_dmg_factor_d_pc; $skill1004_dmg_factor_a_npc=&$___LOCAL_SKILL1004__VARS__skill1004_dmg_factor_a_npc; $skill1004_dmg_factor_d_npc=&$___LOCAL_SKILL1004__VARS__skill1004_dmg_factor_d_npc;   } while (0);
		$skill1004_lvl = round(\skillbase\skill_getvalue(1004,'lvl',$pa));
		if($skill1004_lvl < 0) $skill1004_lvl = 0;
		if($skill1004_lvl > 4) $skill1004_lvl = 4;
		if(!$pd['type']) return $skill1004_dmg_factor_a_pc[$skill1004_lvl];
		else return $skill1004_dmg_factor_a_npc[$skill1004_lvl];
	}
	
	function get_defender_factor(&$pa, &$pd, $active){
		
		if (!\skillbase\skill_query(1004, $pd) || !check_unlocked1004($pd)) return 1;
		do { global $___LOCAL_SKILL1004__VARS__skill1004_title,$___LOCAL_SKILL1004__VARS__skill1004_dmg_factor_a_pc,$___LOCAL_SKILL1004__VARS__skill1004_dmg_factor_d_pc,$___LOCAL_SKILL1004__VARS__skill1004_dmg_factor_a_npc,$___LOCAL_SKILL1004__VARS__skill1004_dmg_factor_d_npc; $skill1004_title=&$___LOCAL_SKILL1004__VARS__skill1004_title; $skill1004_dmg_factor_a_pc=&$___LOCAL_SKILL1004__VARS__skill1004_dmg_factor_a_pc; $skill1004_dmg_factor_d_pc=&$___LOCAL_SKILL1004__VARS__skill1004_dmg_factor_d_pc; $skill1004_dmg_factor_a_npc=&$___LOCAL_SKILL1004__VARS__skill1004_dmg_factor_a_npc; $skill1004_dmg_factor_d_npc=&$___LOCAL_SKILL1004__VARS__skill1004_dmg_factor_d_npc;   } while (0);
		$skill1004_lvl = round(\skillbase\skill_getvalue(1004,'lvl',$pd));
		if($skill1004_lvl < 0) $skill1004_lvl = 0;
		if($skill1004_lvl > 4) $skill1004_lvl = 4;
		if(!$pa['type']) return $skill1004_dmg_factor_d_pc[$skill1004_lvl];
		else return $skill1004_dmg_factor_d_npc[$skill1004_lvl];
	}
	
	function get_final_dmg_multiplier(&$pa, &$pd, $active)
	{
		
		$ra = \skill1004\get_attacker_factor ($pa, $pd, $active);
		$rd = \skill1004\get_defender_factor ($pa, $pd, $active);
		if($ra != 1 || $rd != 1) {
			do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
			$log .= '由于难度调整';
		}
		if($ra != 1) $log .= \battle\battlelog_parser($pa, $pd, $active, '，<span class="yellow b"><:pa_name:>造成的最终伤害变为了'.($ra*100).'%</span>');
		if($rd != 1) $log .= \battle\battlelog_parser($pa, $pd, $active, '，<span class="yellow b"><:pd_name:>受到的最终伤害变为了'.($rd*100).'%</span>');
		if($ra != 1 || $rd != 1) {
			$log .= '！<br>';
		}
		$r=Array($rd, $ra);
if(isset($r)) {$__VAR_DUMP_VARS_skill1004_r = $r; unset($r); } else {$__VAR_DUMP_VARS_skill1004_r = NULL;} 
		//======== Start of contents from mod skill228 ========
		do{
			$skill228_get_final_dmg_multiplier_ret = NULL;

		
		$r=Array();
		if ($pa['bskill']==228) 
		{
			do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;  global $___LOCAL_SKILL228__VARS__skill228_skillpoint_req,$___LOCAL_SKILL228__VARS__stuntime228; $skill228_skillpoint_req=&$___LOCAL_SKILL228__VARS__skill228_skillpoint_req; $stuntime228=&$___LOCAL_SKILL228__VARS__stuntime228;   } while (0);
			if ($active)
				$log.='<span class="lime b">你有如天神下凡，对敌人打出雷霆一击！</span><span class="cyan b">敌人被你击晕了！</span><br>';
			else  $log.='<span class="lime b">敌人有如天神下凡，对你打出雷霆一击！</span><span class="cyan b">你被敌人击晕了！</span><br>';
			$r=Array(1.6);
			\skill602\set_stun_period($stuntime228,$pd);
			\skill602\send_stun_battle_news($pa['name'],$pd['name']);
		}
if(isset($r)) {$__VAR_DUMP_VARS_skill228_r = $r; unset($r); } else {$__VAR_DUMP_VARS_skill228_r = NULL;} 
		//======== Start of contents from mod skill507 ========
		do{
			$skill507_get_final_dmg_multiplier_ret = NULL;

		
		$r=Array();
		if ( !empty($pa['skill507_flag']) )
		{
			$r=Array(666);	
		}
if(isset($r)) {$__VAR_DUMP_VARS_skill507_r = $r; unset($r); } else {$__VAR_DUMP_VARS_skill507_r = NULL;} 
		//======== Start of contents from mod skill208 ========
		do{
			$skill208_get_final_dmg_multiplier_ret = NULL;

		
		$r=Array();
		if ($pa['bskill']==208) 
		{
			do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
			if ($pa['card']==5){
				if ($active)
					$log.='<span class="yellow b">「强袭」使你造成的最终伤害提高了70%！</span><br>';
				else  $log.='<span class="yellow b">「强袭」使敌人造成的最终伤害提高了70%！</span><br>';
				$r=Array(1.7);
			}else{
				if ($active)
					$log.='<span class="yellow b">「强袭」使你造成的最终伤害提高了40%！</span><br>';
				else  $log.='<span class="yellow b">「强袭」使敌人造成的最终伤害提高了40%！</span><br>';
				$r=Array(1.4);
			}
		}
if(isset($r)) {$__VAR_DUMP_VARS_skill208_r = $r; unset($r); } else {$__VAR_DUMP_VARS_skill208_r = NULL;} 
		//======== Start of contents from mod skill210 ========
		do{
			$skill210_get_final_dmg_multiplier_ret = NULL;

		
		$r=Array();
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;  global $___LOCAL_SKILL210__VARS__skill210_cd,$___LOCAL_SKILL210__VARS__skill210_act_time; $skill210_cd=&$___LOCAL_SKILL210__VARS__skill210_cd; $skill210_act_time=&$___LOCAL_SKILL210__VARS__skill210_act_time;   } while (0);
		$var_210=20;
		if ($pa['card']==5) $var_210=40;
		if ((\skillbase\skill_query(210,$pa))&&(\skill210\check_skill210_state ($pa)==1)&&(rand(0,99)<$var_210)&&(\weapon\get_skillkind($pa,$pd,$active) == 'wk')&&($pa['club']==2)) 
		{
			$z=2;
			if ($active)
				$log.='<span class="red b">暴击！</span><span class="lime b">「歼灭」使你造成了'.$z.'倍最终伤害！</span><br>';
			else  $log.='<span class="red b">暴击！</span><span class="lime b">「歼灭」使敌人造成了'.$z.'倍最终伤害！</span><br>';
			$r=Array($z);
		}
if(isset($r)) {$__VAR_DUMP_VARS_skill210_r = $r; unset($r); } else {$__VAR_DUMP_VARS_skill210_r = NULL;} 
		//======== Start of contents from mod skill218 ========
		do{
			$skill218_get_final_dmg_multiplier_ret = NULL;

		
		$r=Array();
		if ((\skillbase\skill_query(218,$pa))&&(\skill218\check_unlocked218 ($pa))&&(strlen($pd['original_inf'])>0))
		{
			$var_218=\skill218\get_skill218_extra_dmgrate ($pa,$pd,$active);
			
			if ($var_218>0)
			{
				if ($active)
					$log.="<span class=\"yellow b\">「渗透」使你造成的最终伤害提高了{$var_218}%！</span><br>";
				else  $log.="<span class=\"yellow b\">「渗透」使敌人造成的最终伤害提高了{$var_218}%！</span><br>";
				$r=Array(1+$var_218/100);
			}	
		}
if(isset($r)) {$__VAR_DUMP_VARS_skill218_r = $r; unset($r); } else {$__VAR_DUMP_VARS_skill218_r = NULL;} 
		//======== Start of contents from mod skill444 ========
		do{
			$skill444_get_final_dmg_multiplier_ret = NULL;

		
		$r=Array();
		if ((\skillbase\skill_query(444,$pa))&&(\skill444\check_unlocked444 ($pa)))
		{
			
			if ($active)
				$log.="<span class=\"yellow b\">“就杀那个最菜的！”「怒吼」使你造成的最终伤害提高了100%！</span><br>";
			else  $log.="<span class=\"yellow b\">“就杀那个最菜的！”「怒吼」使敌人造成的最终伤害提高了100%！</span><br>";
			$r=Array(2);	
		}
if(isset($r)) {$__VAR_DUMP_VARS_skill444_r = $r; unset($r); } else {$__VAR_DUMP_VARS_skill444_r = NULL;} 
		//======== Start of contents from mod skill202 ========
		do{
			$skill202_get_final_dmg_multiplier_ret = NULL;

		
		$r=Array();
		if ((\skillbase\skill_query(202,$pa))&&(\skill202\check_unlocked202 ($pa))&&(\weapon\get_skillkind($pa,$pd,$active) == 'wg'))
		{
			$var_202=$pa['skill202_count']*\skill202\get_skill202_extra_dmgrate ($pa,$pd,$active);
			
			if ($var_202>0)
			{
				if ($active)
					$log.="<span class=\"yellow b\">「破甲」使你造成的最终伤害提高了{$var_202}%！</span><br>";
				else  $log.="<span class=\"yellow b\">「破甲」使敌人造成的最终伤害提高了{$var_202}%！</span><br>";
				$r=Array(1+$var_202/100);
			}	
			unset($pa['skill202_count']);
		}
if(isset($r)) {$__VAR_DUMP_VARS_skill202_r = $r; unset($r); } else {$__VAR_DUMP_VARS_skill202_r = NULL;} 
		//======== Start of contents from mod skill223 ========
		do{
			$skill223_get_final_dmg_multiplier_ret = NULL;

		
		$r=Array();
		if ($pa['bskill']==223) 
		{
			
			if ($pa['card']==5){
				$var_223=100;
			}else{
				$var_223=50;
			}
			if (isset($pd['original_inf'])){
				$var_223+=(50*strlen($pd['original_inf']));
			}
			if ($active)
				$log.="<span class=\"yellow b\">「暗杀」使你造成的最终伤害提高了{$var_223}%！</span><br>";
			else  $log.="<span class=\"yellow b\">「暗杀」使敌人造成的最终伤害提高了{$var_223}！</span><br>";
			$var_223=($var_223+100)/100;
			$r=Array($var_223);
		}
if(isset($r)) {$__VAR_DUMP_VARS_skill223_r = $r; unset($r); } else {$__VAR_DUMP_VARS_skill223_r = NULL;} 
		//======== Start of contents from mod skill515 ========
		do{
			$skill515_get_final_dmg_multiplier_ret = NULL;

		
		$r=Array();
		if (\skillbase\skill_query(515,$pa) && \skill515\check_unlocked515 ($pa)) 
		{
			
			$factor515 = \skill515\calc_factor515 ();
			if($factor515 > 0) {
				$log .= \battle\battlelog_parser($pa, $pd, $active, '<span class="red b"><:pa_name:>心中具备的「杀戮之力」让最终伤害增加了'.$factor515.'%！</span><br>');
				
				$r=Array(1+$factor515/100);
			}
		}
if(isset($r)) {$__VAR_DUMP_VARS_skill515_r = $r; unset($r); } else {$__VAR_DUMP_VARS_skill515_r = NULL;} 
		//======== Start of contents from mod skill476 ========
		do{
			$skill476_get_final_dmg_multiplier_ret = NULL;

		
		$r=Array();
		if ((\skillbase\skill_query(476,$pa))&&(\skill476\check_unlocked476 ($pa)))
		{
			
			if (strpos($pa['wep'],"精工")===false){
				if ($active)
					$log.="<span class=\"yellow b\">「尊严」使你造成的最终伤害降低了60%！</span><br>";
				else  $log.="<span class=\"yellow b\">「尊严」使敌人造成的最终伤害降低了60%！</span><br>";
				$r=Array(0.4);
			}else{
				if ($active)
					$log.="<span class=\"yellow b\">「尊严」使你造成的最终伤害提高了10%！</span><br>";
				else  $log.="<span class=\"yellow b\">「尊严」使敌人造成的最终伤害提高了10%！</span><br>";
				$r=Array(1.1);
			}
		}
if(isset($r)) {$__VAR_DUMP_VARS_skill476_r = $r; unset($r); } else {$__VAR_DUMP_VARS_skill476_r = NULL;} 
		//======== Start of contents from mod skill470 ========
		do{
			$skill470_get_final_dmg_multiplier_ret = NULL;

		
		$r=Array();
		if (isset($pa['bskill']) && $pa['bskill']>0 && \skillbase\skill_query(470,$pa))	
		{
			
			if ($active)
				$log.='<span class="yellow b">「狙击」使敌人受到的最终伤害增加了12%！</span><br>';
			else  $log.='<span class="yellow b">「狙击」使你受到的最终伤害增加了12%！</span><br>';
			$r=Array(1.12);
		}
if(isset($r)) {$__VAR_DUMP_VARS_skill470_r = $r; unset($r); } else {$__VAR_DUMP_VARS_skill470_r = NULL;} 
		//======== Start of contents from mod skill450 ========
		do{
			$skill450_get_final_dmg_multiplier_ret = NULL;

		
		$r=Array();
		if ((\skillbase\skill_query(450,$pa))&&(\skill450\check_unlocked450 ($pa)))
		{
			do {  __MODULE_NULLFUNCTION__();  } while (0);
			if ($pd['hp']<($pd['mhp']*0.2)){
				if ($active)
					$log.="<span class=\"yellow b\">「淘汰」使你造成的最终伤害提高了15%！</span><br>";
				else  $log.="<span class=\"yellow b\">「淘汰」使敌人造成的最终伤害提高了15%！</span><br>";
				$r=Array(1.15);
			}
		}
if(isset($r)) {$__VAR_DUMP_VARS_skill450_r = $r; unset($r); } else {$__VAR_DUMP_VARS_skill450_r = NULL;} 
		//======== Start of contents from mod skill449 ========
		do{
			$skill449_get_final_dmg_multiplier_ret = NULL;

		
		$r=Array();
		if ((\skillbase\skill_query(449,$pa))&&(\skill449\check_unlocked449 ($pa)))
		{
			do {  __MODULE_NULLFUNCTION__();  } while (0);
			if ($pd['type']==90){
				if ($active)
					$log.="<span class=\"yellow b\">你对小兵的仇恨使你造成的最终伤害提高了8%！</span><br>";
				else  $log.="<span class=\"yellow b\">敌人对小兵的仇恨使其造成的最终伤害提高了8%！</span><br>";
				$r=Array(1.08);
			}
		}
if(isset($r)) {$__VAR_DUMP_VARS_skill449_r = $r; unset($r); } else {$__VAR_DUMP_VARS_skill449_r = NULL;} 
		//======== Start of contents from mod skill439 ========
		do{
			$skill439_get_final_dmg_multiplier_ret = NULL;

		
		$r=Array();
		if (\skillbase\skill_query(439,$pd) && \skill439\check_unlocked439 ($pd))
		{
			
			$var_439=\skillbase\skill_getvalue(439,'type',$pd);
			if ($var_439!=$pa['wep_kind']){
				\skillbase\skill_setvalue(439,'type',$pa['wep_kind'],$pd);
			}else{
				\skillbase\skill_setvalue(439,'type','X',$pd);
				if ($active) 
					$log .= "<span class=\"yellow b\">黄翔把你的攻击方式ban了，造成的伤害降低75%！</span><br>";
				else 
					$log .= "<span class=\"yellow b\">黄翔把敌人的攻击方式ban了，造成的伤害降低75%！</span><br>";
				$r=Array(0.25);
			}
		}
if(isset($r)) {$__VAR_DUMP_VARS_skill439_r = $r; unset($r); } else {$__VAR_DUMP_VARS_skill439_r = NULL;} 
		//======== Start of contents from mod skill438 ========
		do{
			$skill438_get_final_dmg_multiplier_ret = NULL;

		
		$r=Array();
		if ((\skillbase\skill_query(438,$pa))&&(\skill438\check_unlocked438 ($pa)))
		{
			do {  __MODULE_NULLFUNCTION__();  } while (0);
			$r438=\skillbase\skill_getvalue(438,'rate',$pa);
			$r=Array(($r438/100));	
			$r438-=100;
			if ($active)
				$log.="<span class=\"yellow b\">「挽鸽」使你造成的最终伤害提高了{$r438}%！</span><br>";
			else  $log.="<span class=\"yellow b\">「挽鸽」使敌人造成的最终伤害提高了{$r438}%！</span><br>";
			
		}
if(isset($r)) {$__VAR_DUMP_VARS_skill438_r = $r; unset($r); } else {$__VAR_DUMP_VARS_skill438_r = NULL;} 
		//======== Start of contents from mod skill419 ========
		do{
			$skill419_get_final_dmg_multiplier_ret = NULL;

		
		$r=Array();
		if ((\skillbase\skill_query(419,$pa))&&(\skill419\check_unlocked419 ($pa)))
		{
			
			if ($active)
				$log.="<span class=\"yellow b\">「暗夜」使你造成的最终伤害提高了12%！</span><br>";
			else  $log.="<span class=\"yellow b\">「暗夜」使敌人造成的最终伤害提高了12%！</span><br>";
			$r=Array(1.12);	
		}
if(isset($r)) {$__VAR_DUMP_VARS_skill419_r = $r; unset($r); } else {$__VAR_DUMP_VARS_skill419_r = NULL;} 
		//======== Start of contents from mod skill416 ========
		do{
			$skill416_get_final_dmg_multiplier_ret = NULL;

		
		$r=Array();
		if ((\skillbase\skill_query(416,$pa))&&(\skill416\check_unlocked416 ($pa)))
		{
			do { global $___LOCAL_SKILL416__VARS__paneldesc; $paneldesc=&$___LOCAL_SKILL416__VARS__paneldesc;   } while (0);
			$l416=\skillbase\skill_getvalue(416,'lvl',$pa);
			if ($pd['type']==0){
				if ($l416==0){
					if ($active)
						$log.="<span class=\"yellow b\">「团结」使你造成的最终伤害降低了50%！</span><br>";
					else  $log.="<span class=\"yellow b\">「团结」使敌人造成的最终伤害降低了50%！</span><br>";
					$r=Array(0.5);
				}else if ($l416==1){
					if ($active)
						$log.="<span class=\"yellow b\">「独斗」使你造成的最终伤害提高了10%！</span><br>";
					else  $log.="<span class=\"yellow b\">「独斗」使敌人造成的最终伤害提高了10%！</span><br>";
					$r=Array(1.1);
				}
			}else{
				if ($l416==0){
					if ($active)
						$log.="<span class=\"yellow b\">「团结」使你造成的最终伤害提高了30%！</span><br>";
					else  $log.="<span class=\"yellow b\">「团结」使敌人造成的最终伤害提高了30%！</span><br>";
					$r=Array(1.3);
				}else if ($l416==1){
					if ($active)
						$log.="<span class=\"yellow b\">「独斗」使你造成的最终伤害降低了10%！</span><br>";
					else  $log.="<span class=\"yellow b\">「独斗」使敌人造成的最终伤害降低了10%！</span><br>";
					$r=Array(0.9);
				}
			}
		}
if(isset($r)) {$__VAR_DUMP_VARS_skill416_r = $r; unset($r); } else {$__VAR_DUMP_VARS_skill416_r = NULL;} 
		//======== Start of contents from mod skill409 ========
		do{
			$skill409_get_final_dmg_multiplier_ret = NULL;

		
		$r=Array();
		if ((\skillbase\skill_query(409,$pd))&&(\skill409\check_unlocked409 ($pd)))
		{
			
			if ($active)
				$log.="<span class=\"yellow b\">「不动」使敌人受到的最终伤害降低了10%！</span><br>";
			else  $log.="<span class=\"yellow b\">「不动」使你受到的最终伤害降低了10%！</span><br>";
			$r=Array(0.9);	
		}
if(isset($r)) {$__VAR_DUMP_VARS_skill409_r = $r; unset($r); } else {$__VAR_DUMP_VARS_skill409_r = NULL;} 
		//======== Start of contents from mod skill408 ========
		do{
			$skill408_get_final_dmg_multiplier_ret = NULL;

		
		$r=Array();
		if ((\skillbase\skill_query(408,$pa))&&(\skill408\check_unlocked408 ($pa)))
		{
			do { global $___LOCAL_SKILL408__VARS__paneldesc; $paneldesc=&$___LOCAL_SKILL408__VARS__paneldesc;  global $___LOCAL_WEAPON__VARS__nowep,$___LOCAL_WEAPON__VARS__nosta,$___LOCAL_WEAPON__VARS__skilltypeinfo,$___LOCAL_WEAPON__VARS__attinfo,$___LOCAL_WEAPON__VARS__attinfo2,$___LOCAL_WEAPON__VARS__skillinfo,$___LOCAL_WEAPON__VARS__wep_equip_list,$___LOCAL_WEAPON__VARS__counter_obbs,$___LOCAL_WEAPON__VARS__rangeinfo,$___LOCAL_WEAPON__VARS__hitrate_obbs, $___LOCAL_WEAPON__VARS__hitrate_max_obbs,$___LOCAL_WEAPON__VARS__hitrate_r,$___LOCAL_WEAPON__VARS__dmg_fluc,$___LOCAL_WEAPON__VARS__skill_dmg,$___LOCAL_WEAPON__VARS__wepimprate,$___LOCAL_WEAPON__VARS__wepdeathstate; $nowep=&$___LOCAL_WEAPON__VARS__nowep; $nosta=&$___LOCAL_WEAPON__VARS__nosta; $skilltypeinfo=&$___LOCAL_WEAPON__VARS__skilltypeinfo; $attinfo=&$___LOCAL_WEAPON__VARS__attinfo; $attinfo2=&$___LOCAL_WEAPON__VARS__attinfo2; $skillinfo=&$___LOCAL_WEAPON__VARS__skillinfo; $wep_equip_list=&$___LOCAL_WEAPON__VARS__wep_equip_list; $counter_obbs=&$___LOCAL_WEAPON__VARS__counter_obbs; $rangeinfo=&$___LOCAL_WEAPON__VARS__rangeinfo; $hitrate_obbs=&$___LOCAL_WEAPON__VARS__hitrate_obbs;  $hitrate_max_obbs=&$___LOCAL_WEAPON__VARS__hitrate_max_obbs; $hitrate_r=&$___LOCAL_WEAPON__VARS__hitrate_r; $dmg_fluc=&$___LOCAL_WEAPON__VARS__dmg_fluc; $skill_dmg=&$___LOCAL_WEAPON__VARS__skill_dmg; $wepimprate=&$___LOCAL_WEAPON__VARS__wepimprate; $wepdeathstate=&$___LOCAL_WEAPON__VARS__wepdeathstate;   } while (0);
			$l408=\skillbase\skill_getvalue(408,'lvl',$pa);
			$var_408=0;
			if ($l408==1){
				if ($pa['wep_kind']=='P') $var_408=20;
				if ($pa['wep_kind']=='N') $var_408=40;
			}else if ($l408==2){
				if ($pa['wep_kind']=='G') $var_408=20;
			}else if ($l408==3){
				if ($pa['wep_kind']=='K') $var_408=20;
				if ($pa['wep_kind']=='C') $var_408=15;
			}else if ($l408==4){
				if ($pa['wep_kind']=='D') $var_408=15;
			}else if ($l408==5){
				$var_408=$rangeinfo[$pd['wepk'][1]]*3;
				if ($var_408==0) $var_408=24;
			}
			if ($var_408>0){
				if ($active)
					$log.="<span class=\"yellow b\">「菁英」使你造成的最终伤害提高了{$var_408}%！</span><br>";
				else  $log.="<span class=\"yellow b\">「菁英」使敌人造成的最终伤害提高了{$var_408}%！</span><br>";
				$r=Array(1+$var_408/100);
			}
		}
if(isset($r)) {$__VAR_DUMP_VARS_skill408_r = $r; unset($r); } else {$__VAR_DUMP_VARS_skill408_r = NULL;} 
		//======== Start of contents from mod skill406 ========
		do{
			$skill406_get_final_dmg_multiplier_ret = NULL;

		
		$r=Array();
		if ((\skillbase\skill_query(406,$pa))&&(\skill406\check_unlocked406 ($pa)))
		{
			
			if ($active)
				$log.="<span class=\"yellow b\">「心火」使你造成的最终伤害提高了100%！</span><br>";
			else  $log.="<span class=\"yellow b\">「心火」使敌人造成的最终伤害提高了100%！</span><br>";
			$r=Array(2);	
		}
if(isset($r)) {$__VAR_DUMP_VARS_skill406_r = $r; unset($r); } else {$__VAR_DUMP_VARS_skill406_r = NULL;} 
		//======== Start of contents from mod skill405 ========
		do{
			$skill405_get_final_dmg_multiplier_ret = NULL;

		
		$r=Array();
		if ((\skillbase\skill_query(405,$pa))&&(\skill405\check_unlocked405 ($pa))&&(($pa['wep_kind']=='K')||($pa['wep_kind']=='D')))
		{
			
			if ($active)
				$log.="<span class=\"yellow b\">「疾走」使你造成的最终伤害提高了20%！</span><br>";
			else  $log.="<span class=\"yellow b\">「疾走」使敌人造成的最终伤害提高了20%！</span><br>";
			$r=Array(1.2);	
		}
if(isset($r)) {$__VAR_DUMP_VARS_skill405_r = $r; unset($r); } else {$__VAR_DUMP_VARS_skill405_r = NULL;} 
		//======== Start of contents from mod skill74 ========
		do{
			$skill74_get_final_dmg_multiplier_ret = NULL;

		
		$r=Array();
		if ($pa['bskill']==74) 
		{
			
			if ($active)
				$log.='<span class="lime b">你对敌人释放出必杀技！</span><br>';
			else  $log.='<span class="lime b">敌人对你释放出必杀技！</span><br>';
			$x=($pa['club']==9?2:1.7);
			$r=Array($x);
		}
if(isset($r)) {$__VAR_DUMP_VARS_skill74_r = $r; unset($r); } else {$__VAR_DUMP_VARS_skill74_r = NULL;} if(isset($x)) {$__VAR_DUMP_VARS_skill74_x = $x; unset($x); } else {$__VAR_DUMP_VARS_skill74_x = NULL;} 
		//======== Start of contents from mod skill63 ========
		do{
			$skill63_get_final_dmg_multiplier_ret = NULL;

		
		$r=Array();
		if (\skillbase\skill_query(63,$pd) && \skill63\check_unlocked63 ($pd)) 
		{
			
			$clv = (int)\skillbase\skill_getvalue(63,'t',$pd);
			if ($clv==0)				{
				$ep = (int)\skillbase\skill_getvalue(63,'p',$pd);
				if ($pa['pid']==$ep)					{
					if ($active)
						$log.='<span class="yellow b">由于你被噩梦缠绕，你对其造成的最终伤害减少了20%！</span><br>';
					else  $log.='<span class="yellow b">由于敌人被噩梦缠绕，其对你造成的最终伤害减少了20%！</span><br>';
					$r=Array(0.8);
				}
			}
		}
if(isset($r)) {$__VAR_DUMP_VARS_skill63_r = $r; unset($r); } else {$__VAR_DUMP_VARS_skill63_r = NULL;} 
		//======== Start of contents from mod skill62 ========
		do{
			$skill62_get_final_dmg_multiplier_ret = NULL;

		
		$r=Array();
		if (\skillbase\skill_query(62,$pa) && \skill62\check_unlocked62 ($pa))
		{
			do { global $___LOCAL_SKILL62__VARS__numlim62; $numlim62=&$___LOCAL_SKILL62__VARS__numlim62;   } while (0);
			$x = 7*($numlim62-((int)\skillbase\skill_getvalue(62,'t',$pa)));
			if ($x>0)
			{
				if ($active)
					$log.='「腐蚀」技能使敌人受到的伤害减少了'.$x.'%！<br>';
				else  $log.='「腐蚀」技能使你受到的伤害减少了'.$x.'%！<br>';
				$r=Array((100-$x)/100);
			}
		}
if(isset($r)) {$__VAR_DUMP_VARS_skill62_r = $r; unset($r); } else {$__VAR_DUMP_VARS_skill62_r = NULL;} if(isset($x)) {$__VAR_DUMP_VARS_skill62_x = $x; unset($x); } else {$__VAR_DUMP_VARS_skill62_x = NULL;} 
		//======== Start of contents from mod skill83 ========
		do{
			$skill83_get_final_dmg_multiplier_ret = NULL;

		
		$r=Array();
		if ( \skillbase\skill_query(83,$pa) && \skill83\check_unlocked83 ($pa) && \skill83\check_wepk_debuff83 ($pa['skill83_owep'],$pa['skill83_owepk']) )
		{
			
			$rr = \skill83\check_wepk_debuff83 ($pa['skill83_owep'],$pa['skill83_owepk']);
			if ($active)
				$log.="<span class=\"yellow b\">「尊严」使你造成的最终伤害降低了{$rr}%！</span><br>";
			else  $log.="<span class=\"yellow b\">「尊严」使敌人造成的最终伤害降低了{$rr}%！</span><br>";
			$r=Array(1-$rr/100);	
		}
if(isset($r)) {$__VAR_DUMP_VARS_skill83_r = $r; unset($r); } else {$__VAR_DUMP_VARS_skill83_r = NULL;} 
		//======== Start of contents from mod skill462 ========
		do{
			$skill462_get_final_dmg_multiplier_ret = NULL;

		
		$r=Array();
		if (isset($pa['bskill']) && $pa['bskill']>0 && \skillbase\skill_query(462,$pd))	
		{
			
			if ($active)
				$log.='<span class="yellow b">「抗性」使敌人受到的最终伤害降低了35%！</span><br>';
			else  $log.='<span class="yellow b">「抗性」使你受到的最终伤害降低了35%！</span><br>';
			$r=Array(0.65);
		}
if(isset($r)) {$__VAR_DUMP_VARS_skill462_r = $r; unset($r); } else {$__VAR_DUMP_VARS_skill462_r = NULL;} 
		//======== Start of contents from mod skill456 ========
		do{
			$skill456_get_final_dmg_multiplier_ret = NULL;

		
		$r=Array();
		if (\skillbase\skill_query(456,$pa)) 
		{
			do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__pdata_pool, $___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser,$___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain, $___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut,$___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__database, $___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb,$___LOCAL_SYS__VARS__noitm, $___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo,$___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo, $___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event,$___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin, $___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit,$___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh, $___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs,$___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg, $___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__replay_ignore_mode,$___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre, $___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user,$___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min, $___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday,$___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype, $___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime,$___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum, $___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode,$___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist, $___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool;  $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser; $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain;  $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut; $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $database=&$___LOCAL_SYS__VARS__database;  $charset=&$___LOCAL_SYS__VARS__charset; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb; $noitm=&$___LOCAL_SYS__VARS__noitm;  $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo; $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo;  $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event; $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin;  $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit; $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh;  $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs; $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg;  $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode; $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre;  $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user; $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min;  $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday; $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype;  $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime; $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum;  $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode; $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist;  $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass; $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;  global $___LOCAL_SKILL456__VARS__skill456_act_time; $skill456_act_time=&$___LOCAL_SKILL456__VARS__skill456_act_time;   } while (0);
			$x=$now-$starttime; 
			if ($x<$skill456_act_time)
			{
				if ($active)
					$log.='<span class="yellow b">你抱着破釜沉舟之心，对敌人打出致命一击！</span><br>';
				else  $log.='<span class="yellow b">敌人抱着破釜沉舟之心，对你打出致命一击！</span><br>';
				$r=Array(1.4);
			}
		}
if(isset($r)) {$__VAR_DUMP_VARS_skill456_r = $r; unset($r); } else {$__VAR_DUMP_VARS_skill456_r = NULL;} 
		//======== Start of contents from mod skill453 ========
		do{
			$skill453_get_final_dmg_multiplier_ret = NULL;

		
		$r=Array();
		if (\skillbase\skill_query(453,$pa) && !$pa['is_counter']) 			{
			\skill453\sk453_skill_status_update ();
			do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__pdata_pool, $___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser,$___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain, $___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut,$___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__database, $___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb,$___LOCAL_SYS__VARS__noitm, $___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo,$___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo, $___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event,$___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin, $___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit,$___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh, $___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs,$___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg, $___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__replay_ignore_mode,$___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre, $___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user,$___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min, $___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday,$___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype, $___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime,$___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum, $___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode,$___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist, $___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool;  $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser; $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain;  $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut; $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $database=&$___LOCAL_SYS__VARS__database;  $charset=&$___LOCAL_SYS__VARS__charset; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb; $noitm=&$___LOCAL_SYS__VARS__noitm;  $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo; $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo;  $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event; $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin;  $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit; $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh;  $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs; $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg;  $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode; $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre;  $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user; $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min;  $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday; $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype;  $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime; $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum;  $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode; $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist;  $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass; $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;  global $___LOCAL_SKILL453__VARS__skill453_cd,$___LOCAL_SKILL453__VARS__skill453_act_time,$___LOCAL_SKILL453__VARS__skill453_buff_lose_time,$___LOCAL_SKILL453__VARS__skill453_factor; $skill453_cd=&$___LOCAL_SKILL453__VARS__skill453_cd; $skill453_act_time=&$___LOCAL_SKILL453__VARS__skill453_act_time; $skill453_buff_lose_time=&$___LOCAL_SKILL453__VARS__skill453_buff_lose_time; $skill453_factor=&$___LOCAL_SKILL453__VARS__skill453_factor;   } while (0);
			$tarpid = (int)\skillbase\skill_getvalue(453,'tarpid',$pa); 
			$skill453_count = (int)\skillbase\skill_getvalue(453,'cnt',$pa); 
			
			if ($pd['pid']!=$tarpid || $skill453_count==0)
			{
								$skill453_count=0;
				\skillbase\skill_setvalue(453,'target',$pd['name'],$pa); 
				\skillbase\skill_setvalue(453,'tarpid',$pd['pid'],$pa); 
			}
			$skill453_count++;
			$rat=$skill453_count*$skill453_factor;
			if ($active)
				$log.='<span class="yellow b">你对敌人的连续攻击使伤害增加了'.$rat.'%！</span><br>';
			else  $log.='<span class="yellow b">敌人对你的连续攻击使伤害增加了'.$rat.'%！</span><br>';
			$r=Array(1+$rat/100.0);
			\skillbase\skill_setvalue(453,'cnt',$skill453_count,$pa); 
			\skillbase\skill_setvalue(453,'lasthit',$now,$pa);
		}
if(isset($r)) {$__VAR_DUMP_VARS_skill453_r = $r; unset($r); } else {$__VAR_DUMP_VARS_skill453_r = NULL;} 
		//======== Start of contents from mod skill520 ========
		do{
			$skill520_get_final_dmg_multiplier_ret = NULL;

		
		$r=Array();
		if ( \skillbase\skill_query(520,$pa) && \skill520\check_unlocked520 ($pa) && empty($pa['is_counter']) && empty($pd['killnum']))
		{
			do { global $___LOCAL_SKILL520__VARS__skill520_factor,$___LOCAL_SKILL520__VARS__skill520_debufftime; $skill520_factor=&$___LOCAL_SKILL520__VARS__skill520_factor; $skill520_debufftime=&$___LOCAL_SKILL520__VARS__skill520_debufftime;   } while (0);
			$log .= \battle\battlelog_parser($pa, $pd, $active, "<span class=\"yellow b\">「纯洁」使<:pa_name:>造成的最终伤害降低了{$skill520_factor}%！</span><br>");

			$r=Array(1-$skill520_factor/100);	
		}
if(isset($r)) {$__VAR_DUMP_VARS_skill520_r = $r; unset($r); } else {$__VAR_DUMP_VARS_skill520_r = NULL;} 
		//======== Start of contents from mod skill485 ========
		do{
			$skill485_get_final_dmg_multiplier_ret = NULL;

		
		$r=Array();
		if (\skillbase\skill_query(485,$pa) && \skill485\check_unlocked485 ($pa) && !$pd['type'] && $pd['killnum'] > 0) 
		{
			do { global $___LOCAL_SKILL485__VARS__skill485factors; $skill485factors=&$___LOCAL_SKILL485__VARS__skill485factors;   } while (0);
			$lvl485 = \skillbase\skill_getvalue(485,'lvl',$pa);
			$skill485fac = $pd['killnum'] * $skill485factors[$lvl485];
			if($active){
				$log .= '对方的举止表明，他无疑犯下了累累血债，这让你怒不可遏！你的伤害增加了<span class="red b">'.$skill485fac.'</span>%！<br>';
			}else{
				$log .= '你手中的累累血债让'.$pa['name'].'怒不可遏！'.$pa['name'].'的伤害增加了<span class="red b">'.$skill485fac.'</span>%！<br>';
			}			
			$r[] = 1 + $skill485fac / 100;
		}
if(isset($r)) {$__VAR_DUMP_VARS_skill485_r = $r; unset($r); } else {$__VAR_DUMP_VARS_skill485_r = NULL;} 
		//======== Start of contents from mod skill477 ========
		do{
			$skill477_get_final_dmg_multiplier_ret = NULL;

		
		$r=Array();
		if (\skillbase\skill_query(477,$pa) && $pd['ss']<30)
		{
			
			if ($active)
				$log.="<span class=\"yellow b\">由于敌人没戏唱了，你的伤害增加了30%！</span><br>";
			else  $log.="<span class=\"yellow b\">由于你没戏唱了，你受到的伤害增加了30%</span><br>";
			$r=Array(1.30);	
		}
		//======== Start of contents from mod attack ========
		do{
			$attack_get_final_dmg_multiplier_ret = NULL;

		
		$attack_get_final_dmg_multiplier_ret =  Array();
			break; 
		}while(0);
		//======== End of contents from mod attack ========

		$skill477_get_final_dmg_multiplier_ret =  array_merge($r,$attack_get_final_dmg_multiplier_ret);
			break; 
		}while(0);
		//======== End of contents from mod skill477 ========

$r = $__VAR_DUMP_VARS_skill485_r; 
		$skill485_get_final_dmg_multiplier_ret =  array_merge($r,$skill477_get_final_dmg_multiplier_ret);
			break; 
		}while(0);
		//======== End of contents from mod skill485 ========

$r = $__VAR_DUMP_VARS_skill520_r; 
		$skill520_get_final_dmg_multiplier_ret =  array_merge($r,$skill485_get_final_dmg_multiplier_ret);
			break; 
		}while(0);
		//======== End of contents from mod skill520 ========

$r = $__VAR_DUMP_VARS_skill453_r; 
		$skill453_get_final_dmg_multiplier_ret =  array_merge($r,$skill520_get_final_dmg_multiplier_ret);
			break; 
		}while(0);
		//======== End of contents from mod skill453 ========

$r = $__VAR_DUMP_VARS_skill456_r; 
		$skill456_get_final_dmg_multiplier_ret =  array_merge($r,$skill453_get_final_dmg_multiplier_ret);
			break; 
		}while(0);
		//======== End of contents from mod skill456 ========

$r = $__VAR_DUMP_VARS_skill462_r; 
		$skill462_get_final_dmg_multiplier_ret =  array_merge($r,$skill456_get_final_dmg_multiplier_ret);
			break; 
		}while(0);
		//======== End of contents from mod skill462 ========

$r = $__VAR_DUMP_VARS_skill83_r; 
		$skill83_get_final_dmg_multiplier_ret =  array_merge($r,$skill462_get_final_dmg_multiplier_ret);
			break; 
		}while(0);
		//======== End of contents from mod skill83 ========

$r = $__VAR_DUMP_VARS_skill62_r; $x = $__VAR_DUMP_VARS_skill62_x; 
		$skill62_get_final_dmg_multiplier_ret =  array_merge($r,$skill83_get_final_dmg_multiplier_ret);
			break; 
		}while(0);
		//======== End of contents from mod skill62 ========

$r = $__VAR_DUMP_VARS_skill63_r; 
		$skill63_get_final_dmg_multiplier_ret =  array_merge($r,$skill62_get_final_dmg_multiplier_ret);
			break; 
		}while(0);
		//======== End of contents from mod skill63 ========

$r = $__VAR_DUMP_VARS_skill74_r; $x = $__VAR_DUMP_VARS_skill74_x; 
		$skill74_get_final_dmg_multiplier_ret =  array_merge($r,$skill63_get_final_dmg_multiplier_ret);
			break; 
		}while(0);
		//======== End of contents from mod skill74 ========

$r = $__VAR_DUMP_VARS_skill405_r; 
		$skill405_get_final_dmg_multiplier_ret =  array_merge($r,$skill74_get_final_dmg_multiplier_ret);
			break; 
		}while(0);
		//======== End of contents from mod skill405 ========

$r = $__VAR_DUMP_VARS_skill406_r; 
		$skill406_get_final_dmg_multiplier_ret =  array_merge($r,$skill405_get_final_dmg_multiplier_ret);
			break; 
		}while(0);
		//======== End of contents from mod skill406 ========

$r = $__VAR_DUMP_VARS_skill408_r; 
		$skill408_get_final_dmg_multiplier_ret =  array_merge($r,$skill406_get_final_dmg_multiplier_ret);
			break; 
		}while(0);
		//======== End of contents from mod skill408 ========

$r = $__VAR_DUMP_VARS_skill409_r; 
		$skill409_get_final_dmg_multiplier_ret =  array_merge($r,$skill408_get_final_dmg_multiplier_ret);
			break; 
		}while(0);
		//======== End of contents from mod skill409 ========

$r = $__VAR_DUMP_VARS_skill416_r; 
		$skill416_get_final_dmg_multiplier_ret =  array_merge($r,$skill409_get_final_dmg_multiplier_ret);
			break; 
		}while(0);
		//======== End of contents from mod skill416 ========

$r = $__VAR_DUMP_VARS_skill419_r; 
		$skill419_get_final_dmg_multiplier_ret =  array_merge($r,$skill416_get_final_dmg_multiplier_ret);
			break; 
		}while(0);
		//======== End of contents from mod skill419 ========

$r = $__VAR_DUMP_VARS_skill438_r; 
		$skill438_get_final_dmg_multiplier_ret =  array_merge($r,$skill419_get_final_dmg_multiplier_ret);
			break; 
		}while(0);
		//======== End of contents from mod skill438 ========

$r = $__VAR_DUMP_VARS_skill439_r; 
		$skill439_get_final_dmg_multiplier_ret =  array_merge($r,$skill438_get_final_dmg_multiplier_ret);
			break; 
		}while(0);
		//======== End of contents from mod skill439 ========

$r = $__VAR_DUMP_VARS_skill449_r; 
		$skill449_get_final_dmg_multiplier_ret =  array_merge($r,$skill439_get_final_dmg_multiplier_ret);
			break; 
		}while(0);
		//======== End of contents from mod skill449 ========

$r = $__VAR_DUMP_VARS_skill450_r; 
		$skill450_get_final_dmg_multiplier_ret =  array_merge($r,$skill449_get_final_dmg_multiplier_ret);
			break; 
		}while(0);
		//======== End of contents from mod skill450 ========

$r = $__VAR_DUMP_VARS_skill470_r; 
		$skill470_get_final_dmg_multiplier_ret =  array_merge($r,$skill450_get_final_dmg_multiplier_ret);
			break; 
		}while(0);
		//======== End of contents from mod skill470 ========

$r = $__VAR_DUMP_VARS_skill476_r; 
		$skill476_get_final_dmg_multiplier_ret =  array_merge($r,$skill470_get_final_dmg_multiplier_ret);
			break; 
		}while(0);
		//======== End of contents from mod skill476 ========

$r = $__VAR_DUMP_VARS_skill515_r; 
		$skill515_get_final_dmg_multiplier_ret =  array_merge($r,$skill476_get_final_dmg_multiplier_ret);
			break; 
		}while(0);
		//======== End of contents from mod skill515 ========

$r = $__VAR_DUMP_VARS_skill223_r; 
		$skill223_get_final_dmg_multiplier_ret =  array_merge($r,$skill515_get_final_dmg_multiplier_ret);
			break; 
		}while(0);
		//======== End of contents from mod skill223 ========

$r = $__VAR_DUMP_VARS_skill202_r; 
		$skill202_get_final_dmg_multiplier_ret =  array_merge($r,$skill223_get_final_dmg_multiplier_ret);
			break; 
		}while(0);
		//======== End of contents from mod skill202 ========

$r = $__VAR_DUMP_VARS_skill444_r; 
		$skill444_get_final_dmg_multiplier_ret =  array_merge($r,$skill202_get_final_dmg_multiplier_ret);
			break; 
		}while(0);
		//======== End of contents from mod skill444 ========

$r = $__VAR_DUMP_VARS_skill218_r; 
		$skill218_get_final_dmg_multiplier_ret =  array_merge($r,$skill444_get_final_dmg_multiplier_ret);
			break; 
		}while(0);
		//======== End of contents from mod skill218 ========

$r = $__VAR_DUMP_VARS_skill210_r; 
		$skill210_get_final_dmg_multiplier_ret =  array_merge($r,$skill218_get_final_dmg_multiplier_ret);
			break; 
		}while(0);
		//======== End of contents from mod skill210 ========

$r = $__VAR_DUMP_VARS_skill208_r; 
		$skill208_get_final_dmg_multiplier_ret =  array_merge($r,$skill210_get_final_dmg_multiplier_ret);
			break; 
		}while(0);
		//======== End of contents from mod skill208 ========

$r = $__VAR_DUMP_VARS_skill507_r; 
		$skill507_get_final_dmg_multiplier_ret =  array_merge($r,$skill208_get_final_dmg_multiplier_ret);
			break; 
		}while(0);
		//======== End of contents from mod skill507 ========

$r = $__VAR_DUMP_VARS_skill228_r; 
		$skill228_get_final_dmg_multiplier_ret =  array_merge($r,$skill507_get_final_dmg_multiplier_ret);
			break; 
		}while(0);
		//======== End of contents from mod skill228 ========

$r = $__VAR_DUMP_VARS_skill1004_r; 		
		return array_merge($r,$skill228_get_final_dmg_multiplier_ret);
	
	}
}

?>