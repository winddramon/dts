<?php

namespace skill1004
{
	$skill1004_title=array('无限制', '简单', '通常', '困难', '疯狂');
	
	$skill1004_dmg_factor_a_pc=array(1, 0.5, 1, 0.8, 0.5);
	$skill1004_dmg_factor_d_pc=array(1, 0.2, 1, 1.5, 2);
	$skill1004_dmg_factor_a_npc=array(1, 2, 1, 0.8, 0.5);
	$skill1004_dmg_factor_d_npc=array(1, 1, 1, 1.2, 2);
}

?>