<?php
namespace skill1005
{
$goal1005=array(
'智慧果',
'智慧果',
'智慧果',
);
}
?>
