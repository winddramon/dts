<?php

namespace gtype1
{
	$npcinfo_gtype1 = array
		( 
		1 => array
			(
			'mode' => 3,
			'num' => 0,
			'pass' => 'bra',
			'club' => 0,
			'bid' => 0,
			'inf' => '',
			'rage' => 0,
			'pose'=> 2,
			'skills'=>array('401'=>'3','400'=>'6','459'=>'0','461'=>'1','462'=>'0'),
			'tactic' => 3,
			'killnum' => 0,
			'teamID' => '',
			'teamPass' => '',
			'gd' => 'f',
			'pls' => 0,
			'mhp' => 7500,
			'msp' => 4000,
			'att' => 750,
			'def' => 750,
			'lvl' => 75,
			'skill' => 1111,
			'money' => 9999,
			'arb' => '奥术盔甲B - 炎',
			'arbk' => 'DB',
			'arbe' => 3000,
			'arbs' => 3000,
			'arbsk' => 'Ab',
			'arh' => '奥术盔甲H - 炎',
			'arhk' => 'DH',
			'arhe' => 1444,
			'arhs' => 3000,
			'arf' => '奥术盔甲F - 炎',
			'arfk' => 'DF',
			'arfe' => 1444,
			'arfs' => 3000,
			'ara' => '奥术盔甲A - 炎',
			'arak' => 'DA',
			'arae' => 1444,
			'aras' => 3000,
			'arask' => '',
			'art' => '龙虎旗帜',
			'artk' => 'A',
			'arte' => 1000,
			'arts' => 1000,
			'artsk' => 'H',
			'sub' => array
			(
				0 => array
				(
				'name' => '红暮 DUMMY',
				'icon' => 7,
				'wep' => '燃素加农炮『爆炎』MK-II',
				'wepk' => 'WG',
				'wepe' => 1280,
				'weps' => 999,
				'wepsk' => 'rfn',
				'itm1' => '挑战者之印',
				'itmk1' => 'Y',
				'itme1' => 1,
				'itms1' => 1,
				'itm2' => '黑色碎片',
				'itmk2' => 'WK',
				'itme2' => 10,
				'itms2' => '∞',
				'itmsk2' => 'j',
				'itm3' => '不要按这个按钮',
				'itmk3' => 'Y',
				'itme3' => 1,
				'itms3' => 1,
				'description' => '红杀将军 红暮，坐镇于无月之影的BOSS，达成锁定解除结局所必须击杀的NPC。 <span class="linen b">"红暮真可爱呀！"</span>',
				),
			),
		),
		2 => array
		(
		'mode' => 2,
		'num' => 0,
		'pass' => 'bra',
		'club' => 0,
		'bid' => 0,
		'inf' => '',
		'rage' => 0,
		'pose'=> 0,
		'tactic' => 0,
		'killnum' => 0,
		'teamID' => '',
		'teampass' => '',
		'pls' => 99,
		'mhp' => 2800,
		'msp' => 200,
		'att' => 250,
		'def' => 350,
		'lvl' => 25,
		'skill' => 135,
		'money' => 1600,
		'arb' => 'SSS战队校服',
		'arbk' => 'DB',
		'arbe' => 150,
		'arbs' => 100,
		'arh' => '鼓舞士气的头带',
		'arhk' => 'DH',
		'arhe' => 75,
		'arhs' => 100,
		'arf' => '橙黄学生鞋',
		'arfk' => 'DF',
		'arfe' => 75,
		'arfs' => 100,
		'ara' => '广播装置手表α',
		'arak' => 'DA',
		'arae' => 75,
		'aras' => 100,
		'art' => 'ACFUN的账号',
		'artk' => 'A',
		'arte' => 20,
		'arts' => 10,




		'sub' => array
			(
			0 => array
			  (
			'name' => '水濑 名雪-改',
			'icon' => 11,
			'gd' => 'f',
			'mss' => 50,
			'wep' => '大型闹钟',
			'wepk' => 'WP',
			'wepe' => 75,
			'weps' => 200,
			'itm1' => '雪兔【复制品】',
			'itmk1' => 'WD',
			'itme1' => 270,
			'itms1' => 300,
			'itmsk1' => 'id',
			'itm2' => '水濑 名雪的半身像',
			'itmk2' => 'WP',
			'itme2' => 33,
			'itms2' => 2,
			'itmsk2' => 'r',
			'itm3' => '草莓圣代',
			'itmk3' => 'HB',
			'itme3' => 270,
			'itms3' => 15,
			'description' => '全息幻象 水濑 名雪-改，掉落优秀的爆系武器和命体回复品。',
			),
		1 => array
			(
			'name' => '立华 奏-改',
			'icon' => 12,
			'gd' => 'f',
			'mss' => 50,
			'wep' => 'GS【伪Hand_Sonic】',
			'wepk' => 'WK',
			'wepe' => 75,
			'weps' => 200,
			'itm1' => 'GS【HandSonic Ver.4】',
			'itmk1' => 'WP',
			'itme1' => 300,
			'itms1' => 300,
			'itmsk1' => 'ZN',
			'itm2' => '立华 奏的半身像',
			'itmk2' => 'WP',
			'itme2' => 33,
			'itms2' => 2,
			'itmsk2' => 'r',
			'itm3' => 'Angel Player',
			'itmk3' => 'HM',
			'itme3' => 30,
			'itms3' => 1,
			'itm4' => 'GS【HandSonic Ver.2】',
			'itmk4' => 'WK',
			'itme4' => 200,
			'itms4' => 300,
			'itmsk4' => 'kj',
			'description' => '全息幻象 立华 奏-改，掉落优秀的殴系武器、斩系武器（可以变为原DN刀）和歌魂增加道具。',
			),
		2 => array
			(
			'name' => '思念体-海马 濑人',
			'icon' => 13,
			'gd' => 'm',
			'wep' => '【逆转的女神】',
			'wepk' => 'WC',
			'wepe' => 150,
			'weps' => 200,
			'itm1' => '游戏王卡包',
			'itmk1' => 'ygo',
			'itme1' => 1,
			'itms1' => 7,
			'itm2' => '传说的白磨刀石',
			'itmk2' => 'Y',
			'itme2' => 45,
			'itms2' => 8,
			'itm3' => '次世代数据网络决斗盘',
			'itmk3' => 'DA',
			'itme3' => 100,
			'itms3' => 100,
			'itmsk3' => 'MH',
			'description' => '全息幻象 思念体-海马 濑人，掉落游戏王卡包、强效的磨刀石以及带HP制御属性的手臂防具。',
			),
		3 => array
			(
			'name' => '思念体-触手众',
			'icon' => 14,
			'gd' => 'm',
			'wep' => '触手的力量',
			'wepk' => 'WG',
			'wepe' => 75,
			'weps' => 200,
			'itm1' => '妖精的羽翼',
			'itmk1' => 'A',
			'itme1' => 1,
			'itms1' => 1,
			'itmsk1' => 'q',
			'itm2' => '艾莲娜的圣钉',
			'itmk2' => 'Y',
			'itme2' => 40,
			'itms2' => 10,
			'itm3' => '斗技【神砂风暴】',
			'itmk3' => 'WF',
			'itme3' => 340,
			'itms3' => 300,
			'itm4' => '食堂的盒饭',
			'itmk4' => 'PR2',
			'itme4' => 50,
			'itms4' => 5,
			'description' => '全息幻象 思念体-触手众，掉落优秀的灵系武器、强效的钉子、怒气回复道具以及具有补给净化功能的饰品。',
			),
		),
	),
	
		
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
			5 => array
			(
			'mode' => 2,
			'num' => 0,
			'pass' => 'bra',
			'bid' => 0,
			'inf' => '',
			'rage' => 0,
			'pose'=> 1,
			'tactic' => 3,
			'killnum' => 0,
			
			
			'teamID' => '',
			'teamPass' => '',
			'pls' => 99,
			'mhp' => 3333,
			'msp' => 333,
			'att' => 333,
			'def' => 333,
			'lvl' => 33,
			'skill' => 233,
			'money' => 3333,
			'arb' => '杏仁豆腐模样的以太结晶',
			'arbk' => 'DB',
			'arbe' => 333,
			'arbs' => 333,
			'arbsk' => 'A',
			'arh' => '杏仁豆腐模样的狙击镜片',
			'arhk' => 'DH',
			'arhe' => 333,
			'arhs' => 333,
			'arhsk' => 'cW',
			'arf' => '杏仁豆腐模样的长筒靴',
			'arfk' => 'DF',
			'arfe' => 333,
			'arfs' => 333,
			'arfsk' => 'qE',
			'ara' => '杏仁豆腐模样的童话伪翼',
			'arak' => 'DA',
			'arae' => 333,
			'aras' => 333,
			'arask' => 'UI',
			'art' => '杏仁豆腐模样的HP制御系统',
			'artk' => 'A',
			'arte' => 333,
			'arts' => 333,
			'artsk' => 'H',
			'itm1' => '杏仁豆腐的ID卡',
			'itmk1' => 'Z',
			'itme1' => 1,
			'itms1' => 1,
	
	
	
	
			'sub' => array
			(
			0 => array
				(
				'name' => '冴月 麟',
				'icon' => 3,
				'gd' => 'f',
				'club' => 9,
				'mss' => 30,
				'wep' => '简称为UCW的杏仁豆腐',
				'wepk' => 'WK',
				'wepe' => 133,
				'weps' => 333,
				'wepsk' => 'dr',
				'itm2' => '《红魔乡设定废案》',
				'itmk2' => 'VS',
				'itme2' => 1,
				'itms2' => 1,
				'itmsk2' => '246',
				'itm3' => '《ぼくのフレンド》',
				'itmk3' => 'ss',
				'itme3' => 110,
				'itms3' => 1,
				'itmsk3' => '',
				'description' => '杏仁豆腐 冴月 麟，对玩家有较大威胁，掉落启动死斗模式的钥匙和一本隐形技能书。',
				),
			1 => array
				(
				'name' => '某四面',
				'icon' => 4,
				'gd' => 'm',
				'club' => 8,
				'wep' => '深生态杏仁豆腐',
				'wepk' => 'WD',
				'wepe' => 100,
				'weps' => 333,
				'wepsk' => 'drp',
				'itm2' => '安雅人体冰雕',
				'itmk2' => 'Y',
				'itme2' => 1,
				'itms2' => 1,
				'itmsk2' => '',
				'description' => '杏仁豆腐 某四面，对玩家有较大威胁，掉落启动死斗模式的钥匙和武器师安雅的奖赏的素材。',
				),
			),
		),
		
		6 => array
			(
			'mode' => 2,
			'num' => 0,
			'pass' => 'bra',
			'club' => 0,
			'bid' => 0,
			'inf' => '',
			'rage' => 0,
			'pose'=> 4,
			'tactic' => 3,
			'skills'=>array('461'=>'1'),
			'killnum' => 0,
			'teamID' => '',
			'teamPass' => '',
			'gd' => 'r',
			'pls' => 99,
			'mhp' => 8888,
			'msp' => 400,
			'att' => 400,
			'def' => 777,
			'lvl' => 45,
			'skill' => 477,
			'money' => 17777,
			'arb' => '【属性防御装甲】',
			'arbk' => 'DB',
			'arbe' => 480,
			'arbs' => 200,
			'arbsk' => 'a',
			'arh' => '【冲击防御头盔】',
			'arhk' => 'DH',
			'arhe' => 360,
			'arhs' => 200,
			'arhsk' => 'A',
			'arf' => '【数据护膝】',
			'arfk' => 'DF',
			'arfe' => 360,
			'arfs' => 200,
			'arfsk' => 'R',
			'ara' => '【陷阱拦截护盾】',
			'arak' => 'DA',
			'arae' => 360,
			'aras' => 200,
			'arask' => 'm',
			'art' => '【ACFUN的荣耀】',
			'artk' => 'Ag',
			'arte' => 5000,
			'arts' => 500,
			'artsk' => 'H',
	
	
	
	
			'sub' => array
			(
				0 => array
				(
				'name' => 'Acg_Xilin',
				'icon' => 'avatar_rek/xilin.png',
				'mss' => 100,
				'wep' => '【全屏幕弹幕发射】',
				'wepk' => 'WG',
				'wepe' => 360,
				'weps' => 600,
				'wepsk' => 'rew',
				'itm1' => '■DeathNote■',
				'itmk1' => 'Y',
				'itme1' => 1,
				'itms1' => 1,
				'itm2' => 'TDG压片猴',
				'itmk2' => 'Y',
				'itme2' => 1,
				'itms2' => 1,
				'description' => '黑幕 Acg_Xilin，对玩家具有很大威胁，如果防御值没有达到2000最好不要惹他（她）。掉落可以杀死任意一名玩家的道具“死亡笔记”，和大量的金钱。',
				),
			),
		),
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
		
		9 => array
			(
			'mode' => 3,
			'num' => 0,
			'pass' => 'bra',
			'club' => 17,
			'bid' => 0,
			'inf' => '',
			'rage' => 0,
			'pose'=> 1,
			'tactic' => 3,
			'killnum' => 99,
			'teamID' => '',
			'teamPass' => '',
			'gd' => 'f',
			'pls' => 26,
			'mhp' => 10000000,
			'msp' => 4000,
			'att' => 200000,
			'def' => 4000,
			'lvl' => 97,
			'skill' => 2400,
			'money' => 1,
			'arb' => '奥术盔甲B - 霜',
			'arbk' => 'DB',
			'arbe' => 6000,
			'arbs' => 400,
			'arbsk' => 'Aa',
			'arh' => '奥术盔甲H - 霜',
			'arhk' => 'DH',
			'arhe' => 4000,
			'arhs' => 300,
			'arf' => '奥术盔甲F - 霜',
			'arfk' => 'DF',
			'arfe' => 4000,
			'arfs' => 300,
			'ara' => '奥术盔甲A - 霜',
			'arak' => 'DA',
			'arae' => 4000,
			'aras' => 300,
			'art' => '龙虎徽标',
			'artk' => 'A',
			'arte' => 200,
			'arts' => 300,
			'artsk' => 'Hc',
			'sub' => array
			(
				0 => array
				(
				'name' => '蓝凝 DUMMY',
				'mss' => 40,
				'skills' => array('406'=>'0','432'=>'0','459'=>'0','461'=>'1'),
				'icon' => 52,
				'wep' => '『AZURE RONDO』',
				'wepk' => 'WKF',
				'wepe' => 2000,
				'weps' => 360,
				'wepsk' => 'rkd',
				'itm1' => '挑战者之证',
				'itmk1' => 'Y',
				'itme1' => 1,
				'itms1' => 1,
				'itm2' => '琉璃血',
				'itmk2' => 'Y',
				'itme2' => 1,
				'itms2' => 1,
				'itm3' => '好想按这个按钮',
				'itmk3' => 'Y',
				'itme3' => 1,
				'itms3' => 1,
				'description' => '坐镇于冰封墓场的NPC，几乎无敌的存在。<span class="yellow b">没事还是不要惹她好了……</span>',
				),
			),
		),
		
		
		
		11 => array
			(
			'mode' => 1,
			'num' => 0,
			'pass' => 'bra',
			'club' => 0,
			'bid' => 0,
			'inf' => '',
			'rage' => 88,
			'pose'=> 1,
			'tactic' => 3,
			'killnum' => 0,
			'teamID' => '',
			'teamPass' => '',
			'gd' => 'r',
			'pls' => 99,
			'mhp' => 2888,
			'msp' => 888,
			'att' => 88,
			'def' => 88,
			'lvl' => 30,
			'skill' => 100,
			'money' => 888,
			'arb' => '职人的佩服',
			'arbk' => 'DB',
			'arbe' => 888,
			'arbs' => 888,
			'arbsk' => 'a',
			'arh' => '职人的搞头',
			'arhk' => 'DH',
			'arhe' => 888,
			'arhs' => 888,
			'arhsk' => 'DF',
			'arf' => '职人的满足',
			'arfk' => 'DF',
			'arfe' => 888,
			'arfs' => 888,
			'ara' => '职人的拿手',
			'arak' => 'DA',
			'arae' => 888,
			'aras' => 888,
			'arask' => 'H',
			'art' => '职人的荣耀',
			'artk' => 'A',
			'arte' => 888,
			'arts' => 888,
			'artsk' => 'c',
	
	
	
	
			'sub' => array
			(
				0 => array
				(
				'name' => 'Hank',
				'icon' => 91,
				'mss' => 100,
				'wep' => '『性感玉米』',
				'wepk' => 'WD',
				'wepe' => 88,
				'weps' => 888,
				'wepsk' => 'ewuip',
				'itm1' => '我打败HANK了！',
				'itmk1' => 'Z',
				'itme1' => 1,
				'itms1' => 1,
				'description' => '真职人 Hank，使用带有全属性的爆系武器，掉落极优秀的防具。',
				),
				
				1 => array
				(
				'name' => '爱情上甘岭',
				'icon' => 92,
				'mss' => 100,
				'wep' => '『阿里嘎头哦～』',
				'wepk' => 'WK',
				'wepe' => 88,
				'weps' => 888,
				'wepsk' => 'ewuip',
				'itm1' => '我成功TDGSGL了！',
				'itmk1' => 'Z',
				'itme1' => 1,
				'itms1' => 1,
				'description' => '真职人 爱情上甘岭，使用带有全属性的斩系武器，掉落极优秀的防具。',
				),
				
				2 => array
				(
				'name' => '221',
				'icon' => 94,
				'mss' => 100,
				'wep' => '『和谐你全家』',
				'wepk' => 'WP',
				'wepe' => 88,
				'weps' => 888,
				'wepsk' => 'uiewp',
				'arb' => '神之装束',
				'arbk' => 'DB',
				'arbe' => 888,
				'arbs' => 888,
				'arbsk' => 'a',
				'arh' => '神之远见',
				'arhk' => 'DH',
				'arhe' => 888,
				'arhs' => 888,
				'arhsk' => 'DF',
				'arf' => '神之步伐',
				'arfk' => 'DF',
				'arfe' => 888,
				'arfs' => 888,
				'ara' => '神之操控',
				'arak' => 'DA',
				'arae' => 888,
				'aras' => 888,
				'arask' => 'H',
				'art' => '神之荣耀',
				'artk' => 'A',
				'arte' => 888,
				'arts' => 888,
				'artsk' => 'c',
				'itm1' => '荼荼丸的茶',
				'itmk1' => 'Z',
				'itme1' => 1,
				'itms1' => 1,
				'description' => '真职人 221，使用带有全属性的殴系武器，掉落极优秀的防具。',
				
				),
				3 => array
				(
				'name' => 'Erul Tron',
				'icon' => 93,
				'club' => 0,
				'mss' => 70,
				'wep' => '『罗德不列颠号』',
				'wepk' => 'WC',
				'wepe' => 88,
				'weps' => 888,
				'wepsk' => 'uiewp',
				'arb' => '少女的泳衣',
				'arbk' => 'DB',
				'arbe' => 888,
				'arbs' => 888,
				'arbsk' => 'a',
				'arh' => '少女的单马尾',
				'arhk' => 'DH',
				'arhe' => 888,
				'arhs' => 888,
				'arhsk' => 'DF',
				'arf' => '少女的高筒靴',
				'arfk' => 'DF',
				'arfe' => 888,
				'arfs' => 888,
				'ara' => '少女的绒边手套',
				'arak' => 'DA',
				'arae' => 888,
				'aras' => 888,
				'arask' => 'H',
				'art' => '少女的星星眼',
				'artk' => 'A',
				'arte' => 888,
				'arts' => 888,
				'artsk' => 'c',
				'itm1' => '罗德不列颠号舰长钥匙',
				'itmk1' => 'Z',
				'itme1' => 1,
				'itms1' => 1,
				'description' => '真职人 Erul Tron，使用带有全属性的射系武器，掉落极优秀的防具。',
				),
				
				4 => array
				(
				'name' => '亚玛丽欧·维拉蒂安',
				'icon' => 95,
				'club' => 0,
				'mss' => 50,
				'wep' => '负人气的光环',
				'wepk' => 'WP',
				'wepe' => 88,
				'weps' => 888,
				'wepsk' => 'uiewp',
				'arb' => '阿婆主的点击量',
				'arbk' => 'DB',
				'arbe' => 888,
				'arbs' => 888,
				'arbsk' => 'a',
				'arh' => '阿婆主的点击量',
				'arhk' => 'DH',
				'arhe' => 888,
				'arhs' => 888,
				'arhsk' => 'DF',
				'arf' => '阿婆主的点击量',
				'arfk' => 'DF',
				'arfe' => 888,
				'arfs' => 888,
				'ara' => '阿婆主的点击量',
				'arak' => 'DA',
				'arae' => 888,
				'aras' => 888,
				'arask' => 'H',
				'art' => '阿婆主的点击量',
				'artk' => 'A',
				'arte' => 888,
				'arts' => 888,
				'artsk' => 'c',
				'itm1' => '点击量终于爆表了！',
				'itmk1' => 'Z',
				'itme1' => 1,
				'itms1' => 1,
				'itm2' => '负人品的结界',
				'itmk2' => 'WG',
				'itme2' => 88,
				'itms2' => 88,
				'itmsk2' => 'kN',
				'description' => '真职人 亚玛丽欧·维拉蒂安，使用带有全属性的殴系武器，掉落极优秀的防具。',
				),
				
				5 => array
				(
				'name' => '便当盒',
				'icon' => 100,
				'gd' => 'f',
				'club' => 17,
				'lvl' => 1,
				'mhp' => 8888888,
				'skills'=>array('401'=>'5','461'=>'1'),
				'skill' => 20,
				'def' => 88888,
				'wep' => '灭罪「正直者の死」',
				'wepk' => 'WF',
				'wepe' => 8,
				'weps' => 888,
				'wepsk' => 'r',
				'arb' => '吉祥物',
				'arbk' => 'DB',
				'arbe' => 1,
				'arbs' => 10000,
				'arbsk' => 'Aa',
				'arh' => '吉祥物',
				'arhk' => 'DH',
				'arhe' => 1,
				'arhs' => 10000,
				'arhsk' => '',
				'arf' => '吉祥物',
				'arfk' => 'DF',
				'arfe' => 1,
				'arfs' => 10000,
				'ara' => '吉祥物',
				'arak' => 'DA',
				'arae' => 1,
				'aras' => 10000,
				'arask' => '',
				'art' => '姬露瑞希的爱心便当',
				'artk' => 'A',
				'arte' => 1,
				'arts' => 1,
				'artsk' => 'Bb',
				'description' => '真职人 便当盒，ACFUN大逃杀吉祥物，卖萌的存在，拥有888万点HP和双抹消饰品，几乎无法杀死。',
				),
				
				6 => array
				(
				'name' => 'KHIBIKI《黑曲》',
				'mode'=>'3',
				'gd' => 'f',
				'icon' => 113,
				'mss' => 30,
				'club' => 17,
				'lvl' => 1,
				'mhp' => 6666666,
				'skills'=>array('415'=>'1','461'=>'1'),
				'skill' => 20,
				'def' => 20,
				'wep' => '武裝幻想『DAYDREAM』',
				'wepk' => 'WG',
				'wepe' => 8,
				'weps' => 888,
				'wepsk' => 'r',
				'arb' => '【純黑色的連帽型外套】',
				'arbk' => 'DB',
				'arbe' => 1,
				'arbs' => 10000,
				'arbsk' => 'Aa',
				'arh' => '【純黑色的耳罩式耳機】',
				'arhk' => 'DH',
				'arhe' => 1,
				'arhs' => 10000,
				'arhsk' => '',
				'arf' => '【純黑色的皮製型長靴】',
				'arfk' => 'DF',
				'arfe' => 1,
				'arfs' => 10000,
				'ara' => '【純黑色的電子式繪筆】',
				'arak' => 'DA',
				'arae' => 1,
				'aras' => 10000,
				'arask' => '',
				'art' => '黑色終曲『HONOUR』',
				'artk' => 'A',
				'arte' => 1,
				'arts' => 1,
				'artsk' => 'Zz',
				'description' => '真职人 黑色夺魂曲，ACFUN大逃杀吉祥物，卖萌的存在，似乎很难对其造成伤害。',
				),
			),
		),
		
		13 => array
			(
			'mode' => 1,
			'num' => 0,
			'pass' => 'bra',
			'club' => 98,
			'bid' => 0,
			'inf' => '',
			'rage' => 174,
			'pose'=> 4,
			'tactic' => 3,
			'killnum' => 99,
			'teamID' => '循环',
			'teamPass' => 'L1g2t2D2k',
			'gd' => 'f',
			'pls' => 26,
			'mhp' => 28800,
			'msp' => 400,
			'att' => 1600,
			'def' => 600,
			'lvl' => 60,
			'skill' => 625,
			'money' => 8000,
			'arb' => '希-玻粒子固化装甲',
			'arbk' => 'DB',
			'arbe' => 10,
			'arbs' => 500,
			'arbsk' => 'B',
			'arh' => '知觉增幅设备',
			'arhk' => 'DH',
			'arhe' => 64,
			'arhs' => 500,
			'arhsk' => 'Hc',
			'arf' => '空间扰动场',
			'arfk' => 'DF',
			'arfe' => 1500,
			'arfs' => 500,
			'arfsk' => 'a',
			'ara' => '破旧的长袍',
			'arak' => 'DA',
			'arae' => 4,
			'aras' => 800,
			'art' => '循环的预示',
			'artk' => 'A',
			'arte' => 1,
			'arts' => 1,
			'artsk' => 'M',
			'sub' => array
			(
				0 => array
				(
				'name' => '卡玛·克莱因',
				'icon' => 9,
				'wep' => '巴鲁康宁MK-III',
				'wepk' => 'WG',
				'wepe' => 1600,
				'weps' => 5000,
				'wepsk' => 'rdo',
				'itm1' => '凛剑·银槲之剑',
				'itmk1' => 'WK',
				'itme1' => 2800,
				'itms1' => 180,
				'itmsk1' => 'k',
				'itm2' => '焰剑·永恒终焉',
				'itmk2' => 'WK',
				'itme2' => 2800,
				'itms2' => 180,
				'itmsk2' => 'f',
				'itm3' => '奇怪的按钮',
				'itmk3' => 'Y',
				'itme3' => 1,
				'itms3' => 1,
				),
			),
		),
		
		14 => array(
		'mode' => 1,
		'num' => 0,
		'pass' => 'bra',
		'club' => 99,
		'bid' => 0,
		'inf' => '',
		'state' => 1,
		'rage' => 5,
		'pose'=> 0,
		'tactic' => 0,
		'killnum' => 0,
		'teamID' => '',
		'teamPass' => '',
		'gd' => 'f',
		'pls' => 99,
		'mhp' => 2800,
		'msp' => 400,
		'att' => 75,
		'def' => 75,
		'lvl' => 20,
		'skill' => 25,
		'money' => 3,
		'sub' => array
		(
			0 => array
			(
			'name' => '讲解员 梦美',
			'icon' => 61,
			'mss' => 50,
			'wep' => '垃圾花束',
			'wepk' => 'WP',
			'wepe' => 175,
			'weps' => 36,
			'wepsk' => 'c',
			'arb' => '接待员制服',
			'arbk' => 'DB',
			'arbe' => 75,
			'arbs' => 50,
			'arbsk' => 'a',
			'arh' => '橙色信号缎带',
			'arhk' => 'DH',
			'arhe' => 640,
			'arhs' => 50,
			'arf' => '蓝色信号缎带',
			'arfk' => 'DF',
			'arfe' => 640,
			'arfs' => 50,
			'ara' => '绿色信号缎带',
			'arak' => 'DA',
			'arae' => 640,
			'aras' => 50,
			'art' => '星空之愿',
			'artk' => 'A',
			'arte' => 1,
			'arts' => 1,
			'artsk' => 'H',
			'description' => '数据碎片 讲解员 梦美，<span class="yellow b">被击杀后会变身为攻击力极强的NPC</span>。',
			),
			1 => array
			(
			'name' => '喧哗少女 叶留佳',
			'icon' => 63,
			'mss' => 50,
			'wep' => '七色玻璃珠',
			'wepk' => 'WK',
			'wepe' => 160,
			'weps' => 36,
			'wepsk' => 'ec',
			'arb' => 'RF高校校服',
			'arbk' => 'DB',
			'arbe' => 75,
			'arbs' => 50,
			'arbsk' => 'a',
			'arh' => '粉红双球发饰',
			'arhk' => 'DH',
			'arhe' => 640,
			'arhs' => 50,
			'arf' => '女式皮鞋',
			'arfk' => 'DF',
			'arfe' => 640,
			'arfs' => 50,
			'ara' => '奇怪的袋子',
			'arak' => 'DA',
			'arae' => 640,
			'aras' => 50,
			'art' => '友情之愿',
			'artk' => 'A',
			'arte' => 1,
			'arts' => 1,
			'artsk' => 'H',
			'description' => '数据碎片 喧哗少女 叶留佳，<span class="yellow b">被击杀后会变身为攻击力极强的NPC</span>。',
			),
			2 => array
			(
			'name' => '风纪委员 静流',
			'icon' => 65,
			'mss' => 50,
			'wep' => '银白口哨',
			'wepk' => 'WF',
			'wepe' => 175,
			'weps' => 200,
			'wepsk' => 'c',
			'arb' => '风祭学院校服',
			'arbk' => 'DB',
			'arbe' => 75,
			'arbs' => 50,
			'arbsk' => '',
			'arh' => '白色眼罩',
			'arhk' => 'DH',
			'arhe' => 640,
			'arhs' => 50,
			'arf' => '女式运动鞋',
			'arfk' => 'DF',
			'arfe' => 640,
			'arfs' => 50,
			'ara' => 'Mp3播放器',
			'arak' => 'DA',
			'arae' => 640,
			'aras' => 50,
			'art' => '平和之愿',
			'artk' => 'A',
			'arte' => 1,
			'arts' => 1,
			'artsk' => 'H',
			'description' => '数据碎片 风纪委员 静流，<span class="yellow b">被击杀后会变身为攻击力极强的NPC</span>。',
			),
		),
	), 
	16 => array(
			'mode' => 3,
			'num' => 1,
			'pass' => 'bra',
			'club' => 21,
			'bid' => 0,
			'inf' => '',
			'rage' => 0,
			'pose'=> 1,
			'tactic' => 4,
			'skills'=>array('21'=>'1','489'=>'1'),
			'killnum' => 0,
			'teamID' => '',
			'teamPass' => '',
			'gd' => 'f',
			'pls' => 34,
			'mhp' => 400,
			'msp' => 400,
			'att' => 100,
			'def' => 1000,
			'lvl' => 0,
			'skill' => 0,
			'money' => 20,
			'arb' => '幻境浸入式连体服',
			'arbk' => 'DB',
			'arbe' => 20,
			'arbs' => 200,
			'arbsk' => 'H',
			'arh' => '模因增幅发饰',
			'arhk' => 'DH',
			'arhe' => 10,
			'arhs' => 200,
			'arf' => '逆格式塔冲浪靴',
			'arfk' => 'DF',
			'arfe' => 10,
			'arfs' => 200,
			'ara' => '弹出式无限导图',
			'arak' => 'DA',
			'arae' => 10,
			'aras' => 200,
			'arask' => '',
			'art' => '非图灵智能助手',
			'artk' => 'A',
			'arte' => 1,
			'arts' => 1,
			'artsk' => 'h',
			'sub' => array
			(
				0 => array
				(
				'name' => '薇娜·安妮茜',
				'icon' => 'avatar_rek/weena2.png',
				'mss' => 100,
				'wep' => '「乌托邦暴风」-劣',
				'wepk' => 'WF',
				'wepe' => 10,
				'weps' => 9000,
				'wepsk' => '',
				'itm1' => '技术总监的ID卡',
				'itmk1' => 'Z',
				'itme1' => 1,
				'itms1' => 1,
				'description' => '幻境技术总监 薇娜·安妮茜，只在除错模式登场的NPC，坐镇于英灵殿。虽然数值弱不禁风，但如她所说，击倒她是徒劳无功的。',
				),
			),
		),
	20 => array
		(
		'mode' => 2,
		'num' => 0,
		'pass' => 'gbauibg2',
		'club' => 0,
		'bid' => 0,
		'inf' => '',
		'rage' => 88,
		'pose'=> 1,
		'tactic' => 3,
		'killnum' => 0,
		'teamID' => '',
		'teamPass' => '',
		'gd' => 'r',
		'pls' => 34,
		'mhp' => 3000,
		'msp' => 400,
		'att' => 200,
		'def' => 200,
		'lvl' => 40,
		'skill' => 300,
		'money' => 800,
		'arb' => '英雄战甲B',
		'arbk' => 'DB',
		'arbe' => 1000,
		'arbs' => 300,
		'arbsk' => 'A',
		'arh' => '英雄战甲H',
		'arhk' => 'DH',
		'arhe' => 600,
		'arhs' => 300,
		'arhsk' => 'DF',
		'arf' => '英雄战甲F',
		'arfk' => 'DF',
		'arfe' => 500,
		'arfs' => 300,
		'arfsk' => 'a',
		'ara' => '英雄战甲A',
		'arak' => 'DA',
		'arae' => 600,
		'aras' => 300,
		'arask' => 'H',
		'art' => '英雄之力',
		'artk' => 'A',
		'arte' => 9,
		'arts' => 9,
		'artsk' => 'c',




		'sub' => array
		(
			0 => array
			(
			'name' => '霜火协奏曲',
			'icon' => 0,
			'club' => 6,
			'wep' => '『看吧，你的死兆星正在天上闪耀！』',
			'wepk' => 'WC',
			'wepe' => 333,
			'weps' => 600,
			'wepsk' => 'w',
			),
			1 => array
			(
			'name' => '脸骑士-菜包',
			'club' => 98,
			'icon' => 0,
			'wep' => '脸',
			'wepk' => 'WP',
			'wepe' => 300,
			'weps' => 600,
			'wepsk' => 'N',
			),
			2 => array
			(
			'name' => '枪毙的某神',
			'icon' => 0,
			'club' => 3,
			'wep' => '《小黄的时间球》',
			'wepk' => 'WC',
			'wepe' => 180,
			'weps' => 600,
			'wepsk' => 'r',
			),
			3 => array
			(
			'name' => '我是高达',
			'icon' => 0,
			'club' => 8,
			'wep' => '毒性凸眼鱼',
			'wepk' => 'WF',
			'wepe' => 200,
			'weps' => 600,
			'wepsk' => 'pd',
			),
			4 => array
			(
			'name' => '一旦接受这种设定',
			'icon' => 0,
			'club' => 10,
			'wep' => '『一瞬千击』',
			'wepk' => 'WP',
			'wepe' => 190,
			'weps' => 600,
			'wepsk' => 'r',
			),
			5 => array
			(
			'name' => '一方通行',
			'icon' => 0,
			'club' => 9,
			'wep' => '【矢量操作】',
			'wepk' => 'WG',
			'wepe' => 300,
			'weps' => 600,
			'wepsk' => 'N',
			),
			6 => array
			(
			'name' => '晓魂之歌',
			'icon' => 0,
			'club' => 2,
			'wep' => '锋利的电气毒性晓魂之歌-改[+4]',
			'wepk' => 'WK',
			'wepe' => 300,
			'weps' => 600,
			'wepsk' => 'pew',
			),
			7 => array
			(
			'name' => '卡',
			'icon' => 0,
			'club' => 13,
			'wep' => '【不屈的意志】',
			'wepk' => 'WF',
			'wepe' => 140,
			'weps' => 600,
			'wepsk' => 'r',
			),
			8 => array
			(
			'name' => 'Exocet',
			'icon' => 0,
			'club' => 9,
			'wep' => '『微型火箭加速噴射單輪車』',
			'wepk' => 'WP',
			'wepe' => 110,
			'weps' => 600,
			'wepsk' => 'ru',
			),
			9 => array
			(
			'name' => '中西醫',
			'icon' => 0,
			'club' => 1,
			'wep' => '《衷中參西錄》',
			'wepk' => 'WP',
			'wepe' => 250,
			'weps' => 600,
			'wepsk' => 'p',
			),
			10 => array
			(
			'name' => '黑猫',
			'icon' => 0,
			'club' => 6,
			'wep' => '阔剑地雷吸附器',
			'wepk' => 'WP',
			'wepe' => 400,
			'weps' => 600,
			'wepsk' => 'Mm',
			),
			11 => array
			(
			'name' => '水羊',
			'icon' => 0,
			'club' => 2,
			'wep' => '■Darthnote■',
			'wepk' => 'WK',
			'wepe' => 400,
			'weps' => 600,
			'wepsk' => 'c',
			),
			12 => array
			(
			'name' => '上帝的左手',
			'icon' => 0,
			'club' => 2,
			'wep' => '胡来的左手',
			'wepk' => 'WK',
			'wepe' => 270,
			'weps' => 600,
			'wepsk' => 'd',
			),
			13 => array
			(
			'name' => '半人半灵半吊子',
			'icon' => 0,
			'club' => 98,
			'wep' => '楼观剑',
			'wepk' => 'WK',
			'wepe' => 200,
			'weps' => 600,
			'wepsk' => 'd',
			'itm1' => '白楼剑',
			'itmk1' => 'WK',
			'itme1' => 130,
			'itms1' => 600,
			'itmsk1' => 'r',
			),
			14 => array
			(
			'name' => '死亡荆棘',
			'icon' => 0,
			'club' => 7,
			'wep' => '【荆棘式电子地雷】',
			'wepk' => 'WK',
			'wepe' => 210,
			'weps' => 600,
			'wepsk' => 'd',
			),
			15 => array
			(
			'name' => '超魔理沙-电子',
			'icon' => 0,
			'club' => 14,
			'wep' => '【荆棘式电子地雷】',
			'wepk' => 'WP',
			'wepe' => 240,
			'weps' => 600,
			'wepsk' => 'd',
			),
			16 => array
			(
			'name' => '东方地雷殿',
			'icon' => 0,
			'club' => 7,
			'wep' => '【荆棘式电子地雷】',
			'wepk' => 'WD',
			'wepe' => 210,
			'weps' => 600,
			'wepsk' => 'd',
			),
			17 => array
			(
			'name' => 'fossil',
			'icon' => 0,
			'club' => 1,
			'wep' => '大钉棍棒',
			'wepk' => 'WP',
			'wepe' => 250,
			'weps' => 600,
			'wepsk' => 'Nn',
			),
			18 => array
			(
			'name' => '流风之念',
			'icon' => 0,
			'club' => 4,
			'wep' => '连击烧输尿管~☆',
			'wepk' => 'WG',
			'wepe' => 150,
			'weps' => 600,
			'wepsk' => 'ru',
			),
			19 => array
			(
			'name' => 'MESSIAH',
			'icon' => 0,
			'club' => 4,
			'wep' => '本格的嘴炮',
			'wepk' => 'WG',
			'wepe' => 240,
			'weps' => 600,
			'wepsk' => 'd',
			),
			20 => array
			(
			'name' => '帕秋莉诺蕾姬',
			'icon' => 0,
			'club' => 9,
			'wep' => '水&火符「Phlogistic Rain」',
			'wepk' => 'WF',
			'wepe' => 260,
			'weps' => 600,
			'wepsk' => 'ui',
			),
			21 => array
			(
			'name' => '坂田铜时',
			'icon' => 0,
			'club' => 1,
			'wep' => '无毁的受王拳',
			'wepk' => 'WP',
			'wepe' => 380,
			'weps' => 600,
			),
			22 => array
			(
			'name' => '耶和华',
			'icon' => 0,
			'club' => 15,
			'wep' => 'L5爆发！',
			'wepk' => 'WF',
			'wepe' => 250,
			'weps' => 600,
			'wepsk' => 'd',
			),
			23 => array
			(
			'name' => '闹球肾',
			'icon' => 0,
			'club' => 1,
			'wep' => '一个半角符号',
			'wepk' => 'WF',
			'wepe' => 150,
			'weps' => 600,
			'wepsk' => 'rd',
			),
			24 => array
			(
			'name' => '初音ミク',
			'icon' => 0,
			'club' => 4,
			'wep' => '「Falchion Rider」模样的杏仁豆腐',
			'wepk' => 'WG',
			'wepe' => 190,
			'weps' => 600,
			'wepsk' => 'r',
			'arb' => '英雄战甲B模样的杏仁豆腐',
			'arh' => '英雄战甲H模样的杏仁豆腐',
			'arf' => '英雄战甲F模样的杏仁豆腐',
			'ara' => '英雄战甲A模样的杏仁豆腐',
			'art' => '英雄之力模样的杏仁豆腐',
			),
			25 => array
			(
			'name' => 'Abyss混沌',
			'icon' => 0,
			'club' => 1,
			'wep' => '混乱邪恶之塔',
			'wepk' => 'WF',
			'wepe' => 1,
			'weps' => 1,
			'wepsk' => 'r',
			),
			26 => array
			(
			'name' => '飞雪大大',
			'icon' => 0,
			'club' => 9,
			'wep' => '魔王の剑',
			'wepk' => 'WK',
			'wepe' => 300,
			'weps' => 300,
			'wepsk' => 'u',
			),
			27 => array
			(
			'name' => '微笑的疯子',
			'icon' => 0,
			'club' => 1,
			'wep' => '把妹の手',
			'wepk' => 'WP',
			'wepe' => 100,
			'weps' => 600,
			'wepsk' => 'Nnr',
			),
			28 => array
			(
			'name' => '挂机中的灰尘',
			'icon' => 0,
			'club' => 9,
			'wep' => '★挂机の萌力★',
			'wepk' => 'WF',
			'wepe' => 250,
			'weps' => 600,
			'wepsk' => 'ni',
			),
			29 => array
			(
			'name' => '西园寺世界酱',
			'icon' => 0,
			'club' => 5,
			'wep' => '节操炸弹G',
			'wepk' => 'WD',
			'wepe' => 300,
			'weps' => 600,
			'wepsk' => 'id',
			),
			30 => array
			(
			'name' => '索非亚小傻鸟',
			'icon' => 0,
			'club' => 8,
			'wep' => 'COCO☆酱',
			'wepk' => 'WC',
			'wepe' => 280,
			'weps' => 600,
			'wepsk' => 'lu',
			),
			31 => array
			(
			'name' => '浮云_小坏',
			'icon' => 0,
			'club' => 9,
			'wep' => '向日葵妖精',
			'wepk' => 'WG',
			'wepe' => 251,
			'weps' => 600,
			'wepsk' => 'ud',
			'itm1' => 'YES♂SIR',
			'itmk1' => 'Z',
			'itme1' => 1,
			'itms1' => 1,
			),
			32 => array
			(
			'name' => '人形蚂蚁α',
			'icon' => 0,
			'club' => 9,
			'wep' => '纸条■■■■',
			'wepk' => 'WC',
			'wepe' => 280,
			'weps' => 600,
			'wepsk' => 'Ne',
			),
			33 => array
			(
			'name' => 'tabris',
			'icon' => 0,
			'club' => 13,
			'wep' => '十二试炼',
			'wepk' => 'WC',
			'wepe' => 400,
			'weps' => 600,
			'wepsk' => 'r',
			),
			34 => array
			(
			'name' => '吔姐蕉',
			'icon' => 0,
			'club' => 1,
			'wep' => '无毁的受王拳',
			'wepk' => 'WP',
			'wepe' => 410,
			'weps' => 600,
			),
			35 => array
			(
			'name' => 'ad53123426',
			'icon' => 0,
			'club' => 9,
			'wep' => '无毁的受王拳',
			'wepk' => 'WP',
			'wepe' => 530,
			'weps' => 600,
			),
		),
	),
	
	21 => array
		(
		'mode' => 1,
		'num' => 1,
		'pass' => 'wei42bg',
		'club' => 0,
		'bid' => 0,
		'inf' => '',
		'rage' => 250,
		'pose'=> 2,
		'tactic' => 3,
		'killnum' => 0,
		'teamID' => '',
		'teamPass' => '',
		'gd' => 'r',
		'pls' => 34,
		'mhp' => 12900,
		'msp' => 800,
		'att' => 4000,
		'def' => 4000,
		'lvl' => 65,
		'skill' => 800,
		'money' => 40000,
		'arb' => '武神战甲B',
		'arbk' => 'DB',
		'arbe' => 3000,
		'arbs' => 300,
		'arbsk' => 'A',
		'arh' => '武神战甲H',
		'arhk' => 'DH',
		'arhe' => 2000,
		'arhs' => 300,
		'arhsk' => 'b',
		'arf' => '武神战甲F',
		'arfk' => 'DF',
		'arfe' => 2000,
		'arfs' => 300,
		'arfsk' => 'a',
		'ara' => '武神战甲A',
		'arak' => 'DA',
		'arae' => 2000,
		'aras' => 300,
		'arask' => 'H',
		'art' => '武神之魂',
		'artk' => 'A',
		'arte' => 9,
		'arts' => 9,
		'artsk' => 'ch',




		'sub' => array
		(
			0 => array
			(
			'name' => '黑熊',
			'gd' => 'm',
			'icon' => 210,
			'club' => 18,
			'mhp' => 8932,
			'att' => 5120,
			'skill' => 1919,
			'money' => 20,
			'skills' => array('400'=>'5','401'=>'5','402'=>'1','403'=>'5','461'=>'1','422'=>'0'),
			'wep' => 'Solidarity',
			'wepk' => 'WG',
			'wepe' => 3000,
			'weps' => 3000,
			'wepsk' => 'Nnrd',
			'arb' => 'NATO',
			'arbk' => 'DB',
			'arbe' => 2333,
			'arbs' => 300,
			'arbsk' => 'ZA',
			'arh' => 'Voice of America',
			'arhk' => 'DH',
			'arhe' => 2333,
			'arhs' => 300,
			'arhsk' => 'ZB',
			'arf' => 'One small step',
			'arfk' => 'DF',
			'arfe' => 2333,
			'arfs' => 300,
			'arfsk' => 'Za',
			'ara' => 'Tear down this WALL',
			'arak' => 'DA',
			'arae' => 2333,
			'aras' => 300,
			'arask' => 'ZH',
			'art' => 'Bear Trap',
			'artk' => 'A',
			'arte' => 1,
			'arts' => 1,
			'artsk' => 'Zch',
			'itm1' => '『黑熊刀』',
			'itmk1' => 'WK',
			'itme1' => 90,
			'itms1' => 350,
			'itmsk1' => 'Nnrd',
			'itm2' => '超重型黑熊列车 古斯塔夫最大炮',
			'itmk2' => 'WG',
			'itme2' => 3000,
			'itms2' => 3000,
			'itmsk2' => 'Nnrd',
			'itm3' => '《黑熊语录》',
			'itmk3' => 'VV',
			'itme3' => 153,
			'itms3' => 1,
			'itmsk3' => 'Z',
			'itm4' => '这个是什么按钮',
			'itmk4' => 'Y',
			'itme4' => 1,
			'itms4' => 1,
			'description' => '武神 黑熊，<span class="yellow b">旧英灵四天王之首，被称为英灵殿唯一的良心。（咦？）<br>附带很不要脸的<span class="red b">【直死1】</span>和<span class="red b">【暴风】</span>技能</span>',
			),
		),
	),
		22 => array
		(
		'mode' => 1,
		'num' => 0,
		'club' => 0,
		'bid' => 0,
		'inf' => '',
		'rage' => 255,
		'pose'=> 4,
		'tactic' => 3,
		'killnum' => 99,
		'teamID' => '',
		'teamPass' => '',
		'pls' => 34,
		'mhp' => 23333,
		'msp' => 2333,
		'def' => 2333,
		'lvl' => 97,
		'skill' => 444,
		'money' => 100000,
		'arb' => '天神的威光',
		'arbk' => 'DB',
		'arbe' => 6000,
		'arbs' => 400,
		'arbsk' => 'ab',
		'arh' => '天神的极光',
		'arhk' => 'DH',
		'arhe' => 4000,
		'arhs' => 300,
		'arhsk' => 'h',
		'arf' => '天神的霞光',
		'arfk' => 'DF',
		'arfe' => 4000,
		'arfs' => 300,
		'arfsk' => 'A',
		'ara' => '天神的寒光',
		'arak' => 'DA',
		'arae' => 4000,
		'aras' => 300,
		'arask' => 'c',
		'art' => '天神的曙光',
		'artk' => 'A',
		'arte' => 200,
		'arts' => 300,
		'artsk' => 'H',
		'sub' => array
		(
			0 => array
			(
			'name' => '冴月麟MK-II',
			'gd' => 'f',
			'icon' => 3,
			'club' => 9,
			'mss' => 50,
			'att' => 23333,
			'skill' => array('wp' => 1600, 'wk' => 2300, 'wc' => 2700, 'wg' => 1900, 'wd' => 1500, 'wf' => 2800),
			'skills' => array('81' => '0', '461'=>'1'),
			'wep' => '键 希望弹',
			'wepk' => 'WC',
			'wepe' => 50000,
			'weps' => 998,
			'wepsk' => 'zdfkc',
			'arb' => '真 - 桔黄色的大衣',
			'arh' => '真 - 红色的发圈',
			'arf' => '真 - 橙黄学生鞋',
			'ara' => '真 - 带翅膀的书包',
			'art' => '真 - 奇迹之愿',
			'itm1' => '键 燃烧弹',
			'itmk1' => 'WF',
			'itme1' => 48000,
			'itms1' => '∞',
			'itmsk1' => 'Nfzr',
			'itm2' => '键 生命弹',
			'itmk2' => 'WG',
			'itme2' => 50000,
			'itms2' => 998,
			'itmsk2' => 'zdrfk',
			'itm3' => '键 未来弹',
			'itmk3' => 'WP',
			'itme3' => 50000,
			'itms3' => '∞',
			'itmsk3' => 'rcdfN',





			'itm5' => '键 旅途弹',
			'itmk5' => 'WK',
			'itme5' => 50000,
			'itms5' => 998,
			'itmsk5' => 'zdNkc',
			'itm6' => '键 审判弹',
			'itmk6' => 'WF',
			'itme6' => 100000,
			'itms6' => '∞',
			'itmsk6' => 'nrfkx',
			'description' => '天神 冴月麟MK-II，ACFUN大逃杀的最初创作者。KEY社的铁杆粉丝。会切换武器。（没有键 催泪弹是刻意的）',
			),
			1 => array
			(
			'name' => '星莲船四面BOSS',
			'gd' => 'm',
			'icon' => 163,
			'club' => 18,
			'att' => 233,
			'mhp' => 4444,
			'skill' => 120,
			'skills' => array('461'=>'1'),
			'wep' => '【黑暗童话】',
			'wepk' => 'WJ',
			'wepe' => 1,
			'weps' => 9999,
			'wepsk' => 'rdpn',
			'arb' => '可爱标记拼成的披风',
			'arh' => '天马经理的面罩',
			'arf' => '刀锋般的后腿',
			'ara' => '研究员的笔记本',
			'art' => 'S.M.I.L.E.!',
			'itm2' => '四面的腿',
			'itmk2' => 'PB2',
			'itme2' => 1,
			'itms2' => 1,
			'itmsk2' => 'x',
			'itm1' => '武器师安雅的奖赏',
			'itmk1' => 'Y',
			'itme1' => 1,
			'itms1' => 3,
			'itmsk1' => 'z',
			'description' => '天神 星莲船四面BOSS，AC大逃杀程序员、抖M，本体已经变成了马。虽然武器的攻击力是1，但由于重型枪械的百分比伤害设定，实际上对玩家拥有即死效果。',
			),
			2 => array
			(
			'name' => '虚子',
			'gd' => 'f',
			'icon' => 161,
			'club' => 18,
			'mhp' => 8932,
			'att' => 5120,
			'skill' => 1919,
			'skills' => array('400'=>'5','401'=>'5','402'=>'4','461'=>'1'),
			'wep' => 'WE will BURY YOU',
			'wepk' => 'WG',
			'wepe' => 3000,
			'weps' => 3000,
			'wepsk' => 'Nnrd',
			'arb' => 'Warsaw Pact',
			'arh' => 'De-Stalinization',
			'arf' => 'Muslim Revolution',
			'ara' => 'Flower Power',
			'art' => 'Glasnost',
			'itm1' => '『寻星者』',
			'itmk1' => 'WK',
			'itme1' => 90,
			'itms1' => 350,
			'itmsk1' => 'Nnrd',
			'itm2' => '超重型炮塔列车 古斯塔夫最大炮',
			'itmk2' => 'WG',
			'itme2' => 3000,
			'itms2' => 3000,
			'itmsk2' => 'Nnrd',
			'itm3' => '《董子语录》',
			'itmk3' => 'VV',
			'itme3' => 153,
			'itms3' => 1,
			'itmsk3' => 'Z',
			'description' => '天神 虚子，AC大逃杀程序员，毒舌属性。<br>附带很不要脸的<span class="red b">【直死4】</span>技能，命中抬走送往印度，现在订购还附赠美味香蕉一串。pong友，今天你被直死了吗？',
			),
			3 => array
			(
			'name' => 'lemon',
			'gd' => 'r',
			'icon' => 162,
			'club' => 7,
			'lvl' => 0,
			'rage' => 0,
			'mhp' => 9800,
			'att' => 32767,
			'def' => 32767,
			'skill' => 1150,
			'skills'=>array('412'=>'0','461'=>'1'),	
			'wep' => '电气火绳枪',
			'wepk' => 'WG',
			'wepe' => 30,
			'weps' => 60,
			'wepsk' => 'en',
			'arb' => '工作装',
			'arh' => '防灾头巾',
			'ara' => '垫肩',
			'arf' => '钉鞋',
			'art' => 'Untainted Glory',
			'itm1' => 'ACDTS Farming Helper',
			'itmk1' => 'ME',
			'itme1' => 20,
			'itms1' => 200,
			'itmsk1' => 'z',
			'description' => '天神 lemon，AC大逃杀程序员，代码力深不见底。<br>拥有全英灵殿最高的基础攻击与防御，而更吓人的是其拥有的<span class="red b">【反演】</span>技能，让无数屠殿老司机铩羽而归。',
			),
		),
	),
	
	45=> array
		(
		'mode' => 2,
		'num' => 0,
		'pass' => 'bra',
		'club' => 14,
		'bid' => 0,
		'inf' => '',
		'rage' => 0,
		'skills' => array('404'=>'2'),
		'pose'=> 4,
		'tactic' => 3,
		'killnum' => 0,
		'teamID' => 'MhHmpsz',
		'teamPass' => 'Eb2Lfz3Usvui',
		'pls' => 99,
		'mhp' => 5400,
		'msp' => 200,
		'att' => 200,
		'def' => 300,
		'lvl' => 25,
		'skill' => 120,
		'money' => 4500,
		'mss' => 50,
		'arb' => '电波的意志',
		'arbk' => 'DB',
		'arbe' => 420,
		'arbs' => 100,
		'arh' => '智者的头脑',
		'arhk' => 'DH',
		'arhe' => 340,
		'arhs' => 100,
		'ara' => '触手的潜能',
		'arak' => 'DA',
		'arae' => 340,
		'aras' => 100,
		'arask' => 'R',
		'arf' => '头名的尊严',
		'arfk' => 'DF',
		'arfe' => 340,
		'arfs' => 100,
		'art' => '你沒戲唱了，快去死吧！',
		'artk' => 'A',
		'arte' => 200,
		'arts' => 10,
		'artsk' => 'xa',
		'sub' => array
		(
		0 => array
			(
			'name' => '索菲亚小傻鸟',
			'gd' => 'm',
			'icon' => 109,
			'wep' => '燃烧吧',
			'wepk' => 'WG',
			'wepe' => 40,
			'weps' => 20000,
			'wepsk' => 'Au',
			'itm1' => '傻鸟的结婚请柬',
			'itmk1' => 'WC',
			'itme1' => 600,
			'itms1' => 150,
			'itmsk1' => 'rdc',
			'itm2' => '红烧小鸟',
			'itmk2' => 'HB',
			'itme2' => 500,
			'itms2' => 150,
			'itm3' => 'kitty酱的围裙',
			'itmk3' => 'DB',
			'itme3' => 500,
			'itms3' => 150,
			'itmsk3' => 'PF',
			'description' => '电波幽灵 索菲亚小傻鸟，电波第一代触手代表。另一个身份是A岛美食版女神kitty酱。',
			),
		1 => array
			(
			'name' => '虚名',
			'gd' => 'm',
			'icon' => 110,
			'wep' => '片翼虚影',
			'wepk' => 'WK',
			'wepe' => 15,
			'weps' => 100,
			'wepsk' => 'Ad',
			'itm1' => '虚名的精灵片翼',
			'itmk1' => 'WK',
			'itme1' => 600,
			'itms1' => 150,
			'itmsk1' => 'uid',
			'itm2' => '不明黑色物质',
			'itmk2' => 'HB',
			'itme2' => 500,
			'itms2' => 150,
			'itm3' => '悲叹之种',
			'itmk3' => 'DH',
			'itme3' => 500,
			'itms3' => 150,
			'itmsk3' => 'KG',
			'description' => '电波幽灵 虚名，电波第二代触手代表。本命武器为精灵片翼。',
			),
		2 => array
			(
			'name' => 'YS',
			'gd' => 'm',
			'icon' => 111,
			'wep' => '毁灭阴影',
			'wepk' => 'WF',
			'wepe' => 80,
			'weps' => 150,
			'wepsk' => 'Ac',
			'itm1' => 'YS的魂之挽歌',
			'itmk1' => 'WF',
			'itme1' => 600,
			'itms1' => 20,
			'itmsk1' => 'd',
			'itm2' => '奶酪',
			'itmk2' => 'HB',
			'itme2' => 500,
			'itms2' => 150,
			'itm3' => '卜择手断',
			'itmk3' => 'DA',
			'itme3' => 500,
			'itms3' => 150,
			'itmsk3' => 'CD',
			'description' => '电波幽灵 YS，电波第三代触手代表。是一名脸很黑的小学生。',
			),
		3 => array
			(
			'name' => '逆向朝阳',
			'gd' => 'f',
			'icon' => 112,
			'wep' => '大爷星人',
			'wepk' => 'WC',
			'wepe' => 50,
			'weps' => 200,
			'wepsk' => 'AN',
			'itm1' => '朝阳的肥猫大爷',
			'itmk1' => 'WP',
			'itme1' => 600,
			'itms1' => 150,
			'itmsk1' => 'cd',
			'itm2' => '肉用大爷',
			'itmk2' => 'HB',
			'itme2' => 500,
			'itms2' => 150,
			'itm3' => '挂在腿上的大爷',
			'itmk3' => 'DF',
			'itme3' => 500,
			'itms3' => 150,
			'itmsk3' => 'a',
			'description' => '电波幽灵 逆向朝阳，电波第二代触手，电波前段时间的统治者。养了很多猫大爷。',
			),
		),
	),
	
		88 => array
			(
			'mode' => 1,
			'num' => 0,
			'pass' => 'bra',
			'club' => 17,
			'bid' => 0,
			'inf' => '',
			'rage' => 188,
			'pose'=> 2,
			'tactic' => 3,
			'killnum' => 88,
			'teamID' => '',
			'teamPass' => '',
			'gd' => 'm',
			'pls' => 32,
			'mhp' => 8888888,
			'msp' => 888,
			'att' => 88888,
			'def' => 88888,
			'lvl' => 88,
			'skill' => 88888,
			'money' => 88888,
			'arb' => '[数据删除]',
			'arbk' => 'DB',
			'arbe' => 8888,
			'arbs' => 8888,
			'arbsk' => 'Aa',
			'arh' => '[数据删除]',
			'arhk' => 'DH',
			'arhe' => 8888,
			'arhs' => 8888,
			'arhsk' => 'Bb',
			'arf' => '[数据删除]',
			'arfk' => 'DF',
			'arfe' => 8888,
			'arfs' => 8888,
			'arfsk' => 'Mm',
			'ara' => '[数据删除]',
			'arak' => 'DA',
			'arae' => 8888,
			'aras' => 8888,
			'arask' => 'Hc',
			'art' => '[数据删除]',
			'artk' => 'A',
			'arte' => 1,
			'arts' => 1,
			'artsk' => 'xH',
			'sub' => array
			(
				0 => array
				(
				'name' => 'SCP-682',
				'icon' => 103,
				'wep' => '[数据删除]',
				'wepk' => 'WN',
				'wepe' => 8888,
				'weps' => 8888,
				'wepsk' => 'nrd',
				'description' => 'SCP-682，坐镇于SCP研究设施，完全无敌的存在，要是不幸被打到的话，必死无疑。最好的避免方法，就是<span class="yellow b">永远不要去SCP研究设施</span>。',
				),
				1 => array
				(
				'name' => 'SCP-173',
				'icon' => 106,
				'wep' => '[数据删除]',
				'wepk' => 'WF',
				'wepe' => 8888,
				'weps' => 8888,
				'wepsk' => 'nrd',
				'description' => 'SCP-173，坐镇于SCP研究设施，完全无敌的存在，要是不幸被打到的话，必死无疑。最好的避免方法，就是<span class="yellow b">永远不要去SCP研究设施</span>。',
				),
				2 => array
				(
				'name' => 'SCP-076',
				'icon' => 107,
				'wep' => '[数据删除]',
				'wepk' => 'WK',
				'wepe' => 8888,
				'weps' => 8888,
				'wepsk' => 'nrd',
				'description' => 'SCP-076，坐镇于SCP研究设施，完全无敌的存在，要是不幸被打到的话，必死无疑。最好的避免方法，就是<span class="yellow b">永远不要去SCP研究设施</span>。',
				),
				3 => array
				(
				'name' => 'SCP-958',
				'icon' => 108,
				'wep' => '[数据删除]',
				'wepk' => 'WG',
				'wepe' => 8888,
				'weps' => 8888,
				'wepsk' => 'nrd',
				'description' => 'SCP-958，坐镇于SCP研究设施，完全无敌的存在，要是不幸被打到的话，必死无疑。最好的避免方法，就是<span class="yellow b">永远不要去SCP研究设施</span>。',
				),
			),
		),
		90 => array
			(
			'mode' => 2,
			'num' => 0,
			'pass' => 'bra',
			'club' => 0,
			'bid' => 0,
			'inf' => '',
			'rage' => 0,
			'pose'=> 0,
			'tactic' => 0,
			'killnum' => 0,
			'teamID' => '',
			'teamPass' => '',
			'gd' => 'r',
			'pls' => 99,
			'mhp' => 500,
			'msp' => 200,
			'att' => 130,
			'def' => 150,
			'lvl' => 10,
			'skill' => 40,
			'money' => 220,
			'arb' => '跟风群皮',
			'arbk' => 'DB',
			'arbe' => 35,
			'arbs' => 30,
			
			'arh' => '萌豚头像',
			'arhk' => 'DH',
			'arhe' => 25,
			'arhs' => 30,
			
			'arf' => '女装丝袜',
			'arfk' => 'DF',
			'arfe' => 25,
			'arfs' => 30,
			
			'ara' => '发送按钮',
			'arak' => 'DA',
			'arae' => 25,
			'aras' => 30,
			
			'art' => '键盘侠之证',
			'artk' => 'A',
			'arte' => 20,
			'arts' => 10,
			
	
	
	
	

			'itm4' => '压缩饼干',
			'itmk4' => 'HB',
			'itme4' => 35,
			'itms4' => 10,
			
			'itm3' => '紧急药剂',
			'itmk3' => 'Ca',
			'itme3' => 1,
			'itms3' => 3,
			
			'sub' => array
			(
			0 => array
				(
				'name' => '复读机',
				'icon' => 25,
				'wep' => '水群之枪',
				'wepk' => 'WG',
				'wepe' => 50,
				'weps' => 50,
				'description' => '“人类的本质就是复读机。”<br>无威胁的杂兵，也是数目最多的NPC之一，碰见了就上去给他一击吧。',
				),
			1 => array
				(
				'name' => '秦国人',
				'icon' => 26,
				'wep' => '丢人之摸',
				'wepk' => 'WP',
				'wepe' => 50,
				'weps' => 50,
				'description' => '“真鸡儿丢人！”<br>无威胁的杂兵，也是数目最多的NPC之一，碰见了就上去给他一击吧。',
				),
			2 => array
				(
				'name' => '白学家',
				'icon' => 29,
				'mss' => 30,
				'wep' => '雪碧之罐',
				'wepk' => 'WC',
				'wepe' => 50,
				'weps' => 50,
				'description' => '“又到了那个寒冷的季节……”<br>无威胁的杂兵，也是数目最多的NPC之一，碰见了就上去给他一击吧。',
				),
			3 => array
				(
				'name' => '膜触党',
				'icon' => 28,
				'wep' => '捧杀之钩',
				'wepk' => 'WK',
				'wepe' => 50,
				'weps' => 50,
				'description' => '“这服就我不是触手了。”<br>无威胁的杂兵，也是数目最多的NPC之一，碰见了就上去给他一击吧。',
				),
			),
		),
	);
}

?>