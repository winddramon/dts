<?php

namespace npc_action
{
	$npc_action_gametype = Array(18,13);
	$npc_action_min_intv = 30;
	
	$npc_action_data = Array(
		'冴月 麟' => Array(
			'intv' => 240,
			'devi' => Array(-60, 60),
			'actions' => Array(
				'move' => 1,
				'chase' => 100,
				'ambush' => 100,
				
			),
			
			'setting' => Array(
				'move' => Array(
					'moveto_list' => Array(99),
					'avoid_forbidden' => 1,
					'avoid_dangerous' => 1,
					
					
					
					
					'addchat' => 1,
					'addchat_txt' => Array(
						'【MOVED TO "<:para2:>". 】',
					),
				),
				'guard' => Array(
					'guard_time' => 180,
				),
				'chase' => Array(
					'object' => Array('W'),
					'avoid_forbidden' => 0,
					'avoid_dangerous' => 0,
					
					'need_rage_GE' => 30,
					
					'rage_change_after_action' => -3,
					'addchat' => 1,
					'addchat_txt' => Array(
						'【CHASE: "<:para3:>" . MOVED TO "<:para2:>". 】',
					),
				),
				'evade' => Array(
					'early_action' => 1,
					'object' => Array('B'),
					'avoid_forbidden' => 1,
					'avoid_dangerous' => 1,
					
					
					'need_rage_LE' => 70,
					
					'addchat' => 1,
					'addchat_txt' => Array(
						'【EVADE: "<:para3:>" . MOVED TO "<:para2:>". 】',
					),
				),
				'ambush' => Array(
					'early_action' => 1,
					'object' => Array('A'),
					
					'need_rage_GE' => 30,
					'rage_change_after_action' => -5,
					'ambush_findrate_buff' => 0,
					'action_if_fail' => 'guard',
					'addchat' => 1,
					'addchat_txt' => Array(
						'【AMBUSH: "<:para3:>" BEFORE AISATSU! 】',
					),
				),
			),
		),	
		
		
		'某四面' => Array(
			'intv' => 240,
			'devi' => Array(-60, 60),
			'actions' => Array(
				'move' => 1,
				'chase' => 100,
				'ambush' => 100,
			),
			
			'setting' => Array(
				'move' => Array(
					'moveto_list' => Array(99),
					'avoid_forbidden' => 1,
					'avoid_dangerous' => 1,
					
					
					
					
					'addchat' => 1,
					'addchat_txt' => Array(
						'♪ Then they’re eatin’ every apple in "<:para2:>"’s apple tree ♪',
						'♪ They don’t care about "<:para2:>", not zilch, no, nothin’ ♪',
						'♪ ’ Cept bringin’  about "<:para2:>"’ s destruction ♪'
					),
				),
				'guard' => Array(
					'guard_time' => 180,
				),
				'evade' => Array(
					'early_action' => 1,
					'object' => Array('T'),
					'avoid_forbidden' => 1,
					'avoid_dangerous' => 1,
					
					'need_rage_GE' => 30,
					
					'rage_change_after_action' => -3,
					'addchat' => 1,
					'addchat_txt' => Array(
						'♪ "<:para3:>" care for their young just like we ponies do ♪',
					),
				),
				'ambush' => Array(
					'early_action' => 1,
					'object' => Array('A'),
					
					'need_rage_GE' => 30,
					'rage_change_after_action' => -5,
					'ambush_findrate_buff' => 0,
					'action_if_fail' => 'guard',
					'addchat' => 1,
					'addchat_txt' => Array(
						'♪ "<:para3:>"’ve crossed the line, it’s time to fight them back! ♪',
					),
				),
			),
		),
		
		
		'便当盒' => Array(
			'intv' => 60,
			'devi' => Array(-10, 10),
			'actions' => Array(
				'move' => 100,
				'guard' => 100,
			),
			
			'setting' => Array(
				'move' => Array(
					'early_action' => 1,
					'moveto_list' => Array(99),
					'avoid_forbidden' => 1,
					'avoid_dangerous' => 1,
					
					'need_rage_GE' => 100,
					
					'rage_change_after_action' => -100,
					'addchat' => 1,
					'addchat_txt' => Array(
						'ybb，赶紧切地图！'
					),
				),
				'guard' => Array(
					'guard_time' => 0,
				),
			),
		),
		
		
		'KHIBIKI《黑曲》' => Array(
			'type' => 11,
			'intv' => 60,
			'devi' => Array(-10, 10),
			'actions' => Array(
				'move' => 100,
				'guard' => 100,
			),
			
			'setting' => Array(
				'move' => Array(
					'moveto_list' => Array(99),
					'avoid_forbidden' => 1,
					'avoid_dangerous' => 1,
					
					'need_rage_GE' => 100,
					
					'rage_change_after_action' => -100,
					'addchat' => 1,
					'addchat_txt' => Array(
						'OAO?'
					),
				),
				'guard' => Array(
					'guard_time' => 0,
				),
			),
		),
		
		
		'一一五 i' => Array(
			'intv' => 90,
			'devi' => Array(-30, 30),
			'actions' => Array(
				'chase' => 100,
				'ambush' => 100,
			),
			
			'setting' => Array(
				'guard' => Array(
					'guard_time' => 30,
				),
				'chase' => Array(
					'object' => Array('T'),
					'avoid_forbidden' => 0,
					'avoid_dangerous' => 0,
					
					
					
					
					'addchat' => 1,
					'addchat_txt' => Array(
						'发动魔法卡『位置移动』！',
						'曾经有一个游戏开创了『传送击杀』这么一个东西，可惜大逃杀在传送后不能马上攻击。',
						'听说会打枪的猫又妖怪是先尾行再扔手雷的，但我觉得能一击毙命的时候还是大刺刺追击更好。',
					),
				),
				'ambush' => Array(
					'early_action' => 1,
					'object' => Array('A'),
					
					
					
					'ambush_findrate_buff' => 20,
					'action_if_fail' => 'guard',
					'addchat' => 1,
					'addchat_txt' => Array(
						'难道你以为我只是一个血条比较厚的木桩？',
						'我的回合，抽卡，进战阶！',
						'SURPRISE——',
					),
				),
			),
		),
	);
}
?>