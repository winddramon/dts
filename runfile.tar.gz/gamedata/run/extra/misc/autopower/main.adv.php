<?php

namespace autopower
{
	global $max_autopower_num; $max_autopower_num = 15;	
	global $autopower_penalty; $autopower_penalty = 1.5;	
	
	function init() {}
	
	function itemuse(&$theitem) 
	{
		return \instance10\itemuse($theitem);
	}	
}

?>
