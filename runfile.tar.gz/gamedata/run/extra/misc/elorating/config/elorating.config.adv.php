<?php
namespace elorating{
	
	
	global $elo_servermark;
	$elo_servermark = array(
		'D' => 'lg.dianbo.me',
		'S' => 'dts.sentur.info',
		'0' => '000.76573.org',
	);
}
?>