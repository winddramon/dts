<?php

namespace bubblebox
{
	$bubblebox_style = Array();
	
	function init() {}
	
	function bubblebox_delete_trailing_spaces($s)
	{
		
		$head=0; 
		while ($head<strlen($s) && ctype_space($s[$head])) $head++;
		$tail=strlen($s)-1;
		while ($head<=$tail && ctype_space($s[$tail])) $tail--;
		if ($head>$tail) return '';
		return substr($s,$head,$tail-$head+1);
	}
	
	function bubblebox_set_default()
	{
		
		do { global $___LOCAL_BUBBLEBOX__VARS__bubblebox_style; $bubblebox_style=&$___LOCAL_BUBBLEBOX__VARS__bubblebox_style;   } while (0);
		$bubblebox_style = Array(
			
			'id' => '',			
			'height' => 100,		
			'width' => 100,		
			
			'z-index-base' => 10,	
			'offset-x' => 0,		
			'offset-y' => 0,		
			'opacity' => 0.95,	
			'cancellable' => 0,	
			'scroll-bar' => 1,	
			
			'border-width-x' => 5,	
			'border-width-y' => 5,	
			'margin-top' => 8,	
			'margin-bottom' => 8,	
			'margin-left' => 8,	
			'margin-right' => 4,	
		);
	}
	
	function bubblebox_set_style($str)
	{
		
		do { global $___LOCAL_BUBBLEBOX__VARS__bubblebox_style; $bubblebox_style=&$___LOCAL_BUBBLEBOX__VARS__bubblebox_style;   } while (0);
		bubblebox_set_default();
		$str.=';'; $i=0; $s1=''; $s2=''; $sflag=0;
		while ($i<strlen($str))
		{
			if ($str[$i]==';')
			{
				if ($sflag) 
				{
					$s1=bubblebox_delete_trailing_spaces($s1);
					$s2=bubblebox_delete_trailing_spaces($s2);
					if ($s1!='' && isset($bubblebox_style[$s1])) $bubblebox_style[$s1]=$s2;
					$sflag=0; $s1=''; $s2='';
				}
			}
			else  if ($str[$i]==':')
			{
				if ($sflag==0) $sflag++;
			}
			else
			{
				if ($sflag==0) $s1.=$str[$i]; else $s2.=$str[$i];
			}
			$i++;
		}
	}
	
	function bubblebox_get_style($str)
	{
		
		do { global $___LOCAL_BUBBLEBOX__VARS__bubblebox_style; $bubblebox_style=&$___LOCAL_BUBBLEBOX__VARS__bubblebox_style;   } while (0);
		return $bubblebox_style[$str];
	}			
}

?>
