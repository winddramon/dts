<?php

namespace bufficons
{
	$bufficons_list = Array();

	$tmp_totsec = $tmp_nowsec = 0;

	function init() {}
	
	
	
	
	
	
	
	
	

	
	
	
	
	
	
	
	function bufficon_show($src, $para)
	{
		
		if ($para['style']==1)
		{
			$wh=round($para['nowsec']/$para['totsec']*32).'px';
			$para['lsec']=(int)($para['totsec']-$para['nowsec']);
			include template('MOD_BUFFICONS_ICON_STYLE_1');
		}
		if ($para['style']==2)
		{
			$wh=round($para['nowsec']/$para['totsec']*32).'px';
			$para['lsec']=(int)($para['totsec']-$para['nowsec']);
			include template('MOD_BUFFICONS_ICON_STYLE_2');
		}
		if ($para['style']==3)
		{
			include template('MOD_BUFFICONS_ICON_STYLE_3');
		}
	}
	
	
	function bufficons_list()
	{
		return \item_umb\bufficons_list();
	}

	
	function bufficons_display(&$pa=NULL)
	{
		
		do { global $___LOCAL_BUFFICONS__VARS__bufficons_list,$___LOCAL_BUFFICONS__VARS__tmp_totsec,$___LOCAL_BUFFICONS__VARS__tmp_nowsec; $bufficons_list=&$___LOCAL_BUFFICONS__VARS__bufficons_list; $tmp_totsec=&$___LOCAL_BUFFICONS__VARS__tmp_totsec; $tmp_nowsec=&$___LOCAL_BUFFICONS__VARS__tmp_nowsec;   } while (0);
		foreach($bufficons_list as $token => $config) {
			list($src, $para) = bufficons_display_single($token, $config, $pa);
			if(!empty($src) && !empty($para)) bufficon_show($src, $para);
		}
	}

	
	
	
	
	function bufficons_display_single($token, $config, &$pa=NULL) {
		return \skill500\bufficons_display_single($token,$config,$pa);
	}
	
	
	
	
	
	
	
	function bufficons_set_timestamp($token, $end, $cd, &$pa=NULL, $tp=1, $msec=0)
	{
		
		if(is_numeric($token) && defined('MOD_SKILL'.$token) && \skillbase\skill_query($token, $pa) && \skillbase\skill_check_unlocked($token, $pa) && ($end || $cd)){
			$now = get_var_in_module('now','sys');
			$end_ts = $now + (int)$end;
			$cd_ts = $end_ts + (int)$cd;
			if(2 == $tp && 1 == \bufficons\bufficons_check_buff_state($token, $pa, $msec)) {
				do { global $___LOCAL_BUFFICONS__VARS__bufficons_list,$___LOCAL_BUFFICONS__VARS__tmp_totsec,$___LOCAL_BUFFICONS__VARS__tmp_nowsec; $bufficons_list=&$___LOCAL_BUFFICONS__VARS__bufficons_list; $tmp_totsec=&$___LOCAL_BUFFICONS__VARS__tmp_totsec; $tmp_nowsec=&$___LOCAL_BUFFICONS__VARS__tmp_nowsec;   } while (0);
				$addsec = $tmp_totsec - $tmp_nowsec;
				$end_ts += $addsec;
				$cd_ts += $addsec;
			}
			\skillbase\skill_setvalue($token,'start_ts',$now,$pa);
			\skillbase\skill_setvalue($token,'end_ts',$end_ts,$pa);
			\skillbase\skill_setvalue($token,'cd_ts',$cd_ts,$pa);
			if(!empty($msec)) {
				$now_calc = get_now(1);
				$addmsec = (int)(1000*($now_calc - $now));
				$end_addmsec = (int)(1000*($end - (int)$end)) + $addmsec;
				$cd_addmsec = (int)(1000*($cd - (int)$cd)) + $addmsec;
				\skillbase\skill_setvalue($token,'start_msec',$addmsec,$pa);
				\skillbase\skill_setvalue($token,'end_msec',$end_addmsec,$pa);
				\skillbase\skill_setvalue($token,'cd_msec',$cd_addmsec,$pa);
			}
			return true;
		}
		return false;
	}

	
	
	
	
	
	
	function bufficons_check_buff_state($token, &$pa=NULL, $msec=0)
	{
		return \skill182\bufficons_check_buff_state($token,$pa,$msec);
	}

	
	
	
	function bufficons_check_buff_state_shell($token, &$pa=NULL, $msec=0)
	{
		return \skill500\bufficons_check_buff_state_shell($token,$pa,$msec);
	}

	
	
	
	function bufficons_activate_buff($token, $end, $cd, &$pa=NULL, $tp=1, $msec=0)
	{
		
		
		$is_successful = true;
		$fail_hint = '';
		list($is_successful, $fail_hint) = \bufficons\bufficons_check_buff_state_shell($token, $pa, $msec);
		if($is_successful){
			$is_successful = \bufficons\bufficons_set_timestamp($token, $end, $cd, $pa, $tp, $msec);
			if(!$is_successful) {
				$fail_hint = '因技能编号错误或者时间为0等原因，发动技能失败！<br>';
			}
		}
		
		return Array($is_successful, $fail_hint);
	}

	
	
	
	function bufficons_impose_buff($token, $end, $cd, &$pa=NULL, $tp=1, $msec=0) {
		
		if(!\skillbase\skill_query($token, $pa)) {
			\skillbase\skill_acquire($token, $pa);
		}
		$fail_hint = '';
		$is_successful = \bufficons\bufficons_set_timestamp($token, $end, $cd, $pa, $tp, $msec);
		if(!$is_successful) {
			$fail_hint = '因技能编号错误或者时间为0等原因，施加异常状态失败！<br>';
		}

		return Array($is_successful, $fail_hint);
	}
}

?>