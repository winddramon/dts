<?php

namespace searchmemory
{
	$searchmemory_disabled_gtype = array(1);
	$searchmemory_max_slotnum = 5;
	$searchmemory_max_recordnum = 30;
	$searchmemory_battle_active_debuff = -40;
	$searchmemory_enemy_in_memory_escape_rate = 50;
	
	$weather_memory_loss = array(
		8 => -2,
		9 => -3,
		12 => -3
	);
	
	
	$searchmemorycoldtime = 1500;
	
	$gametype_keep_enemy_in_searchmemory = Array(19);
	$gametype_keep_corpse_in_searchmemory = Array(19);
}

?>