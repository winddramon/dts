<?php

namespace item_armor_empower
{
	$ea_itmsk = array
	(
		
		'sup' => array('B','b','Z','h'),
		
		'def' => array('A','a','P','K','G','C','D','F','R','q','U','I','E','W'),
		
		'misc' => array('H','M','m'),
	);
	
	function init() {
		do { global $___LOCAL_ITEMMAIN__VARS__tmp_itmsk_arr_pool,$___LOCAL_ITEMMAIN__VARS__itemfind_extra_log,$___LOCAL_ITEMMAIN__VARS__item_equip_list,$___LOCAL_ITEMMAIN__VARS__item_hotkey_id_list,$___LOCAL_ITEMMAIN__VARS__itemmain_drophint,$___LOCAL_ITEMMAIN__VARS__item_allow_find_and_use,$___LOCAL_ITEMMAIN__VARS__nosta,$___LOCAL_ITEMMAIN__VARS__nospk,$___LOCAL_ITEMMAIN__VARS__item_obbs,$___LOCAL_ITEMMAIN__VARS__map_noitemdrop_arealist, $___LOCAL_ITEMMAIN__VARS__itemkind_equipable,$___LOCAL_ITEMMAIN__VARS__iteminfo,$___LOCAL_ITEMMAIN__VARS__itemspkinfo,$___LOCAL_ITEMMAIN__VARS__itemspkdesc,$___LOCAL_ITEMMAIN__VARS__itemspkdesc_help,$___LOCAL_ITEMMAIN__VARS__itemspkremark; $tmp_itmsk_arr_pool=&$___LOCAL_ITEMMAIN__VARS__tmp_itmsk_arr_pool; $itemfind_extra_log=&$___LOCAL_ITEMMAIN__VARS__itemfind_extra_log; $item_equip_list=&$___LOCAL_ITEMMAIN__VARS__item_equip_list; $item_hotkey_id_list=&$___LOCAL_ITEMMAIN__VARS__item_hotkey_id_list; $itemmain_drophint=&$___LOCAL_ITEMMAIN__VARS__itemmain_drophint; $item_allow_find_and_use=&$___LOCAL_ITEMMAIN__VARS__item_allow_find_and_use; $nosta=&$___LOCAL_ITEMMAIN__VARS__nosta; $nospk=&$___LOCAL_ITEMMAIN__VARS__nospk; $item_obbs=&$___LOCAL_ITEMMAIN__VARS__item_obbs; $map_noitemdrop_arealist=&$___LOCAL_ITEMMAIN__VARS__map_noitemdrop_arealist;  $itemkind_equipable=&$___LOCAL_ITEMMAIN__VARS__itemkind_equipable; $iteminfo=&$___LOCAL_ITEMMAIN__VARS__iteminfo; $itemspkinfo=&$___LOCAL_ITEMMAIN__VARS__itemspkinfo; $itemspkdesc=&$___LOCAL_ITEMMAIN__VARS__itemspkdesc; $itemspkdesc_help=&$___LOCAL_ITEMMAIN__VARS__itemspkdesc_help; $itemspkremark=&$___LOCAL_ITEMMAIN__VARS__itemspkremark;   } while (0);
		$iteminfo['EA'] = '防具改造';
	}
	
	function parse_itmuse_desc($n, $k, $e, $s, $sk){
if(isset($n)) {$__VAR_DUMP_MOD_item_armor_empower_VARS_n = $n; } else {$__VAR_DUMP_MOD_item_armor_empower_VARS_n = NULL;} if(isset($k)) {$__VAR_DUMP_MOD_item_armor_empower_VARS_k = $k; } else {$__VAR_DUMP_MOD_item_armor_empower_VARS_k = NULL;} if(isset($e)) {$__VAR_DUMP_MOD_item_armor_empower_VARS_e = $e; } else {$__VAR_DUMP_MOD_item_armor_empower_VARS_e = NULL;} if(isset($s)) {$__VAR_DUMP_MOD_item_armor_empower_VARS_s = $s; } else {$__VAR_DUMP_MOD_item_armor_empower_VARS_s = NULL;} if(isset($sk)) {$__VAR_DUMP_MOD_item_armor_empower_VARS_sk = $sk; } else {$__VAR_DUMP_MOD_item_armor_empower_VARS_sk = NULL;} 
		//======== Start of contents from mod item_ext_armor ========
		do{
			$___TMP_MOD_item_ext_armor_FUNC_parse_itmuse_desc_RET = NULL;
if(isset($n)) {$__VAR_DUMP_MOD_item_ext_armor_VARS_n = $n; } else {$__VAR_DUMP_MOD_item_ext_armor_VARS_n = NULL;} if(isset($k)) {$__VAR_DUMP_MOD_item_ext_armor_VARS_k = $k; } else {$__VAR_DUMP_MOD_item_ext_armor_VARS_k = NULL;} if(isset($e)) {$__VAR_DUMP_MOD_item_ext_armor_VARS_e = $e; } else {$__VAR_DUMP_MOD_item_ext_armor_VARS_e = NULL;} if(isset($s)) {$__VAR_DUMP_MOD_item_ext_armor_VARS_s = $s; } else {$__VAR_DUMP_MOD_item_ext_armor_VARS_s = NULL;} if(isset($sk)) {$__VAR_DUMP_MOD_item_ext_armor_VARS_sk = $sk; } else {$__VAR_DUMP_MOD_item_ext_armor_VARS_sk = NULL;} 
		//======== Start of contents from mod logistics ========
		do{
			$___TMP_MOD_logistics_FUNC_parse_itmuse_desc_RET = NULL;
if(isset($n)) {$__VAR_DUMP_MOD_logistics_VARS_n = $n; } else {$__VAR_DUMP_MOD_logistics_VARS_n = NULL;} if(isset($k)) {$__VAR_DUMP_MOD_logistics_VARS_k = $k; } else {$__VAR_DUMP_MOD_logistics_VARS_k = NULL;} if(isset($e)) {$__VAR_DUMP_MOD_logistics_VARS_e = $e; } else {$__VAR_DUMP_MOD_logistics_VARS_e = NULL;} if(isset($s)) {$__VAR_DUMP_MOD_logistics_VARS_s = $s; } else {$__VAR_DUMP_MOD_logistics_VARS_s = NULL;} if(isset($sk)) {$__VAR_DUMP_MOD_logistics_VARS_sk = $sk; } else {$__VAR_DUMP_MOD_logistics_VARS_sk = NULL;} 
		//======== Start of contents from mod instance5 ========
		do{
			$___TMP_MOD_instance5_FUNC_parse_itmuse_desc_RET = NULL;
if(isset($n)) {$__VAR_DUMP_MOD_instance5_VARS_n = $n; } else {$__VAR_DUMP_MOD_instance5_VARS_n = NULL;} if(isset($k)) {$__VAR_DUMP_MOD_instance5_VARS_k = $k; } else {$__VAR_DUMP_MOD_instance5_VARS_k = NULL;} if(isset($e)) {$__VAR_DUMP_MOD_instance5_VARS_e = $e; } else {$__VAR_DUMP_MOD_instance5_VARS_e = NULL;} if(isset($s)) {$__VAR_DUMP_MOD_instance5_VARS_s = $s; } else {$__VAR_DUMP_MOD_instance5_VARS_s = NULL;} if(isset($sk)) {$__VAR_DUMP_MOD_instance5_VARS_sk = $sk; } else {$__VAR_DUMP_MOD_instance5_VARS_sk = NULL;} 
		//======== Start of contents from mod empowers ========
		do{
			$___TMP_MOD_empowers_FUNC_parse_itmuse_desc_RET = NULL;
if(isset($n)) {$__VAR_DUMP_MOD_empowers_VARS_n = $n; } else {$__VAR_DUMP_MOD_empowers_VARS_n = NULL;} if(isset($k)) {$__VAR_DUMP_MOD_empowers_VARS_k = $k; } else {$__VAR_DUMP_MOD_empowers_VARS_k = NULL;} if(isset($e)) {$__VAR_DUMP_MOD_empowers_VARS_e = $e; } else {$__VAR_DUMP_MOD_empowers_VARS_e = NULL;} if(isset($s)) {$__VAR_DUMP_MOD_empowers_VARS_s = $s; } else {$__VAR_DUMP_MOD_empowers_VARS_s = NULL;} if(isset($sk)) {$__VAR_DUMP_MOD_empowers_VARS_sk = $sk; } else {$__VAR_DUMP_MOD_empowers_VARS_sk = NULL;} 
		//======== Start of contents from mod song ========
		do{
			$___TMP_MOD_song_FUNC_parse_itmuse_desc_RET = NULL;
if(isset($n)) {$__VAR_DUMP_MOD_song_VARS_n = $n; } else {$__VAR_DUMP_MOD_song_VARS_n = NULL;} if(isset($k)) {$__VAR_DUMP_MOD_song_VARS_k = $k; } else {$__VAR_DUMP_MOD_song_VARS_k = NULL;} if(isset($e)) {$__VAR_DUMP_MOD_song_VARS_e = $e; } else {$__VAR_DUMP_MOD_song_VARS_e = NULL;} if(isset($s)) {$__VAR_DUMP_MOD_song_VARS_s = $s; } else {$__VAR_DUMP_MOD_song_VARS_s = NULL;} if(isset($sk)) {$__VAR_DUMP_MOD_song_VARS_sk = $sk; } else {$__VAR_DUMP_MOD_song_VARS_sk = NULL;} 
		//======== Start of contents from mod item_uu ========
		do{
			$___TMP_MOD_item_uu_FUNC_parse_itmuse_desc_RET = NULL;
if(isset($n)) {$__VAR_DUMP_MOD_item_uu_VARS_n = $n; } else {$__VAR_DUMP_MOD_item_uu_VARS_n = NULL;} if(isset($k)) {$__VAR_DUMP_MOD_item_uu_VARS_k = $k; } else {$__VAR_DUMP_MOD_item_uu_VARS_k = NULL;} if(isset($e)) {$__VAR_DUMP_MOD_item_uu_VARS_e = $e; } else {$__VAR_DUMP_MOD_item_uu_VARS_e = NULL;} if(isset($s)) {$__VAR_DUMP_MOD_item_uu_VARS_s = $s; } else {$__VAR_DUMP_MOD_item_uu_VARS_s = NULL;} if(isset($sk)) {$__VAR_DUMP_MOD_item_uu_VARS_sk = $sk; } else {$__VAR_DUMP_MOD_item_uu_VARS_sk = NULL;} 
		//======== Start of contents from mod item_randskills ========
		do{
			$___TMP_MOD_item_randskills_FUNC_parse_itmuse_desc_RET = NULL;
if(isset($n)) {$__VAR_DUMP_MOD_item_randskills_VARS_n = $n; } else {$__VAR_DUMP_MOD_item_randskills_VARS_n = NULL;} if(isset($k)) {$__VAR_DUMP_MOD_item_randskills_VARS_k = $k; } else {$__VAR_DUMP_MOD_item_randskills_VARS_k = NULL;} if(isset($e)) {$__VAR_DUMP_MOD_item_randskills_VARS_e = $e; } else {$__VAR_DUMP_MOD_item_randskills_VARS_e = NULL;} if(isset($s)) {$__VAR_DUMP_MOD_item_randskills_VARS_s = $s; } else {$__VAR_DUMP_MOD_item_randskills_VARS_s = NULL;} if(isset($sk)) {$__VAR_DUMP_MOD_item_randskills_VARS_sk = $sk; } else {$__VAR_DUMP_MOD_item_randskills_VARS_sk = NULL;} 
		//======== Start of contents from mod skill593 ========
		do{
			$___TMP_MOD_skill593_FUNC_parse_itmuse_desc_RET = NULL;
if(isset($n)) {$__VAR_DUMP_MOD_skill593_VARS_n = $n; } else {$__VAR_DUMP_MOD_skill593_VARS_n = NULL;} if(isset($k)) {$__VAR_DUMP_MOD_skill593_VARS_k = $k; } else {$__VAR_DUMP_MOD_skill593_VARS_k = NULL;} if(isset($e)) {$__VAR_DUMP_MOD_skill593_VARS_e = $e; } else {$__VAR_DUMP_MOD_skill593_VARS_e = NULL;} if(isset($s)) {$__VAR_DUMP_MOD_skill593_VARS_s = $s; } else {$__VAR_DUMP_MOD_skill593_VARS_s = NULL;} if(isset($sk)) {$__VAR_DUMP_MOD_skill593_VARS_sk = $sk; } else {$__VAR_DUMP_MOD_skill593_VARS_sk = NULL;} 
		//======== Start of contents from mod addnpc ========
		do{
			$___TMP_MOD_addnpc_FUNC_parse_itmuse_desc_RET = NULL;
if(isset($n)) {$__VAR_DUMP_MOD_addnpc_VARS_n = $n; } else {$__VAR_DUMP_MOD_addnpc_VARS_n = NULL;} if(isset($k)) {$__VAR_DUMP_MOD_addnpc_VARS_k = $k; } else {$__VAR_DUMP_MOD_addnpc_VARS_k = NULL;} if(isset($e)) {$__VAR_DUMP_MOD_addnpc_VARS_e = $e; } else {$__VAR_DUMP_MOD_addnpc_VARS_e = NULL;} if(isset($s)) {$__VAR_DUMP_MOD_addnpc_VARS_s = $s; } else {$__VAR_DUMP_MOD_addnpc_VARS_s = NULL;} if(isset($sk)) {$__VAR_DUMP_MOD_addnpc_VARS_sk = $sk; } else {$__VAR_DUMP_MOD_addnpc_VARS_sk = NULL;} 
		//======== Start of contents from mod item_slip ========
		do{
			$___TMP_MOD_item_slip_FUNC_parse_itmuse_desc_RET = NULL;
if(isset($n)) {$__VAR_DUMP_MOD_item_slip_VARS_n = $n; } else {$__VAR_DUMP_MOD_item_slip_VARS_n = NULL;} if(isset($k)) {$__VAR_DUMP_MOD_item_slip_VARS_k = $k; } else {$__VAR_DUMP_MOD_item_slip_VARS_k = NULL;} if(isset($e)) {$__VAR_DUMP_MOD_item_slip_VARS_e = $e; } else {$__VAR_DUMP_MOD_item_slip_VARS_e = NULL;} if(isset($s)) {$__VAR_DUMP_MOD_item_slip_VARS_s = $s; } else {$__VAR_DUMP_MOD_item_slip_VARS_s = NULL;} if(isset($sk)) {$__VAR_DUMP_MOD_item_slip_VARS_sk = $sk; } else {$__VAR_DUMP_MOD_item_slip_VARS_sk = NULL;} 
		//======== Start of contents from mod item_uv ========
		do{
			$___TMP_MOD_item_uv_FUNC_parse_itmuse_desc_RET = NULL;
if(isset($n)) {$__VAR_DUMP_MOD_item_uv_VARS_n = $n; } else {$__VAR_DUMP_MOD_item_uv_VARS_n = NULL;} if(isset($k)) {$__VAR_DUMP_MOD_item_uv_VARS_k = $k; } else {$__VAR_DUMP_MOD_item_uv_VARS_k = NULL;} if(isset($e)) {$__VAR_DUMP_MOD_item_uv_VARS_e = $e; } else {$__VAR_DUMP_MOD_item_uv_VARS_e = NULL;} if(isset($s)) {$__VAR_DUMP_MOD_item_uv_VARS_s = $s; } else {$__VAR_DUMP_MOD_item_uv_VARS_s = NULL;} if(isset($sk)) {$__VAR_DUMP_MOD_item_uv_VARS_sk = $sk; } else {$__VAR_DUMP_MOD_item_uv_VARS_sk = NULL;} 
		//======== Start of contents from mod item_misc ========
		do{
			$___TMP_MOD_item_misc_FUNC_parse_itmuse_desc_RET = NULL;
if(isset($n)) {$__VAR_DUMP_MOD_item_misc_VARS_n = $n; } else {$__VAR_DUMP_MOD_item_misc_VARS_n = NULL;} if(isset($k)) {$__VAR_DUMP_MOD_item_misc_VARS_k = $k; } else {$__VAR_DUMP_MOD_item_misc_VARS_k = NULL;} if(isset($e)) {$__VAR_DUMP_MOD_item_misc_VARS_e = $e; } else {$__VAR_DUMP_MOD_item_misc_VARS_e = NULL;} if(isset($s)) {$__VAR_DUMP_MOD_item_misc_VARS_s = $s; } else {$__VAR_DUMP_MOD_item_misc_VARS_s = NULL;} if(isset($sk)) {$__VAR_DUMP_MOD_item_misc_VARS_sk = $sk; } else {$__VAR_DUMP_MOD_item_misc_VARS_sk = NULL;} 
		//======== Start of contents from mod trap ========
		do{
			$___TMP_MOD_trap_FUNC_parse_itmuse_desc_RET = NULL;
if(isset($n)) {$__VAR_DUMP_MOD_trap_VARS_n = $n; } else {$__VAR_DUMP_MOD_trap_VARS_n = NULL;} if(isset($k)) {$__VAR_DUMP_MOD_trap_VARS_k = $k; } else {$__VAR_DUMP_MOD_trap_VARS_k = NULL;} if(isset($e)) {$__VAR_DUMP_MOD_trap_VARS_e = $e; } else {$__VAR_DUMP_MOD_trap_VARS_e = NULL;} if(isset($s)) {$__VAR_DUMP_MOD_trap_VARS_s = $s; } else {$__VAR_DUMP_MOD_trap_VARS_s = NULL;} if(isset($sk)) {$__VAR_DUMP_MOD_trap_VARS_sk = $sk; } else {$__VAR_DUMP_MOD_trap_VARS_sk = NULL;} 
		//======== Start of contents from mod item_addarea ========
		do{
			$___TMP_MOD_item_addarea_FUNC_parse_itmuse_desc_RET = NULL;
if(isset($n)) {$__VAR_DUMP_MOD_item_addarea_VARS_n = $n; } else {$__VAR_DUMP_MOD_item_addarea_VARS_n = NULL;} if(isset($k)) {$__VAR_DUMP_MOD_item_addarea_VARS_k = $k; } else {$__VAR_DUMP_MOD_item_addarea_VARS_k = NULL;} if(isset($e)) {$__VAR_DUMP_MOD_item_addarea_VARS_e = $e; } else {$__VAR_DUMP_MOD_item_addarea_VARS_e = NULL;} if(isset($s)) {$__VAR_DUMP_MOD_item_addarea_VARS_s = $s; } else {$__VAR_DUMP_MOD_item_addarea_VARS_s = NULL;} if(isset($sk)) {$__VAR_DUMP_MOD_item_addarea_VARS_sk = $sk; } else {$__VAR_DUMP_MOD_item_addarea_VARS_sk = NULL;} 
		//======== Start of contents from mod item_uee ========
		do{
			$___TMP_MOD_item_uee_FUNC_parse_itmuse_desc_RET = NULL;
if(isset($n)) {$__VAR_DUMP_MOD_item_uee_VARS_n = $n; } else {$__VAR_DUMP_MOD_item_uee_VARS_n = NULL;} if(isset($k)) {$__VAR_DUMP_MOD_item_uee_VARS_k = $k; } else {$__VAR_DUMP_MOD_item_uee_VARS_k = NULL;} if(isset($e)) {$__VAR_DUMP_MOD_item_uee_VARS_e = $e; } else {$__VAR_DUMP_MOD_item_uee_VARS_e = NULL;} if(isset($s)) {$__VAR_DUMP_MOD_item_uee_VARS_s = $s; } else {$__VAR_DUMP_MOD_item_uee_VARS_s = NULL;} if(isset($sk)) {$__VAR_DUMP_MOD_item_uee_VARS_sk = $sk; } else {$__VAR_DUMP_MOD_item_uee_VARS_sk = NULL;} 
		//======== Start of contents from mod itemmain ========
		do{
			$___TMP_MOD_itemmain_FUNC_parse_itmuse_desc_RET = NULL;

		
		$___TMP_MOD_itemmain_FUNC_parse_itmuse_desc_RET =  '';
			break; 
		}while(0);
		//======== End of contents from mod itemmain ========

$n = $__VAR_DUMP_MOD_item_uee_VARS_n; unset($__VAR_DUMP_MOD_item_uee_VARS_n);$k = $__VAR_DUMP_MOD_item_uee_VARS_k; unset($__VAR_DUMP_MOD_item_uee_VARS_k);$e = $__VAR_DUMP_MOD_item_uee_VARS_e; unset($__VAR_DUMP_MOD_item_uee_VARS_e);$s = $__VAR_DUMP_MOD_item_uee_VARS_s; unset($__VAR_DUMP_MOD_item_uee_VARS_s);$sk = $__VAR_DUMP_MOD_item_uee_VARS_sk; unset($__VAR_DUMP_MOD_item_uee_VARS_sk);

		
		$ret = $___TMP_MOD_itemmain_FUNC_parse_itmuse_desc_RET;
		if(strpos($k,'EE')===0) {
			$ret .= '可干扰虚拟幻境系统。<br>如果成功，所有禁区解除，直到下一次增加禁区为止。<br>注意：不论成功与否，都有被反击代码反杀的风险。';
		}
		$___TMP_MOD_item_uee_FUNC_parse_itmuse_desc_RET =  $ret;
			break; 
		}while(0);
		//======== End of contents from mod item_uee ========

$n = $__VAR_DUMP_MOD_item_addarea_VARS_n; unset($__VAR_DUMP_MOD_item_addarea_VARS_n);$k = $__VAR_DUMP_MOD_item_addarea_VARS_k; unset($__VAR_DUMP_MOD_item_addarea_VARS_k);$e = $__VAR_DUMP_MOD_item_addarea_VARS_e; unset($__VAR_DUMP_MOD_item_addarea_VARS_e);$s = $__VAR_DUMP_MOD_item_addarea_VARS_s; unset($__VAR_DUMP_MOD_item_addarea_VARS_s);$sk = $__VAR_DUMP_MOD_item_addarea_VARS_sk; unset($__VAR_DUMP_MOD_item_addarea_VARS_sk);

		
		$ret = $___TMP_MOD_item_uee_FUNC_parse_itmuse_desc_RET;
		if(strpos($k,'Y')===0 || strpos($k,'Z')===0){
			do { global $___LOCAL_ITEM_ADDAREA__VARS__item_addarea_nlist,$___LOCAL_ITEM_ADDAREA__VARS__item_delayarea_nlist; $item_addarea_nlist=&$___LOCAL_ITEM_ADDAREA__VARS__item_addarea_nlist; $item_delayarea_nlist=&$___LOCAL_ITEM_ADDAREA__VARS__item_delayarea_nlist;   } while (0);
			if (in_array($n, $item_addarea_nlist)){
				$ret .= '使用后会将下次禁区时间提前到1分钟以后';
			}elseif(in_array($n, $item_delayarea_nlist)){
				$ret .= '使用后会将下次禁区时间延迟30分钟';
			}
		}
		$___TMP_MOD_item_addarea_FUNC_parse_itmuse_desc_RET =  $ret;
			break; 
		}while(0);
		//======== End of contents from mod item_addarea ========

$n = $__VAR_DUMP_MOD_trap_VARS_n; unset($__VAR_DUMP_MOD_trap_VARS_n);$k = $__VAR_DUMP_MOD_trap_VARS_k; unset($__VAR_DUMP_MOD_trap_VARS_k);$e = $__VAR_DUMP_MOD_trap_VARS_e; unset($__VAR_DUMP_MOD_trap_VARS_e);$s = $__VAR_DUMP_MOD_trap_VARS_s; unset($__VAR_DUMP_MOD_trap_VARS_s);$sk = $__VAR_DUMP_MOD_trap_VARS_sk; unset($__VAR_DUMP_MOD_trap_VARS_sk);

		
		$ret = $___TMP_MOD_item_addarea_FUNC_parse_itmuse_desc_RET;
		if(strpos($k,'TNc')===0 || strpos($k,'TOc')===0) {
			$ret .= '埋设后拥有必杀效果';
		}elseif(strpos($k,'T')===0){
			$theitem = Array('itm' => $n, 'itmk' => $k, 'itme' => $e, 'itms' => $s, 'itmsk' => $sk);
			$trape = \trap\get_trap_itme_limit ($theitem);
			$ret .= '埋设后效果值为'.$trape;
		}
		$___TMP_MOD_trap_FUNC_parse_itmuse_desc_RET =  $ret;
			break; 
		}while(0);
		//======== End of contents from mod trap ========

$n = $__VAR_DUMP_MOD_item_misc_VARS_n; unset($__VAR_DUMP_MOD_item_misc_VARS_n);$k = $__VAR_DUMP_MOD_item_misc_VARS_k; unset($__VAR_DUMP_MOD_item_misc_VARS_k);$e = $__VAR_DUMP_MOD_item_misc_VARS_e; unset($__VAR_DUMP_MOD_item_misc_VARS_e);$s = $__VAR_DUMP_MOD_item_misc_VARS_s; unset($__VAR_DUMP_MOD_item_misc_VARS_s);$sk = $__VAR_DUMP_MOD_item_misc_VARS_sk; unset($__VAR_DUMP_MOD_item_misc_VARS_sk);

		
		$ret = $___TMP_MOD_trap_FUNC_parse_itmuse_desc_RET;
		
		if(strpos($k,'Y')===0 || strpos($k,'Z')===0){
			if ($n == '凸眼鱼'){
				$ret .= '使用后可以销毁整个战场现有的尸体';
			}elseif ($n == '■DeathNote■') {
				$ret .= '填入玩家的名字和头像就可以直接杀死该玩家';
			}elseif ($n == '游戏解除钥匙') {
				$ret .= '使用后达成『锁定解除』胜利';
			}elseif ($n == '奇怪的按钮') {
				$ret .= '警告：极度危险！';
			}elseif ($n == '『C.H.A.O.S』') {
				$ret .= '献祭包裹里的全部物品以获得通往『幻境解离』的必备道具。需要持有黑色发卡，当前歌魂不少于233点，且击杀玩家数不能过多。';
			}elseif ($n == '『S.C.R.A.P』') {
				$ret .= '还不满足『幻境解离』的条件！使用后可以恢复成『C.H.A.O.S』';
			}elseif ($n == '『G.A.M.E.O.V.E.R』') {
				$ret .= '使用后达成『幻境解离』胜利';
			}elseif ($n == '杏仁豆腐的ID卡') {
				$ret .= '连斗后使用可以让全场NPC消失并进入『死斗阶段』';
			}elseif (strpos($n,'水果刀')!==false) {
				$ret .= '可以切水果，视你的斩系熟练度决定生成补给还是水果皮';
			}
		}
		$___TMP_MOD_item_misc_FUNC_parse_itmuse_desc_RET =  $ret;
			break; 
		}while(0);
		//======== End of contents from mod item_misc ========

$n = $__VAR_DUMP_MOD_item_uv_VARS_n; unset($__VAR_DUMP_MOD_item_uv_VARS_n);$k = $__VAR_DUMP_MOD_item_uv_VARS_k; unset($__VAR_DUMP_MOD_item_uv_VARS_k);$e = $__VAR_DUMP_MOD_item_uv_VARS_e; unset($__VAR_DUMP_MOD_item_uv_VARS_e);$s = $__VAR_DUMP_MOD_item_uv_VARS_s; unset($__VAR_DUMP_MOD_item_uv_VARS_s);$sk = $__VAR_DUMP_MOD_item_uv_VARS_sk; unset($__VAR_DUMP_MOD_item_uv_VARS_sk);

		
		$ret = $___TMP_MOD_item_misc_FUNC_parse_itmuse_desc_RET;
		if ((strpos($k,'V')===0) && (strpos($k,'S')!==false)){
			do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;   } while (0);
			if(!empty($clubskillname[$sk])){
				$ret .= '使用后获得技能「'.$clubskillname[$sk].'」';
			}
			if ($sk == '249'){
				$ret .= '：埋设陷阱伤害增加';
			}elseif ($sk == '250') {
				$ret .= '：受到陷阱伤害减少';
			}elseif ($sk == '723') {
				$ret .= '：射系武器弹夹翻倍且自动装填弹药';
			}elseif ($sk == '738') {
				$ret .= '：可以选择减少移动和探索体力消耗，或增加移动和探索体力消耗并减少冷却时间';
			}elseif ($sk == '739') {
				$ret .= '：可用歌魂交换空歌魂上限';
			}
		}
		$___TMP_MOD_item_uv_FUNC_parse_itmuse_desc_RET =  $ret;
			break; 
		}while(0);
		//======== End of contents from mod item_uv ========

$n = $__VAR_DUMP_MOD_item_slip_VARS_n; unset($__VAR_DUMP_MOD_item_slip_VARS_n);$k = $__VAR_DUMP_MOD_item_slip_VARS_k; unset($__VAR_DUMP_MOD_item_slip_VARS_k);$e = $__VAR_DUMP_MOD_item_slip_VARS_e; unset($__VAR_DUMP_MOD_item_slip_VARS_e);$s = $__VAR_DUMP_MOD_item_slip_VARS_s; unset($__VAR_DUMP_MOD_item_slip_VARS_s);$sk = $__VAR_DUMP_MOD_item_slip_VARS_sk; unset($__VAR_DUMP_MOD_item_slip_VARS_sk);

		
		$ret = $___TMP_MOD_item_uv_FUNC_parse_itmuse_desc_RET;
		if(('Y' == $k || 'Z' == $k) && strpos($n,'提示纸条') === 0) {
			$ret .= '这是林苍月安放的纸条。除了基础提示之外，似乎还有别的作用。';
		}
		$___TMP_MOD_item_slip_FUNC_parse_itmuse_desc_RET =  $ret;
			break; 
		}while(0);
		//======== End of contents from mod item_slip ========

$n = $__VAR_DUMP_MOD_addnpc_VARS_n; unset($__VAR_DUMP_MOD_addnpc_VARS_n);$k = $__VAR_DUMP_MOD_addnpc_VARS_k; unset($__VAR_DUMP_MOD_addnpc_VARS_k);$e = $__VAR_DUMP_MOD_addnpc_VARS_e; unset($__VAR_DUMP_MOD_addnpc_VARS_e);$s = $__VAR_DUMP_MOD_addnpc_VARS_s; unset($__VAR_DUMP_MOD_addnpc_VARS_s);$sk = $__VAR_DUMP_MOD_addnpc_VARS_sk; unset($__VAR_DUMP_MOD_addnpc_VARS_sk);

		
		$ret = $___TMP_MOD_item_slip_FUNC_parse_itmuse_desc_RET;
		if(strpos($k,'Y')===0 || strpos($k,'Z')===0){
			if ($n == '挑战者之印'){
				$ret .= '召唤3名「幻影执行官」进入战场，击败他们能缴获「社员的ID卡」以合成「游戏解除钥匙」';
			}elseif ($n == '破灭之诗') {
				$ret .= '暂时解除禁区，天气变为极光，同时让拟似意识在雏菊之丘登场，通往『幻境解离』的必经之路';
			}elseif ($n == '黑色碎片') {
				$ret .= '召唤「Dark Force幼体」进入战场，把她彻底击倒能缴获「游戏解除钥匙」';
			}
		}
		$___TMP_MOD_addnpc_FUNC_parse_itmuse_desc_RET =  $ret;
			break; 
		}while(0);
		//======== End of contents from mod addnpc ========

$n = $__VAR_DUMP_MOD_skill593_VARS_n; unset($__VAR_DUMP_MOD_skill593_VARS_n);$k = $__VAR_DUMP_MOD_skill593_VARS_k; unset($__VAR_DUMP_MOD_skill593_VARS_k);$e = $__VAR_DUMP_MOD_skill593_VARS_e; unset($__VAR_DUMP_MOD_skill593_VARS_e);$s = $__VAR_DUMP_MOD_skill593_VARS_s; unset($__VAR_DUMP_MOD_skill593_VARS_s);$sk = $__VAR_DUMP_MOD_skill593_VARS_sk; unset($__VAR_DUMP_MOD_skill593_VARS_sk);

		
		$ret = $___TMP_MOD_addnpc_FUNC_parse_itmuse_desc_RET;
		if ($n == '「蝴蝶梦丸」'){
			$ret .= '服用后会精神舒畅';
		}elseif ($n == '「蝴蝶梦丸噩梦」') {
			$ret .= '服用后会噩梦缠身';
		}elseif ($n == '「国士无双之药」') {
			$ret .= '服用后身体会变得强壮，但使用第四次后会发生意外';
		}elseif ($n == '「蓬莱之药」') {
			$ret .= '服用后会受到永生的诅咒';
		}
		$___TMP_MOD_skill593_FUNC_parse_itmuse_desc_RET =  $ret;
			break; 
		}while(0);
		//======== End of contents from mod skill593 ========

$n = $__VAR_DUMP_MOD_item_randskills_VARS_n; unset($__VAR_DUMP_MOD_item_randskills_VARS_n);$k = $__VAR_DUMP_MOD_item_randskills_VARS_k; unset($__VAR_DUMP_MOD_item_randskills_VARS_k);$e = $__VAR_DUMP_MOD_item_randskills_VARS_e; unset($__VAR_DUMP_MOD_item_randskills_VARS_e);$s = $__VAR_DUMP_MOD_item_randskills_VARS_s; unset($__VAR_DUMP_MOD_item_randskills_VARS_s);$sk = $__VAR_DUMP_MOD_item_randskills_VARS_sk; unset($__VAR_DUMP_MOD_item_randskills_VARS_sk);

		
		$ret = $___TMP_MOD_skill593_FUNC_parse_itmuse_desc_RET;
		if (strpos($k,'SC01')===0)
		{
			$ret .= '使用后可以在三个未拥有的随机称号技能中选择一个习得';
		}
		elseif (strpos($k,'SC02')===0)
		{
			$ret .= '使用后可以随机习得一个未拥有的称号技能';
		}
		elseif (strpos($k,'SCC1')===0)
		{
			$ret .= '使用后可以在三个C级技能中选择一个习得';
		}
		elseif (strpos($k,'SCC2')===0)
		{
			$ret .= '使用后可以随机习得一个C级技能';
		}
		elseif (strpos($k,'SCB1')===0)
		{
			$ret .= '使用后可以在三个B级技能中选择一个习得';
		}
		elseif (strpos($k,'SCB2')===0)
		{
			$ret .= '使用后可以随机习得一个B级技能';
		}
		elseif (strpos($k,'SCA1')===0)
		{
			$ret .= '使用后可以在三个A级技能中选择一个习得';
		}
		elseif (strpos($k,'SCA2')===0)
		{
			$ret .= '使用后可以随机习得一个A级技能';
		}
		elseif (strpos($k,'SCS1')===0)
		{
			$ret .= '使用后可以在三个S级技能中选择一个习得';
		}
		elseif (strpos($k,'SCS2')===0)
		{
			$ret .= '使用后可以随机习得一个S级技能';
		}
		elseif (strpos($k,'SCX2')===0)
		{
			$ret .= '使用后可以随机习得一个奇怪的技能';
		}
		elseif(strpos($k,'Y')===0 || strpos($k,'Z')===0)
		{
			if ($n == '四面骰'){
				$ret .= '使用后可以将自己的所有技能替换为随机称号技能';
			}
		}
		$___TMP_MOD_item_randskills_FUNC_parse_itmuse_desc_RET =  $ret;
			break; 
		}while(0);
		//======== End of contents from mod item_randskills ========

$n = $__VAR_DUMP_MOD_item_uu_VARS_n; unset($__VAR_DUMP_MOD_item_uu_VARS_n);$k = $__VAR_DUMP_MOD_item_uu_VARS_k; unset($__VAR_DUMP_MOD_item_uu_VARS_k);$e = $__VAR_DUMP_MOD_item_uu_VARS_e; unset($__VAR_DUMP_MOD_item_uu_VARS_e);$s = $__VAR_DUMP_MOD_item_uu_VARS_s; unset($__VAR_DUMP_MOD_item_uu_VARS_s);$sk = $__VAR_DUMP_MOD_item_uu_VARS_sk; unset($__VAR_DUMP_MOD_item_uu_VARS_sk);

		
		$ret = $___TMP_MOD_item_randskills_FUNC_parse_itmuse_desc_RET;
		if(strpos($k,'U')===0) {
			$ret .= '使用后将随机扫除当前地区的陷阱，效果值累计不超过'.$e.'点。无法扫除某些特殊地雷';
		}
		$___TMP_MOD_item_uu_FUNC_parse_itmuse_desc_RET =  $ret;
			break; 
		}while(0);
		//======== End of contents from mod item_uu ========

$n = $__VAR_DUMP_MOD_song_VARS_n; unset($__VAR_DUMP_MOD_song_VARS_n);$k = $__VAR_DUMP_MOD_song_VARS_k; unset($__VAR_DUMP_MOD_song_VARS_k);$e = $__VAR_DUMP_MOD_song_VARS_e; unset($__VAR_DUMP_MOD_song_VARS_e);$s = $__VAR_DUMP_MOD_song_VARS_s; unset($__VAR_DUMP_MOD_song_VARS_s);$sk = $__VAR_DUMP_MOD_song_VARS_sk; unset($__VAR_DUMP_MOD_song_VARS_sk);

		
		$ret = $___TMP_MOD_item_uu_FUNC_parse_itmuse_desc_RET;
		if(strpos($k,'ss')===0){
			$sn = \song\check_sname ($n);
			switch ($sn) {
				case 'Alicemagic':
					$ret .= '歌唱：使你和同地区玩家的防御力上升30';
					break;
				case 'Crow Song':
					$ret .= '歌唱：使你和同地区玩家的攻击力上升30';
					break;
				case 'KARMA':
					$ret .= '歌唱：使你和同地区玩家的RP变为0';
					break;
				case '驱寒颂歌':
					$ret .= '歌唱：使你和同地区玩家的最大生命、最大体力和金钱上升10，RP下降10';
					break;
				case 'Butterfly':
					$ret .= '歌唱：使你和同地区玩家的生命和体力回复2000（可超出最大值），且武器耐久变为∞';
					break;
				case '小苹果':
					$ret .= '歌唱：使你和同地区玩家的体力下降100，但怒气增加5';
					break;
				case '空想神话':
					$ret .= '歌唱：耗尽歌魂，你和同地区玩家的攻击、防御、生命、体力、怒气、各系熟练、武器和防具耐久随机增加，增加值总和不大于你消耗的歌魂';
					break;
				case 'ぼくのフレンド':
					$ret .= '歌唱：使你和同地区玩家获得技能「朋友」';
					break;
				case '星めぐりの歌':
					$ret .= '歌唱：使你和同地区玩家的射熟和投熟上升30';
					break;
				case 'CANOE':
					$ret .= '歌唱：使你和同地区玩家的爆熟和灵熟上升30';
					break;
				case '遥か彼方':
					$ret .= '歌唱：使你和同地区玩家的殴熟和斩熟上升30';
					break;
				case '雨だれの歌':
					$ret .= '歌唱：使你和同地区玩家的生命上限上升10，体力上限上升50';
					break;
				case 'More One Night':
					$ret .= '歌唱：使你和同地区玩家的最大生命增加，增加值等于场上死亡NPC数，但无法再赢得「最后幸存」胜利';
					break;
				case 'Baba yetu':
					$ret .= '歌唱：使你和同地区玩家获得12点经验值（不会立刻升级）';
					break;
				case 'Clear Morning':
					$ret .= '歌唱：使你和同地区玩家的生命回复1000（可超出最大值）';
					break;
				case 'Never Gonna Give You Up':
					$ret .= '歌唱：使你和同地区玩家的怒气清空，但也有概率变为最大值';
					break;
				case '『勇者』':
					$ret .= '歌唱：使你和同地区玩家的灵熟上升30，其他系熟练度上升5';
					break;
				case '夜雀之歌':
					$ret .= '歌唱：使除你之外的同地区玩家获得暂时的「夜盲」负面状态';
					break;
				default :
					$ret .= '好像不存在这样一首歌呢……';
					break;
			}
		}
		$___TMP_MOD_song_FUNC_parse_itmuse_desc_RET =  $ret;
			break; 
		}while(0);
		//======== End of contents from mod song ========

$n = $__VAR_DUMP_MOD_empowers_VARS_n; unset($__VAR_DUMP_MOD_empowers_VARS_n);$k = $__VAR_DUMP_MOD_empowers_VARS_k; unset($__VAR_DUMP_MOD_empowers_VARS_k);$e = $__VAR_DUMP_MOD_empowers_VARS_e; unset($__VAR_DUMP_MOD_empowers_VARS_e);$s = $__VAR_DUMP_MOD_empowers_VARS_s; unset($__VAR_DUMP_MOD_empowers_VARS_s);$sk = $__VAR_DUMP_MOD_empowers_VARS_sk; unset($__VAR_DUMP_MOD_empowers_VARS_sk);

		
		$ret = $___TMP_MOD_song_FUNC_parse_itmuse_desc_RET;
		if(strpos($k,'Y')===0 || strpos($k,'Z')===0){
			if (\empowers\check_nail ($n)){
				$ret .= '为手中名字带有“棍棒”的钝器打钉子，以增加效果值';
			}elseif (\empowers\check_hone ($n)) {
				$ret .= '让手中锐器更加锋利，以增加效果值';
			}elseif ($n == '针线包') {
				$ret .= '增加装备着的身体防具的效果值';
			}elseif ($n == '武器师安雅的奖赏') {
				$ret .= '强化手中武器的效果值、耐久值，或者将类型转变为你更擅长的系别';
			}
		}elseif(strpos($k,'EI')===0){
			$ret .= '强化手中武器的效果值、耐久值，或者将类型转变为你更擅长的系别';
			if(1==$sk){
				$ret .= '<br>只要武器类型与你最擅长的系不同，则必定改系';
			}elseif(2==$sk){
				$ret .= '<br>武器效果值和耐久值都会额外强化1.5倍';
			}
		}
		$___TMP_MOD_empowers_FUNC_parse_itmuse_desc_RET =  $ret;
			break; 
		}while(0);
		//======== End of contents from mod empowers ========

$n = $__VAR_DUMP_MOD_instance5_VARS_n; unset($__VAR_DUMP_MOD_instance5_VARS_n);$k = $__VAR_DUMP_MOD_instance5_VARS_k; unset($__VAR_DUMP_MOD_instance5_VARS_k);$e = $__VAR_DUMP_MOD_instance5_VARS_e; unset($__VAR_DUMP_MOD_instance5_VARS_e);$s = $__VAR_DUMP_MOD_instance5_VARS_s; unset($__VAR_DUMP_MOD_instance5_VARS_s);$sk = $__VAR_DUMP_MOD_instance5_VARS_sk; unset($__VAR_DUMP_MOD_instance5_VARS_sk);

		
		$ret = $___TMP_MOD_empowers_FUNC_parse_itmuse_desc_RET;
		if(strpos($k,'Y')===0 || strpos($k,'Z')===0){
			if ($n == '伐木解除钥匙') {
				$ret .= '使用后可结束当前局伐木模式';
			}
		}
		$___TMP_MOD_instance5_FUNC_parse_itmuse_desc_RET =  $ret;
			break; 
		}while(0);
		//======== End of contents from mod instance5 ========

$n = $__VAR_DUMP_MOD_logistics_VARS_n; unset($__VAR_DUMP_MOD_logistics_VARS_n);$k = $__VAR_DUMP_MOD_logistics_VARS_k; unset($__VAR_DUMP_MOD_logistics_VARS_k);$e = $__VAR_DUMP_MOD_logistics_VARS_e; unset($__VAR_DUMP_MOD_logistics_VARS_e);$s = $__VAR_DUMP_MOD_logistics_VARS_s; unset($__VAR_DUMP_MOD_logistics_VARS_s);$sk = $__VAR_DUMP_MOD_logistics_VARS_sk; unset($__VAR_DUMP_MOD_logistics_VARS_sk);

		
		$ret = $___TMP_MOD_instance5_FUNC_parse_itmuse_desc_RET;
		if(strpos($k,'Y')===0 || strpos($k,'Z')===0){
			if ($n == '记录用投影底座'){
				$ret .= '可以选择一个包裹中的道具，将它的投影记录到展柜中';
			}
		}
		$___TMP_MOD_logistics_FUNC_parse_itmuse_desc_RET =  $ret;
			break; 
		}while(0);
		//======== End of contents from mod logistics ========

$n = $__VAR_DUMP_MOD_item_ext_armor_VARS_n; unset($__VAR_DUMP_MOD_item_ext_armor_VARS_n);$k = $__VAR_DUMP_MOD_item_ext_armor_VARS_k; unset($__VAR_DUMP_MOD_item_ext_armor_VARS_k);$e = $__VAR_DUMP_MOD_item_ext_armor_VARS_e; unset($__VAR_DUMP_MOD_item_ext_armor_VARS_e);$s = $__VAR_DUMP_MOD_item_ext_armor_VARS_s; unset($__VAR_DUMP_MOD_item_ext_armor_VARS_s);$sk = $__VAR_DUMP_MOD_item_ext_armor_VARS_sk; unset($__VAR_DUMP_MOD_item_ext_armor_VARS_sk);

		
		$ret = $___TMP_MOD_logistics_FUNC_parse_itmuse_desc_RET;
		if ((strpos($k, 'D') === 0) && (strpos(substr($k, 2), 'S') !== false))
		{
			$ret .= '这一防具可以叠加装备在相同位置的防具上';
		}
		$___TMP_MOD_item_ext_armor_FUNC_parse_itmuse_desc_RET =  $ret;
			break; 
		}while(0);
		//======== End of contents from mod item_ext_armor ========

$n = $__VAR_DUMP_MOD_item_armor_empower_VARS_n; unset($__VAR_DUMP_MOD_item_armor_empower_VARS_n);$k = $__VAR_DUMP_MOD_item_armor_empower_VARS_k; unset($__VAR_DUMP_MOD_item_armor_empower_VARS_k);$e = $__VAR_DUMP_MOD_item_armor_empower_VARS_e; unset($__VAR_DUMP_MOD_item_armor_empower_VARS_e);$s = $__VAR_DUMP_MOD_item_armor_empower_VARS_s; unset($__VAR_DUMP_MOD_item_armor_empower_VARS_s);$sk = $__VAR_DUMP_MOD_item_armor_empower_VARS_sk; unset($__VAR_DUMP_MOD_item_armor_empower_VARS_sk);
		
		$ret = $___TMP_MOD_item_ext_armor_FUNC_parse_itmuse_desc_RET;
		if(strpos($k,'EA')===0){
			$ret .= '使防具获得额外的属性，或者使其发生神秘的变化';
		}
		return $ret;
	
	}
	
	function use_armor_empower($itmn = 0)
	{
		return \skill505\use_armor_empower($itmn);
	}
	
	function armor_empower(&$theitem, &$empitem)
	{
		
		
		$emp = & $empitem['itm'];
		
		$itm = & $theitem['itm'];
		$itme = & $theitem['itme'];
		$itms = & $theitem['itms'];
		$itmk = & $theitem['itmk'];
		$itmsk = & $theitem['itmsk'];
		
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;  global $___LOCAL_PLAYER__VARS__ss,$___LOCAL_PLAYER__VARS__db_player_structure,$___LOCAL_PLAYER__VARS__db_player_structure_types,$___LOCAL_PLAYER__VARS__gamedata,$___LOCAL_PLAYER__VARS__cmd,$___LOCAL_PLAYER__VARS__main,$___LOCAL_PLAYER__VARS__sdata,$___LOCAL_PLAYER__VARS__fog,$___LOCAL_PLAYER__VARS__upexp,$___LOCAL_PLAYER__VARS__lvlupexp, $___LOCAL_PLAYER__VARS__iconImg,$___LOCAL_PLAYER__VARS__iconImgB,$___LOCAL_PLAYER__VARS__iconImgBwidth,$___LOCAL_PLAYER__VARS__ardef,$___LOCAL_PLAYER__VARS__hpcolor,$___LOCAL_PLAYER__VARS__spcolor,$___LOCAL_PLAYER__VARS__newhpimg,$___LOCAL_PLAYER__VARS__newspimg,$___LOCAL_PLAYER__VARS__splt,$___LOCAL_PLAYER__VARS__hplt, $___LOCAL_PLAYER__VARS__tpldata,$___LOCAL_PLAYER__VARS__icon_list,$___LOCAL_PLAYER__VARS__icon_list_contents_to_frontend,$___LOCAL_PLAYER__VARS__typeinfo,$___LOCAL_PLAYER__VARS__killmsginfo,$___LOCAL_PLAYER__VARS__lwinfo,$___LOCAL_PLAYER__VARS__sexinfo,$___LOCAL_PLAYER__VARS__equip_list,$___LOCAL_PLAYER__VARS__battle_equip_list,$___LOCAL_PLAYER__VARS__pc_icon_range, $___LOCAL_PLAYER__VARS__pid,$___LOCAL_PLAYER__VARS__type,$___LOCAL_PLAYER__VARS__name,$___LOCAL_PLAYER__VARS__pass,$___LOCAL_PLAYER__VARS__ip,$___LOCAL_PLAYER__VARS__motto,$___LOCAL_PLAYER__VARS__killmsg,$___LOCAL_PLAYER__VARS__lastword,$___LOCAL_PLAYER__VARS__winner_flag,$___LOCAL_PLAYER__VARS__player_dead_flag, $___LOCAL_PLAYER__VARS__corpse_clear_flag,$___LOCAL_PLAYER__VARS__gd,$___LOCAL_PLAYER__VARS__sNo,$___LOCAL_PLAYER__VARS__club,$___LOCAL_PLAYER__VARS__validtime,$___LOCAL_PLAYER__VARS__endtime,$___LOCAL_PLAYER__VARS__cdsec,$___LOCAL_PLAYER__VARS__cdmsec,$___LOCAL_PLAYER__VARS__cdtime,$___LOCAL_PLAYER__VARS__action, $___LOCAL_PLAYER__VARS__a_actionnum,$___LOCAL_PLAYER__VARS__v_actionnum,$___LOCAL_PLAYER__VARS__hp,$___LOCAL_PLAYER__VARS__mhp,$___LOCAL_PLAYER__VARS__sp,$___LOCAL_PLAYER__VARS__msp,$___LOCAL_PLAYER__VARS__mss,$___LOCAL_PLAYER__VARS__att,$___LOCAL_PLAYER__VARS__def,$___LOCAL_PLAYER__VARS__pls, $___LOCAL_PLAYER__VARS__lvl,$___LOCAL_PLAYER__VARS__exp,$___LOCAL_PLAYER__VARS__money,$___LOCAL_PLAYER__VARS__rp,$___LOCAL_PLAYER__VARS__bid,$___LOCAL_PLAYER__VARS__inf,$___LOCAL_PLAYER__VARS__rage,$___LOCAL_PLAYER__VARS__pose,$___LOCAL_PLAYER__VARS__tactic,$___LOCAL_PLAYER__VARS__killnum, $___LOCAL_PLAYER__VARS__npckillnum,$___LOCAL_PLAYER__VARS__state,$___LOCAL_PLAYER__VARS__skillpoint,$___LOCAL_PLAYER__VARS__flare,$___LOCAL_PLAYER__VARS__wp,$___LOCAL_PLAYER__VARS__wk,$___LOCAL_PLAYER__VARS__wg,$___LOCAL_PLAYER__VARS__wc,$___LOCAL_PLAYER__VARS__wd,$___LOCAL_PLAYER__VARS__wf, $___LOCAL_PLAYER__VARS__icon,$___LOCAL_PLAYER__VARS__teamID,$___LOCAL_PLAYER__VARS__teamPass,$___LOCAL_PLAYER__VARS__card,$___LOCAL_PLAYER__VARS__cardname,$___LOCAL_PLAYER__VARS__wep,$___LOCAL_PLAYER__VARS__wepk,$___LOCAL_PLAYER__VARS__wepe,$___LOCAL_PLAYER__VARS__weps,$___LOCAL_PLAYER__VARS__wepsk, $___LOCAL_PLAYER__VARS__arb,$___LOCAL_PLAYER__VARS__arbk,$___LOCAL_PLAYER__VARS__arbe,$___LOCAL_PLAYER__VARS__arbs,$___LOCAL_PLAYER__VARS__arbsk,$___LOCAL_PLAYER__VARS__arh,$___LOCAL_PLAYER__VARS__arhk,$___LOCAL_PLAYER__VARS__arhe,$___LOCAL_PLAYER__VARS__arhs,$___LOCAL_PLAYER__VARS__arhsk, $___LOCAL_PLAYER__VARS__ara,$___LOCAL_PLAYER__VARS__arak,$___LOCAL_PLAYER__VARS__arae,$___LOCAL_PLAYER__VARS__aras,$___LOCAL_PLAYER__VARS__arask,$___LOCAL_PLAYER__VARS__arf,$___LOCAL_PLAYER__VARS__arfk,$___LOCAL_PLAYER__VARS__arfe,$___LOCAL_PLAYER__VARS__arfs,$___LOCAL_PLAYER__VARS__arfsk, $___LOCAL_PLAYER__VARS__art,$___LOCAL_PLAYER__VARS__artk,$___LOCAL_PLAYER__VARS__arte,$___LOCAL_PLAYER__VARS__arts,$___LOCAL_PLAYER__VARS__artsk,$___LOCAL_PLAYER__VARS__itm0,$___LOCAL_PLAYER__VARS__itmk0,$___LOCAL_PLAYER__VARS__itme0,$___LOCAL_PLAYER__VARS__itms0,$___LOCAL_PLAYER__VARS__itmsk0, $___LOCAL_PLAYER__VARS__itm1,$___LOCAL_PLAYER__VARS__itmk1,$___LOCAL_PLAYER__VARS__itme1,$___LOCAL_PLAYER__VARS__itms1,$___LOCAL_PLAYER__VARS__itmsk1,$___LOCAL_PLAYER__VARS__itm2,$___LOCAL_PLAYER__VARS__itmk2,$___LOCAL_PLAYER__VARS__itme2,$___LOCAL_PLAYER__VARS__itms2,$___LOCAL_PLAYER__VARS__itmsk2, $___LOCAL_PLAYER__VARS__itm3,$___LOCAL_PLAYER__VARS__itmk3,$___LOCAL_PLAYER__VARS__itme3,$___LOCAL_PLAYER__VARS__itms3,$___LOCAL_PLAYER__VARS__itmsk3,$___LOCAL_PLAYER__VARS__itm4,$___LOCAL_PLAYER__VARS__itmk4,$___LOCAL_PLAYER__VARS__itme4,$___LOCAL_PLAYER__VARS__itms4,$___LOCAL_PLAYER__VARS__itmsk4, $___LOCAL_PLAYER__VARS__itm5,$___LOCAL_PLAYER__VARS__itmk5,$___LOCAL_PLAYER__VARS__itme5,$___LOCAL_PLAYER__VARS__itms5,$___LOCAL_PLAYER__VARS__itmsk5,$___LOCAL_PLAYER__VARS__itm6,$___LOCAL_PLAYER__VARS__itmk6,$___LOCAL_PLAYER__VARS__itme6,$___LOCAL_PLAYER__VARS__itms6,$___LOCAL_PLAYER__VARS__itmsk6, $___LOCAL_PLAYER__VARS__searchmemory,$___LOCAL_PLAYER__VARS__nskill,$___LOCAL_PLAYER__VARS__nskillpara; $ss=&$___LOCAL_PLAYER__VARS__ss; $db_player_structure=&$___LOCAL_PLAYER__VARS__db_player_structure; $db_player_structure_types=&$___LOCAL_PLAYER__VARS__db_player_structure_types; $gamedata=&$___LOCAL_PLAYER__VARS__gamedata; $cmd=&$___LOCAL_PLAYER__VARS__cmd; $main=&$___LOCAL_PLAYER__VARS__main; $sdata=&$___LOCAL_PLAYER__VARS__sdata; $fog=&$___LOCAL_PLAYER__VARS__fog; $upexp=&$___LOCAL_PLAYER__VARS__upexp; $lvlupexp=&$___LOCAL_PLAYER__VARS__lvlupexp;  $iconImg=&$___LOCAL_PLAYER__VARS__iconImg; $iconImgB=&$___LOCAL_PLAYER__VARS__iconImgB; $iconImgBwidth=&$___LOCAL_PLAYER__VARS__iconImgBwidth; $ardef=&$___LOCAL_PLAYER__VARS__ardef; $hpcolor=&$___LOCAL_PLAYER__VARS__hpcolor; $spcolor=&$___LOCAL_PLAYER__VARS__spcolor; $newhpimg=&$___LOCAL_PLAYER__VARS__newhpimg; $newspimg=&$___LOCAL_PLAYER__VARS__newspimg; $splt=&$___LOCAL_PLAYER__VARS__splt; $hplt=&$___LOCAL_PLAYER__VARS__hplt;  $tpldata=&$___LOCAL_PLAYER__VARS__tpldata; $icon_list=&$___LOCAL_PLAYER__VARS__icon_list; $icon_list_contents_to_frontend=&$___LOCAL_PLAYER__VARS__icon_list_contents_to_frontend; $typeinfo=&$___LOCAL_PLAYER__VARS__typeinfo; $killmsginfo=&$___LOCAL_PLAYER__VARS__killmsginfo; $lwinfo=&$___LOCAL_PLAYER__VARS__lwinfo; $sexinfo=&$___LOCAL_PLAYER__VARS__sexinfo; $equip_list=&$___LOCAL_PLAYER__VARS__equip_list; $battle_equip_list=&$___LOCAL_PLAYER__VARS__battle_equip_list; $pc_icon_range=&$___LOCAL_PLAYER__VARS__pc_icon_range;  $pid=&$___LOCAL_PLAYER__VARS__pid; $type=&$___LOCAL_PLAYER__VARS__type; $name=&$___LOCAL_PLAYER__VARS__name; $pass=&$___LOCAL_PLAYER__VARS__pass; $ip=&$___LOCAL_PLAYER__VARS__ip; $motto=&$___LOCAL_PLAYER__VARS__motto; $killmsg=&$___LOCAL_PLAYER__VARS__killmsg; $lastword=&$___LOCAL_PLAYER__VARS__lastword; $winner_flag=&$___LOCAL_PLAYER__VARS__winner_flag; $player_dead_flag=&$___LOCAL_PLAYER__VARS__player_dead_flag;  $corpse_clear_flag=&$___LOCAL_PLAYER__VARS__corpse_clear_flag; $gd=&$___LOCAL_PLAYER__VARS__gd; $sNo=&$___LOCAL_PLAYER__VARS__sNo; $club=&$___LOCAL_PLAYER__VARS__club; $validtime=&$___LOCAL_PLAYER__VARS__validtime; $endtime=&$___LOCAL_PLAYER__VARS__endtime; $cdsec=&$___LOCAL_PLAYER__VARS__cdsec; $cdmsec=&$___LOCAL_PLAYER__VARS__cdmsec; $cdtime=&$___LOCAL_PLAYER__VARS__cdtime; $action=&$___LOCAL_PLAYER__VARS__action;  $a_actionnum=&$___LOCAL_PLAYER__VARS__a_actionnum; $v_actionnum=&$___LOCAL_PLAYER__VARS__v_actionnum; $hp=&$___LOCAL_PLAYER__VARS__hp; $mhp=&$___LOCAL_PLAYER__VARS__mhp; $sp=&$___LOCAL_PLAYER__VARS__sp; $msp=&$___LOCAL_PLAYER__VARS__msp; $mss=&$___LOCAL_PLAYER__VARS__mss; $att=&$___LOCAL_PLAYER__VARS__att; $def=&$___LOCAL_PLAYER__VARS__def; $pls=&$___LOCAL_PLAYER__VARS__pls;  $lvl=&$___LOCAL_PLAYER__VARS__lvl; $exp=&$___LOCAL_PLAYER__VARS__exp; $money=&$___LOCAL_PLAYER__VARS__money; $rp=&$___LOCAL_PLAYER__VARS__rp; $bid=&$___LOCAL_PLAYER__VARS__bid; $inf=&$___LOCAL_PLAYER__VARS__inf; $rage=&$___LOCAL_PLAYER__VARS__rage; $pose=&$___LOCAL_PLAYER__VARS__pose; $tactic=&$___LOCAL_PLAYER__VARS__tactic; $killnum=&$___LOCAL_PLAYER__VARS__killnum;  $npckillnum=&$___LOCAL_PLAYER__VARS__npckillnum; $state=&$___LOCAL_PLAYER__VARS__state; $skillpoint=&$___LOCAL_PLAYER__VARS__skillpoint; $flare=&$___LOCAL_PLAYER__VARS__flare; $wp=&$___LOCAL_PLAYER__VARS__wp; $wk=&$___LOCAL_PLAYER__VARS__wk; $wg=&$___LOCAL_PLAYER__VARS__wg; $wc=&$___LOCAL_PLAYER__VARS__wc; $wd=&$___LOCAL_PLAYER__VARS__wd; $wf=&$___LOCAL_PLAYER__VARS__wf;  $icon=&$___LOCAL_PLAYER__VARS__icon; $teamID=&$___LOCAL_PLAYER__VARS__teamID; $teamPass=&$___LOCAL_PLAYER__VARS__teamPass; $card=&$___LOCAL_PLAYER__VARS__card; $cardname=&$___LOCAL_PLAYER__VARS__cardname; $wep=&$___LOCAL_PLAYER__VARS__wep; $wepk=&$___LOCAL_PLAYER__VARS__wepk; $wepe=&$___LOCAL_PLAYER__VARS__wepe; $weps=&$___LOCAL_PLAYER__VARS__weps; $wepsk=&$___LOCAL_PLAYER__VARS__wepsk;  $arb=&$___LOCAL_PLAYER__VARS__arb; $arbk=&$___LOCAL_PLAYER__VARS__arbk; $arbe=&$___LOCAL_PLAYER__VARS__arbe; $arbs=&$___LOCAL_PLAYER__VARS__arbs; $arbsk=&$___LOCAL_PLAYER__VARS__arbsk; $arh=&$___LOCAL_PLAYER__VARS__arh; $arhk=&$___LOCAL_PLAYER__VARS__arhk; $arhe=&$___LOCAL_PLAYER__VARS__arhe; $arhs=&$___LOCAL_PLAYER__VARS__arhs; $arhsk=&$___LOCAL_PLAYER__VARS__arhsk;  $ara=&$___LOCAL_PLAYER__VARS__ara; $arak=&$___LOCAL_PLAYER__VARS__arak; $arae=&$___LOCAL_PLAYER__VARS__arae; $aras=&$___LOCAL_PLAYER__VARS__aras; $arask=&$___LOCAL_PLAYER__VARS__arask; $arf=&$___LOCAL_PLAYER__VARS__arf; $arfk=&$___LOCAL_PLAYER__VARS__arfk; $arfe=&$___LOCAL_PLAYER__VARS__arfe; $arfs=&$___LOCAL_PLAYER__VARS__arfs; $arfsk=&$___LOCAL_PLAYER__VARS__arfsk;  $art=&$___LOCAL_PLAYER__VARS__art; $artk=&$___LOCAL_PLAYER__VARS__artk; $arte=&$___LOCAL_PLAYER__VARS__arte; $arts=&$___LOCAL_PLAYER__VARS__arts; $artsk=&$___LOCAL_PLAYER__VARS__artsk; $itm0=&$___LOCAL_PLAYER__VARS__itm0; $itmk0=&$___LOCAL_PLAYER__VARS__itmk0; $itme0=&$___LOCAL_PLAYER__VARS__itme0; $itms0=&$___LOCAL_PLAYER__VARS__itms0; $itmsk0=&$___LOCAL_PLAYER__VARS__itmsk0;  $itm1=&$___LOCAL_PLAYER__VARS__itm1; $itmk1=&$___LOCAL_PLAYER__VARS__itmk1; $itme1=&$___LOCAL_PLAYER__VARS__itme1; $itms1=&$___LOCAL_PLAYER__VARS__itms1; $itmsk1=&$___LOCAL_PLAYER__VARS__itmsk1; $itm2=&$___LOCAL_PLAYER__VARS__itm2; $itmk2=&$___LOCAL_PLAYER__VARS__itmk2; $itme2=&$___LOCAL_PLAYER__VARS__itme2; $itms2=&$___LOCAL_PLAYER__VARS__itms2; $itmsk2=&$___LOCAL_PLAYER__VARS__itmsk2;  $itm3=&$___LOCAL_PLAYER__VARS__itm3; $itmk3=&$___LOCAL_PLAYER__VARS__itmk3; $itme3=&$___LOCAL_PLAYER__VARS__itme3; $itms3=&$___LOCAL_PLAYER__VARS__itms3; $itmsk3=&$___LOCAL_PLAYER__VARS__itmsk3; $itm4=&$___LOCAL_PLAYER__VARS__itm4; $itmk4=&$___LOCAL_PLAYER__VARS__itmk4; $itme4=&$___LOCAL_PLAYER__VARS__itme4; $itms4=&$___LOCAL_PLAYER__VARS__itms4; $itmsk4=&$___LOCAL_PLAYER__VARS__itmsk4;  $itm5=&$___LOCAL_PLAYER__VARS__itm5; $itmk5=&$___LOCAL_PLAYER__VARS__itmk5; $itme5=&$___LOCAL_PLAYER__VARS__itme5; $itms5=&$___LOCAL_PLAYER__VARS__itms5; $itmsk5=&$___LOCAL_PLAYER__VARS__itmsk5; $itm6=&$___LOCAL_PLAYER__VARS__itm6; $itmk6=&$___LOCAL_PLAYER__VARS__itmk6; $itme6=&$___LOCAL_PLAYER__VARS__itme6; $itms6=&$___LOCAL_PLAYER__VARS__itms6; $itmsk6=&$___LOCAL_PLAYER__VARS__itmsk6;  $searchmemory=&$___LOCAL_PLAYER__VARS__searchmemory; $nskill=&$___LOCAL_PLAYER__VARS__nskill; $nskillpara=&$___LOCAL_PLAYER__VARS__nskillpara;  global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;  global $___LOCAL_ARMOR__VARS__nosta,$___LOCAL_ARMOR__VARS__noarb,$___LOCAL_ARMOR__VARS__armor_equip_list,$___LOCAL_ARMOR__VARS__armor_iteminfo; $nosta=&$___LOCAL_ARMOR__VARS__nosta; $noarb=&$___LOCAL_ARMOR__VARS__noarb; $armor_equip_list=&$___LOCAL_ARMOR__VARS__armor_equip_list; $armor_iteminfo=&$___LOCAL_ARMOR__VARS__armor_iteminfo;   } while (0);
		$log .= "你使用了<span class=\"yellow b\">$emp</span>，";
		$dice = rand(0, 99);
		if ($dice < 30 && strpos(substr($itmk,2),'S') === false)
		{
			
			$itmk = substr($itmk, 0, 2).'S'.substr($itmk, 2);
			$log .= "将<span class=\"yellow b\">{$itm}</span>改造成了一件外甲！";
		}
		elseif ($dice < 60)
		{
			
			$hu_up = (int)(min($itme/2, $mhp/2));
			$hu_value = \itemmain\check_in_itmsk('^hu', $itmsk);
			if ($hu_value)
			{
				$hu_value = (int)$hu_value + $hu_up;
				$itmsk = \itemmain\replace_in_itmsk('^hu', '^hu'.$hu_value, $itmsk);
			}
			else $itmsk .= '^hu'.$hu_up;
			$log .= "使<span class=\"yellow b\">{$itm}</span>变得更加坚韧、牢靠了！";
		}
		else
		{
			
			
			$count = rand(3,5);
			do { global $___LOCAL_ITEM_ARMOR_EMPOWER__VARS__ea_itmsk; $ea_itmsk=&$___LOCAL_ITEM_ARMOR_EMPOWER__VARS__ea_itmsk;   } while (0);
			$i = 0;
			if (rand(0,3) < 1)
			{
				$tmpsk = array_randompick($ea_itmsk['sup']);
				if (!\itemmain\check_in_itmsk($tmpsk, $itmsk))
				{
					$itmsk .= $tmpsk;
					$i += 1;
				}
			}
			if (rand(0,2) < 1)
			{
				$tmpsk = array_randompick($ea_itmsk['misc']);
				if (!\itemmain\check_in_itmsk($tmpsk, $itmsk))
				{
					$itmsk .= $tmpsk;
					$i += 1;
				}
			}
			$def_nonexist = array_diff($ea_itmsk['def'], \itemmain\get_itmsk_array($itmsk));
			shuffle($def_nonexist);
			foreach($def_nonexist as $key)
			{
				$itmsk .= $key;
				$i += 1;
				if ($i >= $count) break;
			}
			
			if ($i > 0) $log .= "使<span class=\"yellow b\">{$itm}</span>获得了额外的防御属性！";
			else
			{
				$itme += ceil($itme/2);
				if ($nosta !== $itms) $itms += ceil($itms/2);
				$log .= "增强了<span class=\"yellow b\">{$itm}</span>的效果和耐久！";
			}
		}	
		addnews($now, 'armorempower', $name, $emp, $itm);
		if (strpos($itm, '-改') === false) {
			$itm = $itm.'-改';
		}
		\itemmain\itms_reduce($empitem);
	}
	
	function itemuse(&$theitem) 
	{
		$___TEMP_backtrace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 2); 
		array_shift($___TEMP_backtrace);
		if (count($___TEMP_backtrace)==0) $___TEMP_PARENT_NAME=''; else $___TEMP_PARENT_NAME=strtolower($___TEMP_backtrace[0]['function']);
		if ($___TEMP_PARENT_NAME!='skill505\itemuse') 
		{
			return \instance10\itemuse($theitem);
		}
		unset($___TEMP_PARENT_NAME); unset($___TEMP_backtrace); 
	
		
		
		
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;  global $___LOCAL_PLAYER__VARS__ss,$___LOCAL_PLAYER__VARS__db_player_structure,$___LOCAL_PLAYER__VARS__db_player_structure_types,$___LOCAL_PLAYER__VARS__gamedata,$___LOCAL_PLAYER__VARS__cmd,$___LOCAL_PLAYER__VARS__main,$___LOCAL_PLAYER__VARS__sdata,$___LOCAL_PLAYER__VARS__fog,$___LOCAL_PLAYER__VARS__upexp,$___LOCAL_PLAYER__VARS__lvlupexp, $___LOCAL_PLAYER__VARS__iconImg,$___LOCAL_PLAYER__VARS__iconImgB,$___LOCAL_PLAYER__VARS__iconImgBwidth,$___LOCAL_PLAYER__VARS__ardef,$___LOCAL_PLAYER__VARS__hpcolor,$___LOCAL_PLAYER__VARS__spcolor,$___LOCAL_PLAYER__VARS__newhpimg,$___LOCAL_PLAYER__VARS__newspimg,$___LOCAL_PLAYER__VARS__splt,$___LOCAL_PLAYER__VARS__hplt, $___LOCAL_PLAYER__VARS__tpldata,$___LOCAL_PLAYER__VARS__icon_list,$___LOCAL_PLAYER__VARS__icon_list_contents_to_frontend,$___LOCAL_PLAYER__VARS__typeinfo,$___LOCAL_PLAYER__VARS__killmsginfo,$___LOCAL_PLAYER__VARS__lwinfo,$___LOCAL_PLAYER__VARS__sexinfo,$___LOCAL_PLAYER__VARS__equip_list,$___LOCAL_PLAYER__VARS__battle_equip_list,$___LOCAL_PLAYER__VARS__pc_icon_range, $___LOCAL_PLAYER__VARS__pid,$___LOCAL_PLAYER__VARS__type,$___LOCAL_PLAYER__VARS__name,$___LOCAL_PLAYER__VARS__pass,$___LOCAL_PLAYER__VARS__ip,$___LOCAL_PLAYER__VARS__motto,$___LOCAL_PLAYER__VARS__killmsg,$___LOCAL_PLAYER__VARS__lastword,$___LOCAL_PLAYER__VARS__winner_flag,$___LOCAL_PLAYER__VARS__player_dead_flag, $___LOCAL_PLAYER__VARS__corpse_clear_flag,$___LOCAL_PLAYER__VARS__gd,$___LOCAL_PLAYER__VARS__sNo,$___LOCAL_PLAYER__VARS__club,$___LOCAL_PLAYER__VARS__validtime,$___LOCAL_PLAYER__VARS__endtime,$___LOCAL_PLAYER__VARS__cdsec,$___LOCAL_PLAYER__VARS__cdmsec,$___LOCAL_PLAYER__VARS__cdtime,$___LOCAL_PLAYER__VARS__action, $___LOCAL_PLAYER__VARS__a_actionnum,$___LOCAL_PLAYER__VARS__v_actionnum,$___LOCAL_PLAYER__VARS__hp,$___LOCAL_PLAYER__VARS__mhp,$___LOCAL_PLAYER__VARS__sp,$___LOCAL_PLAYER__VARS__msp,$___LOCAL_PLAYER__VARS__mss,$___LOCAL_PLAYER__VARS__att,$___LOCAL_PLAYER__VARS__def,$___LOCAL_PLAYER__VARS__pls, $___LOCAL_PLAYER__VARS__lvl,$___LOCAL_PLAYER__VARS__exp,$___LOCAL_PLAYER__VARS__money,$___LOCAL_PLAYER__VARS__rp,$___LOCAL_PLAYER__VARS__bid,$___LOCAL_PLAYER__VARS__inf,$___LOCAL_PLAYER__VARS__rage,$___LOCAL_PLAYER__VARS__pose,$___LOCAL_PLAYER__VARS__tactic,$___LOCAL_PLAYER__VARS__killnum, $___LOCAL_PLAYER__VARS__npckillnum,$___LOCAL_PLAYER__VARS__state,$___LOCAL_PLAYER__VARS__skillpoint,$___LOCAL_PLAYER__VARS__flare,$___LOCAL_PLAYER__VARS__wp,$___LOCAL_PLAYER__VARS__wk,$___LOCAL_PLAYER__VARS__wg,$___LOCAL_PLAYER__VARS__wc,$___LOCAL_PLAYER__VARS__wd,$___LOCAL_PLAYER__VARS__wf, $___LOCAL_PLAYER__VARS__icon,$___LOCAL_PLAYER__VARS__teamID,$___LOCAL_PLAYER__VARS__teamPass,$___LOCAL_PLAYER__VARS__card,$___LOCAL_PLAYER__VARS__cardname,$___LOCAL_PLAYER__VARS__wep,$___LOCAL_PLAYER__VARS__wepk,$___LOCAL_PLAYER__VARS__wepe,$___LOCAL_PLAYER__VARS__weps,$___LOCAL_PLAYER__VARS__wepsk, $___LOCAL_PLAYER__VARS__arb,$___LOCAL_PLAYER__VARS__arbk,$___LOCAL_PLAYER__VARS__arbe,$___LOCAL_PLAYER__VARS__arbs,$___LOCAL_PLAYER__VARS__arbsk,$___LOCAL_PLAYER__VARS__arh,$___LOCAL_PLAYER__VARS__arhk,$___LOCAL_PLAYER__VARS__arhe,$___LOCAL_PLAYER__VARS__arhs,$___LOCAL_PLAYER__VARS__arhsk, $___LOCAL_PLAYER__VARS__ara,$___LOCAL_PLAYER__VARS__arak,$___LOCAL_PLAYER__VARS__arae,$___LOCAL_PLAYER__VARS__aras,$___LOCAL_PLAYER__VARS__arask,$___LOCAL_PLAYER__VARS__arf,$___LOCAL_PLAYER__VARS__arfk,$___LOCAL_PLAYER__VARS__arfe,$___LOCAL_PLAYER__VARS__arfs,$___LOCAL_PLAYER__VARS__arfsk, $___LOCAL_PLAYER__VARS__art,$___LOCAL_PLAYER__VARS__artk,$___LOCAL_PLAYER__VARS__arte,$___LOCAL_PLAYER__VARS__arts,$___LOCAL_PLAYER__VARS__artsk,$___LOCAL_PLAYER__VARS__itm0,$___LOCAL_PLAYER__VARS__itmk0,$___LOCAL_PLAYER__VARS__itme0,$___LOCAL_PLAYER__VARS__itms0,$___LOCAL_PLAYER__VARS__itmsk0, $___LOCAL_PLAYER__VARS__itm1,$___LOCAL_PLAYER__VARS__itmk1,$___LOCAL_PLAYER__VARS__itme1,$___LOCAL_PLAYER__VARS__itms1,$___LOCAL_PLAYER__VARS__itmsk1,$___LOCAL_PLAYER__VARS__itm2,$___LOCAL_PLAYER__VARS__itmk2,$___LOCAL_PLAYER__VARS__itme2,$___LOCAL_PLAYER__VARS__itms2,$___LOCAL_PLAYER__VARS__itmsk2, $___LOCAL_PLAYER__VARS__itm3,$___LOCAL_PLAYER__VARS__itmk3,$___LOCAL_PLAYER__VARS__itme3,$___LOCAL_PLAYER__VARS__itms3,$___LOCAL_PLAYER__VARS__itmsk3,$___LOCAL_PLAYER__VARS__itm4,$___LOCAL_PLAYER__VARS__itmk4,$___LOCAL_PLAYER__VARS__itme4,$___LOCAL_PLAYER__VARS__itms4,$___LOCAL_PLAYER__VARS__itmsk4, $___LOCAL_PLAYER__VARS__itm5,$___LOCAL_PLAYER__VARS__itmk5,$___LOCAL_PLAYER__VARS__itme5,$___LOCAL_PLAYER__VARS__itms5,$___LOCAL_PLAYER__VARS__itmsk5,$___LOCAL_PLAYER__VARS__itm6,$___LOCAL_PLAYER__VARS__itmk6,$___LOCAL_PLAYER__VARS__itme6,$___LOCAL_PLAYER__VARS__itms6,$___LOCAL_PLAYER__VARS__itmsk6, $___LOCAL_PLAYER__VARS__searchmemory,$___LOCAL_PLAYER__VARS__nskill,$___LOCAL_PLAYER__VARS__nskillpara; $ss=&$___LOCAL_PLAYER__VARS__ss; $db_player_structure=&$___LOCAL_PLAYER__VARS__db_player_structure; $db_player_structure_types=&$___LOCAL_PLAYER__VARS__db_player_structure_types; $gamedata=&$___LOCAL_PLAYER__VARS__gamedata; $cmd=&$___LOCAL_PLAYER__VARS__cmd; $main=&$___LOCAL_PLAYER__VARS__main; $sdata=&$___LOCAL_PLAYER__VARS__sdata; $fog=&$___LOCAL_PLAYER__VARS__fog; $upexp=&$___LOCAL_PLAYER__VARS__upexp; $lvlupexp=&$___LOCAL_PLAYER__VARS__lvlupexp;  $iconImg=&$___LOCAL_PLAYER__VARS__iconImg; $iconImgB=&$___LOCAL_PLAYER__VARS__iconImgB; $iconImgBwidth=&$___LOCAL_PLAYER__VARS__iconImgBwidth; $ardef=&$___LOCAL_PLAYER__VARS__ardef; $hpcolor=&$___LOCAL_PLAYER__VARS__hpcolor; $spcolor=&$___LOCAL_PLAYER__VARS__spcolor; $newhpimg=&$___LOCAL_PLAYER__VARS__newhpimg; $newspimg=&$___LOCAL_PLAYER__VARS__newspimg; $splt=&$___LOCAL_PLAYER__VARS__splt; $hplt=&$___LOCAL_PLAYER__VARS__hplt;  $tpldata=&$___LOCAL_PLAYER__VARS__tpldata; $icon_list=&$___LOCAL_PLAYER__VARS__icon_list; $icon_list_contents_to_frontend=&$___LOCAL_PLAYER__VARS__icon_list_contents_to_frontend; $typeinfo=&$___LOCAL_PLAYER__VARS__typeinfo; $killmsginfo=&$___LOCAL_PLAYER__VARS__killmsginfo; $lwinfo=&$___LOCAL_PLAYER__VARS__lwinfo; $sexinfo=&$___LOCAL_PLAYER__VARS__sexinfo; $equip_list=&$___LOCAL_PLAYER__VARS__equip_list; $battle_equip_list=&$___LOCAL_PLAYER__VARS__battle_equip_list; $pc_icon_range=&$___LOCAL_PLAYER__VARS__pc_icon_range;  $pid=&$___LOCAL_PLAYER__VARS__pid; $type=&$___LOCAL_PLAYER__VARS__type; $name=&$___LOCAL_PLAYER__VARS__name; $pass=&$___LOCAL_PLAYER__VARS__pass; $ip=&$___LOCAL_PLAYER__VARS__ip; $motto=&$___LOCAL_PLAYER__VARS__motto; $killmsg=&$___LOCAL_PLAYER__VARS__killmsg; $lastword=&$___LOCAL_PLAYER__VARS__lastword; $winner_flag=&$___LOCAL_PLAYER__VARS__winner_flag; $player_dead_flag=&$___LOCAL_PLAYER__VARS__player_dead_flag;  $corpse_clear_flag=&$___LOCAL_PLAYER__VARS__corpse_clear_flag; $gd=&$___LOCAL_PLAYER__VARS__gd; $sNo=&$___LOCAL_PLAYER__VARS__sNo; $club=&$___LOCAL_PLAYER__VARS__club; $validtime=&$___LOCAL_PLAYER__VARS__validtime; $endtime=&$___LOCAL_PLAYER__VARS__endtime; $cdsec=&$___LOCAL_PLAYER__VARS__cdsec; $cdmsec=&$___LOCAL_PLAYER__VARS__cdmsec; $cdtime=&$___LOCAL_PLAYER__VARS__cdtime; $action=&$___LOCAL_PLAYER__VARS__action;  $a_actionnum=&$___LOCAL_PLAYER__VARS__a_actionnum; $v_actionnum=&$___LOCAL_PLAYER__VARS__v_actionnum; $hp=&$___LOCAL_PLAYER__VARS__hp; $mhp=&$___LOCAL_PLAYER__VARS__mhp; $sp=&$___LOCAL_PLAYER__VARS__sp; $msp=&$___LOCAL_PLAYER__VARS__msp; $mss=&$___LOCAL_PLAYER__VARS__mss; $att=&$___LOCAL_PLAYER__VARS__att; $def=&$___LOCAL_PLAYER__VARS__def; $pls=&$___LOCAL_PLAYER__VARS__pls;  $lvl=&$___LOCAL_PLAYER__VARS__lvl; $exp=&$___LOCAL_PLAYER__VARS__exp; $money=&$___LOCAL_PLAYER__VARS__money; $rp=&$___LOCAL_PLAYER__VARS__rp; $bid=&$___LOCAL_PLAYER__VARS__bid; $inf=&$___LOCAL_PLAYER__VARS__inf; $rage=&$___LOCAL_PLAYER__VARS__rage; $pose=&$___LOCAL_PLAYER__VARS__pose; $tactic=&$___LOCAL_PLAYER__VARS__tactic; $killnum=&$___LOCAL_PLAYER__VARS__killnum;  $npckillnum=&$___LOCAL_PLAYER__VARS__npckillnum; $state=&$___LOCAL_PLAYER__VARS__state; $skillpoint=&$___LOCAL_PLAYER__VARS__skillpoint; $flare=&$___LOCAL_PLAYER__VARS__flare; $wp=&$___LOCAL_PLAYER__VARS__wp; $wk=&$___LOCAL_PLAYER__VARS__wk; $wg=&$___LOCAL_PLAYER__VARS__wg; $wc=&$___LOCAL_PLAYER__VARS__wc; $wd=&$___LOCAL_PLAYER__VARS__wd; $wf=&$___LOCAL_PLAYER__VARS__wf;  $icon=&$___LOCAL_PLAYER__VARS__icon; $teamID=&$___LOCAL_PLAYER__VARS__teamID; $teamPass=&$___LOCAL_PLAYER__VARS__teamPass; $card=&$___LOCAL_PLAYER__VARS__card; $cardname=&$___LOCAL_PLAYER__VARS__cardname; $wep=&$___LOCAL_PLAYER__VARS__wep; $wepk=&$___LOCAL_PLAYER__VARS__wepk; $wepe=&$___LOCAL_PLAYER__VARS__wepe; $weps=&$___LOCAL_PLAYER__VARS__weps; $wepsk=&$___LOCAL_PLAYER__VARS__wepsk;  $arb=&$___LOCAL_PLAYER__VARS__arb; $arbk=&$___LOCAL_PLAYER__VARS__arbk; $arbe=&$___LOCAL_PLAYER__VARS__arbe; $arbs=&$___LOCAL_PLAYER__VARS__arbs; $arbsk=&$___LOCAL_PLAYER__VARS__arbsk; $arh=&$___LOCAL_PLAYER__VARS__arh; $arhk=&$___LOCAL_PLAYER__VARS__arhk; $arhe=&$___LOCAL_PLAYER__VARS__arhe; $arhs=&$___LOCAL_PLAYER__VARS__arhs; $arhsk=&$___LOCAL_PLAYER__VARS__arhsk;  $ara=&$___LOCAL_PLAYER__VARS__ara; $arak=&$___LOCAL_PLAYER__VARS__arak; $arae=&$___LOCAL_PLAYER__VARS__arae; $aras=&$___LOCAL_PLAYER__VARS__aras; $arask=&$___LOCAL_PLAYER__VARS__arask; $arf=&$___LOCAL_PLAYER__VARS__arf; $arfk=&$___LOCAL_PLAYER__VARS__arfk; $arfe=&$___LOCAL_PLAYER__VARS__arfe; $arfs=&$___LOCAL_PLAYER__VARS__arfs; $arfsk=&$___LOCAL_PLAYER__VARS__arfsk;  $art=&$___LOCAL_PLAYER__VARS__art; $artk=&$___LOCAL_PLAYER__VARS__artk; $arte=&$___LOCAL_PLAYER__VARS__arte; $arts=&$___LOCAL_PLAYER__VARS__arts; $artsk=&$___LOCAL_PLAYER__VARS__artsk; $itm0=&$___LOCAL_PLAYER__VARS__itm0; $itmk0=&$___LOCAL_PLAYER__VARS__itmk0; $itme0=&$___LOCAL_PLAYER__VARS__itme0; $itms0=&$___LOCAL_PLAYER__VARS__itms0; $itmsk0=&$___LOCAL_PLAYER__VARS__itmsk0;  $itm1=&$___LOCAL_PLAYER__VARS__itm1; $itmk1=&$___LOCAL_PLAYER__VARS__itmk1; $itme1=&$___LOCAL_PLAYER__VARS__itme1; $itms1=&$___LOCAL_PLAYER__VARS__itms1; $itmsk1=&$___LOCAL_PLAYER__VARS__itmsk1; $itm2=&$___LOCAL_PLAYER__VARS__itm2; $itmk2=&$___LOCAL_PLAYER__VARS__itmk2; $itme2=&$___LOCAL_PLAYER__VARS__itme2; $itms2=&$___LOCAL_PLAYER__VARS__itms2; $itmsk2=&$___LOCAL_PLAYER__VARS__itmsk2;  $itm3=&$___LOCAL_PLAYER__VARS__itm3; $itmk3=&$___LOCAL_PLAYER__VARS__itmk3; $itme3=&$___LOCAL_PLAYER__VARS__itme3; $itms3=&$___LOCAL_PLAYER__VARS__itms3; $itmsk3=&$___LOCAL_PLAYER__VARS__itmsk3; $itm4=&$___LOCAL_PLAYER__VARS__itm4; $itmk4=&$___LOCAL_PLAYER__VARS__itmk4; $itme4=&$___LOCAL_PLAYER__VARS__itme4; $itms4=&$___LOCAL_PLAYER__VARS__itms4; $itmsk4=&$___LOCAL_PLAYER__VARS__itmsk4;  $itm5=&$___LOCAL_PLAYER__VARS__itm5; $itmk5=&$___LOCAL_PLAYER__VARS__itmk5; $itme5=&$___LOCAL_PLAYER__VARS__itme5; $itms5=&$___LOCAL_PLAYER__VARS__itms5; $itmsk5=&$___LOCAL_PLAYER__VARS__itmsk5; $itm6=&$___LOCAL_PLAYER__VARS__itm6; $itmk6=&$___LOCAL_PLAYER__VARS__itmk6; $itme6=&$___LOCAL_PLAYER__VARS__itme6; $itms6=&$___LOCAL_PLAYER__VARS__itms6; $itmsk6=&$___LOCAL_PLAYER__VARS__itmsk6;  $searchmemory=&$___LOCAL_PLAYER__VARS__searchmemory; $nskill=&$___LOCAL_PLAYER__VARS__nskill; $nskillpara=&$___LOCAL_PLAYER__VARS__nskillpara;  global $___LOCAL_ITEMMAIN__VARS__tmp_itmsk_arr_pool,$___LOCAL_ITEMMAIN__VARS__itemfind_extra_log,$___LOCAL_ITEMMAIN__VARS__item_equip_list,$___LOCAL_ITEMMAIN__VARS__item_hotkey_id_list,$___LOCAL_ITEMMAIN__VARS__itemmain_drophint,$___LOCAL_ITEMMAIN__VARS__item_allow_find_and_use,$___LOCAL_ITEMMAIN__VARS__nosta,$___LOCAL_ITEMMAIN__VARS__nospk,$___LOCAL_ITEMMAIN__VARS__item_obbs,$___LOCAL_ITEMMAIN__VARS__map_noitemdrop_arealist, $___LOCAL_ITEMMAIN__VARS__itemkind_equipable,$___LOCAL_ITEMMAIN__VARS__iteminfo,$___LOCAL_ITEMMAIN__VARS__itemspkinfo,$___LOCAL_ITEMMAIN__VARS__itemspkdesc,$___LOCAL_ITEMMAIN__VARS__itemspkdesc_help,$___LOCAL_ITEMMAIN__VARS__itemspkremark; $tmp_itmsk_arr_pool=&$___LOCAL_ITEMMAIN__VARS__tmp_itmsk_arr_pool; $itemfind_extra_log=&$___LOCAL_ITEMMAIN__VARS__itemfind_extra_log; $item_equip_list=&$___LOCAL_ITEMMAIN__VARS__item_equip_list; $item_hotkey_id_list=&$___LOCAL_ITEMMAIN__VARS__item_hotkey_id_list; $itemmain_drophint=&$___LOCAL_ITEMMAIN__VARS__itemmain_drophint; $item_allow_find_and_use=&$___LOCAL_ITEMMAIN__VARS__item_allow_find_and_use; $nosta=&$___LOCAL_ITEMMAIN__VARS__nosta; $nospk=&$___LOCAL_ITEMMAIN__VARS__nospk; $item_obbs=&$___LOCAL_ITEMMAIN__VARS__item_obbs; $map_noitemdrop_arealist=&$___LOCAL_ITEMMAIN__VARS__map_noitemdrop_arealist;  $itemkind_equipable=&$___LOCAL_ITEMMAIN__VARS__itemkind_equipable; $iteminfo=&$___LOCAL_ITEMMAIN__VARS__iteminfo; $itemspkinfo=&$___LOCAL_ITEMMAIN__VARS__itemspkinfo; $itemspkdesc=&$___LOCAL_ITEMMAIN__VARS__itemspkdesc; $itemspkdesc_help=&$___LOCAL_ITEMMAIN__VARS__itemspkdesc_help; $itemspkremark=&$___LOCAL_ITEMMAIN__VARS__itemspkremark;  global $___LOCAL_ARMOR__VARS__nosta,$___LOCAL_ARMOR__VARS__noarb,$___LOCAL_ARMOR__VARS__armor_equip_list,$___LOCAL_ARMOR__VARS__armor_iteminfo; $nosta=&$___LOCAL_ARMOR__VARS__nosta; $noarb=&$___LOCAL_ARMOR__VARS__noarb; $armor_equip_list=&$___LOCAL_ARMOR__VARS__armor_equip_list; $armor_iteminfo=&$___LOCAL_ARMOR__VARS__armor_iteminfo;  global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
		
		$itm=&$theitem['itm']; $itmk=&$theitem['itmk'];
		$itme=&$theitem['itme']; $itms=&$theitem['itms']; $itmsk=&$theitem['itmsk'];
		
		if ($itmk === 'EA')
		{
			$flag = false;
			for ($i = 1; $i <= 6; $i ++) {
				if (strpos(${'itmk'.$i}, 'D') === 0) {
					$flag = true;
					break;
				}
			}
			if (!$flag) $log .= '你的包裹里没有可以改造的防具。<br>';
			else
			{
				ob_start();
				include template(MOD_ITEM_ARMOR_EMPOWER_USE_ARMOR_EMPOWER);
				$cmd = ob_get_contents();
				ob_end_clean();
			}				
			return;
		}
if(isset($itmk)) {$__VAR_DUMP_MOD_item_armor_empower_VARS_itmk = &$itmk; unset($itmk); } else {$__VAR_DUMP_MOD_item_armor_empower_VARS_itmk = NULL;}if(isset($itmsk)) {$__VAR_DUMP_MOD_item_armor_empower_VARS_itmsk = &$itmsk; unset($itmsk); } else {$__VAR_DUMP_MOD_item_armor_empower_VARS_itmsk = NULL;}
		//======== Start of contents from mod ex_equipskill ========
		do{
			$___TMP_MOD_ex_equipskill_FUNC_itemuse_RET = NULL;

		
		
		$itmk=&$theitem['itmk']; $itmsk=&$theitem['itmsk'];
		
		$eqpsk_id = (int)\itemmain\check_in_itmsk('^eqpsk', $itmsk);
		if ((in_array($itmk[0], array('W','D','A'))) && $eqpsk_id)
		{
			$eqpsk_flag = 1;
		}
		//======== Start of contents from mod skill567 ========
		do{
			$___TMP_MOD_skill567_FUNC_itemuse_RET = NULL;

		
		
		if (\skillbase\skill_query(567) && ($theitem['itmk'][0] === 'P') && (\poison\poison_check_pid($theitem['itmsk']) === (int)$pid))
		{
			$theitem['itmk'][0] = 'H';
			$itm_temp = $theitem['itm'];
			$itmk_temp = $theitem['itmk'];
			\blessstone\itemuse($theitem);
			if (($theitem['itm'] == $itm_temp) && ($theitem['itmk'] == $itmk_temp)) $theitem['itmk'][0] = 'P';
		}
		else \blessstone\itemuse($theitem);
		}while(0);
		//======== End of contents from mod skill567 ========

		$___TMP_MOD_skill567_FUNC_itemuse_RET;
		if (!empty($eqpsk_flag))
		{
			do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;   } while (0);
			if (defined('MOD_SKILL'.$eqpsk_id) && !empty($clubskillname[$eqpsk_id]) && !\skillbase\skill_query($eqpsk_id, $sdata))
			{
				
				$dummy = \player\create_dummy_playerdata();
				$skarr = \attrbase\get_ex_def_array($dummy, $sdata, 0);
				if (in_array('^eqpsk'.$eqpsk_id, $skarr))
				{
					
					\skillbase\skill_acquire($eqpsk_id, $sdata);
					\skillbase\skill_setvalue($eqpsk_id, 'eqpsk_flag', 1, $sdata);
					$log .= "你现在能使用技能<span class=\"yellow b\">「{$clubskillname[$eqpsk_id]}」</span>了！";
				}
			}
		}
		}while(0);
		//======== End of contents from mod ex_equipskill ========

$itmk = &$__VAR_DUMP_MOD_item_armor_empower_VARS_itmk; $itmsk = &$__VAR_DUMP_MOD_item_armor_empower_VARS_itmsk; 
		$___TMP_MOD_ex_equipskill_FUNC_itemuse_RET;
	
	}
	
	function act()
	{
		return \skill962\act();
	}
	
	function parse_news($nid, $news, $hour, $min, $sec, $a, $b, $c, $d, $e, $exarr = array())
	{
		return \skill489\parse_news($nid,$news,$hour,$min,$sec,$a,$b,$c,$d,$e,$exarr);
	}
}

?>
