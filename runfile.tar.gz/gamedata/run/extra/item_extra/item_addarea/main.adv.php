<?php

namespace item_addarea
{
	$item_addarea_nlist = array('不要按这个按钮','好想按这个按钮','这个是什么按钮');
	$item_delayarea_nlist = array('你不准增加禁区');
	
	function init() 
	{
	}
	
	function parse_itmuse_desc($n, $k, $e, $s, $sk){
		return \item_armor_empower\parse_itmuse_desc($n,$k,$e,$s,$sk);
	}
	
	function itemuse(&$theitem)
	{
		return \instance10\itemuse($theitem);
	}
	
	function parse_news($nid, $news, $hour, $min, $sec, $a, $b, $c, $d, $e, $exarr = array())	
	{
		return \skill489\parse_news($nid,$news,$hour,$min,$sec,$a,$b,$c,$d,$e,$exarr);
	}
}

?>