<?php

namespace item_ext_armor
{
	function init() {
		do { global $___LOCAL_ITEMMAIN__VARS__tmp_itmsk_arr_pool,$___LOCAL_ITEMMAIN__VARS__itemfind_extra_log,$___LOCAL_ITEMMAIN__VARS__item_equip_list,$___LOCAL_ITEMMAIN__VARS__item_hotkey_id_list,$___LOCAL_ITEMMAIN__VARS__itemmain_drophint,$___LOCAL_ITEMMAIN__VARS__item_allow_find_and_use,$___LOCAL_ITEMMAIN__VARS__nosta,$___LOCAL_ITEMMAIN__VARS__nospk,$___LOCAL_ITEMMAIN__VARS__item_obbs,$___LOCAL_ITEMMAIN__VARS__map_noitemdrop_arealist, $___LOCAL_ITEMMAIN__VARS__itemkind_equipable,$___LOCAL_ITEMMAIN__VARS__iteminfo,$___LOCAL_ITEMMAIN__VARS__itemspkinfo,$___LOCAL_ITEMMAIN__VARS__itemspkdesc,$___LOCAL_ITEMMAIN__VARS__itemspkdesc_help,$___LOCAL_ITEMMAIN__VARS__itemspkremark; $tmp_itmsk_arr_pool=&$___LOCAL_ITEMMAIN__VARS__tmp_itmsk_arr_pool; $itemfind_extra_log=&$___LOCAL_ITEMMAIN__VARS__itemfind_extra_log; $item_equip_list=&$___LOCAL_ITEMMAIN__VARS__item_equip_list; $item_hotkey_id_list=&$___LOCAL_ITEMMAIN__VARS__item_hotkey_id_list; $itemmain_drophint=&$___LOCAL_ITEMMAIN__VARS__itemmain_drophint; $item_allow_find_and_use=&$___LOCAL_ITEMMAIN__VARS__item_allow_find_and_use; $nosta=&$___LOCAL_ITEMMAIN__VARS__nosta; $nospk=&$___LOCAL_ITEMMAIN__VARS__nospk; $item_obbs=&$___LOCAL_ITEMMAIN__VARS__item_obbs; $map_noitemdrop_arealist=&$___LOCAL_ITEMMAIN__VARS__map_noitemdrop_arealist;  $itemkind_equipable=&$___LOCAL_ITEMMAIN__VARS__itemkind_equipable; $iteminfo=&$___LOCAL_ITEMMAIN__VARS__iteminfo; $itemspkinfo=&$___LOCAL_ITEMMAIN__VARS__itemspkinfo; $itemspkdesc=&$___LOCAL_ITEMMAIN__VARS__itemspkdesc; $itemspkdesc_help=&$___LOCAL_ITEMMAIN__VARS__itemspkdesc_help; $itemspkremark=&$___LOCAL_ITEMMAIN__VARS__itemspkremark;   } while (0);
		$iteminfo['DBS'] = '身体外甲';
		$iteminfo['DHS'] = '头部外甲';
		$iteminfo['DAS'] = '手臂外甲';
		$iteminfo['DFS'] = '腿部外甲';		
		$itemspkinfo['^su'] = '外甲';
		$itemspkdesc['^su'] = '当前装备外甲的信息为：<:skn:>';
		$itemspkinfo['^arn'] = '原防具名';
		$itemspkinfo['^are'] = '原防具效果值';
		$itemspkinfo['^ars'] = '原防具耐久值';
	}
	
	function parse_itmuse_desc($n, $k, $e, $s, $sk){
		return \item_armor_empower\parse_itmuse_desc($n,$k,$e,$s,$sk);
	}
	
	
	function get_itmsk_desc_single_comp_process($skk, $skn, $sks) {
		return \ex_equipskill\get_itmsk_desc_single_comp_process($skk,$skn,$sks);
	}
	
	
	function use_armor(&$theitem, $pos = '')
	{
		return \skill505\use_armor($theitem,$pos);
	}
	
	
	
	function use_armor_ext_armor_process(&$theitem, &$positem)
	{
		
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;  global $___LOCAL_ARMOR__VARS__nosta,$___LOCAL_ARMOR__VARS__noarb,$___LOCAL_ARMOR__VARS__armor_equip_list,$___LOCAL_ARMOR__VARS__armor_iteminfo; $nosta=&$___LOCAL_ARMOR__VARS__nosta; $noarb=&$___LOCAL_ARMOR__VARS__noarb; $armor_equip_list=&$___LOCAL_ARMOR__VARS__armor_equip_list; $armor_iteminfo=&$___LOCAL_ARMOR__VARS__armor_iteminfo;   } while (0);
		
		if(empty($theitem['itms']) || empty($positem['itms'])) return; 
		
		
		$positem['itmsk'] = armor_put_su($positem['itmsk'], $theitem);
		
		
		$itmsk_arr = \itemmain\get_itmsk_array($theitem['itmsk']);
		$itmsk_arr = array_diff($itmsk_arr, Array('Z'));
		if (!empty($itmsk_arr)){
			$positem['itmsk'] .= '|'.implode('', $itmsk_arr).'|';
		}
		
		
		if ($theitem['itms'] === $nosta)
		{
			
			$positem['itmsk'] .= '^are'.$positem['itme'];
		}
		else
		{
			
			
			if ($positem['itms'] === $nosta)
			{
				$positem['itmsk'] .= '^ars0';
				$positem['itms'] = $theitem['itms'];
			}				
			else
			{
				$positem['itmsk'] .= '^ars'.$positem['itms'];
				$positem['itms'] += $theitem['itms'];
			}
		}			
		
		$positem['itme'] += $theitem['itme'];
		
		armor_changename_to_ext($theitem, $positem);
	}
	
	
	function armor_changename_to_ext(&$theitem, &$positem)
	{
		
		if(!empty(\itemmain\check_in_itmsk('^arn', $positem['itmsk']))) {
			$positem['itmsk'] = \itemmain\replace_in_itmsk('^arn','',$positem['itmsk']);
		}
		$positem['itmsk'] .= '^arn_'.\attrbase\base64_encode_comp_itmsk($positem['itm']).'1';
		$positem['itm'] = $theitem['itm'].'('.$positem['itm'].')';
		return;
	}
	
	
	function armor_hurt(&$pa, &$pd, $active, $which, $hurtvalue)
	{
		
		do { global $___LOCAL_ARMOR__VARS__nosta,$___LOCAL_ARMOR__VARS__noarb,$___LOCAL_ARMOR__VARS__armor_equip_list,$___LOCAL_ARMOR__VARS__armor_iteminfo; $nosta=&$___LOCAL_ARMOR__VARS__nosta; $noarb=&$___LOCAL_ARMOR__VARS__noarb; $armor_equip_list=&$___LOCAL_ARMOR__VARS__armor_equip_list; $armor_iteminfo=&$___LOCAL_ARMOR__VARS__armor_iteminfo;  global $___LOCAL_WOUND__VARS__inf_place,$___LOCAL_WOUND__VARS__infinfo,$___LOCAL_WOUND__VARS__infname,$___LOCAL_WOUND__VARS__infskillinfo,$___LOCAL_WOUND__VARS__wep_infatt,$___LOCAL_WOUND__VARS__wep_infobbs,$___LOCAL_WOUND__VARS__inf_recover_sp_cost; $inf_place=&$___LOCAL_WOUND__VARS__inf_place; $infinfo=&$___LOCAL_WOUND__VARS__infinfo; $infname=&$___LOCAL_WOUND__VARS__infname; $infskillinfo=&$___LOCAL_WOUND__VARS__infskillinfo; $wep_infatt=&$___LOCAL_WOUND__VARS__wep_infatt; $wep_infobbs=&$___LOCAL_WOUND__VARS__wep_infobbs; $inf_recover_sp_cost=&$___LOCAL_WOUND__VARS__inf_recover_sp_cost;  global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
		if (in_array($which,$armor_equip_list) && isset($pd[$which.'e']) && $pd[$which.'e']>0)	
		{
			$suitem = \item_ext_armor\armor_get_su ($pd[$which.'sk']);
			if ($suitem)
			{
				$su = $suitem['itm'];
				$suk = $suitem['itmk'];
				$sue = $suitem['itme'];
				$sus = $suitem['itms'];
				$susk = $suitem['itmsk'];
				$su_break_flag = 0;
				$are = \itemmain\check_in_itmsk('^are', $pd[$which.'sk']);
				if (false !== $are)
				{
					if ($hurtvalue >= $pd[$which.'e'] - $are)
					{
						$x = max($pd[$which.'e'] - $are, 1);
						$su_break_flag = 1;
					}
					else $x = $hurtvalue;
					$pd[$which.'e'] -= $x;
					if ($active)
					{
						$log .= "{$pd['name']}的外甲".$su."的效果值下降了{$x}！<br>";
					}
					else
					{
						$log .= "你的外甲".$su."的效果值下降了{$x}！<br>";
					}					
					if (1 === $su_break_flag)
					{
						\item_ext_armor\suit_break ($pa, $pd, $active, $which);
					}
				}
				else
				{
					$ars = \itemmain\check_in_itmsk('^ars', $pd[$which.'sk']);
					if (false === $ars) $ars = 1;
					if (0 === (int)$ars)
					{
						$x = min($pd[$which.'s'], $hurtvalue);
						$pd[$which.'s'] -= $x;
						if ($pd[$which.'s']<=0)
						{
							$pd[$which.'s'] = $nosta;
							$pd[$which.'e'] -= $sue;
							if ($pd[$which.'e'] < 0) $pd[$which.'e'] = 0;
							if ($active)
							{
								$log .= "{$pd['name']}的外甲".$su."的耐久度下降了{$x}！<br>";
							}
							else
							{
								$log .= "你的外甲".$su."的耐久度下降了{$x}！<br>";
							}
							\item_ext_armor\suit_break ($pa, $pd, $active, $which);
						}
					}
					else
					{		
						if ($hurtvalue >= $pd[$which.'s'] - $ars)
						{
							$x = max($pd[$which.'s'] - $ars, 1);
							$su_break_flag = 1;
						}
						else $x = $hurtvalue;
						if ($active)
						{
							$log .= "{$pd['name']}的外甲".$su."的耐久度下降了{$x}！<br>";
						}
						else
						{
							$log .= "你的外甲".$su."的耐久度下降了{$x}！<br>";
						}
						$pd[$which.'s'] -= $x;					
						if (1 === $su_break_flag)
						{
							$pd[$which.'e'] -= $sue;
							if ($pd[$which.'e'] < 0) $pd[$which.'e'] = 0;
							\item_ext_armor\suit_break ($pa, $pd, $active, $which);
						}
					}
				}
				return $x;
			}
		}
if(isset($active)) {$__VAR_DUMP_MOD_item_ext_armor_VARS_active = $active; } else {$__VAR_DUMP_MOD_item_ext_armor_VARS_active = NULL;} if(isset($which)) {$__VAR_DUMP_MOD_item_ext_armor_VARS_which = $which; } else {$__VAR_DUMP_MOD_item_ext_armor_VARS_which = NULL;} if(isset($hurtvalue)) {$__VAR_DUMP_MOD_item_ext_armor_VARS_hurtvalue = $hurtvalue; } else {$__VAR_DUMP_MOD_item_ext_armor_VARS_hurtvalue = NULL;} if(isset($x)) {$__VAR_DUMP_MOD_item_ext_armor_VARS_x = $x; unset($x); } else {$__VAR_DUMP_MOD_item_ext_armor_VARS_x = NULL;} 
		//======== Start of contents from mod skill517 ========
		do{
			$___TMP_MOD_skill517_FUNC_armor_hurt_RET = NULL;

		
		if (!empty($pa['bskill']) && $pa['bskill']==517 && 1 == $pa['skill517_hit_flag']) 
		{
			
			$log .= \battle\battlelog_parser($pa, $pd, $active, "<span class=\"yellow b\">然而，攻击瞄准的是<:pd_name:>的防具！</span><br>");
			$pa['skill517_hit_flag'] = 2;
		}
if(isset($active)) {$__VAR_DUMP_MOD_skill517_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill517_VARS_active = NULL;} if(isset($which)) {$__VAR_DUMP_MOD_skill517_VARS_which = $which; } else {$__VAR_DUMP_MOD_skill517_VARS_which = NULL;} if(isset($hurtvalue)) {$__VAR_DUMP_MOD_skill517_VARS_hurtvalue = $hurtvalue; } else {$__VAR_DUMP_MOD_skill517_VARS_hurtvalue = NULL;} 
		//======== Start of contents from mod armor ========
		do{
			$___TMP_MOD_armor_FUNC_armor_hurt_RET = NULL;

		
		
		if (in_array($which,$armor_equip_list) && isset($pd[$which.'e']) && $pd[$which.'e']>0)	
		{
			if ($pd[$which.'s'] == $nosta)	
			{
				$x = min($pd[$which.'e'], $hurtvalue);
				$pd[$which.'e'] -= $x;
				if ($active)
				{
					$log .= "{$pd['name']}的".$pd[$which]."的效果值下降了{$x}！<br>";
				}
				else
				{
					$log .= "你的".$pd[$which]."的效果值下降了{$x}！<br>";
				}
						
				if ($pd[$which.'e']<=0) \armor\armor_break ($pa, $pd, $active, $which);
			}
			else  
			{
				$x = min($pd[$which.'s'], $hurtvalue);
				$pd[$which.'s'] -= $x;
				if ($active)
				{
					$log .= "{$pd['name']}的".$pd[$which]."的耐久度下降了{$x}！<br>";
				}
				else
				{
					$log .= "你的".$pd[$which]."的耐久度下降了{$x}！<br>";
				}
						
				if ($pd[$which.'s']<=0) \armor\armor_break ($pa, $pd, $active, $which);
			}
			$___TMP_MOD_armor_FUNC_armor_hurt_RET =  $x;
			break; 
		}
		else{  $___TMP_MOD_armor_FUNC_armor_hurt_RET =  0;
			break; }
		}while(0);
		//======== End of contents from mod armor ========

$active = $__VAR_DUMP_MOD_skill517_VARS_active; unset($__VAR_DUMP_MOD_skill517_VARS_active);$which = $__VAR_DUMP_MOD_skill517_VARS_which; unset($__VAR_DUMP_MOD_skill517_VARS_which);$hurtvalue = $__VAR_DUMP_MOD_skill517_VARS_hurtvalue; unset($__VAR_DUMP_MOD_skill517_VARS_hurtvalue);
		$___TMP_MOD_skill517_FUNC_armor_hurt_RET =  $___TMP_MOD_armor_FUNC_armor_hurt_RET;
			break; 
		}while(0);
		//======== End of contents from mod skill517 ========

$active = $__VAR_DUMP_MOD_item_ext_armor_VARS_active; unset($__VAR_DUMP_MOD_item_ext_armor_VARS_active);$which = $__VAR_DUMP_MOD_item_ext_armor_VARS_which; unset($__VAR_DUMP_MOD_item_ext_armor_VARS_which);$hurtvalue = $__VAR_DUMP_MOD_item_ext_armor_VARS_hurtvalue; unset($__VAR_DUMP_MOD_item_ext_armor_VARS_hurtvalue);$x = $__VAR_DUMP_MOD_item_ext_armor_VARS_x; 
		return $___TMP_MOD_skill517_FUNC_armor_hurt_RET;
	
	}
	
	
	function suit_break(&$pa, &$pd, $active, $whicharmor)
	{
		return \ex_storage\suit_break($pa,$pd,$active,$whicharmor);
	}
	
	
	function itemoff($item)
	{
		
		
		if (strpos($item, 'ar') === 0)
		{
			do { global $___LOCAL_PLAYER__VARS__ss,$___LOCAL_PLAYER__VARS__db_player_structure,$___LOCAL_PLAYER__VARS__db_player_structure_types,$___LOCAL_PLAYER__VARS__gamedata,$___LOCAL_PLAYER__VARS__cmd,$___LOCAL_PLAYER__VARS__main,$___LOCAL_PLAYER__VARS__sdata,$___LOCAL_PLAYER__VARS__fog,$___LOCAL_PLAYER__VARS__upexp,$___LOCAL_PLAYER__VARS__lvlupexp, $___LOCAL_PLAYER__VARS__iconImg,$___LOCAL_PLAYER__VARS__iconImgB,$___LOCAL_PLAYER__VARS__iconImgBwidth,$___LOCAL_PLAYER__VARS__ardef,$___LOCAL_PLAYER__VARS__hpcolor,$___LOCAL_PLAYER__VARS__spcolor,$___LOCAL_PLAYER__VARS__newhpimg,$___LOCAL_PLAYER__VARS__newspimg,$___LOCAL_PLAYER__VARS__splt,$___LOCAL_PLAYER__VARS__hplt, $___LOCAL_PLAYER__VARS__tpldata,$___LOCAL_PLAYER__VARS__icon_list,$___LOCAL_PLAYER__VARS__icon_list_contents_to_frontend,$___LOCAL_PLAYER__VARS__typeinfo,$___LOCAL_PLAYER__VARS__killmsginfo,$___LOCAL_PLAYER__VARS__lwinfo,$___LOCAL_PLAYER__VARS__sexinfo,$___LOCAL_PLAYER__VARS__equip_list,$___LOCAL_PLAYER__VARS__battle_equip_list,$___LOCAL_PLAYER__VARS__pc_icon_range, $___LOCAL_PLAYER__VARS__pid,$___LOCAL_PLAYER__VARS__type,$___LOCAL_PLAYER__VARS__name,$___LOCAL_PLAYER__VARS__pass,$___LOCAL_PLAYER__VARS__ip,$___LOCAL_PLAYER__VARS__motto,$___LOCAL_PLAYER__VARS__killmsg,$___LOCAL_PLAYER__VARS__lastword,$___LOCAL_PLAYER__VARS__winner_flag,$___LOCAL_PLAYER__VARS__player_dead_flag, $___LOCAL_PLAYER__VARS__corpse_clear_flag,$___LOCAL_PLAYER__VARS__gd,$___LOCAL_PLAYER__VARS__sNo,$___LOCAL_PLAYER__VARS__club,$___LOCAL_PLAYER__VARS__validtime,$___LOCAL_PLAYER__VARS__endtime,$___LOCAL_PLAYER__VARS__cdsec,$___LOCAL_PLAYER__VARS__cdmsec,$___LOCAL_PLAYER__VARS__cdtime,$___LOCAL_PLAYER__VARS__action, $___LOCAL_PLAYER__VARS__a_actionnum,$___LOCAL_PLAYER__VARS__v_actionnum,$___LOCAL_PLAYER__VARS__hp,$___LOCAL_PLAYER__VARS__mhp,$___LOCAL_PLAYER__VARS__sp,$___LOCAL_PLAYER__VARS__msp,$___LOCAL_PLAYER__VARS__mss,$___LOCAL_PLAYER__VARS__att,$___LOCAL_PLAYER__VARS__def,$___LOCAL_PLAYER__VARS__pls, $___LOCAL_PLAYER__VARS__lvl,$___LOCAL_PLAYER__VARS__exp,$___LOCAL_PLAYER__VARS__money,$___LOCAL_PLAYER__VARS__rp,$___LOCAL_PLAYER__VARS__bid,$___LOCAL_PLAYER__VARS__inf,$___LOCAL_PLAYER__VARS__rage,$___LOCAL_PLAYER__VARS__pose,$___LOCAL_PLAYER__VARS__tactic,$___LOCAL_PLAYER__VARS__killnum, $___LOCAL_PLAYER__VARS__npckillnum,$___LOCAL_PLAYER__VARS__state,$___LOCAL_PLAYER__VARS__skillpoint,$___LOCAL_PLAYER__VARS__flare,$___LOCAL_PLAYER__VARS__wp,$___LOCAL_PLAYER__VARS__wk,$___LOCAL_PLAYER__VARS__wg,$___LOCAL_PLAYER__VARS__wc,$___LOCAL_PLAYER__VARS__wd,$___LOCAL_PLAYER__VARS__wf, $___LOCAL_PLAYER__VARS__icon,$___LOCAL_PLAYER__VARS__teamID,$___LOCAL_PLAYER__VARS__teamPass,$___LOCAL_PLAYER__VARS__card,$___LOCAL_PLAYER__VARS__cardname,$___LOCAL_PLAYER__VARS__wep,$___LOCAL_PLAYER__VARS__wepk,$___LOCAL_PLAYER__VARS__wepe,$___LOCAL_PLAYER__VARS__weps,$___LOCAL_PLAYER__VARS__wepsk, $___LOCAL_PLAYER__VARS__arb,$___LOCAL_PLAYER__VARS__arbk,$___LOCAL_PLAYER__VARS__arbe,$___LOCAL_PLAYER__VARS__arbs,$___LOCAL_PLAYER__VARS__arbsk,$___LOCAL_PLAYER__VARS__arh,$___LOCAL_PLAYER__VARS__arhk,$___LOCAL_PLAYER__VARS__arhe,$___LOCAL_PLAYER__VARS__arhs,$___LOCAL_PLAYER__VARS__arhsk, $___LOCAL_PLAYER__VARS__ara,$___LOCAL_PLAYER__VARS__arak,$___LOCAL_PLAYER__VARS__arae,$___LOCAL_PLAYER__VARS__aras,$___LOCAL_PLAYER__VARS__arask,$___LOCAL_PLAYER__VARS__arf,$___LOCAL_PLAYER__VARS__arfk,$___LOCAL_PLAYER__VARS__arfe,$___LOCAL_PLAYER__VARS__arfs,$___LOCAL_PLAYER__VARS__arfsk, $___LOCAL_PLAYER__VARS__art,$___LOCAL_PLAYER__VARS__artk,$___LOCAL_PLAYER__VARS__arte,$___LOCAL_PLAYER__VARS__arts,$___LOCAL_PLAYER__VARS__artsk,$___LOCAL_PLAYER__VARS__itm0,$___LOCAL_PLAYER__VARS__itmk0,$___LOCAL_PLAYER__VARS__itme0,$___LOCAL_PLAYER__VARS__itms0,$___LOCAL_PLAYER__VARS__itmsk0, $___LOCAL_PLAYER__VARS__itm1,$___LOCAL_PLAYER__VARS__itmk1,$___LOCAL_PLAYER__VARS__itme1,$___LOCAL_PLAYER__VARS__itms1,$___LOCAL_PLAYER__VARS__itmsk1,$___LOCAL_PLAYER__VARS__itm2,$___LOCAL_PLAYER__VARS__itmk2,$___LOCAL_PLAYER__VARS__itme2,$___LOCAL_PLAYER__VARS__itms2,$___LOCAL_PLAYER__VARS__itmsk2, $___LOCAL_PLAYER__VARS__itm3,$___LOCAL_PLAYER__VARS__itmk3,$___LOCAL_PLAYER__VARS__itme3,$___LOCAL_PLAYER__VARS__itms3,$___LOCAL_PLAYER__VARS__itmsk3,$___LOCAL_PLAYER__VARS__itm4,$___LOCAL_PLAYER__VARS__itmk4,$___LOCAL_PLAYER__VARS__itme4,$___LOCAL_PLAYER__VARS__itms4,$___LOCAL_PLAYER__VARS__itmsk4, $___LOCAL_PLAYER__VARS__itm5,$___LOCAL_PLAYER__VARS__itmk5,$___LOCAL_PLAYER__VARS__itme5,$___LOCAL_PLAYER__VARS__itms5,$___LOCAL_PLAYER__VARS__itmsk5,$___LOCAL_PLAYER__VARS__itm6,$___LOCAL_PLAYER__VARS__itmk6,$___LOCAL_PLAYER__VARS__itme6,$___LOCAL_PLAYER__VARS__itms6,$___LOCAL_PLAYER__VARS__itmsk6, $___LOCAL_PLAYER__VARS__searchmemory,$___LOCAL_PLAYER__VARS__nskill,$___LOCAL_PLAYER__VARS__nskillpara; $ss=&$___LOCAL_PLAYER__VARS__ss; $db_player_structure=&$___LOCAL_PLAYER__VARS__db_player_structure; $db_player_structure_types=&$___LOCAL_PLAYER__VARS__db_player_structure_types; $gamedata=&$___LOCAL_PLAYER__VARS__gamedata; $cmd=&$___LOCAL_PLAYER__VARS__cmd; $main=&$___LOCAL_PLAYER__VARS__main; $sdata=&$___LOCAL_PLAYER__VARS__sdata; $fog=&$___LOCAL_PLAYER__VARS__fog; $upexp=&$___LOCAL_PLAYER__VARS__upexp; $lvlupexp=&$___LOCAL_PLAYER__VARS__lvlupexp;  $iconImg=&$___LOCAL_PLAYER__VARS__iconImg; $iconImgB=&$___LOCAL_PLAYER__VARS__iconImgB; $iconImgBwidth=&$___LOCAL_PLAYER__VARS__iconImgBwidth; $ardef=&$___LOCAL_PLAYER__VARS__ardef; $hpcolor=&$___LOCAL_PLAYER__VARS__hpcolor; $spcolor=&$___LOCAL_PLAYER__VARS__spcolor; $newhpimg=&$___LOCAL_PLAYER__VARS__newhpimg; $newspimg=&$___LOCAL_PLAYER__VARS__newspimg; $splt=&$___LOCAL_PLAYER__VARS__splt; $hplt=&$___LOCAL_PLAYER__VARS__hplt;  $tpldata=&$___LOCAL_PLAYER__VARS__tpldata; $icon_list=&$___LOCAL_PLAYER__VARS__icon_list; $icon_list_contents_to_frontend=&$___LOCAL_PLAYER__VARS__icon_list_contents_to_frontend; $typeinfo=&$___LOCAL_PLAYER__VARS__typeinfo; $killmsginfo=&$___LOCAL_PLAYER__VARS__killmsginfo; $lwinfo=&$___LOCAL_PLAYER__VARS__lwinfo; $sexinfo=&$___LOCAL_PLAYER__VARS__sexinfo; $equip_list=&$___LOCAL_PLAYER__VARS__equip_list; $battle_equip_list=&$___LOCAL_PLAYER__VARS__battle_equip_list; $pc_icon_range=&$___LOCAL_PLAYER__VARS__pc_icon_range;  $pid=&$___LOCAL_PLAYER__VARS__pid; $type=&$___LOCAL_PLAYER__VARS__type; $name=&$___LOCAL_PLAYER__VARS__name; $pass=&$___LOCAL_PLAYER__VARS__pass; $ip=&$___LOCAL_PLAYER__VARS__ip; $motto=&$___LOCAL_PLAYER__VARS__motto; $killmsg=&$___LOCAL_PLAYER__VARS__killmsg; $lastword=&$___LOCAL_PLAYER__VARS__lastword; $winner_flag=&$___LOCAL_PLAYER__VARS__winner_flag; $player_dead_flag=&$___LOCAL_PLAYER__VARS__player_dead_flag;  $corpse_clear_flag=&$___LOCAL_PLAYER__VARS__corpse_clear_flag; $gd=&$___LOCAL_PLAYER__VARS__gd; $sNo=&$___LOCAL_PLAYER__VARS__sNo; $club=&$___LOCAL_PLAYER__VARS__club; $validtime=&$___LOCAL_PLAYER__VARS__validtime; $endtime=&$___LOCAL_PLAYER__VARS__endtime; $cdsec=&$___LOCAL_PLAYER__VARS__cdsec; $cdmsec=&$___LOCAL_PLAYER__VARS__cdmsec; $cdtime=&$___LOCAL_PLAYER__VARS__cdtime; $action=&$___LOCAL_PLAYER__VARS__action;  $a_actionnum=&$___LOCAL_PLAYER__VARS__a_actionnum; $v_actionnum=&$___LOCAL_PLAYER__VARS__v_actionnum; $hp=&$___LOCAL_PLAYER__VARS__hp; $mhp=&$___LOCAL_PLAYER__VARS__mhp; $sp=&$___LOCAL_PLAYER__VARS__sp; $msp=&$___LOCAL_PLAYER__VARS__msp; $mss=&$___LOCAL_PLAYER__VARS__mss; $att=&$___LOCAL_PLAYER__VARS__att; $def=&$___LOCAL_PLAYER__VARS__def; $pls=&$___LOCAL_PLAYER__VARS__pls;  $lvl=&$___LOCAL_PLAYER__VARS__lvl; $exp=&$___LOCAL_PLAYER__VARS__exp; $money=&$___LOCAL_PLAYER__VARS__money; $rp=&$___LOCAL_PLAYER__VARS__rp; $bid=&$___LOCAL_PLAYER__VARS__bid; $inf=&$___LOCAL_PLAYER__VARS__inf; $rage=&$___LOCAL_PLAYER__VARS__rage; $pose=&$___LOCAL_PLAYER__VARS__pose; $tactic=&$___LOCAL_PLAYER__VARS__tactic; $killnum=&$___LOCAL_PLAYER__VARS__killnum;  $npckillnum=&$___LOCAL_PLAYER__VARS__npckillnum; $state=&$___LOCAL_PLAYER__VARS__state; $skillpoint=&$___LOCAL_PLAYER__VARS__skillpoint; $flare=&$___LOCAL_PLAYER__VARS__flare; $wp=&$___LOCAL_PLAYER__VARS__wp; $wk=&$___LOCAL_PLAYER__VARS__wk; $wg=&$___LOCAL_PLAYER__VARS__wg; $wc=&$___LOCAL_PLAYER__VARS__wc; $wd=&$___LOCAL_PLAYER__VARS__wd; $wf=&$___LOCAL_PLAYER__VARS__wf;  $icon=&$___LOCAL_PLAYER__VARS__icon; $teamID=&$___LOCAL_PLAYER__VARS__teamID; $teamPass=&$___LOCAL_PLAYER__VARS__teamPass; $card=&$___LOCAL_PLAYER__VARS__card; $cardname=&$___LOCAL_PLAYER__VARS__cardname; $wep=&$___LOCAL_PLAYER__VARS__wep; $wepk=&$___LOCAL_PLAYER__VARS__wepk; $wepe=&$___LOCAL_PLAYER__VARS__wepe; $weps=&$___LOCAL_PLAYER__VARS__weps; $wepsk=&$___LOCAL_PLAYER__VARS__wepsk;  $arb=&$___LOCAL_PLAYER__VARS__arb; $arbk=&$___LOCAL_PLAYER__VARS__arbk; $arbe=&$___LOCAL_PLAYER__VARS__arbe; $arbs=&$___LOCAL_PLAYER__VARS__arbs; $arbsk=&$___LOCAL_PLAYER__VARS__arbsk; $arh=&$___LOCAL_PLAYER__VARS__arh; $arhk=&$___LOCAL_PLAYER__VARS__arhk; $arhe=&$___LOCAL_PLAYER__VARS__arhe; $arhs=&$___LOCAL_PLAYER__VARS__arhs; $arhsk=&$___LOCAL_PLAYER__VARS__arhsk;  $ara=&$___LOCAL_PLAYER__VARS__ara; $arak=&$___LOCAL_PLAYER__VARS__arak; $arae=&$___LOCAL_PLAYER__VARS__arae; $aras=&$___LOCAL_PLAYER__VARS__aras; $arask=&$___LOCAL_PLAYER__VARS__arask; $arf=&$___LOCAL_PLAYER__VARS__arf; $arfk=&$___LOCAL_PLAYER__VARS__arfk; $arfe=&$___LOCAL_PLAYER__VARS__arfe; $arfs=&$___LOCAL_PLAYER__VARS__arfs; $arfsk=&$___LOCAL_PLAYER__VARS__arfsk;  $art=&$___LOCAL_PLAYER__VARS__art; $artk=&$___LOCAL_PLAYER__VARS__artk; $arte=&$___LOCAL_PLAYER__VARS__arte; $arts=&$___LOCAL_PLAYER__VARS__arts; $artsk=&$___LOCAL_PLAYER__VARS__artsk; $itm0=&$___LOCAL_PLAYER__VARS__itm0; $itmk0=&$___LOCAL_PLAYER__VARS__itmk0; $itme0=&$___LOCAL_PLAYER__VARS__itme0; $itms0=&$___LOCAL_PLAYER__VARS__itms0; $itmsk0=&$___LOCAL_PLAYER__VARS__itmsk0;  $itm1=&$___LOCAL_PLAYER__VARS__itm1; $itmk1=&$___LOCAL_PLAYER__VARS__itmk1; $itme1=&$___LOCAL_PLAYER__VARS__itme1; $itms1=&$___LOCAL_PLAYER__VARS__itms1; $itmsk1=&$___LOCAL_PLAYER__VARS__itmsk1; $itm2=&$___LOCAL_PLAYER__VARS__itm2; $itmk2=&$___LOCAL_PLAYER__VARS__itmk2; $itme2=&$___LOCAL_PLAYER__VARS__itme2; $itms2=&$___LOCAL_PLAYER__VARS__itms2; $itmsk2=&$___LOCAL_PLAYER__VARS__itmsk2;  $itm3=&$___LOCAL_PLAYER__VARS__itm3; $itmk3=&$___LOCAL_PLAYER__VARS__itmk3; $itme3=&$___LOCAL_PLAYER__VARS__itme3; $itms3=&$___LOCAL_PLAYER__VARS__itms3; $itmsk3=&$___LOCAL_PLAYER__VARS__itmsk3; $itm4=&$___LOCAL_PLAYER__VARS__itm4; $itmk4=&$___LOCAL_PLAYER__VARS__itmk4; $itme4=&$___LOCAL_PLAYER__VARS__itme4; $itms4=&$___LOCAL_PLAYER__VARS__itms4; $itmsk4=&$___LOCAL_PLAYER__VARS__itmsk4;  $itm5=&$___LOCAL_PLAYER__VARS__itm5; $itmk5=&$___LOCAL_PLAYER__VARS__itmk5; $itme5=&$___LOCAL_PLAYER__VARS__itme5; $itms5=&$___LOCAL_PLAYER__VARS__itms5; $itmsk5=&$___LOCAL_PLAYER__VARS__itmsk5; $itm6=&$___LOCAL_PLAYER__VARS__itm6; $itmk6=&$___LOCAL_PLAYER__VARS__itmk6; $itme6=&$___LOCAL_PLAYER__VARS__itme6; $itms6=&$___LOCAL_PLAYER__VARS__itms6; $itmsk6=&$___LOCAL_PLAYER__VARS__itmsk6;  $searchmemory=&$___LOCAL_PLAYER__VARS__searchmemory; $nskill=&$___LOCAL_PLAYER__VARS__nskill; $nskillpara=&$___LOCAL_PLAYER__VARS__nskillpara;  global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;  global $___LOCAL_ARMOR__VARS__nosta,$___LOCAL_ARMOR__VARS__noarb,$___LOCAL_ARMOR__VARS__armor_equip_list,$___LOCAL_ARMOR__VARS__armor_iteminfo; $nosta=&$___LOCAL_ARMOR__VARS__nosta; $noarb=&$___LOCAL_ARMOR__VARS__noarb; $armor_equip_list=&$___LOCAL_ARMOR__VARS__armor_equip_list; $armor_iteminfo=&$___LOCAL_ARMOR__VARS__armor_iteminfo;   } while (0);
			$itmn = substr($item,2,1);
			$itm = & ${'ar'.$itmn};
			$itmk = & ${'ar'.$itmn.'k'};
			$itme = & ${'ar'.$itmn.'e'};
			$itms = & ${'ar'.$itmn.'s'};
			$itmsk = & ${'ar'.$itmn.'sk'};
			
			if(!\itemmain\itemoff_valid_check($itm, $itmk, $itme, $itms, $itmsk))
			{
				$mode = 'command';
				return;
			}
			
			$positem = array('itm' => &${'ar'.$itmn}, 'itmk' => &${'ar'.$itmn.'k'}, 'itme' => &${'ar'.$itmn.'e'},'itms' => &${'ar'.$itmn.'s'},'itmsk' => &${'ar'.$itmn.'sk'});
			$getitem = array('itm' => &$itm0, 'itmk' => &$itmk0, 'itme' => &$itme0,'itms' => &$itms0,'itmsk' => &$itmsk0);
			
			$result = \item_ext_armor\armor_remove_su ($positem, $getitem);
			if (1 === $result)
			{
				$log .= "你卸下了外甲<span class=\"yellow b\">$itm0</span>。<br>";
				\itemmain\itemget();
				return;
			}
		}
if(isset($item)) {$__VAR_DUMP_MOD_item_ext_armor_VARS_item = $item; } else {$__VAR_DUMP_MOD_item_ext_armor_VARS_item = NULL;} if(isset($itm)) {$__VAR_DUMP_MOD_item_ext_armor_VARS_itm = &$itm; unset($itm); } else {$__VAR_DUMP_MOD_item_ext_armor_VARS_itm = NULL;}if(isset($itmk)) {$__VAR_DUMP_MOD_item_ext_armor_VARS_itmk = &$itmk; unset($itmk); } else {$__VAR_DUMP_MOD_item_ext_armor_VARS_itmk = NULL;}if(isset($itme)) {$__VAR_DUMP_MOD_item_ext_armor_VARS_itme = &$itme; unset($itme); } else {$__VAR_DUMP_MOD_item_ext_armor_VARS_itme = NULL;}if(isset($itms)) {$__VAR_DUMP_MOD_item_ext_armor_VARS_itms = &$itms; unset($itms); } else {$__VAR_DUMP_MOD_item_ext_armor_VARS_itms = NULL;}if(isset($itmsk)) {$__VAR_DUMP_MOD_item_ext_armor_VARS_itmsk = &$itmsk; unset($itmsk); } else {$__VAR_DUMP_MOD_item_ext_armor_VARS_itmsk = NULL;}if(isset($itmn)) {$__VAR_DUMP_MOD_item_ext_armor_VARS_itmn = $itmn; unset($itmn); } else {$__VAR_DUMP_MOD_item_ext_armor_VARS_itmn = NULL;} if(isset($mode)) {$__VAR_DUMP_MOD_item_ext_armor_VARS_mode = $mode; unset($mode); } else {$__VAR_DUMP_MOD_item_ext_armor_VARS_mode = NULL;} 
		//======== Start of contents from mod itemmain ========
		do{
			$___TMP_MOD_itemmain_FUNC_itemoff_RET = NULL;

		
		
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;  global $___LOCAL_PLAYER__VARS__ss,$___LOCAL_PLAYER__VARS__db_player_structure,$___LOCAL_PLAYER__VARS__db_player_structure_types,$___LOCAL_PLAYER__VARS__gamedata,$___LOCAL_PLAYER__VARS__cmd,$___LOCAL_PLAYER__VARS__main,$___LOCAL_PLAYER__VARS__sdata,$___LOCAL_PLAYER__VARS__fog,$___LOCAL_PLAYER__VARS__upexp,$___LOCAL_PLAYER__VARS__lvlupexp, $___LOCAL_PLAYER__VARS__iconImg,$___LOCAL_PLAYER__VARS__iconImgB,$___LOCAL_PLAYER__VARS__iconImgBwidth,$___LOCAL_PLAYER__VARS__ardef,$___LOCAL_PLAYER__VARS__hpcolor,$___LOCAL_PLAYER__VARS__spcolor,$___LOCAL_PLAYER__VARS__newhpimg,$___LOCAL_PLAYER__VARS__newspimg,$___LOCAL_PLAYER__VARS__splt,$___LOCAL_PLAYER__VARS__hplt, $___LOCAL_PLAYER__VARS__tpldata,$___LOCAL_PLAYER__VARS__icon_list,$___LOCAL_PLAYER__VARS__icon_list_contents_to_frontend,$___LOCAL_PLAYER__VARS__typeinfo,$___LOCAL_PLAYER__VARS__killmsginfo,$___LOCAL_PLAYER__VARS__lwinfo,$___LOCAL_PLAYER__VARS__sexinfo,$___LOCAL_PLAYER__VARS__equip_list,$___LOCAL_PLAYER__VARS__battle_equip_list,$___LOCAL_PLAYER__VARS__pc_icon_range, $___LOCAL_PLAYER__VARS__pid,$___LOCAL_PLAYER__VARS__type,$___LOCAL_PLAYER__VARS__name,$___LOCAL_PLAYER__VARS__pass,$___LOCAL_PLAYER__VARS__ip,$___LOCAL_PLAYER__VARS__motto,$___LOCAL_PLAYER__VARS__killmsg,$___LOCAL_PLAYER__VARS__lastword,$___LOCAL_PLAYER__VARS__winner_flag,$___LOCAL_PLAYER__VARS__player_dead_flag, $___LOCAL_PLAYER__VARS__corpse_clear_flag,$___LOCAL_PLAYER__VARS__gd,$___LOCAL_PLAYER__VARS__sNo,$___LOCAL_PLAYER__VARS__club,$___LOCAL_PLAYER__VARS__validtime,$___LOCAL_PLAYER__VARS__endtime,$___LOCAL_PLAYER__VARS__cdsec,$___LOCAL_PLAYER__VARS__cdmsec,$___LOCAL_PLAYER__VARS__cdtime,$___LOCAL_PLAYER__VARS__action, $___LOCAL_PLAYER__VARS__a_actionnum,$___LOCAL_PLAYER__VARS__v_actionnum,$___LOCAL_PLAYER__VARS__hp,$___LOCAL_PLAYER__VARS__mhp,$___LOCAL_PLAYER__VARS__sp,$___LOCAL_PLAYER__VARS__msp,$___LOCAL_PLAYER__VARS__mss,$___LOCAL_PLAYER__VARS__att,$___LOCAL_PLAYER__VARS__def,$___LOCAL_PLAYER__VARS__pls, $___LOCAL_PLAYER__VARS__lvl,$___LOCAL_PLAYER__VARS__exp,$___LOCAL_PLAYER__VARS__money,$___LOCAL_PLAYER__VARS__rp,$___LOCAL_PLAYER__VARS__bid,$___LOCAL_PLAYER__VARS__inf,$___LOCAL_PLAYER__VARS__rage,$___LOCAL_PLAYER__VARS__pose,$___LOCAL_PLAYER__VARS__tactic,$___LOCAL_PLAYER__VARS__killnum, $___LOCAL_PLAYER__VARS__npckillnum,$___LOCAL_PLAYER__VARS__state,$___LOCAL_PLAYER__VARS__skillpoint,$___LOCAL_PLAYER__VARS__flare,$___LOCAL_PLAYER__VARS__wp,$___LOCAL_PLAYER__VARS__wk,$___LOCAL_PLAYER__VARS__wg,$___LOCAL_PLAYER__VARS__wc,$___LOCAL_PLAYER__VARS__wd,$___LOCAL_PLAYER__VARS__wf, $___LOCAL_PLAYER__VARS__icon,$___LOCAL_PLAYER__VARS__teamID,$___LOCAL_PLAYER__VARS__teamPass,$___LOCAL_PLAYER__VARS__card,$___LOCAL_PLAYER__VARS__cardname,$___LOCAL_PLAYER__VARS__wep,$___LOCAL_PLAYER__VARS__wepk,$___LOCAL_PLAYER__VARS__wepe,$___LOCAL_PLAYER__VARS__weps,$___LOCAL_PLAYER__VARS__wepsk, $___LOCAL_PLAYER__VARS__arb,$___LOCAL_PLAYER__VARS__arbk,$___LOCAL_PLAYER__VARS__arbe,$___LOCAL_PLAYER__VARS__arbs,$___LOCAL_PLAYER__VARS__arbsk,$___LOCAL_PLAYER__VARS__arh,$___LOCAL_PLAYER__VARS__arhk,$___LOCAL_PLAYER__VARS__arhe,$___LOCAL_PLAYER__VARS__arhs,$___LOCAL_PLAYER__VARS__arhsk, $___LOCAL_PLAYER__VARS__ara,$___LOCAL_PLAYER__VARS__arak,$___LOCAL_PLAYER__VARS__arae,$___LOCAL_PLAYER__VARS__aras,$___LOCAL_PLAYER__VARS__arask,$___LOCAL_PLAYER__VARS__arf,$___LOCAL_PLAYER__VARS__arfk,$___LOCAL_PLAYER__VARS__arfe,$___LOCAL_PLAYER__VARS__arfs,$___LOCAL_PLAYER__VARS__arfsk, $___LOCAL_PLAYER__VARS__art,$___LOCAL_PLAYER__VARS__artk,$___LOCAL_PLAYER__VARS__arte,$___LOCAL_PLAYER__VARS__arts,$___LOCAL_PLAYER__VARS__artsk,$___LOCAL_PLAYER__VARS__itm0,$___LOCAL_PLAYER__VARS__itmk0,$___LOCAL_PLAYER__VARS__itme0,$___LOCAL_PLAYER__VARS__itms0,$___LOCAL_PLAYER__VARS__itmsk0, $___LOCAL_PLAYER__VARS__itm1,$___LOCAL_PLAYER__VARS__itmk1,$___LOCAL_PLAYER__VARS__itme1,$___LOCAL_PLAYER__VARS__itms1,$___LOCAL_PLAYER__VARS__itmsk1,$___LOCAL_PLAYER__VARS__itm2,$___LOCAL_PLAYER__VARS__itmk2,$___LOCAL_PLAYER__VARS__itme2,$___LOCAL_PLAYER__VARS__itms2,$___LOCAL_PLAYER__VARS__itmsk2, $___LOCAL_PLAYER__VARS__itm3,$___LOCAL_PLAYER__VARS__itmk3,$___LOCAL_PLAYER__VARS__itme3,$___LOCAL_PLAYER__VARS__itms3,$___LOCAL_PLAYER__VARS__itmsk3,$___LOCAL_PLAYER__VARS__itm4,$___LOCAL_PLAYER__VARS__itmk4,$___LOCAL_PLAYER__VARS__itme4,$___LOCAL_PLAYER__VARS__itms4,$___LOCAL_PLAYER__VARS__itmsk4, $___LOCAL_PLAYER__VARS__itm5,$___LOCAL_PLAYER__VARS__itmk5,$___LOCAL_PLAYER__VARS__itme5,$___LOCAL_PLAYER__VARS__itms5,$___LOCAL_PLAYER__VARS__itmsk5,$___LOCAL_PLAYER__VARS__itm6,$___LOCAL_PLAYER__VARS__itmk6,$___LOCAL_PLAYER__VARS__itme6,$___LOCAL_PLAYER__VARS__itms6,$___LOCAL_PLAYER__VARS__itmsk6, $___LOCAL_PLAYER__VARS__searchmemory,$___LOCAL_PLAYER__VARS__nskill,$___LOCAL_PLAYER__VARS__nskillpara; $ss=&$___LOCAL_PLAYER__VARS__ss; $db_player_structure=&$___LOCAL_PLAYER__VARS__db_player_structure; $db_player_structure_types=&$___LOCAL_PLAYER__VARS__db_player_structure_types; $gamedata=&$___LOCAL_PLAYER__VARS__gamedata; $cmd=&$___LOCAL_PLAYER__VARS__cmd; $main=&$___LOCAL_PLAYER__VARS__main; $sdata=&$___LOCAL_PLAYER__VARS__sdata; $fog=&$___LOCAL_PLAYER__VARS__fog; $upexp=&$___LOCAL_PLAYER__VARS__upexp; $lvlupexp=&$___LOCAL_PLAYER__VARS__lvlupexp;  $iconImg=&$___LOCAL_PLAYER__VARS__iconImg; $iconImgB=&$___LOCAL_PLAYER__VARS__iconImgB; $iconImgBwidth=&$___LOCAL_PLAYER__VARS__iconImgBwidth; $ardef=&$___LOCAL_PLAYER__VARS__ardef; $hpcolor=&$___LOCAL_PLAYER__VARS__hpcolor; $spcolor=&$___LOCAL_PLAYER__VARS__spcolor; $newhpimg=&$___LOCAL_PLAYER__VARS__newhpimg; $newspimg=&$___LOCAL_PLAYER__VARS__newspimg; $splt=&$___LOCAL_PLAYER__VARS__splt; $hplt=&$___LOCAL_PLAYER__VARS__hplt;  $tpldata=&$___LOCAL_PLAYER__VARS__tpldata; $icon_list=&$___LOCAL_PLAYER__VARS__icon_list; $icon_list_contents_to_frontend=&$___LOCAL_PLAYER__VARS__icon_list_contents_to_frontend; $typeinfo=&$___LOCAL_PLAYER__VARS__typeinfo; $killmsginfo=&$___LOCAL_PLAYER__VARS__killmsginfo; $lwinfo=&$___LOCAL_PLAYER__VARS__lwinfo; $sexinfo=&$___LOCAL_PLAYER__VARS__sexinfo; $equip_list=&$___LOCAL_PLAYER__VARS__equip_list; $battle_equip_list=&$___LOCAL_PLAYER__VARS__battle_equip_list; $pc_icon_range=&$___LOCAL_PLAYER__VARS__pc_icon_range;  $pid=&$___LOCAL_PLAYER__VARS__pid; $type=&$___LOCAL_PLAYER__VARS__type; $name=&$___LOCAL_PLAYER__VARS__name; $pass=&$___LOCAL_PLAYER__VARS__pass; $ip=&$___LOCAL_PLAYER__VARS__ip; $motto=&$___LOCAL_PLAYER__VARS__motto; $killmsg=&$___LOCAL_PLAYER__VARS__killmsg; $lastword=&$___LOCAL_PLAYER__VARS__lastword; $winner_flag=&$___LOCAL_PLAYER__VARS__winner_flag; $player_dead_flag=&$___LOCAL_PLAYER__VARS__player_dead_flag;  $corpse_clear_flag=&$___LOCAL_PLAYER__VARS__corpse_clear_flag; $gd=&$___LOCAL_PLAYER__VARS__gd; $sNo=&$___LOCAL_PLAYER__VARS__sNo; $club=&$___LOCAL_PLAYER__VARS__club; $validtime=&$___LOCAL_PLAYER__VARS__validtime; $endtime=&$___LOCAL_PLAYER__VARS__endtime; $cdsec=&$___LOCAL_PLAYER__VARS__cdsec; $cdmsec=&$___LOCAL_PLAYER__VARS__cdmsec; $cdtime=&$___LOCAL_PLAYER__VARS__cdtime; $action=&$___LOCAL_PLAYER__VARS__action;  $a_actionnum=&$___LOCAL_PLAYER__VARS__a_actionnum; $v_actionnum=&$___LOCAL_PLAYER__VARS__v_actionnum; $hp=&$___LOCAL_PLAYER__VARS__hp; $mhp=&$___LOCAL_PLAYER__VARS__mhp; $sp=&$___LOCAL_PLAYER__VARS__sp; $msp=&$___LOCAL_PLAYER__VARS__msp; $mss=&$___LOCAL_PLAYER__VARS__mss; $att=&$___LOCAL_PLAYER__VARS__att; $def=&$___LOCAL_PLAYER__VARS__def; $pls=&$___LOCAL_PLAYER__VARS__pls;  $lvl=&$___LOCAL_PLAYER__VARS__lvl; $exp=&$___LOCAL_PLAYER__VARS__exp; $money=&$___LOCAL_PLAYER__VARS__money; $rp=&$___LOCAL_PLAYER__VARS__rp; $bid=&$___LOCAL_PLAYER__VARS__bid; $inf=&$___LOCAL_PLAYER__VARS__inf; $rage=&$___LOCAL_PLAYER__VARS__rage; $pose=&$___LOCAL_PLAYER__VARS__pose; $tactic=&$___LOCAL_PLAYER__VARS__tactic; $killnum=&$___LOCAL_PLAYER__VARS__killnum;  $npckillnum=&$___LOCAL_PLAYER__VARS__npckillnum; $state=&$___LOCAL_PLAYER__VARS__state; $skillpoint=&$___LOCAL_PLAYER__VARS__skillpoint; $flare=&$___LOCAL_PLAYER__VARS__flare; $wp=&$___LOCAL_PLAYER__VARS__wp; $wk=&$___LOCAL_PLAYER__VARS__wk; $wg=&$___LOCAL_PLAYER__VARS__wg; $wc=&$___LOCAL_PLAYER__VARS__wc; $wd=&$___LOCAL_PLAYER__VARS__wd; $wf=&$___LOCAL_PLAYER__VARS__wf;  $icon=&$___LOCAL_PLAYER__VARS__icon; $teamID=&$___LOCAL_PLAYER__VARS__teamID; $teamPass=&$___LOCAL_PLAYER__VARS__teamPass; $card=&$___LOCAL_PLAYER__VARS__card; $cardname=&$___LOCAL_PLAYER__VARS__cardname; $wep=&$___LOCAL_PLAYER__VARS__wep; $wepk=&$___LOCAL_PLAYER__VARS__wepk; $wepe=&$___LOCAL_PLAYER__VARS__wepe; $weps=&$___LOCAL_PLAYER__VARS__weps; $wepsk=&$___LOCAL_PLAYER__VARS__wepsk;  $arb=&$___LOCAL_PLAYER__VARS__arb; $arbk=&$___LOCAL_PLAYER__VARS__arbk; $arbe=&$___LOCAL_PLAYER__VARS__arbe; $arbs=&$___LOCAL_PLAYER__VARS__arbs; $arbsk=&$___LOCAL_PLAYER__VARS__arbsk; $arh=&$___LOCAL_PLAYER__VARS__arh; $arhk=&$___LOCAL_PLAYER__VARS__arhk; $arhe=&$___LOCAL_PLAYER__VARS__arhe; $arhs=&$___LOCAL_PLAYER__VARS__arhs; $arhsk=&$___LOCAL_PLAYER__VARS__arhsk;  $ara=&$___LOCAL_PLAYER__VARS__ara; $arak=&$___LOCAL_PLAYER__VARS__arak; $arae=&$___LOCAL_PLAYER__VARS__arae; $aras=&$___LOCAL_PLAYER__VARS__aras; $arask=&$___LOCAL_PLAYER__VARS__arask; $arf=&$___LOCAL_PLAYER__VARS__arf; $arfk=&$___LOCAL_PLAYER__VARS__arfk; $arfe=&$___LOCAL_PLAYER__VARS__arfe; $arfs=&$___LOCAL_PLAYER__VARS__arfs; $arfsk=&$___LOCAL_PLAYER__VARS__arfsk;  $art=&$___LOCAL_PLAYER__VARS__art; $artk=&$___LOCAL_PLAYER__VARS__artk; $arte=&$___LOCAL_PLAYER__VARS__arte; $arts=&$___LOCAL_PLAYER__VARS__arts; $artsk=&$___LOCAL_PLAYER__VARS__artsk; $itm0=&$___LOCAL_PLAYER__VARS__itm0; $itmk0=&$___LOCAL_PLAYER__VARS__itmk0; $itme0=&$___LOCAL_PLAYER__VARS__itme0; $itms0=&$___LOCAL_PLAYER__VARS__itms0; $itmsk0=&$___LOCAL_PLAYER__VARS__itmsk0;  $itm1=&$___LOCAL_PLAYER__VARS__itm1; $itmk1=&$___LOCAL_PLAYER__VARS__itmk1; $itme1=&$___LOCAL_PLAYER__VARS__itme1; $itms1=&$___LOCAL_PLAYER__VARS__itms1; $itmsk1=&$___LOCAL_PLAYER__VARS__itmsk1; $itm2=&$___LOCAL_PLAYER__VARS__itm2; $itmk2=&$___LOCAL_PLAYER__VARS__itmk2; $itme2=&$___LOCAL_PLAYER__VARS__itme2; $itms2=&$___LOCAL_PLAYER__VARS__itms2; $itmsk2=&$___LOCAL_PLAYER__VARS__itmsk2;  $itm3=&$___LOCAL_PLAYER__VARS__itm3; $itmk3=&$___LOCAL_PLAYER__VARS__itmk3; $itme3=&$___LOCAL_PLAYER__VARS__itme3; $itms3=&$___LOCAL_PLAYER__VARS__itms3; $itmsk3=&$___LOCAL_PLAYER__VARS__itmsk3; $itm4=&$___LOCAL_PLAYER__VARS__itm4; $itmk4=&$___LOCAL_PLAYER__VARS__itmk4; $itme4=&$___LOCAL_PLAYER__VARS__itme4; $itms4=&$___LOCAL_PLAYER__VARS__itms4; $itmsk4=&$___LOCAL_PLAYER__VARS__itmsk4;  $itm5=&$___LOCAL_PLAYER__VARS__itm5; $itmk5=&$___LOCAL_PLAYER__VARS__itmk5; $itme5=&$___LOCAL_PLAYER__VARS__itme5; $itms5=&$___LOCAL_PLAYER__VARS__itms5; $itmsk5=&$___LOCAL_PLAYER__VARS__itmsk5; $itm6=&$___LOCAL_PLAYER__VARS__itm6; $itmk6=&$___LOCAL_PLAYER__VARS__itmk6; $itme6=&$___LOCAL_PLAYER__VARS__itme6; $itms6=&$___LOCAL_PLAYER__VARS__itms6; $itmsk6=&$___LOCAL_PLAYER__VARS__itmsk6;  $searchmemory=&$___LOCAL_PLAYER__VARS__searchmemory; $nskill=&$___LOCAL_PLAYER__VARS__nskill; $nskillpara=&$___LOCAL_PLAYER__VARS__nskillpara;  global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);

		if($item == 'wep'){
			$itm = & $wep;
			$itmk = & $wepk;
			$itme = & $wepe;
			$itms = & $weps;
			$itmsk = & $wepsk;
		} elseif(strpos($item,'ar') === 0) {
			$itmn = substr($item,2,1);
			$itm = & ${'ar'.$itmn};
			$itmk = & ${'ar'.$itmn.'k'};
			$itme = & ${'ar'.$itmn.'e'};
			$itms = & ${'ar'.$itmn.'s'};
			$itmsk = & ${'ar'.$itmn.'sk'};
		}
		if(!\itemmain\itemoff_valid_check ($itm, $itmk, $itme, $itms, $itmsk)){
			$mode = 'command';
			$___TMP_MOD_itemmain_FUNC_itemoff_RET = NULL;
			break; 
		}
		$log .= "你卸下了装备<span class=\"yellow b\">$itm</span>。<br>";

		$itm0 = $itm;
		$itmk0 = $itmk;
		$itme0 = $itme;
		$itms0 = $itms;
		$itmsk0 = $itmsk;
		
		if($item == 'wep'){
		$itm = '拳头';
		$itmsk = '';
		$itmk = 'WN';
		$itme = 0;
		$itms = $nosta;
		} else {
		$itm = $itmk = $itmsk = '';
		$itme = $itms = 0;
		}
		\itemmain\itemget ();
		$___TMP_MOD_itemmain_FUNC_itemoff_RET = NULL;
			break; 
		}while(0);
		//======== End of contents from mod itemmain ========

$item = $__VAR_DUMP_MOD_item_ext_armor_VARS_item; unset($__VAR_DUMP_MOD_item_ext_armor_VARS_item);$itm = &$__VAR_DUMP_MOD_item_ext_armor_VARS_itm; $itmk = &$__VAR_DUMP_MOD_item_ext_armor_VARS_itmk; $itme = &$__VAR_DUMP_MOD_item_ext_armor_VARS_itme; $itms = &$__VAR_DUMP_MOD_item_ext_armor_VARS_itms; $itmsk = &$__VAR_DUMP_MOD_item_ext_armor_VARS_itmsk; $itmn = $__VAR_DUMP_MOD_item_ext_armor_VARS_itmn; $mode = $__VAR_DUMP_MOD_item_ext_armor_VARS_mode; 
		$___TMP_MOD_itemmain_FUNC_itemoff_RET;
	
	}
		
	
	function getcorpse_action(&$edata, $item)
	{
		return \skill597\getcorpse_action($edata,$item);
	}
	
	
	function armor_get_su($itmsk){
		
		$ret = Array();
		$sus = \itemmain\check_in_itmsk('^su', $itmsk);
		if(empty($sus)) return $ret;
		$sus = \attrbase\base64_decode_comp_itmsk($sus);
		
		if(!empty($sus)) {
			$suarr = explode(',', $sus);
			$ret = Array(
				'itm' => $suarr[0],
				'itmk' => $suarr[1],
				'itme' => $suarr[2],
				'itms' => $suarr[3],
				'itmsk' => $suarr[4]
			);
		}
		return $ret;
	}
	
	
	function armor_put_su($itmsk, $suarr){
		
		
		$nowsus = \itemmain\check_in_itmsk('^su', $itmsk);
		if(!empty($nowsus)) {
			$itmsk = \itemmain\replace_in_itmsk('^su','',$itmsk);
		}
		if(!empty($suarr)){
			$sus = $suarr['itm'].','.$suarr['itmk'].','.$suarr['itme'].','.$suarr['itms'].','.$suarr['itmsk'];
			$itmsk .= '^su_'.\attrbase\base64_encode_comp_itmsk($sus).'1';
		}
		return $itmsk;
	}
	
	
	function armor_remove_su(&$positem, &$getitem){
		return \ex_storage\armor_remove_su($positem,$getitem);
	}
	
	
	function armor_changename_from_ext(&$positem, &$getitem)
	{
		
		$arn = \itemmain\check_in_itmsk('^arn', $positem['itmsk']);
		if(!empty($arn))
			$positem['itm'] = \attrbase\base64_decode_comp_itmsk($arn);
		$positem['itmsk'] = \itemmain\replace_in_itmsk('^arn','',$positem['itmsk']);
	}
	
	
	function armor_clean_suit_sk(&$itmsk){
		
		if(strpos($itmsk,'|')===false) return '';
		if(substr_count($itmsk, '|') % 2) $itmsk .= '|';
		preg_match('/\|.*\|/s',$itmsk,$matches);
		$ret = '';
		if(!empty($matches)) {
			$itmsk = preg_replace('/\|.*?\|/s','',$itmsk);
			$ret = substr($matches[0], 1, -1);
		}
		return $ret;
	}
	
	
	function check_comp_itmsk_visible($cinfo){
		return \skill709\check_comp_itmsk_visible($cinfo);
	}
	
	
	function itemdrop_valid_check($itm, $itmk, $itme, $itms, $itmsk, $itmpos)
	{
		
		if(\itemmain\check_in_itmsk('^su', $itmsk)){
			do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
			$log .= '<span class="yellow b">必须先把外甲卸下来才能丢弃！</span><br>';
			return false;
		}
if(isset($itm)) {$__VAR_DUMP_MOD_item_ext_armor_VARS_itm = $itm; } else {$__VAR_DUMP_MOD_item_ext_armor_VARS_itm = NULL;} if(isset($itmk)) {$__VAR_DUMP_MOD_item_ext_armor_VARS_itmk = $itmk; } else {$__VAR_DUMP_MOD_item_ext_armor_VARS_itmk = NULL;} if(isset($itme)) {$__VAR_DUMP_MOD_item_ext_armor_VARS_itme = $itme; } else {$__VAR_DUMP_MOD_item_ext_armor_VARS_itme = NULL;} if(isset($itms)) {$__VAR_DUMP_MOD_item_ext_armor_VARS_itms = $itms; } else {$__VAR_DUMP_MOD_item_ext_armor_VARS_itms = NULL;} if(isset($itmsk)) {$__VAR_DUMP_MOD_item_ext_armor_VARS_itmsk = $itmsk; } else {$__VAR_DUMP_MOD_item_ext_armor_VARS_itmsk = NULL;} if(isset($itmpos)) {$__VAR_DUMP_MOD_item_ext_armor_VARS_itmpos = $itmpos; } else {$__VAR_DUMP_MOD_item_ext_armor_VARS_itmpos = NULL;} 
		//======== Start of contents from mod ex_mhp_temp_up ========
		do{
			$___TMP_MOD_ex_mhp_temp_up_FUNC_itemdrop_valid_check_RET = NULL;
if(isset($itm)) {$__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_itm = $itm; } else {$__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_itm = NULL;} if(isset($itmk)) {$__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_itmk = $itmk; } else {$__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_itmk = NULL;} if(isset($itme)) {$__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_itme = $itme; } else {$__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_itme = NULL;} if(isset($itms)) {$__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_itms = $itms; } else {$__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_itms = NULL;} if(isset($itmsk)) {$__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_itmsk = $itmsk; } else {$__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_itmsk = NULL;} if(isset($itmpos)) {$__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_itmpos = $itmpos; } else {$__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_itmpos = NULL;} 
		//======== Start of contents from mod ex_cursed ========
		do{
			$___TMP_MOD_ex_cursed_FUNC_itemdrop_valid_check_RET = NULL;

		
		if(\itemmain\check_in_itmsk('O', $itmsk)){
			do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
			if(\ex_cursed\check_enkan ()) {
				$log .= '<span class="lime b">圆环之理的光辉暂时消解了道具的诅咒。</span><br>';
			}else{
				$log .= '<span class="red b">摆脱这个道具的诅咒是不可能的。</span><br>';
				$___TMP_MOD_ex_cursed_FUNC_itemdrop_valid_check_RET =  false;
			break; 
			}
		}
if(isset($itm)) {$__VAR_DUMP_MOD_ex_cursed_VARS_itm = $itm; } else {$__VAR_DUMP_MOD_ex_cursed_VARS_itm = NULL;} if(isset($itmk)) {$__VAR_DUMP_MOD_ex_cursed_VARS_itmk = $itmk; } else {$__VAR_DUMP_MOD_ex_cursed_VARS_itmk = NULL;} if(isset($itme)) {$__VAR_DUMP_MOD_ex_cursed_VARS_itme = $itme; } else {$__VAR_DUMP_MOD_ex_cursed_VARS_itme = NULL;} if(isset($itms)) {$__VAR_DUMP_MOD_ex_cursed_VARS_itms = $itms; } else {$__VAR_DUMP_MOD_ex_cursed_VARS_itms = NULL;} if(isset($itmsk)) {$__VAR_DUMP_MOD_ex_cursed_VARS_itmsk = $itmsk; } else {$__VAR_DUMP_MOD_ex_cursed_VARS_itmsk = NULL;} if(isset($itmpos)) {$__VAR_DUMP_MOD_ex_cursed_VARS_itmpos = $itmpos; } else {$__VAR_DUMP_MOD_ex_cursed_VARS_itmpos = NULL;} 
		//======== Start of contents from mod itemmain ========
		do{
			$___TMP_MOD_itemmain_FUNC_itemdrop_valid_check_RET = NULL;

		
		if(!$itms||!$itmk||$itmk=='WN'||$itmk=='DN'){
			do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
			$log .= '该物品不存在！<br>';
			$___TMP_MOD_itemmain_FUNC_itemdrop_valid_check_RET =  false;
			break; 
		}
		$___TMP_MOD_itemmain_FUNC_itemdrop_valid_check_RET =  true;
			break; 
		}while(0);
		//======== End of contents from mod itemmain ========

$itm = $__VAR_DUMP_MOD_ex_cursed_VARS_itm; unset($__VAR_DUMP_MOD_ex_cursed_VARS_itm);$itmk = $__VAR_DUMP_MOD_ex_cursed_VARS_itmk; unset($__VAR_DUMP_MOD_ex_cursed_VARS_itmk);$itme = $__VAR_DUMP_MOD_ex_cursed_VARS_itme; unset($__VAR_DUMP_MOD_ex_cursed_VARS_itme);$itms = $__VAR_DUMP_MOD_ex_cursed_VARS_itms; unset($__VAR_DUMP_MOD_ex_cursed_VARS_itms);$itmsk = $__VAR_DUMP_MOD_ex_cursed_VARS_itmsk; unset($__VAR_DUMP_MOD_ex_cursed_VARS_itmsk);$itmpos = $__VAR_DUMP_MOD_ex_cursed_VARS_itmpos; unset($__VAR_DUMP_MOD_ex_cursed_VARS_itmpos);
		$___TMP_MOD_ex_cursed_FUNC_itemdrop_valid_check_RET =  $___TMP_MOD_itemmain_FUNC_itemdrop_valid_check_RET;
			break; 
		}while(0);
		//======== End of contents from mod ex_cursed ========

$itm = $__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_itm; unset($__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_itm);$itmk = $__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_itmk; unset($__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_itmk);$itme = $__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_itme; unset($__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_itme);$itms = $__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_itms; unset($__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_itms);$itmsk = $__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_itmsk; unset($__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_itmsk);$itmpos = $__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_itmpos; unset($__VAR_DUMP_MOD_ex_mhp_temp_up_VARS_itmpos);

		
		$ret = $___TMP_MOD_ex_cursed_FUNC_itemdrop_valid_check_RET;
		$flag = \attrbase\check_in_itmsk('^hu',\itemmain\get_itmsk_array($itmsk));
		if(false !== $flag && substr($itmpos, 0, 3) !== 'itm'){
			\ex_mhp_temp_up\ex_mhp_temp_lose ();
		}
		$___TMP_MOD_ex_mhp_temp_up_FUNC_itemdrop_valid_check_RET =  $ret;
			break; 
		}while(0);
		//======== End of contents from mod ex_mhp_temp_up ========

$itm = $__VAR_DUMP_MOD_item_ext_armor_VARS_itm; unset($__VAR_DUMP_MOD_item_ext_armor_VARS_itm);$itmk = $__VAR_DUMP_MOD_item_ext_armor_VARS_itmk; unset($__VAR_DUMP_MOD_item_ext_armor_VARS_itmk);$itme = $__VAR_DUMP_MOD_item_ext_armor_VARS_itme; unset($__VAR_DUMP_MOD_item_ext_armor_VARS_itme);$itms = $__VAR_DUMP_MOD_item_ext_armor_VARS_itms; unset($__VAR_DUMP_MOD_item_ext_armor_VARS_itms);$itmsk = $__VAR_DUMP_MOD_item_ext_armor_VARS_itmsk; unset($__VAR_DUMP_MOD_item_ext_armor_VARS_itmsk);$itmpos = $__VAR_DUMP_MOD_item_ext_armor_VARS_itmpos; unset($__VAR_DUMP_MOD_item_ext_armor_VARS_itmpos);
		return $___TMP_MOD_ex_mhp_temp_up_FUNC_itemdrop_valid_check_RET;
	
	}
	
	
	function init_npcdata($npc, $plslist=array()){
if(isset($npc)) {$__VAR_DUMP_MOD_item_ext_armor_VARS_npc = $npc; } else {$__VAR_DUMP_MOD_item_ext_armor_VARS_npc = NULL;} if(isset($plslist)) {$__VAR_DUMP_MOD_item_ext_armor_VARS_plslist = $plslist; } else {$__VAR_DUMP_MOD_item_ext_armor_VARS_plslist = NULL;} 
		//======== Start of contents from mod aprilfool2018 ========
		do{
			$___TMP_MOD_aprilfool2018_FUNC_init_npcdata_RET = NULL;
if(isset($npc)) {$__VAR_DUMP_MOD_aprilfool2018_VARS_npc = $npc; } else {$__VAR_DUMP_MOD_aprilfool2018_VARS_npc = NULL;} if(isset($plslist)) {$__VAR_DUMP_MOD_aprilfool2018_VARS_plslist = $plslist; } else {$__VAR_DUMP_MOD_aprilfool2018_VARS_plslist = NULL;} 
		//======== Start of contents from mod attrbase ========
		do{
			$___TMP_MOD_attrbase_FUNC_init_npcdata_RET = NULL;
if(isset($npc)) {$__VAR_DUMP_MOD_attrbase_VARS_npc = $npc; } else {$__VAR_DUMP_MOD_attrbase_VARS_npc = NULL;} if(isset($plslist)) {$__VAR_DUMP_MOD_attrbase_VARS_plslist = $plslist; } else {$__VAR_DUMP_MOD_attrbase_VARS_plslist = NULL;} 
		//======== Start of contents from mod clubbase ========
		do{
			$___TMP_MOD_clubbase_FUNC_init_npcdata_RET = NULL;
if(isset($npc)) {$__VAR_DUMP_MOD_clubbase_VARS_npc = $npc; } else {$__VAR_DUMP_MOD_clubbase_VARS_npc = NULL;} if(isset($plslist)) {$__VAR_DUMP_MOD_clubbase_VARS_plslist = $plslist; } else {$__VAR_DUMP_MOD_clubbase_VARS_plslist = NULL;} 
		//======== Start of contents from mod npc ========
		do{
			$___TMP_MOD_npc_FUNC_init_npcdata_RET = NULL;

		 
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;  global $___LOCAL_MAP__VARS__all_plsno_cache,$___LOCAL_MAP__VARS__areainterval,$___LOCAL_MAP__VARS__areaadd,$___LOCAL_MAP__VARS__areawarntime,$___LOCAL_MAP__VARS__arealimit,$___LOCAL_MAP__VARS__areaesc,$___LOCAL_MAP__VARS__area_on_start,$___LOCAL_MAP__VARS__dangerous_zone,$___LOCAL_MAP__VARS__plsinfo,$___LOCAL_MAP__VARS__plsinfo_o, $___LOCAL_MAP__VARS__plsinfo_disp,$___LOCAL_MAP__VARS__plsinfo_for_short,$___LOCAL_MAP__VARS__xyinfo,$___LOCAL_MAP__VARS__areainfo; $all_plsno_cache=&$___LOCAL_MAP__VARS__all_plsno_cache; $areainterval=&$___LOCAL_MAP__VARS__areainterval; $areaadd=&$___LOCAL_MAP__VARS__areaadd; $areawarntime=&$___LOCAL_MAP__VARS__areawarntime; $arealimit=&$___LOCAL_MAP__VARS__arealimit; $areaesc=&$___LOCAL_MAP__VARS__areaesc; $area_on_start=&$___LOCAL_MAP__VARS__area_on_start; $dangerous_zone=&$___LOCAL_MAP__VARS__dangerous_zone; $plsinfo=&$___LOCAL_MAP__VARS__plsinfo; $plsinfo_o=&$___LOCAL_MAP__VARS__plsinfo_o;  $plsinfo_disp=&$___LOCAL_MAP__VARS__plsinfo_disp; $plsinfo_for_short=&$___LOCAL_MAP__VARS__plsinfo_for_short; $xyinfo=&$___LOCAL_MAP__VARS__xyinfo; $areainfo=&$___LOCAL_MAP__VARS__areainfo;  global $___LOCAL_PLAYER__VARS__ss,$___LOCAL_PLAYER__VARS__db_player_structure,$___LOCAL_PLAYER__VARS__db_player_structure_types,$___LOCAL_PLAYER__VARS__gamedata,$___LOCAL_PLAYER__VARS__cmd,$___LOCAL_PLAYER__VARS__main,$___LOCAL_PLAYER__VARS__sdata,$___LOCAL_PLAYER__VARS__fog,$___LOCAL_PLAYER__VARS__upexp,$___LOCAL_PLAYER__VARS__lvlupexp, $___LOCAL_PLAYER__VARS__iconImg,$___LOCAL_PLAYER__VARS__iconImgB,$___LOCAL_PLAYER__VARS__iconImgBwidth,$___LOCAL_PLAYER__VARS__ardef,$___LOCAL_PLAYER__VARS__hpcolor,$___LOCAL_PLAYER__VARS__spcolor,$___LOCAL_PLAYER__VARS__newhpimg,$___LOCAL_PLAYER__VARS__newspimg,$___LOCAL_PLAYER__VARS__splt,$___LOCAL_PLAYER__VARS__hplt, $___LOCAL_PLAYER__VARS__tpldata,$___LOCAL_PLAYER__VARS__icon_list,$___LOCAL_PLAYER__VARS__icon_list_contents_to_frontend,$___LOCAL_PLAYER__VARS__typeinfo,$___LOCAL_PLAYER__VARS__killmsginfo,$___LOCAL_PLAYER__VARS__lwinfo,$___LOCAL_PLAYER__VARS__sexinfo,$___LOCAL_PLAYER__VARS__equip_list,$___LOCAL_PLAYER__VARS__battle_equip_list,$___LOCAL_PLAYER__VARS__pc_icon_range, $___LOCAL_PLAYER__VARS__pid,$___LOCAL_PLAYER__VARS__type,$___LOCAL_PLAYER__VARS__name,$___LOCAL_PLAYER__VARS__pass,$___LOCAL_PLAYER__VARS__ip,$___LOCAL_PLAYER__VARS__motto,$___LOCAL_PLAYER__VARS__killmsg,$___LOCAL_PLAYER__VARS__lastword,$___LOCAL_PLAYER__VARS__winner_flag,$___LOCAL_PLAYER__VARS__player_dead_flag, $___LOCAL_PLAYER__VARS__corpse_clear_flag,$___LOCAL_PLAYER__VARS__gd,$___LOCAL_PLAYER__VARS__sNo,$___LOCAL_PLAYER__VARS__club,$___LOCAL_PLAYER__VARS__validtime,$___LOCAL_PLAYER__VARS__endtime,$___LOCAL_PLAYER__VARS__cdsec,$___LOCAL_PLAYER__VARS__cdmsec,$___LOCAL_PLAYER__VARS__cdtime,$___LOCAL_PLAYER__VARS__action, $___LOCAL_PLAYER__VARS__a_actionnum,$___LOCAL_PLAYER__VARS__v_actionnum,$___LOCAL_PLAYER__VARS__hp,$___LOCAL_PLAYER__VARS__mhp,$___LOCAL_PLAYER__VARS__sp,$___LOCAL_PLAYER__VARS__msp,$___LOCAL_PLAYER__VARS__mss,$___LOCAL_PLAYER__VARS__att,$___LOCAL_PLAYER__VARS__def,$___LOCAL_PLAYER__VARS__pls, $___LOCAL_PLAYER__VARS__lvl,$___LOCAL_PLAYER__VARS__exp,$___LOCAL_PLAYER__VARS__money,$___LOCAL_PLAYER__VARS__rp,$___LOCAL_PLAYER__VARS__bid,$___LOCAL_PLAYER__VARS__inf,$___LOCAL_PLAYER__VARS__rage,$___LOCAL_PLAYER__VARS__pose,$___LOCAL_PLAYER__VARS__tactic,$___LOCAL_PLAYER__VARS__killnum, $___LOCAL_PLAYER__VARS__npckillnum,$___LOCAL_PLAYER__VARS__state,$___LOCAL_PLAYER__VARS__skillpoint,$___LOCAL_PLAYER__VARS__flare,$___LOCAL_PLAYER__VARS__wp,$___LOCAL_PLAYER__VARS__wk,$___LOCAL_PLAYER__VARS__wg,$___LOCAL_PLAYER__VARS__wc,$___LOCAL_PLAYER__VARS__wd,$___LOCAL_PLAYER__VARS__wf, $___LOCAL_PLAYER__VARS__icon,$___LOCAL_PLAYER__VARS__teamID,$___LOCAL_PLAYER__VARS__teamPass,$___LOCAL_PLAYER__VARS__card,$___LOCAL_PLAYER__VARS__cardname,$___LOCAL_PLAYER__VARS__wep,$___LOCAL_PLAYER__VARS__wepk,$___LOCAL_PLAYER__VARS__wepe,$___LOCAL_PLAYER__VARS__weps,$___LOCAL_PLAYER__VARS__wepsk, $___LOCAL_PLAYER__VARS__arb,$___LOCAL_PLAYER__VARS__arbk,$___LOCAL_PLAYER__VARS__arbe,$___LOCAL_PLAYER__VARS__arbs,$___LOCAL_PLAYER__VARS__arbsk,$___LOCAL_PLAYER__VARS__arh,$___LOCAL_PLAYER__VARS__arhk,$___LOCAL_PLAYER__VARS__arhe,$___LOCAL_PLAYER__VARS__arhs,$___LOCAL_PLAYER__VARS__arhsk, $___LOCAL_PLAYER__VARS__ara,$___LOCAL_PLAYER__VARS__arak,$___LOCAL_PLAYER__VARS__arae,$___LOCAL_PLAYER__VARS__aras,$___LOCAL_PLAYER__VARS__arask,$___LOCAL_PLAYER__VARS__arf,$___LOCAL_PLAYER__VARS__arfk,$___LOCAL_PLAYER__VARS__arfe,$___LOCAL_PLAYER__VARS__arfs,$___LOCAL_PLAYER__VARS__arfsk, $___LOCAL_PLAYER__VARS__art,$___LOCAL_PLAYER__VARS__artk,$___LOCAL_PLAYER__VARS__arte,$___LOCAL_PLAYER__VARS__arts,$___LOCAL_PLAYER__VARS__artsk,$___LOCAL_PLAYER__VARS__itm0,$___LOCAL_PLAYER__VARS__itmk0,$___LOCAL_PLAYER__VARS__itme0,$___LOCAL_PLAYER__VARS__itms0,$___LOCAL_PLAYER__VARS__itmsk0, $___LOCAL_PLAYER__VARS__itm1,$___LOCAL_PLAYER__VARS__itmk1,$___LOCAL_PLAYER__VARS__itme1,$___LOCAL_PLAYER__VARS__itms1,$___LOCAL_PLAYER__VARS__itmsk1,$___LOCAL_PLAYER__VARS__itm2,$___LOCAL_PLAYER__VARS__itmk2,$___LOCAL_PLAYER__VARS__itme2,$___LOCAL_PLAYER__VARS__itms2,$___LOCAL_PLAYER__VARS__itmsk2, $___LOCAL_PLAYER__VARS__itm3,$___LOCAL_PLAYER__VARS__itmk3,$___LOCAL_PLAYER__VARS__itme3,$___LOCAL_PLAYER__VARS__itms3,$___LOCAL_PLAYER__VARS__itmsk3,$___LOCAL_PLAYER__VARS__itm4,$___LOCAL_PLAYER__VARS__itmk4,$___LOCAL_PLAYER__VARS__itme4,$___LOCAL_PLAYER__VARS__itms4,$___LOCAL_PLAYER__VARS__itmsk4, $___LOCAL_PLAYER__VARS__itm5,$___LOCAL_PLAYER__VARS__itmk5,$___LOCAL_PLAYER__VARS__itme5,$___LOCAL_PLAYER__VARS__itms5,$___LOCAL_PLAYER__VARS__itmsk5,$___LOCAL_PLAYER__VARS__itm6,$___LOCAL_PLAYER__VARS__itmk6,$___LOCAL_PLAYER__VARS__itme6,$___LOCAL_PLAYER__VARS__itms6,$___LOCAL_PLAYER__VARS__itmsk6, $___LOCAL_PLAYER__VARS__searchmemory,$___LOCAL_PLAYER__VARS__nskill,$___LOCAL_PLAYER__VARS__nskillpara; $ss=&$___LOCAL_PLAYER__VARS__ss; $db_player_structure=&$___LOCAL_PLAYER__VARS__db_player_structure; $db_player_structure_types=&$___LOCAL_PLAYER__VARS__db_player_structure_types; $gamedata=&$___LOCAL_PLAYER__VARS__gamedata; $cmd=&$___LOCAL_PLAYER__VARS__cmd; $main=&$___LOCAL_PLAYER__VARS__main; $sdata=&$___LOCAL_PLAYER__VARS__sdata; $fog=&$___LOCAL_PLAYER__VARS__fog; $upexp=&$___LOCAL_PLAYER__VARS__upexp; $lvlupexp=&$___LOCAL_PLAYER__VARS__lvlupexp;  $iconImg=&$___LOCAL_PLAYER__VARS__iconImg; $iconImgB=&$___LOCAL_PLAYER__VARS__iconImgB; $iconImgBwidth=&$___LOCAL_PLAYER__VARS__iconImgBwidth; $ardef=&$___LOCAL_PLAYER__VARS__ardef; $hpcolor=&$___LOCAL_PLAYER__VARS__hpcolor; $spcolor=&$___LOCAL_PLAYER__VARS__spcolor; $newhpimg=&$___LOCAL_PLAYER__VARS__newhpimg; $newspimg=&$___LOCAL_PLAYER__VARS__newspimg; $splt=&$___LOCAL_PLAYER__VARS__splt; $hplt=&$___LOCAL_PLAYER__VARS__hplt;  $tpldata=&$___LOCAL_PLAYER__VARS__tpldata; $icon_list=&$___LOCAL_PLAYER__VARS__icon_list; $icon_list_contents_to_frontend=&$___LOCAL_PLAYER__VARS__icon_list_contents_to_frontend; $typeinfo=&$___LOCAL_PLAYER__VARS__typeinfo; $killmsginfo=&$___LOCAL_PLAYER__VARS__killmsginfo; $lwinfo=&$___LOCAL_PLAYER__VARS__lwinfo; $sexinfo=&$___LOCAL_PLAYER__VARS__sexinfo; $equip_list=&$___LOCAL_PLAYER__VARS__equip_list; $battle_equip_list=&$___LOCAL_PLAYER__VARS__battle_equip_list; $pc_icon_range=&$___LOCAL_PLAYER__VARS__pc_icon_range;  $pid=&$___LOCAL_PLAYER__VARS__pid; $type=&$___LOCAL_PLAYER__VARS__type; $name=&$___LOCAL_PLAYER__VARS__name; $pass=&$___LOCAL_PLAYER__VARS__pass; $ip=&$___LOCAL_PLAYER__VARS__ip; $motto=&$___LOCAL_PLAYER__VARS__motto; $killmsg=&$___LOCAL_PLAYER__VARS__killmsg; $lastword=&$___LOCAL_PLAYER__VARS__lastword; $winner_flag=&$___LOCAL_PLAYER__VARS__winner_flag; $player_dead_flag=&$___LOCAL_PLAYER__VARS__player_dead_flag;  $corpse_clear_flag=&$___LOCAL_PLAYER__VARS__corpse_clear_flag; $gd=&$___LOCAL_PLAYER__VARS__gd; $sNo=&$___LOCAL_PLAYER__VARS__sNo; $club=&$___LOCAL_PLAYER__VARS__club; $validtime=&$___LOCAL_PLAYER__VARS__validtime; $endtime=&$___LOCAL_PLAYER__VARS__endtime; $cdsec=&$___LOCAL_PLAYER__VARS__cdsec; $cdmsec=&$___LOCAL_PLAYER__VARS__cdmsec; $cdtime=&$___LOCAL_PLAYER__VARS__cdtime; $action=&$___LOCAL_PLAYER__VARS__action;  $a_actionnum=&$___LOCAL_PLAYER__VARS__a_actionnum; $v_actionnum=&$___LOCAL_PLAYER__VARS__v_actionnum; $hp=&$___LOCAL_PLAYER__VARS__hp; $mhp=&$___LOCAL_PLAYER__VARS__mhp; $sp=&$___LOCAL_PLAYER__VARS__sp; $msp=&$___LOCAL_PLAYER__VARS__msp; $mss=&$___LOCAL_PLAYER__VARS__mss; $att=&$___LOCAL_PLAYER__VARS__att; $def=&$___LOCAL_PLAYER__VARS__def; $pls=&$___LOCAL_PLAYER__VARS__pls;  $lvl=&$___LOCAL_PLAYER__VARS__lvl; $exp=&$___LOCAL_PLAYER__VARS__exp; $money=&$___LOCAL_PLAYER__VARS__money; $rp=&$___LOCAL_PLAYER__VARS__rp; $bid=&$___LOCAL_PLAYER__VARS__bid; $inf=&$___LOCAL_PLAYER__VARS__inf; $rage=&$___LOCAL_PLAYER__VARS__rage; $pose=&$___LOCAL_PLAYER__VARS__pose; $tactic=&$___LOCAL_PLAYER__VARS__tactic; $killnum=&$___LOCAL_PLAYER__VARS__killnum;  $npckillnum=&$___LOCAL_PLAYER__VARS__npckillnum; $state=&$___LOCAL_PLAYER__VARS__state; $skillpoint=&$___LOCAL_PLAYER__VARS__skillpoint; $flare=&$___LOCAL_PLAYER__VARS__flare; $wp=&$___LOCAL_PLAYER__VARS__wp; $wk=&$___LOCAL_PLAYER__VARS__wk; $wg=&$___LOCAL_PLAYER__VARS__wg; $wc=&$___LOCAL_PLAYER__VARS__wc; $wd=&$___LOCAL_PLAYER__VARS__wd; $wf=&$___LOCAL_PLAYER__VARS__wf;  $icon=&$___LOCAL_PLAYER__VARS__icon; $teamID=&$___LOCAL_PLAYER__VARS__teamID; $teamPass=&$___LOCAL_PLAYER__VARS__teamPass; $card=&$___LOCAL_PLAYER__VARS__card; $cardname=&$___LOCAL_PLAYER__VARS__cardname; $wep=&$___LOCAL_PLAYER__VARS__wep; $wepk=&$___LOCAL_PLAYER__VARS__wepk; $wepe=&$___LOCAL_PLAYER__VARS__wepe; $weps=&$___LOCAL_PLAYER__VARS__weps; $wepsk=&$___LOCAL_PLAYER__VARS__wepsk;  $arb=&$___LOCAL_PLAYER__VARS__arb; $arbk=&$___LOCAL_PLAYER__VARS__arbk; $arbe=&$___LOCAL_PLAYER__VARS__arbe; $arbs=&$___LOCAL_PLAYER__VARS__arbs; $arbsk=&$___LOCAL_PLAYER__VARS__arbsk; $arh=&$___LOCAL_PLAYER__VARS__arh; $arhk=&$___LOCAL_PLAYER__VARS__arhk; $arhe=&$___LOCAL_PLAYER__VARS__arhe; $arhs=&$___LOCAL_PLAYER__VARS__arhs; $arhsk=&$___LOCAL_PLAYER__VARS__arhsk;  $ara=&$___LOCAL_PLAYER__VARS__ara; $arak=&$___LOCAL_PLAYER__VARS__arak; $arae=&$___LOCAL_PLAYER__VARS__arae; $aras=&$___LOCAL_PLAYER__VARS__aras; $arask=&$___LOCAL_PLAYER__VARS__arask; $arf=&$___LOCAL_PLAYER__VARS__arf; $arfk=&$___LOCAL_PLAYER__VARS__arfk; $arfe=&$___LOCAL_PLAYER__VARS__arfe; $arfs=&$___LOCAL_PLAYER__VARS__arfs; $arfsk=&$___LOCAL_PLAYER__VARS__arfsk;  $art=&$___LOCAL_PLAYER__VARS__art; $artk=&$___LOCAL_PLAYER__VARS__artk; $arte=&$___LOCAL_PLAYER__VARS__arte; $arts=&$___LOCAL_PLAYER__VARS__arts; $artsk=&$___LOCAL_PLAYER__VARS__artsk; $itm0=&$___LOCAL_PLAYER__VARS__itm0; $itmk0=&$___LOCAL_PLAYER__VARS__itmk0; $itme0=&$___LOCAL_PLAYER__VARS__itme0; $itms0=&$___LOCAL_PLAYER__VARS__itms0; $itmsk0=&$___LOCAL_PLAYER__VARS__itmsk0;  $itm1=&$___LOCAL_PLAYER__VARS__itm1; $itmk1=&$___LOCAL_PLAYER__VARS__itmk1; $itme1=&$___LOCAL_PLAYER__VARS__itme1; $itms1=&$___LOCAL_PLAYER__VARS__itms1; $itmsk1=&$___LOCAL_PLAYER__VARS__itmsk1; $itm2=&$___LOCAL_PLAYER__VARS__itm2; $itmk2=&$___LOCAL_PLAYER__VARS__itmk2; $itme2=&$___LOCAL_PLAYER__VARS__itme2; $itms2=&$___LOCAL_PLAYER__VARS__itms2; $itmsk2=&$___LOCAL_PLAYER__VARS__itmsk2;  $itm3=&$___LOCAL_PLAYER__VARS__itm3; $itmk3=&$___LOCAL_PLAYER__VARS__itmk3; $itme3=&$___LOCAL_PLAYER__VARS__itme3; $itms3=&$___LOCAL_PLAYER__VARS__itms3; $itmsk3=&$___LOCAL_PLAYER__VARS__itmsk3; $itm4=&$___LOCAL_PLAYER__VARS__itm4; $itmk4=&$___LOCAL_PLAYER__VARS__itmk4; $itme4=&$___LOCAL_PLAYER__VARS__itme4; $itms4=&$___LOCAL_PLAYER__VARS__itms4; $itmsk4=&$___LOCAL_PLAYER__VARS__itmsk4;  $itm5=&$___LOCAL_PLAYER__VARS__itm5; $itmk5=&$___LOCAL_PLAYER__VARS__itmk5; $itme5=&$___LOCAL_PLAYER__VARS__itme5; $itms5=&$___LOCAL_PLAYER__VARS__itms5; $itmsk5=&$___LOCAL_PLAYER__VARS__itmsk5; $itm6=&$___LOCAL_PLAYER__VARS__itm6; $itmk6=&$___LOCAL_PLAYER__VARS__itmk6; $itme6=&$___LOCAL_PLAYER__VARS__itme6; $itms6=&$___LOCAL_PLAYER__VARS__itms6; $itmsk6=&$___LOCAL_PLAYER__VARS__itmsk6;  $searchmemory=&$___LOCAL_PLAYER__VARS__searchmemory; $nskill=&$___LOCAL_PLAYER__VARS__nskill; $nskillpara=&$___LOCAL_PLAYER__VARS__nskillpara;  global $___LOCAL_NPC__VARS__npcinit,$___LOCAL_NPC__VARS__npcinfo,$___LOCAL_NPC__VARS__killzone_resistant_typelist,$___LOCAL_NPC__VARS__npc_typeinfo,$___LOCAL_NPC__VARS__npc_killmsginfo,$___LOCAL_NPC__VARS__npc_lwinfo,$___LOCAL_NPC__VARS__npc_revive_info; $npcinit=&$___LOCAL_NPC__VARS__npcinit; $npcinfo=&$___LOCAL_NPC__VARS__npcinfo; $killzone_resistant_typelist=&$___LOCAL_NPC__VARS__killzone_resistant_typelist; $npc_typeinfo=&$___LOCAL_NPC__VARS__npc_typeinfo; $npc_killmsginfo=&$___LOCAL_NPC__VARS__npc_killmsginfo; $npc_lwinfo=&$___LOCAL_NPC__VARS__npc_lwinfo; $npc_revive_info=&$___LOCAL_NPC__VARS__npc_revive_info;  global $___LOCAL_LVLCTL__VARS__lvuphp,$___LOCAL_LVLCTL__VARS__lvupatt,$___LOCAL_LVLCTL__VARS__lvupdef,$___LOCAL_LVLCTL__VARS__lvupskill,$___LOCAL_LVLCTL__VARS__lvupsp,$___LOCAL_LVLCTL__VARS__lvupspref,$___LOCAL_LVLCTL__VARS__lvupskpt,$___LOCAL_LVLCTL__VARS__sklog,$___LOCAL_LVLCTL__VARS__baseexp; $lvuphp=&$___LOCAL_LVLCTL__VARS__lvuphp; $lvupatt=&$___LOCAL_LVLCTL__VARS__lvupatt; $lvupdef=&$___LOCAL_LVLCTL__VARS__lvupdef; $lvupskill=&$___LOCAL_LVLCTL__VARS__lvupskill; $lvupsp=&$___LOCAL_LVLCTL__VARS__lvupsp; $lvupspref=&$___LOCAL_LVLCTL__VARS__lvupspref; $lvupskpt=&$___LOCAL_LVLCTL__VARS__lvupskpt; $sklog=&$___LOCAL_LVLCTL__VARS__sklog; $baseexp=&$___LOCAL_LVLCTL__VARS__baseexp;   } while (0);
		
		if(!$plslist) $plslist = \map\get_safe_plslist();
		
		$npc['endtime'] = $now;
		$npc['hp'] = $npc['mhp'];
		$npc['sp'] = $npc['msp'];
		if(!empty($npc['mss'])) $npc['ss'] = $npc['mss'];
		
		$npc['exp'] = \lvlctl\calc_upexp($npc['lvl'] - 1);
		
		if(is_array($npc['skill'])) {$npc = array_merge($npc,$npc['skill']);}
		else { $npc['wp'] = $npc['wk'] = $npc['wg'] = $npc['wc'] = $npc['wd'] = $npc['wf'] = $npc['skill'];}						
		
		if($npc['gd'] == 'r'){$npc['gd'] = rand(0,1) ? 'm':'f';}
		
		if($npc['pls'] == 99){
			if(!empty($plslist)){
				$npc['pls'] = array_randompick($plslist);
			}else{
				$npc['pls'] = 0;
			}
		}	
		
		if(!isset($npc['state'])){$npc['state'] = 1;}
		
		
		



		$___TMP_MOD_npc_FUNC_init_npcdata_RET =  $npc;
			break; 
		}while(0);
		//======== End of contents from mod npc ========

$npc = $__VAR_DUMP_MOD_clubbase_VARS_npc; unset($__VAR_DUMP_MOD_clubbase_VARS_npc);$plslist = $__VAR_DUMP_MOD_clubbase_VARS_plslist; unset($__VAR_DUMP_MOD_clubbase_VARS_plslist);

		 
		$npc = $___TMP_MOD_npc_FUNC_init_npcdata_RET;
		\clubbase\init_npcdata_skills ($npc);
		$___TMP_MOD_clubbase_FUNC_init_npcdata_RET =  $npc;
			break; 
		}while(0);
		//======== End of contents from mod clubbase ========

$npc = $__VAR_DUMP_MOD_attrbase_VARS_npc; unset($__VAR_DUMP_MOD_attrbase_VARS_npc);$plslist = $__VAR_DUMP_MOD_attrbase_VARS_plslist; unset($__VAR_DUMP_MOD_attrbase_VARS_plslist);

		 
		$npc = $___TMP_MOD_clubbase_FUNC_init_npcdata_RET;
		
		
		$equip_list = Array('wep', 'arb', 'arh', 'ara', 'arf', 'art', 'itm0', 'itm1', 'itm2', 'itm3', 'itm4', 'itm5', 'itm6');
		foreach($equip_list as $pos) {
			if(strpos($pos, 'itm')===0) {
				$posskn = 'itmsk'.substr($pos, 3);
			}else{
				$posskn = $pos.'sk';
			}
			if(!empty($npc[$posskn])) {
				$npc[$posskn] = \attrbase\config_process_encode_comp_itmsk ($npc[$posskn]);
			}
		}
		
		$___TMP_MOD_attrbase_FUNC_init_npcdata_RET =  $npc;
			break; 
		}while(0);
		//======== End of contents from mod attrbase ========

$npc = $__VAR_DUMP_MOD_aprilfool2018_VARS_npc; unset($__VAR_DUMP_MOD_aprilfool2018_VARS_npc);$plslist = $__VAR_DUMP_MOD_aprilfool2018_VARS_plslist; unset($__VAR_DUMP_MOD_aprilfool2018_VARS_plslist);

		 
		$npc = $___TMP_MOD_attrbase_FUNC_init_npcdata_RET;
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;   } while (0);
		if(in_array($gametype, array(0,4)) && 1 == \achievement_base\check_achtype_available(34) && 41 == $npc['type']) {
			do { global $___LOCAL_PLAYER__VARS__ss,$___LOCAL_PLAYER__VARS__db_player_structure,$___LOCAL_PLAYER__VARS__db_player_structure_types,$___LOCAL_PLAYER__VARS__gamedata,$___LOCAL_PLAYER__VARS__cmd,$___LOCAL_PLAYER__VARS__main,$___LOCAL_PLAYER__VARS__sdata,$___LOCAL_PLAYER__VARS__fog,$___LOCAL_PLAYER__VARS__upexp,$___LOCAL_PLAYER__VARS__lvlupexp, $___LOCAL_PLAYER__VARS__iconImg,$___LOCAL_PLAYER__VARS__iconImgB,$___LOCAL_PLAYER__VARS__iconImgBwidth,$___LOCAL_PLAYER__VARS__ardef,$___LOCAL_PLAYER__VARS__hpcolor,$___LOCAL_PLAYER__VARS__spcolor,$___LOCAL_PLAYER__VARS__newhpimg,$___LOCAL_PLAYER__VARS__newspimg,$___LOCAL_PLAYER__VARS__splt,$___LOCAL_PLAYER__VARS__hplt, $___LOCAL_PLAYER__VARS__tpldata,$___LOCAL_PLAYER__VARS__icon_list,$___LOCAL_PLAYER__VARS__icon_list_contents_to_frontend,$___LOCAL_PLAYER__VARS__typeinfo,$___LOCAL_PLAYER__VARS__killmsginfo,$___LOCAL_PLAYER__VARS__lwinfo,$___LOCAL_PLAYER__VARS__sexinfo,$___LOCAL_PLAYER__VARS__equip_list,$___LOCAL_PLAYER__VARS__battle_equip_list,$___LOCAL_PLAYER__VARS__pc_icon_range, $___LOCAL_PLAYER__VARS__pid,$___LOCAL_PLAYER__VARS__type,$___LOCAL_PLAYER__VARS__name,$___LOCAL_PLAYER__VARS__pass,$___LOCAL_PLAYER__VARS__ip,$___LOCAL_PLAYER__VARS__motto,$___LOCAL_PLAYER__VARS__killmsg,$___LOCAL_PLAYER__VARS__lastword,$___LOCAL_PLAYER__VARS__winner_flag,$___LOCAL_PLAYER__VARS__player_dead_flag, $___LOCAL_PLAYER__VARS__corpse_clear_flag,$___LOCAL_PLAYER__VARS__gd,$___LOCAL_PLAYER__VARS__sNo,$___LOCAL_PLAYER__VARS__club,$___LOCAL_PLAYER__VARS__validtime,$___LOCAL_PLAYER__VARS__endtime,$___LOCAL_PLAYER__VARS__cdsec,$___LOCAL_PLAYER__VARS__cdmsec,$___LOCAL_PLAYER__VARS__cdtime,$___LOCAL_PLAYER__VARS__action, $___LOCAL_PLAYER__VARS__a_actionnum,$___LOCAL_PLAYER__VARS__v_actionnum,$___LOCAL_PLAYER__VARS__hp,$___LOCAL_PLAYER__VARS__mhp,$___LOCAL_PLAYER__VARS__sp,$___LOCAL_PLAYER__VARS__msp,$___LOCAL_PLAYER__VARS__mss,$___LOCAL_PLAYER__VARS__att,$___LOCAL_PLAYER__VARS__def,$___LOCAL_PLAYER__VARS__pls, $___LOCAL_PLAYER__VARS__lvl,$___LOCAL_PLAYER__VARS__exp,$___LOCAL_PLAYER__VARS__money,$___LOCAL_PLAYER__VARS__rp,$___LOCAL_PLAYER__VARS__bid,$___LOCAL_PLAYER__VARS__inf,$___LOCAL_PLAYER__VARS__rage,$___LOCAL_PLAYER__VARS__pose,$___LOCAL_PLAYER__VARS__tactic,$___LOCAL_PLAYER__VARS__killnum, $___LOCAL_PLAYER__VARS__npckillnum,$___LOCAL_PLAYER__VARS__state,$___LOCAL_PLAYER__VARS__skillpoint,$___LOCAL_PLAYER__VARS__flare,$___LOCAL_PLAYER__VARS__wp,$___LOCAL_PLAYER__VARS__wk,$___LOCAL_PLAYER__VARS__wg,$___LOCAL_PLAYER__VARS__wc,$___LOCAL_PLAYER__VARS__wd,$___LOCAL_PLAYER__VARS__wf, $___LOCAL_PLAYER__VARS__icon,$___LOCAL_PLAYER__VARS__teamID,$___LOCAL_PLAYER__VARS__teamPass,$___LOCAL_PLAYER__VARS__card,$___LOCAL_PLAYER__VARS__cardname,$___LOCAL_PLAYER__VARS__wep,$___LOCAL_PLAYER__VARS__wepk,$___LOCAL_PLAYER__VARS__wepe,$___LOCAL_PLAYER__VARS__weps,$___LOCAL_PLAYER__VARS__wepsk, $___LOCAL_PLAYER__VARS__arb,$___LOCAL_PLAYER__VARS__arbk,$___LOCAL_PLAYER__VARS__arbe,$___LOCAL_PLAYER__VARS__arbs,$___LOCAL_PLAYER__VARS__arbsk,$___LOCAL_PLAYER__VARS__arh,$___LOCAL_PLAYER__VARS__arhk,$___LOCAL_PLAYER__VARS__arhe,$___LOCAL_PLAYER__VARS__arhs,$___LOCAL_PLAYER__VARS__arhsk, $___LOCAL_PLAYER__VARS__ara,$___LOCAL_PLAYER__VARS__arak,$___LOCAL_PLAYER__VARS__arae,$___LOCAL_PLAYER__VARS__aras,$___LOCAL_PLAYER__VARS__arask,$___LOCAL_PLAYER__VARS__arf,$___LOCAL_PLAYER__VARS__arfk,$___LOCAL_PLAYER__VARS__arfe,$___LOCAL_PLAYER__VARS__arfs,$___LOCAL_PLAYER__VARS__arfsk, $___LOCAL_PLAYER__VARS__art,$___LOCAL_PLAYER__VARS__artk,$___LOCAL_PLAYER__VARS__arte,$___LOCAL_PLAYER__VARS__arts,$___LOCAL_PLAYER__VARS__artsk,$___LOCAL_PLAYER__VARS__itm0,$___LOCAL_PLAYER__VARS__itmk0,$___LOCAL_PLAYER__VARS__itme0,$___LOCAL_PLAYER__VARS__itms0,$___LOCAL_PLAYER__VARS__itmsk0, $___LOCAL_PLAYER__VARS__itm1,$___LOCAL_PLAYER__VARS__itmk1,$___LOCAL_PLAYER__VARS__itme1,$___LOCAL_PLAYER__VARS__itms1,$___LOCAL_PLAYER__VARS__itmsk1,$___LOCAL_PLAYER__VARS__itm2,$___LOCAL_PLAYER__VARS__itmk2,$___LOCAL_PLAYER__VARS__itme2,$___LOCAL_PLAYER__VARS__itms2,$___LOCAL_PLAYER__VARS__itmsk2, $___LOCAL_PLAYER__VARS__itm3,$___LOCAL_PLAYER__VARS__itmk3,$___LOCAL_PLAYER__VARS__itme3,$___LOCAL_PLAYER__VARS__itms3,$___LOCAL_PLAYER__VARS__itmsk3,$___LOCAL_PLAYER__VARS__itm4,$___LOCAL_PLAYER__VARS__itmk4,$___LOCAL_PLAYER__VARS__itme4,$___LOCAL_PLAYER__VARS__itms4,$___LOCAL_PLAYER__VARS__itmsk4, $___LOCAL_PLAYER__VARS__itm5,$___LOCAL_PLAYER__VARS__itmk5,$___LOCAL_PLAYER__VARS__itme5,$___LOCAL_PLAYER__VARS__itms5,$___LOCAL_PLAYER__VARS__itmsk5,$___LOCAL_PLAYER__VARS__itm6,$___LOCAL_PLAYER__VARS__itmk6,$___LOCAL_PLAYER__VARS__itme6,$___LOCAL_PLAYER__VARS__itms6,$___LOCAL_PLAYER__VARS__itmsk6, $___LOCAL_PLAYER__VARS__searchmemory,$___LOCAL_PLAYER__VARS__nskill,$___LOCAL_PLAYER__VARS__nskillpara; $ss=&$___LOCAL_PLAYER__VARS__ss; $db_player_structure=&$___LOCAL_PLAYER__VARS__db_player_structure; $db_player_structure_types=&$___LOCAL_PLAYER__VARS__db_player_structure_types; $gamedata=&$___LOCAL_PLAYER__VARS__gamedata; $cmd=&$___LOCAL_PLAYER__VARS__cmd; $main=&$___LOCAL_PLAYER__VARS__main; $sdata=&$___LOCAL_PLAYER__VARS__sdata; $fog=&$___LOCAL_PLAYER__VARS__fog; $upexp=&$___LOCAL_PLAYER__VARS__upexp; $lvlupexp=&$___LOCAL_PLAYER__VARS__lvlupexp;  $iconImg=&$___LOCAL_PLAYER__VARS__iconImg; $iconImgB=&$___LOCAL_PLAYER__VARS__iconImgB; $iconImgBwidth=&$___LOCAL_PLAYER__VARS__iconImgBwidth; $ardef=&$___LOCAL_PLAYER__VARS__ardef; $hpcolor=&$___LOCAL_PLAYER__VARS__hpcolor; $spcolor=&$___LOCAL_PLAYER__VARS__spcolor; $newhpimg=&$___LOCAL_PLAYER__VARS__newhpimg; $newspimg=&$___LOCAL_PLAYER__VARS__newspimg; $splt=&$___LOCAL_PLAYER__VARS__splt; $hplt=&$___LOCAL_PLAYER__VARS__hplt;  $tpldata=&$___LOCAL_PLAYER__VARS__tpldata; $icon_list=&$___LOCAL_PLAYER__VARS__icon_list; $icon_list_contents_to_frontend=&$___LOCAL_PLAYER__VARS__icon_list_contents_to_frontend; $typeinfo=&$___LOCAL_PLAYER__VARS__typeinfo; $killmsginfo=&$___LOCAL_PLAYER__VARS__killmsginfo; $lwinfo=&$___LOCAL_PLAYER__VARS__lwinfo; $sexinfo=&$___LOCAL_PLAYER__VARS__sexinfo; $equip_list=&$___LOCAL_PLAYER__VARS__equip_list; $battle_equip_list=&$___LOCAL_PLAYER__VARS__battle_equip_list; $pc_icon_range=&$___LOCAL_PLAYER__VARS__pc_icon_range;  $pid=&$___LOCAL_PLAYER__VARS__pid; $type=&$___LOCAL_PLAYER__VARS__type; $name=&$___LOCAL_PLAYER__VARS__name; $pass=&$___LOCAL_PLAYER__VARS__pass; $ip=&$___LOCAL_PLAYER__VARS__ip; $motto=&$___LOCAL_PLAYER__VARS__motto; $killmsg=&$___LOCAL_PLAYER__VARS__killmsg; $lastword=&$___LOCAL_PLAYER__VARS__lastword; $winner_flag=&$___LOCAL_PLAYER__VARS__winner_flag; $player_dead_flag=&$___LOCAL_PLAYER__VARS__player_dead_flag;  $corpse_clear_flag=&$___LOCAL_PLAYER__VARS__corpse_clear_flag; $gd=&$___LOCAL_PLAYER__VARS__gd; $sNo=&$___LOCAL_PLAYER__VARS__sNo; $club=&$___LOCAL_PLAYER__VARS__club; $validtime=&$___LOCAL_PLAYER__VARS__validtime; $endtime=&$___LOCAL_PLAYER__VARS__endtime; $cdsec=&$___LOCAL_PLAYER__VARS__cdsec; $cdmsec=&$___LOCAL_PLAYER__VARS__cdmsec; $cdtime=&$___LOCAL_PLAYER__VARS__cdtime; $action=&$___LOCAL_PLAYER__VARS__action;  $a_actionnum=&$___LOCAL_PLAYER__VARS__a_actionnum; $v_actionnum=&$___LOCAL_PLAYER__VARS__v_actionnum; $hp=&$___LOCAL_PLAYER__VARS__hp; $mhp=&$___LOCAL_PLAYER__VARS__mhp; $sp=&$___LOCAL_PLAYER__VARS__sp; $msp=&$___LOCAL_PLAYER__VARS__msp; $mss=&$___LOCAL_PLAYER__VARS__mss; $att=&$___LOCAL_PLAYER__VARS__att; $def=&$___LOCAL_PLAYER__VARS__def; $pls=&$___LOCAL_PLAYER__VARS__pls;  $lvl=&$___LOCAL_PLAYER__VARS__lvl; $exp=&$___LOCAL_PLAYER__VARS__exp; $money=&$___LOCAL_PLAYER__VARS__money; $rp=&$___LOCAL_PLAYER__VARS__rp; $bid=&$___LOCAL_PLAYER__VARS__bid; $inf=&$___LOCAL_PLAYER__VARS__inf; $rage=&$___LOCAL_PLAYER__VARS__rage; $pose=&$___LOCAL_PLAYER__VARS__pose; $tactic=&$___LOCAL_PLAYER__VARS__tactic; $killnum=&$___LOCAL_PLAYER__VARS__killnum;  $npckillnum=&$___LOCAL_PLAYER__VARS__npckillnum; $state=&$___LOCAL_PLAYER__VARS__state; $skillpoint=&$___LOCAL_PLAYER__VARS__skillpoint; $flare=&$___LOCAL_PLAYER__VARS__flare; $wp=&$___LOCAL_PLAYER__VARS__wp; $wk=&$___LOCAL_PLAYER__VARS__wk; $wg=&$___LOCAL_PLAYER__VARS__wg; $wc=&$___LOCAL_PLAYER__VARS__wc; $wd=&$___LOCAL_PLAYER__VARS__wd; $wf=&$___LOCAL_PLAYER__VARS__wf;  $icon=&$___LOCAL_PLAYER__VARS__icon; $teamID=&$___LOCAL_PLAYER__VARS__teamID; $teamPass=&$___LOCAL_PLAYER__VARS__teamPass; $card=&$___LOCAL_PLAYER__VARS__card; $cardname=&$___LOCAL_PLAYER__VARS__cardname; $wep=&$___LOCAL_PLAYER__VARS__wep; $wepk=&$___LOCAL_PLAYER__VARS__wepk; $wepe=&$___LOCAL_PLAYER__VARS__wepe; $weps=&$___LOCAL_PLAYER__VARS__weps; $wepsk=&$___LOCAL_PLAYER__VARS__wepsk;  $arb=&$___LOCAL_PLAYER__VARS__arb; $arbk=&$___LOCAL_PLAYER__VARS__arbk; $arbe=&$___LOCAL_PLAYER__VARS__arbe; $arbs=&$___LOCAL_PLAYER__VARS__arbs; $arbsk=&$___LOCAL_PLAYER__VARS__arbsk; $arh=&$___LOCAL_PLAYER__VARS__arh; $arhk=&$___LOCAL_PLAYER__VARS__arhk; $arhe=&$___LOCAL_PLAYER__VARS__arhe; $arhs=&$___LOCAL_PLAYER__VARS__arhs; $arhsk=&$___LOCAL_PLAYER__VARS__arhsk;  $ara=&$___LOCAL_PLAYER__VARS__ara; $arak=&$___LOCAL_PLAYER__VARS__arak; $arae=&$___LOCAL_PLAYER__VARS__arae; $aras=&$___LOCAL_PLAYER__VARS__aras; $arask=&$___LOCAL_PLAYER__VARS__arask; $arf=&$___LOCAL_PLAYER__VARS__arf; $arfk=&$___LOCAL_PLAYER__VARS__arfk; $arfe=&$___LOCAL_PLAYER__VARS__arfe; $arfs=&$___LOCAL_PLAYER__VARS__arfs; $arfsk=&$___LOCAL_PLAYER__VARS__arfsk;  $art=&$___LOCAL_PLAYER__VARS__art; $artk=&$___LOCAL_PLAYER__VARS__artk; $arte=&$___LOCAL_PLAYER__VARS__arte; $arts=&$___LOCAL_PLAYER__VARS__arts; $artsk=&$___LOCAL_PLAYER__VARS__artsk; $itm0=&$___LOCAL_PLAYER__VARS__itm0; $itmk0=&$___LOCAL_PLAYER__VARS__itmk0; $itme0=&$___LOCAL_PLAYER__VARS__itme0; $itms0=&$___LOCAL_PLAYER__VARS__itms0; $itmsk0=&$___LOCAL_PLAYER__VARS__itmsk0;  $itm1=&$___LOCAL_PLAYER__VARS__itm1; $itmk1=&$___LOCAL_PLAYER__VARS__itmk1; $itme1=&$___LOCAL_PLAYER__VARS__itme1; $itms1=&$___LOCAL_PLAYER__VARS__itms1; $itmsk1=&$___LOCAL_PLAYER__VARS__itmsk1; $itm2=&$___LOCAL_PLAYER__VARS__itm2; $itmk2=&$___LOCAL_PLAYER__VARS__itmk2; $itme2=&$___LOCAL_PLAYER__VARS__itme2; $itms2=&$___LOCAL_PLAYER__VARS__itms2; $itmsk2=&$___LOCAL_PLAYER__VARS__itmsk2;  $itm3=&$___LOCAL_PLAYER__VARS__itm3; $itmk3=&$___LOCAL_PLAYER__VARS__itmk3; $itme3=&$___LOCAL_PLAYER__VARS__itme3; $itms3=&$___LOCAL_PLAYER__VARS__itms3; $itmsk3=&$___LOCAL_PLAYER__VARS__itmsk3; $itm4=&$___LOCAL_PLAYER__VARS__itm4; $itmk4=&$___LOCAL_PLAYER__VARS__itmk4; $itme4=&$___LOCAL_PLAYER__VARS__itme4; $itms4=&$___LOCAL_PLAYER__VARS__itms4; $itmsk4=&$___LOCAL_PLAYER__VARS__itmsk4;  $itm5=&$___LOCAL_PLAYER__VARS__itm5; $itmk5=&$___LOCAL_PLAYER__VARS__itmk5; $itme5=&$___LOCAL_PLAYER__VARS__itme5; $itms5=&$___LOCAL_PLAYER__VARS__itms5; $itmsk5=&$___LOCAL_PLAYER__VARS__itmsk5; $itm6=&$___LOCAL_PLAYER__VARS__itm6; $itmk6=&$___LOCAL_PLAYER__VARS__itmk6; $itme6=&$___LOCAL_PLAYER__VARS__itme6; $itms6=&$___LOCAL_PLAYER__VARS__itms6; $itmsk6=&$___LOCAL_PLAYER__VARS__itmsk6;  $searchmemory=&$___LOCAL_PLAYER__VARS__searchmemory; $nskill=&$___LOCAL_PLAYER__VARS__nskill; $nskillpara=&$___LOCAL_PLAYER__VARS__nskillpara;   } while (0);
			$newsname=$typeinfo[$npc['type']].' '.$npc['name'];
			\sys\addnews(0, 'addnpc_pls', $newsname, '', $npc['pls']);
		}
		$___TMP_MOD_aprilfool2018_FUNC_init_npcdata_RET =  $npc;
			break; 
		}while(0);
		//======== End of contents from mod aprilfool2018 ========

$npc = $__VAR_DUMP_MOD_item_ext_armor_VARS_npc; unset($__VAR_DUMP_MOD_item_ext_armor_VARS_npc);$plslist = $__VAR_DUMP_MOD_item_ext_armor_VARS_plslist; unset($__VAR_DUMP_MOD_item_ext_armor_VARS_plslist);
		 
		$npc = $___TMP_MOD_aprilfool2018_FUNC_init_npcdata_RET;
		if(!empty($npc['ext_armor'])) {
			
			$equip_list = Array('arb', 'arh', 'ara', 'arf', 'itm0', 'itm1', 'itm2', 'itm3', 'itm4', 'itm5', 'itm6');
			foreach($equip_list as $pos) {
				if(!empty($npc['ext_armor'][$pos])) {
					if(strpos($pos, 'itm')===0) {
						$n = substr($pos, 3);
						$ik = 'itmk'.$n; $ie = 'itme'.$n; $is = 'itms'.$n; $isk = 'itmsk'.$n;
					}else{
						$ik = $pos.'k'; $ie = $pos.'e'; $is = $pos.'s'; $isk = $pos.'sk';
					}
					if(substr($npc[$ik],0,1) != 'D' || substr($npc['ext_armor'][$ik],0,1) != 'D' || substr($npc['ext_armor'][$ik],2,1) != 'S') continue;
					
					
					if(empty($npc[$pos])) $npc[$pos] = '';
					if(empty($npc[$ik])) $npc[$ik] = '';
					if(empty($npc[$ie])) $npc[$ie] = 0;
					if(empty($npc[$is])) $npc[$is] = 0;
					if(empty($npc[$isk])) $npc[$isk] = '';
					
					
					if(empty($npc['ext_armor'][$ie])) $npc['ext_armor'][$ie] = 0;
					if(empty($npc['ext_armor'][$is])) continue;
					if(empty($npc['ext_armor'][$isk])) $npc['ext_armor'][$isk] = '';
					
					$theitem = Array(
						'itm' => &$npc['ext_armor'][$pos],
						'itmk' => &$npc['ext_armor'][$ik],
						'itme' => &$npc['ext_armor'][$ie],
						'itms' => &$npc['ext_armor'][$is],
						'itmsk' => &$npc['ext_armor'][$isk]
					);
					$positem = Array(
						'itm' => &$npc[$pos],
						'itmk' => &$npc[$ik],
						'itme' => &$npc[$ie],
						'itms' => &$npc[$is],
						'itmsk' => &$npc[$isk]
					);
					\item_ext_armor\use_armor_ext_armor_process ($theitem, $positem);
				}
			}
		}
		return $npc;
	
	}
	
	









}

?>