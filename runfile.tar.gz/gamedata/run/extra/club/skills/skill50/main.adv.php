<?php

namespace skill50
{
	function init() 
	{
		define('MOD_SKILL50_INFO','club;');
		do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;   } while (0);
		$clubskillname[50] = '枭眼';
	}
	
	function acquire50(&$pa)
	{
		
	}
	
	function lost50(&$pa)
	{
		
	}
	
	function check_unlocked50(&$pa)
	{
		
		return $pa['lvl']>=9;
	}
	
	
	function check_skill50_proc(&$pa, &$pd, $active)
	{
		
		$r1 = \weapon\get_weapon_range($pa, $active);
		$r2 = \weapon\get_weapon_range($pd, 1-$active);
		if ($r1 >= $r2 && $r1 != 0 && $r2 != 0)
			return 1;
		else  return 0;
	}
	
	function get_hitrate_multiplier(&$pa, &$pd, $active)
	{
		return \skill265\get_hitrate_multiplier($pa,$pd,$active);
	}
	
	function get_rapid_accuracy_loss(&$pa, &$pd, $active)
	{
		return \skill741\get_rapid_accuracy_loss($pa,$pd,$active);
	}
	
	function calculate_active_obbs_multiplier(&$ldata,&$edata)
	{
		return \skill903\calculate_active_obbs_multiplier($ldata,$edata);
	}
	
}

?>
