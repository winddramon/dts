<?php

namespace skill47
{
	
	$ragecost = 5; 
	
	$wep_skillkind_req = 'wc';
	
	function init() 
	{
		define('MOD_SKILL47_INFO','club;battle;');
		do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;   } while (0);
		$clubskillname[47] = '花雨';
	}
	
	function acquire47(&$pa)
	{
		
	}
	
	function lost47(&$pa)
	{
		
	}
	
	function check_unlocked47(&$pa)
	{
		
		return $pa['lvl']>=3;
	}
	
	function get_rage_cost47(&$pa = NULL)
	{
		
		do { global $___LOCAL_SKILL47__VARS__ragecost,$___LOCAL_SKILL47__VARS__wep_skillkind_req; $ragecost=&$___LOCAL_SKILL47__VARS__ragecost; $wep_skillkind_req=&$___LOCAL_SKILL47__VARS__wep_skillkind_req;   } while (0);
		return $ragecost;
	}
	
	function strike_prepare(&$pa, &$pd, $active)
	{
		$___TEMP_backtrace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 2); 
		array_shift($___TEMP_backtrace);
		if (count($___TEMP_backtrace)==0) $___TEMP_PARENT_NAME=''; else $___TEMP_PARENT_NAME=strtolower($___TEMP_backtrace[0]['function']);
		if ($___TEMP_PARENT_NAME!='skill48\strike_prepare') 
		{
			return \skill507\strike_prepare($pa,$pd,$active);
		}
		unset($___TEMP_PARENT_NAME); unset($___TEMP_backtrace); 
	
		
		
		if ($pa['bskill']!=47) {
			\ex_dmg_nullify\strike_prepare($pa, $pd, $active);
			return;
		}
		if (!\skillbase\skill_query(47,$pa) || !\skill47\check_unlocked47 ($pa))
		{
			do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
			$log .= '你尚未解锁这个技能！';
			$pa['bskill']=0;
		}
		else
		{
			$rcost = \skill47\get_rage_cost47 ($pa);
			if ( !\clubbase\check_battle_skill_unactivatable($pa,$pd,47) )
			{
				do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
				if ($active)
					$log.="<span class=\"lime b\">你对{$pd['name']}发动了技能「花雨」！</span><br>";
				else  $log.="<span class=\"lime b\">{$pa['name']}对你发动了技能「花雨」！</span><br>";
				$pa['rage']-=$rcost;
				addnews ( 0, 'bskill47', $pa['name'], $pd['name'] );
				
				do { global $___LOCAL_EX_DMG_ATT__VARS__ex_attack_list,$___LOCAL_EX_DMG_ATT__VARS__exdmgname,$___LOCAL_EX_DMG_ATT__VARS__ex_good_wep,$___LOCAL_EX_DMG_ATT__VARS__ex_base_dmg,$___LOCAL_EX_DMG_ATT__VARS__ex_max_dmg,$___LOCAL_EX_DMG_ATT__VARS__ex_wep_dmg,$___LOCAL_EX_DMG_ATT__VARS__ex_skill_dmg,$___LOCAL_EX_DMG_ATT__VARS__ex_dmg_fluc,$___LOCAL_EX_DMG_ATT__VARS__ex_inf,$___LOCAL_EX_DMG_ATT__VARS__ex_inf_punish, $___LOCAL_EX_DMG_ATT__VARS__ex_inf_r,$___LOCAL_EX_DMG_ATT__VARS__ex_max_inf_r,$___LOCAL_EX_DMG_ATT__VARS__ex_skill_inf_r; $ex_attack_list=&$___LOCAL_EX_DMG_ATT__VARS__ex_attack_list; $exdmgname=&$___LOCAL_EX_DMG_ATT__VARS__exdmgname; $ex_good_wep=&$___LOCAL_EX_DMG_ATT__VARS__ex_good_wep; $ex_base_dmg=&$___LOCAL_EX_DMG_ATT__VARS__ex_base_dmg; $ex_max_dmg=&$___LOCAL_EX_DMG_ATT__VARS__ex_max_dmg; $ex_wep_dmg=&$___LOCAL_EX_DMG_ATT__VARS__ex_wep_dmg; $ex_skill_dmg=&$___LOCAL_EX_DMG_ATT__VARS__ex_skill_dmg; $ex_dmg_fluc=&$___LOCAL_EX_DMG_ATT__VARS__ex_dmg_fluc; $ex_inf=&$___LOCAL_EX_DMG_ATT__VARS__ex_inf; $ex_inf_punish=&$___LOCAL_EX_DMG_ATT__VARS__ex_inf_punish;  $ex_inf_r=&$___LOCAL_EX_DMG_ATT__VARS__ex_inf_r; $ex_max_inf_r=&$___LOCAL_EX_DMG_ATT__VARS__ex_max_inf_r; $ex_skill_inf_r=&$___LOCAL_EX_DMG_ATT__VARS__ex_skill_inf_r;   } while (0);
				$lis = Array('p', 'u', 'i', 'e', 'w');


				$pa['skill47_flag']=$lis[rand(0,count($lis)-1)];
			}
			else
			{
				if ($active)
				{
					do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
					$log.='怒气不足或其他原因不能发动。<br>';
				}
				$pa['bskill']=0;
			}
		}
		\ex_dmg_nullify\strike_prepare($pa, $pd, $active);
	
	}	
	
	function ex_attack_prepare(&$pa, &$pd, $active)
	{
		return \skill215\ex_attack_prepare($pa,$pd,$active);
	}
	
	function get_ex_attack_array_core(&$pa, &$pd, $active)
	{
		return \skill507\get_ex_attack_array_core($pa,$pd,$active);
	}
	
	function parse_news($nid, $news, $hour, $min, $sec, $a, $b, $c, $d, $e, $exarr = array())
	{
		return \skill489\parse_news($nid,$news,$hour,$min,$sec,$a,$b,$c,$d,$e,$exarr);
	}
	
}

?>
