<?php

namespace skill38
{
	
	$ragecost = 85; 
	
	$wepk_req = 'WP';
	
	function init() 
	{
		define('MOD_SKILL38_INFO','club;battle;');
		do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;   } while (0);
		$clubskillname[38] = '闷棍';
	}
	
	function acquire38(&$pa)
	{
		
	}
	
	function lost38(&$pa)
	{
		
	}
	
	function check_unlocked38(&$pa)
	{
		
		return $pa['lvl']>=11;
	}
	
	function get_rage_cost38(&$pa = NULL)
	{
		
		do { global $___LOCAL_SKILL38__VARS__ragecost,$___LOCAL_SKILL38__VARS__wepk_req; $ragecost=&$___LOCAL_SKILL38__VARS__ragecost; $wepk_req=&$___LOCAL_SKILL38__VARS__wepk_req;   } while (0);
		return $ragecost;
	}
	
	function strike_prepare(&$pa, &$pd, $active)
	{
		return \skill507\strike_prepare($pa,$pd,$active);
	}	
	
	
	function calculate_skill35_proc_rate(&$pa, &$pd, $active)
	{
		
		if ($pa['bskill']!=38){
if(isset($active)) {$__VAR_DUMP_MOD_skill38_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill38_VARS_active = NULL;} 
		//======== Start of contents from mod skill36 ========
		do{
			$___TMP_MOD_skill36_FUNC_calculate_skill35_proc_rate_RET = NULL;

		
		if ($pa['bskill']!=36){
if(isset($active)) {$__VAR_DUMP_MOD_skill36_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill36_VARS_active = NULL;} 
		//======== Start of contents from mod skill35 ========
		do{
			$___TMP_MOD_skill35_FUNC_calculate_skill35_proc_rate_RET = NULL;

		
		do { global $___LOCAL_SKILL35__VARS__attgain,$___LOCAL_SKILL35__VARS__sk35_stuntime,$___LOCAL_SKILL35__VARS__upgradecost,$___LOCAL_SKILL35__VARS__proc_rate; $attgain=&$___LOCAL_SKILL35__VARS__attgain; $sk35_stuntime=&$___LOCAL_SKILL35__VARS__sk35_stuntime; $upgradecost=&$___LOCAL_SKILL35__VARS__upgradecost; $proc_rate=&$___LOCAL_SKILL35__VARS__proc_rate;   } while (0);
		$___TMP_MOD_skill35_FUNC_calculate_skill35_proc_rate_RET =  $proc_rate;
			break; 
		}while(0);
		//======== End of contents from mod skill35 ========

$active = $__VAR_DUMP_MOD_skill36_VARS_active; unset($__VAR_DUMP_MOD_skill36_VARS_active); $___TMP_MOD_skill36_FUNC_calculate_skill35_proc_rate_RET =  $___TMP_MOD_skill35_FUNC_calculate_skill35_proc_rate_RET;
			break; }
		$___TMP_MOD_skill36_FUNC_calculate_skill35_proc_rate_RET =  100;
			break; 
		}while(0);
		//======== End of contents from mod skill36 ========

$active = $__VAR_DUMP_MOD_skill38_VARS_active; unset($__VAR_DUMP_MOD_skill38_VARS_active); return $___TMP_MOD_skill36_FUNC_calculate_skill35_proc_rate_RET;}
		return 100;
	
	}
	
	function get_final_dmg_base(&$pa, &$pd, &$active)
	{
		//======== Start of contents from mod skill232 ========
		do{
			$___TMP_MOD_skill232_FUNC_get_final_dmg_base_RET = NULL;
		//======== Start of contents from mod skill75 ========
		do{
			$___TMP_MOD_skill75_FUNC_get_final_dmg_base_RET = NULL;
		//======== Start of contents from mod skill82 ========
		do{
			$___TMP_MOD_skill82_FUNC_get_final_dmg_base_RET = NULL;
		//======== Start of contents from mod skill30 ========
		do{
			$___TMP_MOD_skill30_FUNC_get_final_dmg_base_RET = NULL;
		//======== Start of contents from mod skill274 ========
		do{
			$___TMP_MOD_skill274_FUNC_get_final_dmg_base_RET = NULL;
		//======== Start of contents from mod skill273 ========
		do{
			$___TMP_MOD_skill273_FUNC_get_final_dmg_base_RET = NULL;
		//======== Start of contents from mod skill85 ========
		do{
			$___TMP_MOD_skill85_FUNC_get_final_dmg_base_RET = NULL;
		//======== Start of contents from mod skill263 ========
		do{
			$___TMP_MOD_skill263_FUNC_get_final_dmg_base_RET = NULL;
		//======== Start of contents from mod skill473 ========
		do{
			$___TMP_MOD_skill473_FUNC_get_final_dmg_base_RET = NULL;
		//======== Start of contents from mod skill466 ========
		do{
			$___TMP_MOD_skill466_FUNC_get_final_dmg_base_RET = NULL;
		//======== Start of contents from mod attack ========
		do{
			$___TMP_MOD_attack_FUNC_get_final_dmg_base_RET = NULL;

		
		$___TMP_MOD_attack_FUNC_get_final_dmg_base_RET =  0;
			break; 
		}while(0);
		//======== End of contents from mod attack ========


		
		$ret = $___TMP_MOD_attack_FUNC_get_final_dmg_base_RET;
		if (\skillbase\skill_query(466,$pa) && $pa['dmg_dealt']>0 && $pd['type']==0) 
		{
			$dmg=round($pd['mhp']*min($pd['lvl'],30)/100.0);
			do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
			if ($active)
				$log.='<class span="yellow b">你的技能「死神」额外造成了'.$dmg.'点伤害！</span><br>';
			else  $log.='<class span="yellow b">敌人的技能「死神」额外造成了'.$dmg.'点伤害！</span><br>';
			$ret += $dmg;
			$pa['mult_words_fdmgbs'] = \attack\add_format($dmg, $pa['mult_words_fdmgbs']);
		}
		$___TMP_MOD_skill466_FUNC_get_final_dmg_base_RET =  $ret;
			break; 
		}while(0);
		//======== End of contents from mod skill466 ========


		
		$ret = $___TMP_MOD_skill466_FUNC_get_final_dmg_base_RET;
		if (\skillbase\skill_query(473,$pa) && $pa['is_hit']) 
		{
			$spcost=floor($pa['sp']*0.09);
			$pa['sp']-=$spcost;
			do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
			if ($active)
				$log.='<class span="yellow b">你的技能「神蚀」消耗了'.$spcost.'点体力，并对敌人造成了相同的伤害！</span><br>';
			else  $log.='<class span="yellow b">敌人的技能「神蚀」消耗了'.$spcost.'点体力，并对你造成了相同的伤害！</span><br>';
			$ret+=$spcost;
			$pa['mult_words_fdmgbs'] = \attack\add_format($spcost, $pa['mult_words_fdmgbs']);
		}
		$___TMP_MOD_skill473_FUNC_get_final_dmg_base_RET =  $ret;
			break; 
		}while(0);
		//======== End of contents from mod skill473 ========


		
		$ret = $___TMP_MOD_skill473_FUNC_get_final_dmg_base_RET;
		if ($pa['is_hit'] && \skillbase\skill_query(263,$pd) && \skill263\check_unlocked263 ($pd))
		{
			$chance=\skill263\get_skill263_chance ($pa, $pd, $active);
			if (rand(0,99)<$chance)
			{
				do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
				$dmgred=min($pd['wp'],800);
				
				if ($active)
					$log.='<span class="yellow b">敌人精湛的格斗技术抵挡了'.$dmgred.'点伤害！</span><br>';
				else	$log.='<span class="yellow b">你精湛的格斗技术抵挡了'.$dmgred.'点伤害！</span><br>';
				$ret-=$dmgred;
				$pa['mult_words_fdmgbs'] = \attack\add_format(-$dmgred, $pa['mult_words_fdmgbs']);
			}
		}
		$___TMP_MOD_skill263_FUNC_get_final_dmg_base_RET =  $ret;
			break; 
		}while(0);
		//======== End of contents from mod skill263 ========


		
		$ret = $___TMP_MOD_skill263_FUNC_get_final_dmg_base_RET;
		if (($pa['bskill']==85) && $pa['is_hit']) 
		{
			do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
			$log .= '<span class="yellow b">「神启」附加了40点伤害！</span><br>';
			$ret += 40;
			$pa['mult_words_fdmgbs'] = \attack\add_format(40, $pa['mult_words_fdmgbs']);
		}
		$___TMP_MOD_skill85_FUNC_get_final_dmg_base_RET =  $ret;
			break; 
		}while(0);
		//======== End of contents from mod skill85 ========


		
		$ret = $___TMP_MOD_skill85_FUNC_get_final_dmg_base_RET;
		if (\skillbase\skill_query(273,$pd) && \skill273\check_unlocked273 ($pd) && 2==\skillbase\skill_getvalue(273,'choice',$pd))
		{
			$chance = \skill273\get_skill273_chance ($pa, $pd, $active);
			if ($pd['club']!=4) $chance=round($chance*3/4);
			if (rand(0,99)<$chance)
			{
				do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
				$dmgdown=\skill273\get_skill273_effect ($pa, $pd, $active);
				if($dmgdown) {
					$wepstr = substr($pd['wepk'],1,1) == 'B' ? '使用'.$pd['wep'].'射出箭' : '掷出手中的'.$pd['wep'];
					if ($active)
						$log.='然而，敌人'.$wepstr.'，<span class="yellow b">抵挡了'.$dmgdown.'点伤害！</span><br>';
					else	$log.='然而，你'.$wepstr.'，<span class="yellow b">抵挡了'.$dmgdown.'点伤害！</span><br>';
					$pd['wepimp'] = 1;
					\weapon\apply_weapon_imp($pd, $pa, 1-$active);
					$pd['wepimp'] = 0;
					$pa['skill273_dmgdown'] = $dmgdown;
					$ret-=$dmgdown;
					$pa['mult_words_fdmgbs'] = \attack\add_format(-$dmgdown, $pa['mult_words_fdmgbs']);
				}
			}
		}
		$___TMP_MOD_skill273_FUNC_get_final_dmg_base_RET =  $ret;
			break; 
		}while(0);
		//======== End of contents from mod skill273 ========


		
		$ret = $___TMP_MOD_skill273_FUNC_get_final_dmg_base_RET;
		if (274==$pa['bskill']) 
		{
			do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
			$v = \skill274\get_skill274_dmg ($pa, $pd, $active);
			if($v) {
				$log.=\battle\battlelog_parser($pa,$pd,$active,'你如流水一般的灵活攻击使<:pd_name:>额外受到<span class="yellow b">'.$v.'</span>点伤害！<br>');
				$ret += $v;
				$pa['mult_words_fdmgbs'] = \attack\add_format($v, $pa['mult_words_fdmgbs']);
			}
		}
		$___TMP_MOD_skill274_FUNC_get_final_dmg_base_RET =  $ret;
			break; 
		}while(0);
		//======== End of contents from mod skill274 ========


		
		$ret = $___TMP_MOD_skill274_FUNC_get_final_dmg_base_RET;
		if ($pa['bskill']==30 && $pa['is_hit'] && !empty($pa['skill30_hpcost'])) 
		{
			$ret+=$pa['skill30_hpcost'];
			$pa['mult_words_fdmgbs'] = \attack\add_format($pa['skill30_hpcost'], $pa['mult_words_fdmgbs']);
		}
		$___TMP_MOD_skill30_FUNC_get_final_dmg_base_RET =  $ret;
			break; 
		}while(0);
		//======== End of contents from mod skill30 ========


		
		$ret = $___TMP_MOD_skill30_FUNC_get_final_dmg_base_RET;
		if ($pa['bskill']==82 && $pa['is_hit']) 
		{
			do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
			$d=\skill82\get_dmg82 ($pa);
			$log.='<span class="yellow b">「解牛」附加了'.$d.'点伤害！</span><br>';
			$ret += $d;
			$pa['mult_words_fdmgbs'] = \attack\add_format($d, $pa['mult_words_fdmgbs']);
		}
		$___TMP_MOD_skill82_FUNC_get_final_dmg_base_RET =  $ret;
			break; 
		}while(0);
		//======== End of contents from mod skill82 ========


		
		$ret = $___TMP_MOD_skill82_FUNC_get_final_dmg_base_RET;
		if ($pa['bskill']==75 && $pa['is_hit']) 
		{
			do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
			$d=$pa['lvl']+30;
			$log.='<span class="yellow b">「剑心」附加了'.$d.'点伤害！</span><br>';
			$ret += $d;
			$pa['mult_words_fdmgbs'] = \attack\add_format($d, $pa['mult_words_fdmgbs']);
		}
		$___TMP_MOD_skill75_FUNC_get_final_dmg_base_RET =  $ret;
			break; 
		}while(0);
		//======== End of contents from mod skill75 ========


		
		$ret = $___TMP_MOD_skill75_FUNC_get_final_dmg_base_RET;
		if (\skill232\check_skill232_shield_on ($pd)) 
		{
			do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;  global $___LOCAL_SKILL232__VARS__shieldgain,$___LOCAL_SKILL232__VARS__shieldeff,$___LOCAL_SKILL232__VARS__upgradecost,$___LOCAL_SKILL232__VARS__skill232_cd; $shieldgain=&$___LOCAL_SKILL232__VARS__shieldgain; $shieldeff=&$___LOCAL_SKILL232__VARS__shieldeff; $upgradecost=&$___LOCAL_SKILL232__VARS__upgradecost; $skill232_cd=&$___LOCAL_SKILL232__VARS__skill232_cd;   } while (0);
			$clv = (int)\skillbase\skill_getvalue(232,'lvl',$pd);
			$v=$shieldeff[$clv];
			$log.=\battle\battlelog_parser($pa,$pd,$active,'力场护盾抵消了<:pd_name:>受到的<span class="yellow b">'.$v.'</span>点伤害！<br>');
			$ret -= $v;
			$pa['mult_words_fdmgbs'] = \attack\add_format(-$v, $pa['mult_words_fdmgbs']);
		}
		$___TMP_MOD_skill232_FUNC_get_final_dmg_base_RET =  $ret;
			break; 
		}while(0);
		//======== End of contents from mod skill232 ========

		
		$ret = $___TMP_MOD_skill232_FUNC_get_final_dmg_base_RET;
		if ($pa['bskill']==38 && $pa['is_hit'] && !empty($pa['skill38_dmg_extra'])) 
		{
			do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
			if ($active)
				$log.="闷棍对体力不支的敌人造成了<span class=\"yellow b\">{$pa['skill38_dmg_extra']}</span>点额外伤害！<br>";
			else  $log.="闷棍对体力不支的你造成了<span class=\"yellow b\">{$pa['skill38_dmg_extra']}</span>点额外伤害！<br>";
			$ret+=$pa['skill38_dmg_extra'];
			$pa['mult_words_fdmgbs'] = \attack\add_format($pa['skill38_dmg_extra'], $pa['mult_words_fdmgbs']);
		}
		return $ret;
	
	}
	
	














	
	function parse_news($nid, $news, $hour, $min, $sec, $a, $b, $c, $d, $e, $exarr = array())
	{
		return \skill489\parse_news($nid,$news,$hour,$min,$sec,$a,$b,$c,$d,$e,$exarr);
	}
	
}

?>
