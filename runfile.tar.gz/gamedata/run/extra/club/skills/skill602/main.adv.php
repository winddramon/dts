<?php

namespace skill602
{

	function init() 
	{
		define('MOD_SKILL602_INFO','hidden;debuff;');
		do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;  global $___LOCAL_BUFFICONS__VARS__bufficons_list,$___LOCAL_BUFFICONS__VARS__tmp_totsec,$___LOCAL_BUFFICONS__VARS__tmp_nowsec; $bufficons_list=&$___LOCAL_BUFFICONS__VARS__bufficons_list; $tmp_totsec=&$___LOCAL_BUFFICONS__VARS__tmp_totsec; $tmp_nowsec=&$___LOCAL_BUFFICONS__VARS__tmp_nowsec;   } while (0);
		$clubskillname[602] = '晕眩';
		$bufficons_list[602] = Array(
			'msec' => 1,
			'hint' => '你处于晕眩状态！<br>无法进行任何行动，也无法战斗，受到的伤害增加',
		);
	}
	
	function acquire602(&$pa)
	{
		
	}
	
	function lost602(&$pa)
	{
		
	}
	
	function check_skill602_state(&$pa = NULL)
	{
		
		return \bufficons\bufficons_check_buff_state(602, $pa);
	}
	
	
	function set_stun_period($t, &$pa)
	{
		
		if (\gameflow_duel\is_gamestate_duel()) $t=$t/3;	
		\bufficons\bufficons_impose_buff(602, $t/1000, 0, $pa, 1, 1);
		$pa['new_stun_flag']=1;
	}
	
	function assault_finish(&$pa, &$pd, $active)		
	{
		
		if ($active)
		{
			if (isset($pd['new_stun_flag']) && $pd['new_stun_flag']==1)
			{
				$pd['battlelog'] .= '敌人的攻击导致你<span class="cyan b">晕眩</span>了！<br>';
				unset($pd['new_stun_flag']);
			}
		}
		else  
		{
			if (isset($pa['new_stun_flag']) && $pa['new_stun_flag']==1)
			{
				$pa['battlelog'] .= '敌人的攻击导致你<span class="cyan b">晕眩</span>了！<br>';
				unset($pa['new_stun_flag']);
			}
		}
if(isset($active)) {$__VAR_DUMP_MOD_skill602_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill602_VARS_active = NULL;} 
		//======== Start of contents from mod skill803 ========
		do{
			$___TMP_MOD_skill803_FUNC_assault_finish_RET = NULL;

		
		if (\skillbase\skill_query(803, $pa)) $pa['inf']='';
		if (\skillbase\skill_query(803, $pd)) $pd['inf']='';
if(isset($active)) {$__VAR_DUMP_MOD_skill803_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill803_VARS_active = NULL;} 
		//======== Start of contents from mod armor ========
		do{
			$___TMP_MOD_armor_FUNC_assault_finish_RET = NULL;

		
		if ($active) 
			$pd['battlelog'].=$pd['armorbreaklog'];
		else  $pa['battlelog'].=$pa['armorbreaklog'];
if(isset($active)) {$__VAR_DUMP_MOD_armor_VARS_active = $active; } else {$__VAR_DUMP_MOD_armor_VARS_active = NULL;} 
		//======== Start of contents from mod skill461 ========
		do{
			$___TMP_MOD_skill461_FUNC_assault_finish_RET = NULL;

		
		if (\skillbase\skill_query(461,$pa) && ((int)\skillbase\skill_getvalue(461,'lvl',$pa))==1) $pa['inf']='';
		if (\skillbase\skill_query(461,$pd) && ((int)\skillbase\skill_getvalue(461,'lvl',$pd))==1) $pd['inf']='';
if(isset($active)) {$__VAR_DUMP_MOD_skill461_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill461_VARS_active = NULL;} 
		//======== Start of contents from mod wound ========
		do{
			$___TMP_MOD_wound_FUNC_assault_finish_RET = NULL;

		
		if ($active) 
		{
			$infold=$pd['original_inf'];
			$infnew=$pd['inf'];
		}
		else
		{
			$infold=$pa['original_inf'];
			$infnew=$pa['inf'];
		}
		
		$str='';
		do { global $___LOCAL_WOUND__VARS__inf_place,$___LOCAL_WOUND__VARS__infinfo,$___LOCAL_WOUND__VARS__infname,$___LOCAL_WOUND__VARS__infskillinfo,$___LOCAL_WOUND__VARS__wep_infatt,$___LOCAL_WOUND__VARS__wep_infobbs,$___LOCAL_WOUND__VARS__inf_recover_sp_cost; $inf_place=&$___LOCAL_WOUND__VARS__inf_place; $infinfo=&$___LOCAL_WOUND__VARS__infinfo; $infname=&$___LOCAL_WOUND__VARS__infname; $infskillinfo=&$___LOCAL_WOUND__VARS__infskillinfo; $wep_infatt=&$___LOCAL_WOUND__VARS__wep_infatt; $wep_infobbs=&$___LOCAL_WOUND__VARS__wep_infobbs; $inf_recover_sp_cost=&$___LOCAL_WOUND__VARS__inf_recover_sp_cost;   } while (0);
		foreach ($infname as $key => $value)
			if ((strpos($infold,$key) === false) && (strpos($infnew, $key)!==false))
			{
				if ($str!='') $str.='、';
				$str.=$value;
			}
		if ($str!='') $str='这场战斗导致你'.$str.'了！<br>';
		
		if ($active)
			$pd['battlelog'] .= $str;
		else  $pa['battlelog'] .= $str;
if(isset($active)) {$__VAR_DUMP_MOD_wound_VARS_active = $active; } else {$__VAR_DUMP_MOD_wound_VARS_active = NULL;} 
		//======== Start of contents from mod battle ========
		do{
			$___TMP_MOD_battle_FUNC_assault_finish_RET = NULL;

		
		foreach(array('pa','pd') as $val){
			unset(${$val}['is_counter'],${$val}['physical_dmg_dealt'],${$val}['wepimp'],${$val}['actual_rapid_time']);
		}
		}while(0);
		//======== End of contents from mod battle ========

$active = $__VAR_DUMP_MOD_wound_VARS_active; unset($__VAR_DUMP_MOD_wound_VARS_active);
		
		$___TMP_MOD_battle_FUNC_assault_finish_RET;
		}while(0);
		//======== End of contents from mod wound ========

$active = $__VAR_DUMP_MOD_skill461_VARS_active; unset($__VAR_DUMP_MOD_skill461_VARS_active);
		$___TMP_MOD_wound_FUNC_assault_finish_RET;
		}while(0);
		//======== End of contents from mod skill461 ========

$active = $__VAR_DUMP_MOD_armor_VARS_active; unset($__VAR_DUMP_MOD_armor_VARS_active);
		$___TMP_MOD_skill461_FUNC_assault_finish_RET;
		}while(0);
		//======== End of contents from mod armor ========

$active = $__VAR_DUMP_MOD_skill803_VARS_active; unset($__VAR_DUMP_MOD_skill803_VARS_active);
		$___TMP_MOD_armor_FUNC_assault_finish_RET;
		}while(0);
		//======== End of contents from mod skill803 ========

$active = $__VAR_DUMP_MOD_skill602_VARS_active; unset($__VAR_DUMP_MOD_skill602_VARS_active);
		$___TMP_MOD_skill803_FUNC_assault_finish_RET;
	
	}
	
	function send_stun_battle_news($aname, $bname)
	{
		
		addnews ( 0, 'bstun1', $aname, $bname );
	}
	
	function parse_news($nid, $news, $hour, $min, $sec, $a, $b, $c, $d, $e, $exarr = array())
	{
		return \skill489\parse_news($nid,$news,$hour,$min,$sec,$a,$b,$c,$d,$e,$exarr);
	}
	
	function check_cooltime_on()
	{
		return \skill603\check_cooltime_on();
	}
	
	function calculate_active_obbs_change(&$ldata,&$edata,$active_r)	
	{
		return \skill603\calculate_active_obbs_change($ldata,$edata,$active_r);
	}
	
	
	function check_can_counter(&$pa, &$pd, $active)			
	{
		return \skill36\check_can_counter($pa,$pd,$active);
	}
	
	function strike_prepare(&$pa, &$pd, $active)
	{
		$___TEMP_backtrace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 2); 
		array_shift($___TEMP_backtrace);
		if (count($___TEMP_backtrace)==0) $___TEMP_PARENT_NAME=''; else $___TEMP_PARENT_NAME=strtolower($___TEMP_backtrace[0]['function']);
		if ($___TEMP_PARENT_NAME!='skill228\strike_prepare') 
		{
			return \skill507\strike_prepare($pa,$pd,$active);
		}
		unset($___TEMP_PARENT_NAME); unset($___TEMP_backtrace); 
	
		
		
		if (1 == \skill602\check_skill602_state ($pd)) $pd['stun_flag']=1;
if(isset($active)) {$__VAR_DUMP_MOD_skill602_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill602_VARS_active = NULL;} 
		//======== Start of contents from mod skill244 ========
		do{
			$___TMP_MOD_skill244_FUNC_strike_prepare_RET = NULL;

		
		if ($pa['bskill']!=244) {
			\skill112\strike_prepare($pa, $pd, $active);
			$___TMP_MOD_skill244_FUNC_strike_prepare_RET = NULL;
			break; 
		}
		if (!\skillbase\skill_query(244,$pa) || !\skill244\check_unlocked244 ($pa))
		{
			do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
			$log .= '你尚未解锁这个技能！';
			$pa['bskill']=0;
		}
		else
		{
			$rcost = \skill244\get_rage_cost244 ($pa);
			if ( !\clubbase\check_battle_skill_unactivatable($pa,$pd,244) )
			{
				do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
				if ($active)
					$log.="<span class=\"lime b\">你对{$pd['name']}发动了技能「归约」！</span><br>";
				else  $log.="<span class=\"lime b\">{$pa['name']}对你发动了技能「归约」！</span><br>";
				$pa['rage']-=$rcost;
				addnews ( 0, 'bskill244', $pa['name'], $pd['name'] );
			}
			else
			{
				if ($active)
				{
					do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
					$log.='怒气不足或其他原因不能发动。<br>';
				}
				$pa['bskill']=0;
			}
		}
		\skill112\strike_prepare($pa, $pd, $active);
		}while(0);
		//======== End of contents from mod skill244 ========

$active = $__VAR_DUMP_MOD_skill602_VARS_active; unset($__VAR_DUMP_MOD_skill602_VARS_active);
		$___TMP_MOD_skill244_FUNC_strike_prepare_RET;
	
	}
	
	function pre_act()
	{
		return \instance_quit_button\pre_act();
	}
}

?>