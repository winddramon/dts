<?php

namespace skill36
{
	
	$ragecost = 25; 
	
	$wep_skillkind_req = 'wp';
	
	function init() 
	{
		define('MOD_SKILL36_INFO','club;battle;');
		do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;   } while (0);
		$clubskillname[36] = '偷袭';
	}
	
	function acquire36(&$pa)
	{
		
	}
	
	function lost36(&$pa)
	{
		
	}
	
	function check_unlocked36(&$pa)
	{
		
		return $pa['lvl']>=3;
	}
	
	function get_rage_cost36(&$pa = NULL)
	{
		
		do { global $___LOCAL_SKILL36__VARS__ragecost,$___LOCAL_SKILL36__VARS__wep_skillkind_req; $ragecost=&$___LOCAL_SKILL36__VARS__ragecost; $wep_skillkind_req=&$___LOCAL_SKILL36__VARS__wep_skillkind_req;   } while (0);
		return $ragecost;
	}
	
	function strike_prepare(&$pa, &$pd, $active)
	{
		$___TEMP_backtrace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 2); 
		array_shift($___TEMP_backtrace);
		if (count($___TEMP_backtrace)==0) $___TEMP_PARENT_NAME=''; else $___TEMP_PARENT_NAME=strtolower($___TEMP_backtrace[0]['function']);
		if ($___TEMP_PARENT_NAME!='ex_phy_nullify\strike_prepare') 
		{
			return \skill507\strike_prepare($pa,$pd,$active);
		}
		unset($___TEMP_PARENT_NAME); unset($___TEMP_backtrace); 
	
		
		
		if ($pa['bskill']!=36) {
			\skill595\strike_prepare($pa, $pd, $active);
			return;
		}
		if (!\skillbase\skill_query(36,$pa) || !\skill36\check_unlocked36 ($pa))
		{
			do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
			$log .= '你尚未解锁这个技能！';
			$pa['bskill']=0;
		}
		else
		{
			$rcost = \skill36\get_rage_cost36 ($pa);
			if (!\clubbase\check_battle_skill_unactivatable($pa,$pd,36))
			{
				do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
				if ($active)
					$log.="<span class=\"lime b\">你对{$pd['name']}发动了技能「偷袭」！</span><br>";
				else  $log.="<span class=\"lime b\">{$pa['name']}对你发动了技能「偷袭」！</span><br>";
				$pa['rage']-=$rcost;
				addnews ( 0, 'bskill36', $pa['name'], $pd['name'] );
			}
			else
			{
				if ($active)
				{
					do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
					$log.='怒气不足或其他原因不能发动。<br>';
				}
				$pa['bskill']=0;
			}
		}
		\skill595\strike_prepare($pa, $pd, $active);
	
	}	
	
	
	function calculate_skill35_proc_rate(&$pa, &$pd, $active)
	{
		return \skill38\calculate_skill35_proc_rate($pa,$pd,$active);
	}
	
	
	function check_can_counter(&$pa, &$pd, $active)
	{
		
		
		if ($pd['bskill']!=36){
if(isset($active)) {$__VAR_DUMP_MOD_skill36_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill36_VARS_active = NULL;} 
		//======== Start of contents from mod skill500 ========
		do{
			$___TMP_MOD_skill500_FUNC_check_can_counter_RET = NULL;

		
		
		if (1 == \skill500\check_skill500_state ($pd) && !\skill500\check_timectl ($pa)){ $___TMP_MOD_skill500_FUNC_check_can_counter_RET =  0;
			break; }
if(isset($active)) {$__VAR_DUMP_MOD_skill500_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill500_VARS_active = NULL;} 
		//======== Start of contents from mod skill603 ========
		do{
			$___TMP_MOD_skill603_FUNC_check_can_counter_RET = NULL;

		
		
		if (1 == \skill603\check_skill603_state ($pa)){ $___TMP_MOD_skill603_FUNC_check_can_counter_RET =  0;
			break; }
if(isset($active)) {$__VAR_DUMP_MOD_skill603_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill603_VARS_active = NULL;} 
		//======== Start of contents from mod skill602 ========
		do{
			$___TMP_MOD_skill602_FUNC_check_can_counter_RET = NULL;

		
		
		if (1 == \skill602\check_skill602_state ($pa)){ $___TMP_MOD_skill602_FUNC_check_can_counter_RET =  0;
			break; }
if(isset($active)) {$__VAR_DUMP_MOD_skill602_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill602_VARS_active = NULL;} 
		//======== Start of contents from mod skill803 ========
		do{
			$___TMP_MOD_skill803_FUNC_check_can_counter_RET = NULL;

		
		if (\skillbase\skill_query(803, $pa)){ $___TMP_MOD_skill803_FUNC_check_can_counter_RET =  0;
			break; }
if(isset($active)) {$__VAR_DUMP_MOD_skill803_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill803_VARS_active = NULL;} 
		//======== Start of contents from mod weather ========
		do{
			$___TMP_MOD_weather_FUNC_check_can_counter_RET = NULL;

		
		
		if (!empty($pa['aurora_revive_flag'])){ $___TMP_MOD_weather_FUNC_check_can_counter_RET =  0;
			break; }
if(isset($active)) {$__VAR_DUMP_MOD_weather_VARS_active = $active; } else {$__VAR_DUMP_MOD_weather_VARS_active = NULL;} 
		//======== Start of contents from mod tactic ========
		do{
			$___TMP_MOD_tactic_FUNC_check_can_counter_RET = NULL;

		
		if ($pa['tactic'] == 4){ $___TMP_MOD_tactic_FUNC_check_can_counter_RET =  0;
			break; }
if(isset($active)) {$__VAR_DUMP_MOD_tactic_VARS_active = $active; } else {$__VAR_DUMP_MOD_tactic_VARS_active = NULL;} 
		//======== Start of contents from mod pose ========
		do{
			$___TMP_MOD_pose_FUNC_check_can_counter_RET = NULL;

		
		if ($pa['pose'] == 5){ $___TMP_MOD_pose_FUNC_check_can_counter_RET =  0;
			break; }
if(isset($active)) {$__VAR_DUMP_MOD_pose_VARS_active = $active; } else {$__VAR_DUMP_MOD_pose_VARS_active = NULL;} 
		//======== Start of contents from mod skill586 ========
		do{
			$___TMP_MOD_skill586_FUNC_check_can_counter_RET = NULL;

		
		if (!empty($pa['skill586_flag'])){ $___TMP_MOD_skill586_FUNC_check_can_counter_RET =  0;
			break; }
if(isset($active)) {$__VAR_DUMP_MOD_skill586_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill586_VARS_active = NULL;} 
		//======== Start of contents from mod skill715 ========
		do{
			$___TMP_MOD_skill715_FUNC_check_can_counter_RET = NULL;

		
		if (\skillbase\skill_query(715, $pa) && !\skillbase\skill_getvalue(715, 'flag1', $pa)){ $___TMP_MOD_skill715_FUNC_check_can_counter_RET =  0;
			break; }
if(isset($active)) {$__VAR_DUMP_MOD_skill715_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill715_VARS_active = NULL;} 
		//======== Start of contents from mod skill560 ========
		do{
			$___TMP_MOD_skill560_FUNC_check_can_counter_RET = NULL;

		
		if (!empty($pa['skill560_flag'])){ $___TMP_MOD_skill560_FUNC_check_can_counter_RET =  1;
			break; }
if(isset($active)) {$__VAR_DUMP_MOD_skill560_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill560_VARS_active = NULL;} 
		//======== Start of contents from mod weapon ========
		do{
			$___TMP_MOD_weapon_FUNC_check_can_counter_RET = NULL;

		
		if (\weapon\check_counterable_by_weapon_range ($pa, $pd, $active))
		{
if(isset($active)) {$__VAR_DUMP_MOD_weapon_VARS_active = $active; } else {$__VAR_DUMP_MOD_weapon_VARS_active = NULL;} 
		//======== Start of contents from mod battle ========
		do{
			$___TMP_MOD_battle_FUNC_check_can_counter_RET = NULL;

		
		$___TMP_MOD_battle_FUNC_check_can_counter_RET =  1;
			break; 
		}while(0);
		//======== End of contents from mod battle ========

$active = $__VAR_DUMP_MOD_weapon_VARS_active; unset($__VAR_DUMP_MOD_weapon_VARS_active);
			if (!$___TMP_MOD_battle_FUNC_check_can_counter_RET){ $___TMP_MOD_weapon_FUNC_check_can_counter_RET =  0;
			break; }
			$___TMP_MOD_weapon_FUNC_check_can_counter_RET =  \weapon\check_counter_dice ($pa, $pd, $active);
			break; 
		}
		else
		{
			$pa['out_of_range'] = 1;
			$___TMP_MOD_weapon_FUNC_check_can_counter_RET =  0;
			break; 
		}
		}while(0);
		//======== End of contents from mod weapon ========

$active = $__VAR_DUMP_MOD_skill560_VARS_active; unset($__VAR_DUMP_MOD_skill560_VARS_active);
		$___TMP_MOD_skill560_FUNC_check_can_counter_RET =  $___TMP_MOD_weapon_FUNC_check_can_counter_RET;
			break; 
		}while(0);
		//======== End of contents from mod skill560 ========

$active = $__VAR_DUMP_MOD_skill715_VARS_active; unset($__VAR_DUMP_MOD_skill715_VARS_active);
		$___TMP_MOD_skill715_FUNC_check_can_counter_RET =  $___TMP_MOD_skill560_FUNC_check_can_counter_RET;
			break; 
		}while(0);
		//======== End of contents from mod skill715 ========

$active = $__VAR_DUMP_MOD_skill586_VARS_active; unset($__VAR_DUMP_MOD_skill586_VARS_active);
		$___TMP_MOD_skill586_FUNC_check_can_counter_RET =  $___TMP_MOD_skill715_FUNC_check_can_counter_RET;
			break; 
		}while(0);
		//======== End of contents from mod skill586 ========

$active = $__VAR_DUMP_MOD_pose_VARS_active; unset($__VAR_DUMP_MOD_pose_VARS_active);	
		$___TMP_MOD_pose_FUNC_check_can_counter_RET =  $___TMP_MOD_skill586_FUNC_check_can_counter_RET;
			break; 
		}while(0);
		//======== End of contents from mod pose ========

$active = $__VAR_DUMP_MOD_tactic_VARS_active; unset($__VAR_DUMP_MOD_tactic_VARS_active);	
		$___TMP_MOD_tactic_FUNC_check_can_counter_RET =  $___TMP_MOD_pose_FUNC_check_can_counter_RET;
			break; 
		}while(0);
		//======== End of contents from mod tactic ========

$active = $__VAR_DUMP_MOD_weather_VARS_active; unset($__VAR_DUMP_MOD_weather_VARS_active); 
		$___TMP_MOD_weather_FUNC_check_can_counter_RET =  $___TMP_MOD_tactic_FUNC_check_can_counter_RET;
			break; 
		}while(0);
		//======== End of contents from mod weather ========

$active = $__VAR_DUMP_MOD_skill803_VARS_active; unset($__VAR_DUMP_MOD_skill803_VARS_active);
		$___TMP_MOD_skill803_FUNC_check_can_counter_RET =  $___TMP_MOD_weather_FUNC_check_can_counter_RET;
			break; 
		}while(0);
		//======== End of contents from mod skill803 ========

$active = $__VAR_DUMP_MOD_skill602_VARS_active; unset($__VAR_DUMP_MOD_skill602_VARS_active); 
		$___TMP_MOD_skill602_FUNC_check_can_counter_RET =  $___TMP_MOD_skill803_FUNC_check_can_counter_RET;
			break; 
		}while(0);
		//======== End of contents from mod skill602 ========

$active = $__VAR_DUMP_MOD_skill603_VARS_active; unset($__VAR_DUMP_MOD_skill603_VARS_active); 
		$___TMP_MOD_skill603_FUNC_check_can_counter_RET =  $___TMP_MOD_skill602_FUNC_check_can_counter_RET;
			break; 
		}while(0);
		//======== End of contents from mod skill603 ========

$active = $__VAR_DUMP_MOD_skill500_VARS_active; unset($__VAR_DUMP_MOD_skill500_VARS_active); 
		$___TMP_MOD_skill500_FUNC_check_can_counter_RET =  $___TMP_MOD_skill603_FUNC_check_can_counter_RET;
			break; 
		}while(0);
		//======== End of contents from mod skill500 ========

$active = $__VAR_DUMP_MOD_skill36_VARS_active; unset($__VAR_DUMP_MOD_skill36_VARS_active); return $___TMP_MOD_skill500_FUNC_check_can_counter_RET;}
		return 0;
	
	}
	
	function parse_news($nid, $news, $hour, $min, $sec, $a, $b, $c, $d, $e, $exarr = array())
	{
		return \skill489\parse_news($nid,$news,$hour,$min,$sec,$a,$b,$c,$d,$e,$exarr);
	}
	
}

?>
