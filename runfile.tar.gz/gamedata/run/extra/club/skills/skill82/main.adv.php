<?php

namespace skill82
{

	$ragecost=5;
	
	$wep_skillkind_req = 'wk';
	
	function init() 
	{
		define('MOD_SKILL82_INFO','club;battle;');
		do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;   } while (0);
		$clubskillname[82] = '解牛';
	}
	
	function acquire82(&$pa)
	{
		
	}
	
	function lost82(&$pa)
	{
		
	}
	
	function check_unlocked82(&$pa)
	{
		
		return 1;
	}
	
	function get_rage_cost82(&$pa = NULL)
	{
		
		do { global $___LOCAL_SKILL82__VARS__ragecost,$___LOCAL_SKILL82__VARS__wep_skillkind_req; $ragecost=&$___LOCAL_SKILL82__VARS__ragecost; $wep_skillkind_req=&$___LOCAL_SKILL82__VARS__wep_skillkind_req;   } while (0);
		return $ragecost;
	}
	
	function get_dmg82(&$pa)
	{
		
		return $pa['lvl']+30;
	}
	
	function strike_prepare(&$pa, &$pd, $active)
	{
		$___TEMP_backtrace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 2); 
		array_shift($___TEMP_backtrace);
		if (count($___TEMP_backtrace)==0) $___TEMP_PARENT_NAME=''; else $___TEMP_PARENT_NAME=strtolower($___TEMP_backtrace[0]['function']);
		if ($___TEMP_PARENT_NAME!='ex_dmg_nullify\strike_prepare') 
		{
			return \skill507\strike_prepare($pa,$pd,$active);
		}
		unset($___TEMP_PARENT_NAME); unset($___TEMP_backtrace); 
	
		
		
		if ($pa['bskill']!=82) {
			\skill49\strike_prepare($pa, $pd, $active);
			return;
		}
		if (!\skillbase\skill_query(82,$pa) || !\skill82\check_unlocked82 ($pa))
		{
			do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
			$log .= '你尚未解锁这个技能！';
			$pa['bskill']=0;
		}
		else
		{
			$rcost = \skill82\get_rage_cost82 ($pa);
			if ( !\clubbase\check_battle_skill_unactivatable($pa,$pd,82) )
			{
				do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
				if ($active)
					$log.="<span class=\"lime b\">你对{$pd['name']}发动了技能「解牛」！</span><br>";
				else  $log.="<span class=\"lime b\">{$pa['name']}对你发动了技能「解牛」！</span><br>";
				$pa['rage']-=$rcost;
				addnews ( 0, 'bskill82', $pa['name'], $pd['name'] );
			}
			else
			{
				if ($active)
				{
					do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
					$log.='怒气不足或其他原因不能发动。<br>';
				}
				$pa['bskill']=0;
			}
		}
		\skill49\strike_prepare($pa, $pd, $active);
	
	}	
	
	function get_final_dmg_base(&$pa, &$pd, &$active)
	{
		return \skill38\get_final_dmg_base($pa,$pd,$active);
	}
	
	
	function calculate_wepimp_rate(&$pa, &$pd, $active)
	{
		return \skill422\calculate_wepimp_rate($pa,$pd,$active);
	}

	function parse_news($nid, $news, $hour, $min, $sec, $a, $b, $c, $d, $e, $exarr = array())
	{
		return \skill489\parse_news($nid,$news,$hour,$min,$sec,$a,$b,$c,$d,$e,$exarr);
	}
}

?>