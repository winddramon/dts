<?php

namespace skill83
{
	function init() 
	{
		define('MOD_SKILL83_INFO','club;locked;debuff;');
		do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;   } while (0);
		$clubskillname[83] = '尊严';
	}
	
	function acquire83(&$pa)
	{
		
	}
	
	function lost83(&$pa)
	{
		
	}
	
	function check_unlocked83(&$pa)
	{
		
		return 1;
	}
	
	function check_wepk_debuff83($owep, $owepk)
	{
		
		$ret = 90;
		if('WN' == $owepk || strpos($owep,'拳')!==false) $ret = 0;
		elseif('WP' == $owepk || 'WK' == $owepk) $ret = 50;
		return $ret;
	}
	
	function strike_prepare(&$pa, &$pd, $active)
	{
		return \skill507\strike_prepare($pa,$pd,$active);
	}
	
	function get_final_dmg_multiplier(&$pa, &$pd, $active)
	{
		return \skill507\get_final_dmg_multiplier($pa,$pd,$active);
	}
}

?>