<?php

namespace skill26
{
	
	$upgradecost = 10;
	
	$ragecost[1] = 20; $ragecost[2] = 25;
	
	function init() 
	{
		define('MOD_SKILL26_INFO','club;battle;upgrade;');
		do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;   } while (0);
		$clubskillname[26] = '聚能';
	}
	
	function acquire26(&$pa)
	{
		
		\skillbase\skill_setvalue(26,'lvl','1',$pa);
	}
	
	function lost26(&$pa)
	{
		
		\skillbase\skill_delvalue(26,'lvl',$pa);
	}
	
	function check_unlocked26(&$pa)
	{
		
		return $pa['lvl']>=3;
	}
	
	function get_rage_cost26(&$pa = NULL)
	{
		
		do { global $___LOCAL_SKILL26__VARS__upgradecost,$___LOCAL_SKILL26__VARS__ragecost; $upgradecost=&$___LOCAL_SKILL26__VARS__upgradecost; $ragecost=&$___LOCAL_SKILL26__VARS__ragecost;   } while (0);
		return $ragecost[\skillbase\skill_getvalue(26,'lvl',$pa)];
	}
	
	function get_skill26_type(&$pa, &$pd, $active){
		
		$attack_type = 'u';
		if (\skillbase\skill_getvalue(26,'lvl',$pa)==2) $attack_type = 'f';
		return $attack_type;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	function check_ex_inf_infliction(&$pa, &$pd, $active, $key)
	{
		return \skill489\check_ex_inf_infliction($pa,$pd,$active,$key);
	}
	
	function calculate_ex_inf_multiple(&$pa, &$pd, $active, $key)
	{
		
		if ($pa['bskill']!=26) return \ex_dmg_def\calculate_ex_inf_multiple($pa, $pd, $active, $key);
		$attack_type =  \skill26\get_skill26_type ($pa, $pd, $active);
		if ($pa['skill26_flag3']==1) return \ex_dmg_def\calculate_ex_inf_multiple($pa, $pd, $active, $attack_type);
		return \ex_dmg_def\calculate_ex_inf_multiple($pa, $pd, $active, $key);
	
	}
	
	function check_ex_single_dmg_def_attr(&$pa, &$pd, $active, $key)
	{
		
		if ($pa['bskill']!=26) return \ex_attr_pierce\check_ex_single_dmg_def_attr($pa, $pd, $active, $key);
		$attack_type =  \skill26\get_skill26_type ($pa, $pd, $active);
		if ($pa['skill26_flag3']==1) return \ex_attr_pierce\check_ex_single_dmg_def_attr($pa, $pd, $active, $attack_type);
		return \ex_attr_pierce\check_ex_single_dmg_def_attr($pa, $pd, $active, $key);
	
	}
	
	function get_ex_attack_array_core(&$pa, &$pd, $active)
	{
		return \skill507\get_ex_attack_array_core($pa,$pd,$active);
	}
	
	function check_attr_pierce_proc(&$pa, &$pd, $active)
	{
		
		if ($pa['bskill']==26 && $pa['skill26_flag1']==2) return $pa['attr_pierce_success'];
if(isset($active)) {$__VAR_DUMP_MOD_skill26_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill26_VARS_active = NULL;} 
		//======== Start of contents from mod ex_purity ========
		do{
			$___TMP_MOD_ex_purity_FUNC_check_attr_pierce_proc_RET = NULL;

		
		
		if (!empty($pa['purity'])) {
			$___TMP_MOD_ex_purity_FUNC_check_attr_pierce_proc_RET = NULL;
			break; 
		}
if(isset($active)) {$__VAR_DUMP_MOD_ex_purity_VARS_active = $active; } else {$__VAR_DUMP_MOD_ex_purity_VARS_active = NULL;} 
		//======== Start of contents from mod ex_attr_pierce ========
		do{
			$___TMP_MOD_ex_attr_pierce_FUNC_check_attr_pierce_proc_RET = NULL;

		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
		$ex_att_array = \attrbase\get_ex_attack_array($pa, $pd, $active);
		if (\attrbase\check_in_itmsk('y', $ex_att_array))
		{
			$proc_rate = \ex_attr_pierce\get_attr_pierce_proc_rate ($pa, $pd, $active);
			$dice = rand(0,99);
			if ($dice<$proc_rate)
			{
				$log .= \battle\battlelog_parser($pa, $pd, $active, "<span class=\"yellow b\"><:pa_name:>的攻击穿透了<:pd_name:>的属性防御属性！</span><br>");
				$pa['attr_pierce_success'] = 1;
			}
		}
		$___TMP_MOD_ex_attr_pierce_FUNC_check_attr_pierce_proc_RET = NULL;
			break; 
		}while(0);
		//======== End of contents from mod ex_attr_pierce ========

$active = $__VAR_DUMP_MOD_ex_purity_VARS_active; unset($__VAR_DUMP_MOD_ex_purity_VARS_active);
		$___TMP_MOD_ex_attr_pierce_FUNC_check_attr_pierce_proc_RET;
		}while(0);
		//======== End of contents from mod ex_purity ========

$active = $__VAR_DUMP_MOD_skill26_VARS_active; unset($__VAR_DUMP_MOD_skill26_VARS_active);
		$___TMP_MOD_ex_purity_FUNC_check_attr_pierce_proc_RET;
	
	}
	
	function check_ex_dmg_nullify(&$pa, &$pd, $active)
	{
		
		if ($pa['bskill']==26 && $pa['skill26_flag1']==2) return $pd['exdmg_nullify_success'];
if(isset($active)) {$__VAR_DUMP_MOD_skill26_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill26_VARS_active = NULL;} 
		//======== Start of contents from mod ex_attr_pierce ========
		do{
			$___TMP_MOD_ex_attr_pierce_FUNC_check_ex_dmg_nullify_RET = NULL;

		
		
		if ($pa['attr_pierce_success']){ $___TMP_MOD_ex_attr_pierce_FUNC_check_ex_dmg_nullify_RET =  0;
			break; }
if(isset($active)) {$__VAR_DUMP_MOD_ex_attr_pierce_VARS_active = $active; } else {$__VAR_DUMP_MOD_ex_attr_pierce_VARS_active = NULL;} 
		//======== Start of contents from mod ex_dmg_nullify ========
		do{
			$___TMP_MOD_ex_dmg_nullify_FUNC_check_ex_dmg_nullify_RET = NULL;

		
		do { global $___LOCAL_EX_DMG_ATT__VARS__ex_attack_list,$___LOCAL_EX_DMG_ATT__VARS__exdmgname,$___LOCAL_EX_DMG_ATT__VARS__ex_good_wep,$___LOCAL_EX_DMG_ATT__VARS__ex_base_dmg,$___LOCAL_EX_DMG_ATT__VARS__ex_max_dmg,$___LOCAL_EX_DMG_ATT__VARS__ex_wep_dmg,$___LOCAL_EX_DMG_ATT__VARS__ex_skill_dmg,$___LOCAL_EX_DMG_ATT__VARS__ex_dmg_fluc,$___LOCAL_EX_DMG_ATT__VARS__ex_inf,$___LOCAL_EX_DMG_ATT__VARS__ex_inf_punish, $___LOCAL_EX_DMG_ATT__VARS__ex_inf_r,$___LOCAL_EX_DMG_ATT__VARS__ex_max_inf_r,$___LOCAL_EX_DMG_ATT__VARS__ex_skill_inf_r; $ex_attack_list=&$___LOCAL_EX_DMG_ATT__VARS__ex_attack_list; $exdmgname=&$___LOCAL_EX_DMG_ATT__VARS__exdmgname; $ex_good_wep=&$___LOCAL_EX_DMG_ATT__VARS__ex_good_wep; $ex_base_dmg=&$___LOCAL_EX_DMG_ATT__VARS__ex_base_dmg; $ex_max_dmg=&$___LOCAL_EX_DMG_ATT__VARS__ex_max_dmg; $ex_wep_dmg=&$___LOCAL_EX_DMG_ATT__VARS__ex_wep_dmg; $ex_skill_dmg=&$___LOCAL_EX_DMG_ATT__VARS__ex_skill_dmg; $ex_dmg_fluc=&$___LOCAL_EX_DMG_ATT__VARS__ex_dmg_fluc; $ex_inf=&$___LOCAL_EX_DMG_ATT__VARS__ex_inf; $ex_inf_punish=&$___LOCAL_EX_DMG_ATT__VARS__ex_inf_punish;  $ex_inf_r=&$___LOCAL_EX_DMG_ATT__VARS__ex_inf_r; $ex_max_inf_r=&$___LOCAL_EX_DMG_ATT__VARS__ex_max_inf_r; $ex_skill_inf_r=&$___LOCAL_EX_DMG_ATT__VARS__ex_skill_inf_r;  global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
		$ex_att_array = \attrbase\get_ex_attack_array($pa, $pd, $active);
		$ex_def_array = \attrbase\get_ex_def_array($pa, $pd, $active);
		
		$flag = 0; $exnum = 0;
		foreach ($ex_attack_list as $key) {
			if (\attrbase\check_in_itmsk($key,$ex_att_array)) { 
				$flag = 1;
				$exnum++; 
			}
		}
		if ($flag && \attrbase\check_in_itmsk('b', $ex_def_array))
		{
			$proc_rate = \ex_dmg_nullify\get_ex_dmg_nullify_proc_rate ($pa, $pd, $active);
			$dice = rand(0,99);
			if ($dice<$proc_rate)
			{
				$log .= "<span class=\"yellow b\">属性攻击的力量完全被防具吸收了！</span>只造成了<span class=\"red b\">{$exnum}</span>点伤害！<br>";
				$pa['ex_dmg_dealt'] = $exnum;
				$pd['exdmg_nullify_success'] = 1;
				$___TMP_MOD_ex_dmg_nullify_FUNC_check_ex_dmg_nullify_RET =  1;
			break; 
			}
			else
			{
				$log .= '<span class="red b">防具免疫属性攻击的效果竟然失效了！</span><br>';
				$___TMP_MOD_ex_dmg_nullify_FUNC_check_ex_dmg_nullify_RET =  0;
			break; 
			}
		}
		$___TMP_MOD_ex_dmg_nullify_FUNC_check_ex_dmg_nullify_RET =  0;
			break; 
		}while(0);
		//======== End of contents from mod ex_dmg_nullify ========

$active = $__VAR_DUMP_MOD_ex_attr_pierce_VARS_active; unset($__VAR_DUMP_MOD_ex_attr_pierce_VARS_active);
		$___TMP_MOD_ex_attr_pierce_FUNC_check_ex_dmg_nullify_RET =  $___TMP_MOD_ex_dmg_nullify_FUNC_check_ex_dmg_nullify_RET;
			break; 
		}while(0);
		//======== End of contents from mod ex_attr_pierce ========

$active = $__VAR_DUMP_MOD_skill26_VARS_active; unset($__VAR_DUMP_MOD_skill26_VARS_active);
		return $___TMP_MOD_ex_attr_pierce_FUNC_check_ex_dmg_nullify_RET;
	
	}
	
	
	function showlog_ex_single_dmg(&$pa, &$pd, $active, $key)
	{
		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;  global $___LOCAL_EX_DMG_ATT__VARS__ex_attack_list,$___LOCAL_EX_DMG_ATT__VARS__exdmgname,$___LOCAL_EX_DMG_ATT__VARS__ex_good_wep,$___LOCAL_EX_DMG_ATT__VARS__ex_base_dmg,$___LOCAL_EX_DMG_ATT__VARS__ex_max_dmg,$___LOCAL_EX_DMG_ATT__VARS__ex_wep_dmg,$___LOCAL_EX_DMG_ATT__VARS__ex_skill_dmg,$___LOCAL_EX_DMG_ATT__VARS__ex_dmg_fluc,$___LOCAL_EX_DMG_ATT__VARS__ex_inf,$___LOCAL_EX_DMG_ATT__VARS__ex_inf_punish, $___LOCAL_EX_DMG_ATT__VARS__ex_inf_r,$___LOCAL_EX_DMG_ATT__VARS__ex_max_inf_r,$___LOCAL_EX_DMG_ATT__VARS__ex_skill_inf_r; $ex_attack_list=&$___LOCAL_EX_DMG_ATT__VARS__ex_attack_list; $exdmgname=&$___LOCAL_EX_DMG_ATT__VARS__exdmgname; $ex_good_wep=&$___LOCAL_EX_DMG_ATT__VARS__ex_good_wep; $ex_base_dmg=&$___LOCAL_EX_DMG_ATT__VARS__ex_base_dmg; $ex_max_dmg=&$___LOCAL_EX_DMG_ATT__VARS__ex_max_dmg; $ex_wep_dmg=&$___LOCAL_EX_DMG_ATT__VARS__ex_wep_dmg; $ex_skill_dmg=&$___LOCAL_EX_DMG_ATT__VARS__ex_skill_dmg; $ex_dmg_fluc=&$___LOCAL_EX_DMG_ATT__VARS__ex_dmg_fluc; $ex_inf=&$___LOCAL_EX_DMG_ATT__VARS__ex_inf; $ex_inf_punish=&$___LOCAL_EX_DMG_ATT__VARS__ex_inf_punish;  $ex_inf_r=&$___LOCAL_EX_DMG_ATT__VARS__ex_inf_r; $ex_max_inf_r=&$___LOCAL_EX_DMG_ATT__VARS__ex_max_inf_r; $ex_skill_inf_r=&$___LOCAL_EX_DMG_ATT__VARS__ex_skill_inf_r;   } while (0);
		if ($pa['bskill']==26 && $pa['skill26_flag2'] == 1)  return;
if(isset($active)) {$__VAR_DUMP_MOD_skill26_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill26_VARS_active = NULL;} if(isset($key)) {$__VAR_DUMP_MOD_skill26_VARS_key = $key; } else {$__VAR_DUMP_MOD_skill26_VARS_key = NULL;} 
		//======== Start of contents from mod ex_dmg_att ========
		do{
			$___TMP_MOD_ex_dmg_att_FUNC_showlog_ex_single_dmg_RET = NULL;

		
		
		if ($pd['ex_dmg_'.$key.'_defend_success'] == 1)	
			
			$log .= '造成了<span class="<:ex_single_dmg:>">'.$pa['ex_dmg_'.$key.'_dealt'].'</span>点属性伤害！';
		else  $log .= $exdmgname[$key].'造成了<span class="<:ex_single_dmg:>">'.$pa['ex_dmg_'.$key.'_dealt'].'</span>点属性伤害！';
		if(empty($pa['mult_words_exdmgbs'])) $pa['mult_words_exdmgbs'] = $pa['ex_dmg_'.$key.'_dealt'];
		else $pa['mult_words_exdmgbs'] = \attack\add_format($pa['ex_dmg_'.$key.'_dealt'],$pa['mult_words_exdmgbs']);
		}while(0);
		//======== End of contents from mod ex_dmg_att ========

$active = $__VAR_DUMP_MOD_skill26_VARS_active; unset($__VAR_DUMP_MOD_skill26_VARS_active);$key = $__VAR_DUMP_MOD_skill26_VARS_key; unset($__VAR_DUMP_MOD_skill26_VARS_key);
		$___TMP_MOD_ex_dmg_att_FUNC_showlog_ex_single_dmg_RET;
	
	}
	
	
	function ex_attack_key_change(&$pa, &$pd, $active, $key){
if(isset($active)) {$__VAR_DUMP_MOD_skill26_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill26_VARS_active = NULL;} if(isset($key)) {$__VAR_DUMP_MOD_skill26_VARS_key = $key; } else {$__VAR_DUMP_MOD_skill26_VARS_key = NULL;} 
		//======== Start of contents from mod ex_dmg_att ========
		do{
			$___TMP_MOD_ex_dmg_att_FUNC_ex_attack_key_change_RET = NULL;

		
		$___TMP_MOD_ex_dmg_att_FUNC_ex_attack_key_change_RET =  $key;
			break; 
		}while(0);
		//======== End of contents from mod ex_dmg_att ========

$active = $__VAR_DUMP_MOD_skill26_VARS_active; unset($__VAR_DUMP_MOD_skill26_VARS_active);$key = $__VAR_DUMP_MOD_skill26_VARS_key; unset($__VAR_DUMP_MOD_skill26_VARS_key);
		
		$ret = $___TMP_MOD_ex_dmg_att_FUNC_ex_attack_key_change_RET;
		if ($pa['bskill']==26 && $pa['skill26_flag3']==1) {
			$ret = \skill26\get_skill26_type ($pa, $pd, $active);
		}
		return $ret;
	
	}
	
	function calculate_physical_dmg(&$pa, &$pd, $active)
	{
		
		if ($pa['bskill']!=26){
if(isset($active)) {$__VAR_DUMP_MOD_skill26_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill26_VARS_active = NULL;} 
		//======== Start of contents from mod ex_attr_pierce ========
		do{
			$___TMP_MOD_ex_attr_pierce_FUNC_calculate_physical_dmg_RET = NULL;

		
		\ex_attr_pierce\check_phy_pierce_proc ($pa, $pd, $active);
if(isset($active)) {$__VAR_DUMP_MOD_ex_attr_pierce_VARS_active = $active; } else {$__VAR_DUMP_MOD_ex_attr_pierce_VARS_active = NULL;} 
		//======== Start of contents from mod weapon ========
		do{
			$___TMP_MOD_weapon_FUNC_calculate_physical_dmg_RET = NULL;

		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
		
		$multiplier = \weapon\get_physical_dmg_multiplier ($pa, $pd, $active);
		$dmg = \weapon\get_physical_dmg ($pa, $pd, $active);
		
		$primary_dmg_color = 'yellow b';
		list($fin_dmg, $mult_words, $mult_words_phydmg) = \attack\apply_multiplier($dmg, $multiplier, '<:fin_dmg:>', $pa['mult_words_phydmgbs']);
		$mult_words_phydmg = \attack\equalsign_format($fin_dmg, $mult_words_phydmg, '<:fin_dmg:>');



		$log .= '造成了'.$mult_words_phydmg.'点物理伤害！<br>';




		
		$replace_color = 'red b';
		
		$fin_dmg_change = \weapon\get_physical_dmg_change ($pa, $pd, $active, $fin_dmg);
		if($fin_dmg_change != $fin_dmg) {
			$fin_dmg = $fin_dmg_change;
			$log .= "总物理伤害：<span class=\"red b\">{$fin_dmg}</span>。<br>";
			$replace_color = 'yellow b';
		}
		$log = str_replace('<:fin_dmg:>', $replace_color, $log);
		
		$pa['physical_dmg_dealt']+=$fin_dmg;
		$pa['dmg_dealt']+=$fin_dmg;
		$pa['mult_words_fdmgbs'] = \attack\add_format($fin_dmg, $pa['mult_words_fdmgbs']);
		$___TMP_MOD_weapon_FUNC_calculate_physical_dmg_RET =  $fin_dmg;
			break; 
		}while(0);
		//======== End of contents from mod weapon ========

$active = $__VAR_DUMP_MOD_ex_attr_pierce_VARS_active; unset($__VAR_DUMP_MOD_ex_attr_pierce_VARS_active);
		$___TMP_MOD_ex_attr_pierce_FUNC_calculate_physical_dmg_RET =  $___TMP_MOD_weapon_FUNC_calculate_physical_dmg_RET;
			break; 
		}while(0);
		//======== End of contents from mod ex_attr_pierce ========

$active = $__VAR_DUMP_MOD_skill26_VARS_active; unset($__VAR_DUMP_MOD_skill26_VARS_active); return $___TMP_MOD_ex_attr_pierce_FUNC_calculate_physical_dmg_RET;}
		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;  global $___LOCAL_ITEMMAIN__VARS__tmp_itmsk_arr_pool,$___LOCAL_ITEMMAIN__VARS__itemfind_extra_log,$___LOCAL_ITEMMAIN__VARS__item_equip_list,$___LOCAL_ITEMMAIN__VARS__item_hotkey_id_list,$___LOCAL_ITEMMAIN__VARS__itemmain_drophint,$___LOCAL_ITEMMAIN__VARS__item_allow_find_and_use,$___LOCAL_ITEMMAIN__VARS__nosta,$___LOCAL_ITEMMAIN__VARS__nospk,$___LOCAL_ITEMMAIN__VARS__item_obbs,$___LOCAL_ITEMMAIN__VARS__map_noitemdrop_arealist, $___LOCAL_ITEMMAIN__VARS__itemkind_equipable,$___LOCAL_ITEMMAIN__VARS__iteminfo,$___LOCAL_ITEMMAIN__VARS__itemspkinfo,$___LOCAL_ITEMMAIN__VARS__itemspkdesc,$___LOCAL_ITEMMAIN__VARS__itemspkdesc_help,$___LOCAL_ITEMMAIN__VARS__itemspkremark; $tmp_itmsk_arr_pool=&$___LOCAL_ITEMMAIN__VARS__tmp_itmsk_arr_pool; $itemfind_extra_log=&$___LOCAL_ITEMMAIN__VARS__itemfind_extra_log; $item_equip_list=&$___LOCAL_ITEMMAIN__VARS__item_equip_list; $item_hotkey_id_list=&$___LOCAL_ITEMMAIN__VARS__item_hotkey_id_list; $itemmain_drophint=&$___LOCAL_ITEMMAIN__VARS__itemmain_drophint; $item_allow_find_and_use=&$___LOCAL_ITEMMAIN__VARS__item_allow_find_and_use; $nosta=&$___LOCAL_ITEMMAIN__VARS__nosta; $nospk=&$___LOCAL_ITEMMAIN__VARS__nospk; $item_obbs=&$___LOCAL_ITEMMAIN__VARS__item_obbs; $map_noitemdrop_arealist=&$___LOCAL_ITEMMAIN__VARS__map_noitemdrop_arealist;  $itemkind_equipable=&$___LOCAL_ITEMMAIN__VARS__itemkind_equipable; $iteminfo=&$___LOCAL_ITEMMAIN__VARS__iteminfo; $itemspkinfo=&$___LOCAL_ITEMMAIN__VARS__itemspkinfo; $itemspkdesc=&$___LOCAL_ITEMMAIN__VARS__itemspkdesc; $itemspkdesc_help=&$___LOCAL_ITEMMAIN__VARS__itemspkdesc_help; $itemspkremark=&$___LOCAL_ITEMMAIN__VARS__itemspkremark;   } while (0);
		$attack_type =  \skill26\get_skill26_type ($pa, $pd, $active);
		$log .= '在技能的作用下，伤害全部转化为了<span class="red b">'.$itemspkinfo[$attack_type].'</span>伤害！<br>';
		
		
		
		



		
		$pflag=\skill26\check_attr_pierce_proc ($pa, $pd, $active);
		
		$flag=\skill26\check_ex_dmg_nullify ($pa, $pd, $active);
		
		$pa['skill26_flag1'] = 2;	
		
		if ($flag)
		{
			
			$pa['physical_dmg_dealt'] += $pa['ex_dmg_dealt'];
			$pa['dmg_dealt'] += $pa['ex_dmg_dealt'];
			
			$pa['ex_dmg_dealt'] = 0;
			return 0;
		}
		
		
		$odmg = $dmg = \weapon\get_physical_dmg($pa, $pd, $active);
		$mult_words_phydmg = \attack\equalsign_format($dmg, $pa['mult_words_phydmgbs'], '<:phy_dmg:>');
		
		$dmg = \ex_dmg_att\calculate_ex_single_dmg($pa, $pd, $active, $attack_type, $dmg);
		
		if($dmg == $odmg) {
			$mult_words_phydmg = str_replace('<:phy_dmg:>','red b',$mult_words_phydmg);
			$log.='武器攻击造成了'.$mult_words_phydmg.'点'.$itemspkinfo[$attack_type]."伤害！<br>";
		}else {
			$mult_words_phydmg = str_replace('<:phy_dmg:>','yellow b',$mult_words_phydmg);
			$log.='武器攻击造成了'.$mult_words_phydmg.'点基础伤害，并转化为了<span class="red b">'.$dmg.'</span>点'.$itemspkinfo[$attack_type].'伤害！<br>';
		}
		
		$pa['physical_dmg_dealt'] += $dmg;
		$pa['dmg_dealt'] += $dmg;
		$pa['mult_words_fdmgbs'] = \attack\add_format($dmg, $pa['mult_words_fdmgbs']);
		$pa['skill26_flag2'] = 2;	
		return $dmg;
	
	}
	
	function strike_prepare(&$pa, &$pd, $active)
	{
		$___TEMP_backtrace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 2); 
		array_shift($___TEMP_backtrace);
		if (count($___TEMP_backtrace)==0) $___TEMP_PARENT_NAME=''; else $___TEMP_PARENT_NAME=strtolower($___TEMP_backtrace[0]['function']);
		if ($___TEMP_PARENT_NAME!='skill507\strike_prepare') 
		{
			return \skill507\strike_prepare($pa,$pd,$active);
		}
		unset($___TEMP_PARENT_NAME); unset($___TEMP_backtrace); 
	
		
		
		if ($pa['bskill']!=26) {
			\skill722\strike_prepare($pa, $pd, $active);
			return;
		}
		if (!\skillbase\skill_query(26,$pa) || !\skill26\check_unlocked26 ($pa))
		{
			do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
			$log .= '你尚未解锁这个技能！';
			$pa['bskill']=0;
		}
		else
		{
			$rcost = \skill26\get_rage_cost26 ($pa);
			if (!\clubbase\check_battle_skill_unactivatable($pa,$pd,26))
			{
				do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
				if ($active)
					$log.="<span class=\"lime b\">你对{$pd['name']}发动了技能「聚能」！</span><br>";
				else  $log.="<span class=\"lime b\">{$pa['name']}对你发动了技能「聚能」！</span><br>";
				$pa['rage']-=$rcost;
				$pa['skill26_flag1']=1;
				$pa['skill26_flag2']=1;
				$pa['skill26_flag3']=1;
				$pa['skill26_flag4']=1;
				addnews ( 0, 'bskill26', $pa['name'], $pd['name'] );
			}
			else
			{
				if ($active)
				{
					do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
					$log.='怒气不足。<br>';
				}
				$pa['bskill']=0;
			}
		}
		\skill722\strike_prepare($pa, $pd, $active);
	
	}	
	
	function strike_finish(&$pa, &$pd, $active)
	{
		return \skill27\strike_finish($pa,$pd,$active);
	}
	
	function upgrade26()
	{
		
		do { global $___LOCAL_SKILL26__VARS__upgradecost,$___LOCAL_SKILL26__VARS__ragecost; $upgradecost=&$___LOCAL_SKILL26__VARS__upgradecost; $ragecost=&$___LOCAL_SKILL26__VARS__ragecost;  global $___LOCAL_PLAYER__VARS__ss,$___LOCAL_PLAYER__VARS__db_player_structure,$___LOCAL_PLAYER__VARS__db_player_structure_types,$___LOCAL_PLAYER__VARS__gamedata,$___LOCAL_PLAYER__VARS__cmd,$___LOCAL_PLAYER__VARS__main,$___LOCAL_PLAYER__VARS__sdata,$___LOCAL_PLAYER__VARS__fog,$___LOCAL_PLAYER__VARS__upexp,$___LOCAL_PLAYER__VARS__lvlupexp, $___LOCAL_PLAYER__VARS__iconImg,$___LOCAL_PLAYER__VARS__iconImgB,$___LOCAL_PLAYER__VARS__iconImgBwidth,$___LOCAL_PLAYER__VARS__ardef,$___LOCAL_PLAYER__VARS__hpcolor,$___LOCAL_PLAYER__VARS__spcolor,$___LOCAL_PLAYER__VARS__newhpimg,$___LOCAL_PLAYER__VARS__newspimg,$___LOCAL_PLAYER__VARS__splt,$___LOCAL_PLAYER__VARS__hplt, $___LOCAL_PLAYER__VARS__tpldata,$___LOCAL_PLAYER__VARS__icon_list,$___LOCAL_PLAYER__VARS__icon_list_contents_to_frontend,$___LOCAL_PLAYER__VARS__typeinfo,$___LOCAL_PLAYER__VARS__killmsginfo,$___LOCAL_PLAYER__VARS__lwinfo,$___LOCAL_PLAYER__VARS__sexinfo,$___LOCAL_PLAYER__VARS__equip_list,$___LOCAL_PLAYER__VARS__battle_equip_list,$___LOCAL_PLAYER__VARS__pc_icon_range, $___LOCAL_PLAYER__VARS__pid,$___LOCAL_PLAYER__VARS__type,$___LOCAL_PLAYER__VARS__name,$___LOCAL_PLAYER__VARS__pass,$___LOCAL_PLAYER__VARS__ip,$___LOCAL_PLAYER__VARS__motto,$___LOCAL_PLAYER__VARS__killmsg,$___LOCAL_PLAYER__VARS__lastword,$___LOCAL_PLAYER__VARS__winner_flag,$___LOCAL_PLAYER__VARS__player_dead_flag, $___LOCAL_PLAYER__VARS__corpse_clear_flag,$___LOCAL_PLAYER__VARS__gd,$___LOCAL_PLAYER__VARS__sNo,$___LOCAL_PLAYER__VARS__club,$___LOCAL_PLAYER__VARS__validtime,$___LOCAL_PLAYER__VARS__endtime,$___LOCAL_PLAYER__VARS__cdsec,$___LOCAL_PLAYER__VARS__cdmsec,$___LOCAL_PLAYER__VARS__cdtime,$___LOCAL_PLAYER__VARS__action, $___LOCAL_PLAYER__VARS__a_actionnum,$___LOCAL_PLAYER__VARS__v_actionnum,$___LOCAL_PLAYER__VARS__hp,$___LOCAL_PLAYER__VARS__mhp,$___LOCAL_PLAYER__VARS__sp,$___LOCAL_PLAYER__VARS__msp,$___LOCAL_PLAYER__VARS__mss,$___LOCAL_PLAYER__VARS__att,$___LOCAL_PLAYER__VARS__def,$___LOCAL_PLAYER__VARS__pls, $___LOCAL_PLAYER__VARS__lvl,$___LOCAL_PLAYER__VARS__exp,$___LOCAL_PLAYER__VARS__money,$___LOCAL_PLAYER__VARS__rp,$___LOCAL_PLAYER__VARS__bid,$___LOCAL_PLAYER__VARS__inf,$___LOCAL_PLAYER__VARS__rage,$___LOCAL_PLAYER__VARS__pose,$___LOCAL_PLAYER__VARS__tactic,$___LOCAL_PLAYER__VARS__killnum, $___LOCAL_PLAYER__VARS__npckillnum,$___LOCAL_PLAYER__VARS__state,$___LOCAL_PLAYER__VARS__skillpoint,$___LOCAL_PLAYER__VARS__flare,$___LOCAL_PLAYER__VARS__wp,$___LOCAL_PLAYER__VARS__wk,$___LOCAL_PLAYER__VARS__wg,$___LOCAL_PLAYER__VARS__wc,$___LOCAL_PLAYER__VARS__wd,$___LOCAL_PLAYER__VARS__wf, $___LOCAL_PLAYER__VARS__icon,$___LOCAL_PLAYER__VARS__teamID,$___LOCAL_PLAYER__VARS__teamPass,$___LOCAL_PLAYER__VARS__card,$___LOCAL_PLAYER__VARS__cardname,$___LOCAL_PLAYER__VARS__wep,$___LOCAL_PLAYER__VARS__wepk,$___LOCAL_PLAYER__VARS__wepe,$___LOCAL_PLAYER__VARS__weps,$___LOCAL_PLAYER__VARS__wepsk, $___LOCAL_PLAYER__VARS__arb,$___LOCAL_PLAYER__VARS__arbk,$___LOCAL_PLAYER__VARS__arbe,$___LOCAL_PLAYER__VARS__arbs,$___LOCAL_PLAYER__VARS__arbsk,$___LOCAL_PLAYER__VARS__arh,$___LOCAL_PLAYER__VARS__arhk,$___LOCAL_PLAYER__VARS__arhe,$___LOCAL_PLAYER__VARS__arhs,$___LOCAL_PLAYER__VARS__arhsk, $___LOCAL_PLAYER__VARS__ara,$___LOCAL_PLAYER__VARS__arak,$___LOCAL_PLAYER__VARS__arae,$___LOCAL_PLAYER__VARS__aras,$___LOCAL_PLAYER__VARS__arask,$___LOCAL_PLAYER__VARS__arf,$___LOCAL_PLAYER__VARS__arfk,$___LOCAL_PLAYER__VARS__arfe,$___LOCAL_PLAYER__VARS__arfs,$___LOCAL_PLAYER__VARS__arfsk, $___LOCAL_PLAYER__VARS__art,$___LOCAL_PLAYER__VARS__artk,$___LOCAL_PLAYER__VARS__arte,$___LOCAL_PLAYER__VARS__arts,$___LOCAL_PLAYER__VARS__artsk,$___LOCAL_PLAYER__VARS__itm0,$___LOCAL_PLAYER__VARS__itmk0,$___LOCAL_PLAYER__VARS__itme0,$___LOCAL_PLAYER__VARS__itms0,$___LOCAL_PLAYER__VARS__itmsk0, $___LOCAL_PLAYER__VARS__itm1,$___LOCAL_PLAYER__VARS__itmk1,$___LOCAL_PLAYER__VARS__itme1,$___LOCAL_PLAYER__VARS__itms1,$___LOCAL_PLAYER__VARS__itmsk1,$___LOCAL_PLAYER__VARS__itm2,$___LOCAL_PLAYER__VARS__itmk2,$___LOCAL_PLAYER__VARS__itme2,$___LOCAL_PLAYER__VARS__itms2,$___LOCAL_PLAYER__VARS__itmsk2, $___LOCAL_PLAYER__VARS__itm3,$___LOCAL_PLAYER__VARS__itmk3,$___LOCAL_PLAYER__VARS__itme3,$___LOCAL_PLAYER__VARS__itms3,$___LOCAL_PLAYER__VARS__itmsk3,$___LOCAL_PLAYER__VARS__itm4,$___LOCAL_PLAYER__VARS__itmk4,$___LOCAL_PLAYER__VARS__itme4,$___LOCAL_PLAYER__VARS__itms4,$___LOCAL_PLAYER__VARS__itmsk4, $___LOCAL_PLAYER__VARS__itm5,$___LOCAL_PLAYER__VARS__itmk5,$___LOCAL_PLAYER__VARS__itme5,$___LOCAL_PLAYER__VARS__itms5,$___LOCAL_PLAYER__VARS__itmsk5,$___LOCAL_PLAYER__VARS__itm6,$___LOCAL_PLAYER__VARS__itmk6,$___LOCAL_PLAYER__VARS__itme6,$___LOCAL_PLAYER__VARS__itms6,$___LOCAL_PLAYER__VARS__itmsk6, $___LOCAL_PLAYER__VARS__searchmemory,$___LOCAL_PLAYER__VARS__nskill,$___LOCAL_PLAYER__VARS__nskillpara; $ss=&$___LOCAL_PLAYER__VARS__ss; $db_player_structure=&$___LOCAL_PLAYER__VARS__db_player_structure; $db_player_structure_types=&$___LOCAL_PLAYER__VARS__db_player_structure_types; $gamedata=&$___LOCAL_PLAYER__VARS__gamedata; $cmd=&$___LOCAL_PLAYER__VARS__cmd; $main=&$___LOCAL_PLAYER__VARS__main; $sdata=&$___LOCAL_PLAYER__VARS__sdata; $fog=&$___LOCAL_PLAYER__VARS__fog; $upexp=&$___LOCAL_PLAYER__VARS__upexp; $lvlupexp=&$___LOCAL_PLAYER__VARS__lvlupexp;  $iconImg=&$___LOCAL_PLAYER__VARS__iconImg; $iconImgB=&$___LOCAL_PLAYER__VARS__iconImgB; $iconImgBwidth=&$___LOCAL_PLAYER__VARS__iconImgBwidth; $ardef=&$___LOCAL_PLAYER__VARS__ardef; $hpcolor=&$___LOCAL_PLAYER__VARS__hpcolor; $spcolor=&$___LOCAL_PLAYER__VARS__spcolor; $newhpimg=&$___LOCAL_PLAYER__VARS__newhpimg; $newspimg=&$___LOCAL_PLAYER__VARS__newspimg; $splt=&$___LOCAL_PLAYER__VARS__splt; $hplt=&$___LOCAL_PLAYER__VARS__hplt;  $tpldata=&$___LOCAL_PLAYER__VARS__tpldata; $icon_list=&$___LOCAL_PLAYER__VARS__icon_list; $icon_list_contents_to_frontend=&$___LOCAL_PLAYER__VARS__icon_list_contents_to_frontend; $typeinfo=&$___LOCAL_PLAYER__VARS__typeinfo; $killmsginfo=&$___LOCAL_PLAYER__VARS__killmsginfo; $lwinfo=&$___LOCAL_PLAYER__VARS__lwinfo; $sexinfo=&$___LOCAL_PLAYER__VARS__sexinfo; $equip_list=&$___LOCAL_PLAYER__VARS__equip_list; $battle_equip_list=&$___LOCAL_PLAYER__VARS__battle_equip_list; $pc_icon_range=&$___LOCAL_PLAYER__VARS__pc_icon_range;  $pid=&$___LOCAL_PLAYER__VARS__pid; $type=&$___LOCAL_PLAYER__VARS__type; $name=&$___LOCAL_PLAYER__VARS__name; $pass=&$___LOCAL_PLAYER__VARS__pass; $ip=&$___LOCAL_PLAYER__VARS__ip; $motto=&$___LOCAL_PLAYER__VARS__motto; $killmsg=&$___LOCAL_PLAYER__VARS__killmsg; $lastword=&$___LOCAL_PLAYER__VARS__lastword; $winner_flag=&$___LOCAL_PLAYER__VARS__winner_flag; $player_dead_flag=&$___LOCAL_PLAYER__VARS__player_dead_flag;  $corpse_clear_flag=&$___LOCAL_PLAYER__VARS__corpse_clear_flag; $gd=&$___LOCAL_PLAYER__VARS__gd; $sNo=&$___LOCAL_PLAYER__VARS__sNo; $club=&$___LOCAL_PLAYER__VARS__club; $validtime=&$___LOCAL_PLAYER__VARS__validtime; $endtime=&$___LOCAL_PLAYER__VARS__endtime; $cdsec=&$___LOCAL_PLAYER__VARS__cdsec; $cdmsec=&$___LOCAL_PLAYER__VARS__cdmsec; $cdtime=&$___LOCAL_PLAYER__VARS__cdtime; $action=&$___LOCAL_PLAYER__VARS__action;  $a_actionnum=&$___LOCAL_PLAYER__VARS__a_actionnum; $v_actionnum=&$___LOCAL_PLAYER__VARS__v_actionnum; $hp=&$___LOCAL_PLAYER__VARS__hp; $mhp=&$___LOCAL_PLAYER__VARS__mhp; $sp=&$___LOCAL_PLAYER__VARS__sp; $msp=&$___LOCAL_PLAYER__VARS__msp; $mss=&$___LOCAL_PLAYER__VARS__mss; $att=&$___LOCAL_PLAYER__VARS__att; $def=&$___LOCAL_PLAYER__VARS__def; $pls=&$___LOCAL_PLAYER__VARS__pls;  $lvl=&$___LOCAL_PLAYER__VARS__lvl; $exp=&$___LOCAL_PLAYER__VARS__exp; $money=&$___LOCAL_PLAYER__VARS__money; $rp=&$___LOCAL_PLAYER__VARS__rp; $bid=&$___LOCAL_PLAYER__VARS__bid; $inf=&$___LOCAL_PLAYER__VARS__inf; $rage=&$___LOCAL_PLAYER__VARS__rage; $pose=&$___LOCAL_PLAYER__VARS__pose; $tactic=&$___LOCAL_PLAYER__VARS__tactic; $killnum=&$___LOCAL_PLAYER__VARS__killnum;  $npckillnum=&$___LOCAL_PLAYER__VARS__npckillnum; $state=&$___LOCAL_PLAYER__VARS__state; $skillpoint=&$___LOCAL_PLAYER__VARS__skillpoint; $flare=&$___LOCAL_PLAYER__VARS__flare; $wp=&$___LOCAL_PLAYER__VARS__wp; $wk=&$___LOCAL_PLAYER__VARS__wk; $wg=&$___LOCAL_PLAYER__VARS__wg; $wc=&$___LOCAL_PLAYER__VARS__wc; $wd=&$___LOCAL_PLAYER__VARS__wd; $wf=&$___LOCAL_PLAYER__VARS__wf;  $icon=&$___LOCAL_PLAYER__VARS__icon; $teamID=&$___LOCAL_PLAYER__VARS__teamID; $teamPass=&$___LOCAL_PLAYER__VARS__teamPass; $card=&$___LOCAL_PLAYER__VARS__card; $cardname=&$___LOCAL_PLAYER__VARS__cardname; $wep=&$___LOCAL_PLAYER__VARS__wep; $wepk=&$___LOCAL_PLAYER__VARS__wepk; $wepe=&$___LOCAL_PLAYER__VARS__wepe; $weps=&$___LOCAL_PLAYER__VARS__weps; $wepsk=&$___LOCAL_PLAYER__VARS__wepsk;  $arb=&$___LOCAL_PLAYER__VARS__arb; $arbk=&$___LOCAL_PLAYER__VARS__arbk; $arbe=&$___LOCAL_PLAYER__VARS__arbe; $arbs=&$___LOCAL_PLAYER__VARS__arbs; $arbsk=&$___LOCAL_PLAYER__VARS__arbsk; $arh=&$___LOCAL_PLAYER__VARS__arh; $arhk=&$___LOCAL_PLAYER__VARS__arhk; $arhe=&$___LOCAL_PLAYER__VARS__arhe; $arhs=&$___LOCAL_PLAYER__VARS__arhs; $arhsk=&$___LOCAL_PLAYER__VARS__arhsk;  $ara=&$___LOCAL_PLAYER__VARS__ara; $arak=&$___LOCAL_PLAYER__VARS__arak; $arae=&$___LOCAL_PLAYER__VARS__arae; $aras=&$___LOCAL_PLAYER__VARS__aras; $arask=&$___LOCAL_PLAYER__VARS__arask; $arf=&$___LOCAL_PLAYER__VARS__arf; $arfk=&$___LOCAL_PLAYER__VARS__arfk; $arfe=&$___LOCAL_PLAYER__VARS__arfe; $arfs=&$___LOCAL_PLAYER__VARS__arfs; $arfsk=&$___LOCAL_PLAYER__VARS__arfsk;  $art=&$___LOCAL_PLAYER__VARS__art; $artk=&$___LOCAL_PLAYER__VARS__artk; $arte=&$___LOCAL_PLAYER__VARS__arte; $arts=&$___LOCAL_PLAYER__VARS__arts; $artsk=&$___LOCAL_PLAYER__VARS__artsk; $itm0=&$___LOCAL_PLAYER__VARS__itm0; $itmk0=&$___LOCAL_PLAYER__VARS__itmk0; $itme0=&$___LOCAL_PLAYER__VARS__itme0; $itms0=&$___LOCAL_PLAYER__VARS__itms0; $itmsk0=&$___LOCAL_PLAYER__VARS__itmsk0;  $itm1=&$___LOCAL_PLAYER__VARS__itm1; $itmk1=&$___LOCAL_PLAYER__VARS__itmk1; $itme1=&$___LOCAL_PLAYER__VARS__itme1; $itms1=&$___LOCAL_PLAYER__VARS__itms1; $itmsk1=&$___LOCAL_PLAYER__VARS__itmsk1; $itm2=&$___LOCAL_PLAYER__VARS__itm2; $itmk2=&$___LOCAL_PLAYER__VARS__itmk2; $itme2=&$___LOCAL_PLAYER__VARS__itme2; $itms2=&$___LOCAL_PLAYER__VARS__itms2; $itmsk2=&$___LOCAL_PLAYER__VARS__itmsk2;  $itm3=&$___LOCAL_PLAYER__VARS__itm3; $itmk3=&$___LOCAL_PLAYER__VARS__itmk3; $itme3=&$___LOCAL_PLAYER__VARS__itme3; $itms3=&$___LOCAL_PLAYER__VARS__itms3; $itmsk3=&$___LOCAL_PLAYER__VARS__itmsk3; $itm4=&$___LOCAL_PLAYER__VARS__itm4; $itmk4=&$___LOCAL_PLAYER__VARS__itmk4; $itme4=&$___LOCAL_PLAYER__VARS__itme4; $itms4=&$___LOCAL_PLAYER__VARS__itms4; $itmsk4=&$___LOCAL_PLAYER__VARS__itmsk4;  $itm5=&$___LOCAL_PLAYER__VARS__itm5; $itmk5=&$___LOCAL_PLAYER__VARS__itmk5; $itme5=&$___LOCAL_PLAYER__VARS__itme5; $itms5=&$___LOCAL_PLAYER__VARS__itms5; $itmsk5=&$___LOCAL_PLAYER__VARS__itmsk5; $itm6=&$___LOCAL_PLAYER__VARS__itm6; $itmk6=&$___LOCAL_PLAYER__VARS__itmk6; $itme6=&$___LOCAL_PLAYER__VARS__itme6; $itms6=&$___LOCAL_PLAYER__VARS__itms6; $itmsk6=&$___LOCAL_PLAYER__VARS__itmsk6;  $searchmemory=&$___LOCAL_PLAYER__VARS__searchmemory; $nskill=&$___LOCAL_PLAYER__VARS__nskill; $nskillpara=&$___LOCAL_PLAYER__VARS__nskillpara;  global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
		if (!\skillbase\skill_query(26))
		{
			$log.='你没有这个技能！<br>';
			return;
		}
		$clv = \skillbase\skill_getvalue(26,'lvl');
		if ($clv == 2)
		{
			$log.='你已经升级完成了，不能继续升级！<br>';
			return;
		}
		if ($skillpoint<$upgradecost) 
		{
			$log.='技能点不足。<br>';
			return;
		}
		$skillpoint-=$upgradecost; \skillbase\skill_setvalue(26,'lvl',2);
		$log.='升级成功。<br>';
	}
	
	function parse_news($nid, $news, $hour, $min, $sec, $a, $b, $c, $d, $e, $exarr = array())
	{
		return \skill489\parse_news($nid,$news,$hour,$min,$sec,$a,$b,$c,$d,$e,$exarr);
	}
	
}

?>