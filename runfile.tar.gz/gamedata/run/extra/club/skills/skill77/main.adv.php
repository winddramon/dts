<?php

namespace skill77
{
	function init() 
	{
		define('MOD_SKILL77_INFO','club;locked;');
		do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;   } while (0);
		$clubskillname[77] = '觉醒';
	}
	
	function acquire77(&$pa)
	{
		
	}
	
	function lost77(&$pa)
	{
		
	}
	
	function check_unlocked77(&$pa)
	{
		
		return $pa['lvl']>=19;
	}
	
	function get_factor70(&$pa)
	{
		
		
		if (\skillbase\skill_query(77,$pa) && \skill77\check_unlocked77 ($pa)) return 0.55;
		else{
		//======== Start of contents from mod skill70 ========
		do{
			$___TMP_MOD_skill70_FUNC_get_factor70_RET = NULL;

		
		if ($pa['lvl']>=19){ $___TMP_MOD_skill70_FUNC_get_factor70_RET =  0.55;
			break; }
		$___TMP_MOD_skill70_FUNC_get_factor70_RET =  0.25;
			break; 
		}while(0);
		//======== End of contents from mod skill70 ========
 return $___TMP_MOD_skill70_FUNC_get_factor70_RET;}
	
	}
}

?>
