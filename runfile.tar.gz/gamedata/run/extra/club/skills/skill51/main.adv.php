<?php

namespace skill51
{
	function init() 
	{
		define('MOD_SKILL51_INFO','club;');
		do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;   } while (0);
		$clubskillname[51] = '百出';
	}
	
	function acquire51(&$pa)
	{
		
	}
	
	function lost51(&$pa)
	{
		
	}
	
	function get_skill48_maxbuff(&$pa)
	{
		
		if (!\skillbase\skill_query(48,$pa)) return 0;
		do { global $___LOCAL_SKILL48__VARS__ragecost,$___LOCAL_SKILL48__VARS__wep_skillkind_req,$___LOCAL_SKILL48__VARS__skill48_ex_map,$___LOCAL_SKILL48__VARS__skill48stateinfo,$___LOCAL_SKILL48__VARS__skill48_ex_kind_list; $ragecost=&$___LOCAL_SKILL48__VARS__ragecost; $wep_skillkind_req=&$___LOCAL_SKILL48__VARS__wep_skillkind_req; $skill48_ex_map=&$___LOCAL_SKILL48__VARS__skill48_ex_map; $skill48stateinfo=&$___LOCAL_SKILL48__VARS__skill48stateinfo; $skill48_ex_kind_list=&$___LOCAL_SKILL48__VARS__skill48_ex_kind_list;   } while (0);
		$maxx=0;
		foreach ($skill48_ex_kind_list as $key => $value)
		{
			$x=\skillbase\skill_getvalue(48,$key,$pa);
			if ($x>$maxx) $maxx=$x;
		}
		return $maxx;
	}
	
	function check_unlocked51(&$pa)
	{
		
		return get_skill48_maxbuff($pa)>=120;
	}
	
	function get_skill51_multiplier(&$pa)
	{
		
		$z=(int)\skillbase\skill_getvalue(48,'tot',$pa); 
		$z*=2;
		return $z;
	}
	
	function get_physical_dmg_multiplier(&$pa, &$pd, $active)
	{
		return \skill265\get_physical_dmg_multiplier($pa,$pd,$active);
	}
	
}

?>
