<?php

namespace skill46
{
	function init() 
	{
		define('MOD_SKILL46_INFO','club;battle;limited;');
		do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;   } while (0);
		$clubskillname[46] = '破巧';
	}
	
	function acquire46(&$pa)
	{
		
		\skillbase\skill_setvalue(46,'rmtime','2',$pa);
	}
	
	function lost46(&$pa)
	{
		
	}
	
	function check_unlocked46(&$pa)
	{
		
		return $pa['lvl']>=15;
	}
	
	function get_remaintime46(&$pa = NULL)
	{
		
		return \skillbase\skill_getvalue(46,'rmtime',$pa);
	}
	
	function strike_prepare(&$pa, &$pd, $active)
	{
		$___TEMP_backtrace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 2); 
		array_shift($___TEMP_backtrace);
		if (count($___TEMP_backtrace)==0) $___TEMP_PARENT_NAME=''; else $___TEMP_PARENT_NAME=strtolower($___TEMP_backtrace[0]['function']);
		if ($___TEMP_PARENT_NAME!='skill60\strike_prepare') 
		{
			return \skill507\strike_prepare($pa,$pd,$active);
		}
		unset($___TEMP_PARENT_NAME); unset($___TEMP_backtrace); 
	
		
		
		if ($pa['bskill']!=46) {
			\skill45\strike_prepare($pa, $pd, $active);
			return;
		}
		if (!\skillbase\skill_query(46,$pa) || !\skill46\check_unlocked46 ($pa))
		{
			do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
			$log .= '你尚未解锁这个技能！';
			$pa['bskill']=0;
		}
		else
		{
			$remtime = (int)\skill46\get_remaintime46 ($pa);
			if (!\clubbase\check_battle_skill_unactivatable($pa,$pd,46))
			{
				do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
				if ($active)
					$log.="<span class=\"lime b\">你对{$pd['name']}发动了技能「破巧」！</span><br>";
				else  $log.="<span class=\"lime b\">{$pa['name']}对你发动了技能「破巧」！</span><br>";
				$remtime--; 
				\skillbase\skill_setvalue(46,'rmtime',$remtime,$pa);
				$pd['skill46_flag']=1;
				addnews ( 0, 'bskill46', $pa['name'], $pd['name'] );
			}
			else
			{
				if ($active)
				{
					do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
					$log.='剩余次数用尽，不能发动。<br>';
				}
				$pa['bskill']=0;
			}
		}
		\skill45\strike_prepare($pa, $pd, $active);
	
	}	
	
	function get_physical_dmg_multiplier(&$pa, &$pd, $active)
	{
		return \skill265\get_physical_dmg_multiplier($pa,$pd,$active);
	}
	
	function parse_news($nid, $news, $hour, $min, $sec, $a, $b, $c, $d, $e, $exarr = array())
	{
		return \skill489\parse_news($nid,$news,$hour,$min,$sec,$a,$b,$c,$d,$e,$exarr);
	}
	
	function skill_enabled_core($skillid, &$pa = NULL)
	{
		return \skill575\skill_enabled_core($skillid,$pa);
	}
}

?>
