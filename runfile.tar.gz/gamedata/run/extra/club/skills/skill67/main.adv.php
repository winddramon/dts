<?php

namespace skill67
{
	function init() 
	{
		define('MOD_SKILL67_INFO','club;');
		do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;   } while (0);
		$clubskillname[67] = '理财';
	}
	
	function acquire67(&$pa)
	{
		
	}
	
	function lost67(&$pa)
	{
		
	}
	
	function check_unlocked67(&$pa)
	{
		
		return $pa['lvl']>=11;
	}
	
	function calc_skill67_money(&$pa)
	{
		
		$ret = $pa['club']==11 ? 200 : 150;
		if(!empty($pa['card']) && $pa['card'] == 89) $ret *= 2;
		return $ret;
	}
	
	function lvlup(&$pa)
	{
		return \skill87\lvlup($pa);
	}
}

?>
