<?php

namespace skill41
{
	function init() 
	{
		define('MOD_SKILL41_INFO','club;locked;');
		do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;   } while (0);
		$clubskillname[41] = '神速';
	}
	
	function acquire41(&$pa)
	{
		
	}
	
	function lost41(&$pa)
	{
		
		\skillbase\skill_delvalue(41,'u',$pa);
	}
	
	function unlock41(&$pa)
	{
		
		\skillbase\skill_setvalue(41,'u','1',$pa);
	}
	
	function lock41(&$pa)
	{
		
		\skillbase\skill_setvalue(41,'u','0',$pa);
	}
	
	function check_unlocked41(&$pa)
	{
		
		$skill41_u = \skillbase\skill_getvalue(41,'u',$pa);
		if ($skill41_u === '1') return 1;
		elseif ($skill41_u === '0') return 0;
		if (\skillbase\skill_query(43,$pa)) return 0;
		return 1;
	}
	
	
	function get_internal_att(&$pa,&$pd,$active)
	{
		$___TEMP_backtrace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 2); 
		array_shift($___TEMP_backtrace);
		if (count($___TEMP_backtrace)==0) $___TEMP_PARENT_NAME=''; else $___TEMP_PARENT_NAME=strtolower($___TEMP_backtrace[0]['function']);
		if ($___TEMP_PARENT_NAME!='wep_g\get_internal_att') 
		{
			return \skill103\get_internal_att($pa,$pd,$active);
		}
		unset($___TEMP_PARENT_NAME); unset($___TEMP_backtrace); 
	
		
		
		if (!\skillbase\skill_query(41,$pa) || !\skill41\check_unlocked41 ($pa)) return \weapon\get_internal_att($pa,$pd,$active);
		return \weapon\get_internal_att($pa,$pd,$active)*1.1;
	
	}
	
	
	function attack_finish(&$pa, &$pd, $active)
	{
		return \skill507\attack_finish($pa,$pd,$active);
	}
	
	function battle_prepare(&$pa, &$pd, $active)
	{
		return \skill42\battle_prepare($pa,$pd,$active);
	}
	
	










	
	
	
	function calculate_counter_rate_change(&$pa, &$pd, $active, $counter_rate)
	{
if(isset($active)) {$__VAR_DUMP_MOD_skill41_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill41_VARS_active = NULL;} if(isset($counter_rate)) {$__VAR_DUMP_MOD_skill41_VARS_counter_rate = $counter_rate; } else {$__VAR_DUMP_MOD_skill41_VARS_counter_rate = NULL;} 
		//======== Start of contents from mod weapon ========
		do{
			$___TMP_MOD_weapon_FUNC_calculate_counter_rate_change_RET = NULL;

		
		$___TMP_MOD_weapon_FUNC_calculate_counter_rate_change_RET =  $counter_rate;
			break; 
		}while(0);
		//======== End of contents from mod weapon ========

$active = $__VAR_DUMP_MOD_skill41_VARS_active; unset($__VAR_DUMP_MOD_skill41_VARS_active);$counter_rate = $__VAR_DUMP_MOD_skill41_VARS_counter_rate; unset($__VAR_DUMP_MOD_skill41_VARS_counter_rate);
		
		$ret = $___TMP_MOD_weapon_FUNC_calculate_counter_rate_change_RET;
		if (!\skillbase\skill_query(41,$pa) || !\skill41\check_unlocked41 ($pa)) return $ret;
		if (rand(0,99)<65) 
		{
			$pa['skill41_proced']=1;
			return 100;
		}
		return $ret;
	
	}
	
	function counter_assault(&$pa, &$pd, $active)
	{
		
		if (!\skillbase\skill_query(41,$pa) || !\skill41\check_unlocked41 ($pa)) {
			\battle\counter_assault($pa,$pd,$active);
			return;
		}
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
		if ($pa['skill41_proced'])
		{
			if ($active)
				$log.='<span class="yellow b">你以惊人的速度完成了反击准备，并立即对敌人进行了反击！</span><br>';
			else  $log.='<span class="yellow b">'.$pa['name'].'以惊人的速度完成了反击准备，并立即对你进行了反击！</span><br>';
		}
		$pa['skill41_proced']=0;
		\battle\counter_assault($pa, $pd, $active);
	
	}
	
}

?>
