<?php

namespace skill263
{
	function init() 
	{
		define('MOD_SKILL263_INFO','club;');
		do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;   } while (0);
		$clubskillname[263] = '格斗';
	}
	
	function acquire263(&$pa)
	{
		
	}
	
	function lost263(&$pa)
	{
		
	}
	
	function check_unlocked263(&$pa)
	{
		
		return $pa['lvl']>=11;
	}
	
	function get_internal_def(&$pa,&$pd,$active)
	{
		$___TEMP_backtrace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 2); 
		array_shift($___TEMP_backtrace);
		if (count($___TEMP_backtrace)==0) $___TEMP_PARENT_NAME=''; else $___TEMP_PARENT_NAME=strtolower($___TEMP_backtrace[0]['function']);
		if ($___TEMP_PARENT_NAME!='skill445\get_internal_def') 
		{
			return \skill42\get_internal_def($pa,$pd,$active);
		}
		unset($___TEMP_PARENT_NAME); unset($___TEMP_backtrace); 
	
		
		
		if ((\skillbase\skill_query(263,$pd))&&(\skill263\check_unlocked263 ($pd))) return \weapon\get_internal_def($pa,$pd,$active)+$pd['wp'];
		return \weapon\get_internal_def($pa,$pd,$active);
	
	}
	
	function get_skill263_chance(&$pa, &$pd, $active)
	{
		return \skill274\get_skill263_chance($pa,$pd,$active);
	}
	
	function get_final_dmg_base(&$pa, &$pd, &$active)
	{
		return \skill38\get_final_dmg_base($pa,$pd,$active);
	}
	


























}

?>
