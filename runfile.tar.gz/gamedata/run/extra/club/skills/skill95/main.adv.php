<?php

namespace skill95
{
	function init()
	{
		define('MOD_SKILL95_INFO','club;debuff;');
		do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;   } while (0);
		$clubskillname[95] = '倾心';
	}
	
	function acquire95(&$pa)
	{
		
		\skillbase\skill_setvalue(95, 'spid', '0', $pa);
	}
	
	function lost95(&$pa)
	{
		
		\skillbase\skill_delvalue(95, 'spid', $pa);
	}
	
	function check_unlocked95(&$pa)
	{
		
		return 1;
	}
	
	
	function check_enemy_meet_active(&$ldata,&$edata)
	{
		return \skill575\check_enemy_meet_active($ldata,$edata);
	}
	
	
	function get_final_dmg_multiplier(&$pa, &$pd, $active)
	{
		return \skill507\get_final_dmg_multiplier($pa,$pd,$active);
	}
	
	
	function calculate_active_obbs_multiplier(&$ldata,&$edata)
	{
		return \skill903\calculate_active_obbs_multiplier($ldata,$edata);
	}
	
}

?>