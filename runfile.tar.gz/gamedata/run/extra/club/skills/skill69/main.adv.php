<?php

namespace skill69
{
	function init() 
	{
		define('MOD_SKILL69_INFO','club;feature;');
		do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;   } while (0);
		$clubskillname[69] = '富家';
		$clubdesc_h[11] = $clubdesc_a[11] = '初始金钱为500元；购买物品时价格打七五折';
	}
	
	function acquire69(&$pa)
	{
		
		$pa['money']+=480;
	}
	
	function lost69(&$pa)
	{
		
	}
	
	function check_unlocked69(&$pa)
	{
		
		return 1;
	}
	
	function get_shopiteminfo($item)
	{
		return \skill901\get_shopiteminfo($item);
	}
	
	function prepare_shopitem($sn)
	{
		return \skill901\prepare_shopitem($sn);
	}
}

?>
