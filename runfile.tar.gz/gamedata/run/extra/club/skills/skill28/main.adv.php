<?php

namespace skill28
{
	$skill28stateinfo=Array(1=>'关闭', 2=>'开启');
	
	function init() 
	{
		define('MOD_SKILL28_INFO','club;upgrade;');
		do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;   } while (0);
		$clubskillname[28] = '毅重';
	}
	
	function acquire28(&$pa)
	{
		
		\skillbase\skill_setvalue(28,'choice','1',$pa);
	}
	
	function lost28(&$pa)
	{
		
		\skillbase\skill_delvalue(28,'choice',$pa);
	}
	
	function check_unlocked28(&$pa)
	{
		
		return $pa['lvl']>=3;
	}
	
	function upgrade28()
	{
		return \ex_mhp_temp_up\upgrade28();
	}
	
	function check_skill28_ex_array(&$pl, $arr)
	{
		
		if(\skillbase\skill_query(28,$pl) && check_unlocked28($pl) && 2 == \skillbase\skill_getvalue(28,'choice',$pl)) {
			$arr = Array('A','a','h');
		}
		return $arr;
	}
	
	function get_ex_def_array(&$pa, &$pd, $active)
	{
if(isset($active)) {$__VAR_DUMP_MOD_skill28_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill28_VARS_active = NULL;} 
		//======== Start of contents from mod attrbase ========
		do{
			$___TMP_MOD_attrbase_FUNC_get_ex_def_array_RET = NULL;

		
		$___TMP_MOD_attrbase_FUNC_get_ex_def_array_RET =  \attrbase\get_ex_def_array_core ($pa, $pd, $active);
			break; 
		}while(0);
		//======== End of contents from mod attrbase ========

$active = $__VAR_DUMP_MOD_skill28_VARS_active; unset($__VAR_DUMP_MOD_skill28_VARS_active);
		
		$ret = $___TMP_MOD_attrbase_FUNC_get_ex_def_array_RET;
		$ret = \skill28\check_skill28_ex_array ($pd, $ret);
		return $ret;
	
	}
	
	function get_ex_attack_array(&$pa, &$pd, $active)
	{
		return \skill265\get_ex_attack_array($pa,$pd,$active);
	}
}

?>
