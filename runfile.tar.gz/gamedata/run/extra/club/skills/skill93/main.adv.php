<?php

namespace skill93
{
	function init()
	{
		define('MOD_SKILL93_INFO','club;');
		do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;   } while (0);
		$clubskillname[93] = '回响';
	}
	
	function acquire93(&$pa)
	{
		
	}
	
	function lost93(&$pa)
	{
		
	}
	
	function check_unlocked93(&$pa)
	{
		
		return $pa['lvl']>=13;
	}
	
	
	function get_ex_attack_array_core(&$pa, &$pd, $active)
	{
		return \skill507\get_ex_attack_array_core($pa,$pd,$active);
	}
	
	
	function calculate_ex_single_dmg_multiple(&$pa, &$pd, $active, $key)
	{
if(isset($active)) {$__VAR_DUMP_MOD_skill93_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill93_VARS_active = NULL;} if(isset($key)) {$__VAR_DUMP_MOD_skill93_VARS_key = $key; } else {$__VAR_DUMP_MOD_skill93_VARS_key = NULL;} 
		//======== Start of contents from mod skill465 ========
		do{
			$___TMP_MOD_skill465_FUNC_calculate_ex_single_dmg_multiple_RET = NULL;
if(isset($active)) {$__VAR_DUMP_MOD_skill465_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill465_VARS_active = NULL;} if(isset($key)) {$__VAR_DUMP_MOD_skill465_VARS_key = $key; } else {$__VAR_DUMP_MOD_skill465_VARS_key = NULL;} 
		//======== Start of contents from mod skill463 ========
		do{
			$___TMP_MOD_skill463_FUNC_calculate_ex_single_dmg_multiple_RET = NULL;

		
		if (!\skillbase\skill_query(463,$pd) || ($key!='f' && $key!='u')){ $___TMP_MOD_skill463_FUNC_calculate_ex_single_dmg_multiple_RET =  \skill448\calculate_ex_single_dmg_multiple($pa, $pd, $active, $key);
			break; }
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
		if ($active)
			$log.='<span class="yellow b">敌人的藤甲烧起来了！烫烫烫烫烫烫烫！</span><br>';
		else  $log.='<span class="yellow b">你的藤甲烧起来了！烫烫烫烫烫烫烫！</span><br>';
		$___TMP_MOD_skill463_FUNC_calculate_ex_single_dmg_multiple_RET =  \skill448\calculate_ex_single_dmg_multiple($pa, $pd, $active, $key)*2.5;
			break; 
		}while(0);
		//======== End of contents from mod skill463 ========

$active = $__VAR_DUMP_MOD_skill465_VARS_active; unset($__VAR_DUMP_MOD_skill465_VARS_active);$key = $__VAR_DUMP_MOD_skill465_VARS_key; unset($__VAR_DUMP_MOD_skill465_VARS_key);

		
		$ret = $___TMP_MOD_skill463_FUNC_calculate_ex_single_dmg_multiple_RET;
		if(\skillbase\skill_query(465,$pa) && ($key=='f' || $key=='u')){
			$ret *=1.5;
			if(!isset($pa['battlelogflag_skill465'])){
				do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
				$log .= \battle\battlelog_parser($pa, $pd, $active,'「圣火」让<:pa_name:>造成的伤害增加了50%！');
				$pa['battlelogflag_skill465'] = 1;
			}
		}
		$___TMP_MOD_skill465_FUNC_calculate_ex_single_dmg_multiple_RET =  $ret;
			break; 
		}while(0);
		//======== End of contents from mod skill465 ========

$active = $__VAR_DUMP_MOD_skill93_VARS_active; unset($__VAR_DUMP_MOD_skill93_VARS_active);$key = $__VAR_DUMP_MOD_skill93_VARS_key; unset($__VAR_DUMP_MOD_skill93_VARS_key);
		
		$ret = $___TMP_MOD_skill465_FUNC_calculate_ex_single_dmg_multiple_RET;
		if (($key == 'w') && isset($pa['skill93_flag']))
		{
			do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
			if ($active) $log.="<br><span class=\"yellow b\">「回响」使你造成的音波伤害大幅增加了！</span><br>";
			else $log.="<br><span class=\"yellow b\">「回响」使{$pa['name']}造成的音波伤害大幅增加了！</span><br>";
			$ret *= 1.6;
		}
		return $ret;
	
	}
	
	
	function get_ex_def_array_core(&$pa, &$pd, $active)
	{
		$___TEMP_backtrace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 2); 
		array_shift($___TEMP_backtrace);
		if (count($___TEMP_backtrace)==0) $___TEMP_PARENT_NAME=''; else $___TEMP_PARENT_NAME=strtolower($___TEMP_backtrace[0]['function']);
		if ($___TEMP_PARENT_NAME!='skill34\get_ex_def_array_core') 
		{
			return \skill34\get_ex_def_array_core($pa,$pd,$active);
		}
		unset($___TEMP_PARENT_NAME); unset($___TEMP_backtrace); 
	
		
if(isset($active)) {$__VAR_DUMP_MOD_skill93_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill93_VARS_active = NULL;} 
		//======== Start of contents from mod skill103 ========
		do{
			$___TMP_MOD_skill103_FUNC_get_ex_def_array_core_RET = NULL;
if(isset($active)) {$__VAR_DUMP_MOD_skill103_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill103_VARS_active = NULL;} 
		//======== Start of contents from mod skill96 ========
		do{
			$___TMP_MOD_skill96_FUNC_get_ex_def_array_core_RET = NULL;
if(isset($active)) {$__VAR_DUMP_MOD_skill96_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill96_VARS_active = NULL;} 
		//======== Start of contents from mod skill89 ========
		do{
			$___TMP_MOD_skill89_FUNC_get_ex_def_array_core_RET = NULL;
if(isset($active)) {$__VAR_DUMP_MOD_skill89_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill89_VARS_active = NULL;} 
		//======== Start of contents from mod attrbase ========
		do{
			$___TMP_MOD_attrbase_FUNC_get_ex_def_array_core_RET = NULL;

		
		do { global $___LOCAL_PLAYER__VARS__ss,$___LOCAL_PLAYER__VARS__db_player_structure,$___LOCAL_PLAYER__VARS__db_player_structure_types,$___LOCAL_PLAYER__VARS__gamedata,$___LOCAL_PLAYER__VARS__cmd,$___LOCAL_PLAYER__VARS__main,$___LOCAL_PLAYER__VARS__sdata,$___LOCAL_PLAYER__VARS__fog,$___LOCAL_PLAYER__VARS__upexp,$___LOCAL_PLAYER__VARS__lvlupexp, $___LOCAL_PLAYER__VARS__iconImg,$___LOCAL_PLAYER__VARS__iconImgB,$___LOCAL_PLAYER__VARS__iconImgBwidth,$___LOCAL_PLAYER__VARS__ardef,$___LOCAL_PLAYER__VARS__hpcolor,$___LOCAL_PLAYER__VARS__spcolor,$___LOCAL_PLAYER__VARS__newhpimg,$___LOCAL_PLAYER__VARS__newspimg,$___LOCAL_PLAYER__VARS__splt,$___LOCAL_PLAYER__VARS__hplt, $___LOCAL_PLAYER__VARS__tpldata,$___LOCAL_PLAYER__VARS__icon_list,$___LOCAL_PLAYER__VARS__icon_list_contents_to_frontend,$___LOCAL_PLAYER__VARS__typeinfo,$___LOCAL_PLAYER__VARS__killmsginfo,$___LOCAL_PLAYER__VARS__lwinfo,$___LOCAL_PLAYER__VARS__sexinfo,$___LOCAL_PLAYER__VARS__equip_list,$___LOCAL_PLAYER__VARS__battle_equip_list,$___LOCAL_PLAYER__VARS__pc_icon_range, $___LOCAL_PLAYER__VARS__pid,$___LOCAL_PLAYER__VARS__type,$___LOCAL_PLAYER__VARS__name,$___LOCAL_PLAYER__VARS__pass,$___LOCAL_PLAYER__VARS__ip,$___LOCAL_PLAYER__VARS__motto,$___LOCAL_PLAYER__VARS__killmsg,$___LOCAL_PLAYER__VARS__lastword,$___LOCAL_PLAYER__VARS__winner_flag,$___LOCAL_PLAYER__VARS__player_dead_flag, $___LOCAL_PLAYER__VARS__corpse_clear_flag,$___LOCAL_PLAYER__VARS__gd,$___LOCAL_PLAYER__VARS__sNo,$___LOCAL_PLAYER__VARS__club,$___LOCAL_PLAYER__VARS__validtime,$___LOCAL_PLAYER__VARS__endtime,$___LOCAL_PLAYER__VARS__cdsec,$___LOCAL_PLAYER__VARS__cdmsec,$___LOCAL_PLAYER__VARS__cdtime,$___LOCAL_PLAYER__VARS__action, $___LOCAL_PLAYER__VARS__a_actionnum,$___LOCAL_PLAYER__VARS__v_actionnum,$___LOCAL_PLAYER__VARS__hp,$___LOCAL_PLAYER__VARS__mhp,$___LOCAL_PLAYER__VARS__sp,$___LOCAL_PLAYER__VARS__msp,$___LOCAL_PLAYER__VARS__mss,$___LOCAL_PLAYER__VARS__att,$___LOCAL_PLAYER__VARS__def,$___LOCAL_PLAYER__VARS__pls, $___LOCAL_PLAYER__VARS__lvl,$___LOCAL_PLAYER__VARS__exp,$___LOCAL_PLAYER__VARS__money,$___LOCAL_PLAYER__VARS__rp,$___LOCAL_PLAYER__VARS__bid,$___LOCAL_PLAYER__VARS__inf,$___LOCAL_PLAYER__VARS__rage,$___LOCAL_PLAYER__VARS__pose,$___LOCAL_PLAYER__VARS__tactic,$___LOCAL_PLAYER__VARS__killnum, $___LOCAL_PLAYER__VARS__npckillnum,$___LOCAL_PLAYER__VARS__state,$___LOCAL_PLAYER__VARS__skillpoint,$___LOCAL_PLAYER__VARS__flare,$___LOCAL_PLAYER__VARS__wp,$___LOCAL_PLAYER__VARS__wk,$___LOCAL_PLAYER__VARS__wg,$___LOCAL_PLAYER__VARS__wc,$___LOCAL_PLAYER__VARS__wd,$___LOCAL_PLAYER__VARS__wf, $___LOCAL_PLAYER__VARS__icon,$___LOCAL_PLAYER__VARS__teamID,$___LOCAL_PLAYER__VARS__teamPass,$___LOCAL_PLAYER__VARS__card,$___LOCAL_PLAYER__VARS__cardname,$___LOCAL_PLAYER__VARS__wep,$___LOCAL_PLAYER__VARS__wepk,$___LOCAL_PLAYER__VARS__wepe,$___LOCAL_PLAYER__VARS__weps,$___LOCAL_PLAYER__VARS__wepsk, $___LOCAL_PLAYER__VARS__arb,$___LOCAL_PLAYER__VARS__arbk,$___LOCAL_PLAYER__VARS__arbe,$___LOCAL_PLAYER__VARS__arbs,$___LOCAL_PLAYER__VARS__arbsk,$___LOCAL_PLAYER__VARS__arh,$___LOCAL_PLAYER__VARS__arhk,$___LOCAL_PLAYER__VARS__arhe,$___LOCAL_PLAYER__VARS__arhs,$___LOCAL_PLAYER__VARS__arhsk, $___LOCAL_PLAYER__VARS__ara,$___LOCAL_PLAYER__VARS__arak,$___LOCAL_PLAYER__VARS__arae,$___LOCAL_PLAYER__VARS__aras,$___LOCAL_PLAYER__VARS__arask,$___LOCAL_PLAYER__VARS__arf,$___LOCAL_PLAYER__VARS__arfk,$___LOCAL_PLAYER__VARS__arfe,$___LOCAL_PLAYER__VARS__arfs,$___LOCAL_PLAYER__VARS__arfsk, $___LOCAL_PLAYER__VARS__art,$___LOCAL_PLAYER__VARS__artk,$___LOCAL_PLAYER__VARS__arte,$___LOCAL_PLAYER__VARS__arts,$___LOCAL_PLAYER__VARS__artsk,$___LOCAL_PLAYER__VARS__itm0,$___LOCAL_PLAYER__VARS__itmk0,$___LOCAL_PLAYER__VARS__itme0,$___LOCAL_PLAYER__VARS__itms0,$___LOCAL_PLAYER__VARS__itmsk0, $___LOCAL_PLAYER__VARS__itm1,$___LOCAL_PLAYER__VARS__itmk1,$___LOCAL_PLAYER__VARS__itme1,$___LOCAL_PLAYER__VARS__itms1,$___LOCAL_PLAYER__VARS__itmsk1,$___LOCAL_PLAYER__VARS__itm2,$___LOCAL_PLAYER__VARS__itmk2,$___LOCAL_PLAYER__VARS__itme2,$___LOCAL_PLAYER__VARS__itms2,$___LOCAL_PLAYER__VARS__itmsk2, $___LOCAL_PLAYER__VARS__itm3,$___LOCAL_PLAYER__VARS__itmk3,$___LOCAL_PLAYER__VARS__itme3,$___LOCAL_PLAYER__VARS__itms3,$___LOCAL_PLAYER__VARS__itmsk3,$___LOCAL_PLAYER__VARS__itm4,$___LOCAL_PLAYER__VARS__itmk4,$___LOCAL_PLAYER__VARS__itme4,$___LOCAL_PLAYER__VARS__itms4,$___LOCAL_PLAYER__VARS__itmsk4, $___LOCAL_PLAYER__VARS__itm5,$___LOCAL_PLAYER__VARS__itmk5,$___LOCAL_PLAYER__VARS__itme5,$___LOCAL_PLAYER__VARS__itms5,$___LOCAL_PLAYER__VARS__itmsk5,$___LOCAL_PLAYER__VARS__itm6,$___LOCAL_PLAYER__VARS__itmk6,$___LOCAL_PLAYER__VARS__itme6,$___LOCAL_PLAYER__VARS__itms6,$___LOCAL_PLAYER__VARS__itmsk6, $___LOCAL_PLAYER__VARS__searchmemory,$___LOCAL_PLAYER__VARS__nskill,$___LOCAL_PLAYER__VARS__nskillpara; $ss=&$___LOCAL_PLAYER__VARS__ss; $db_player_structure=&$___LOCAL_PLAYER__VARS__db_player_structure; $db_player_structure_types=&$___LOCAL_PLAYER__VARS__db_player_structure_types; $gamedata=&$___LOCAL_PLAYER__VARS__gamedata; $cmd=&$___LOCAL_PLAYER__VARS__cmd; $main=&$___LOCAL_PLAYER__VARS__main; $sdata=&$___LOCAL_PLAYER__VARS__sdata; $fog=&$___LOCAL_PLAYER__VARS__fog; $upexp=&$___LOCAL_PLAYER__VARS__upexp; $lvlupexp=&$___LOCAL_PLAYER__VARS__lvlupexp;  $iconImg=&$___LOCAL_PLAYER__VARS__iconImg; $iconImgB=&$___LOCAL_PLAYER__VARS__iconImgB; $iconImgBwidth=&$___LOCAL_PLAYER__VARS__iconImgBwidth; $ardef=&$___LOCAL_PLAYER__VARS__ardef; $hpcolor=&$___LOCAL_PLAYER__VARS__hpcolor; $spcolor=&$___LOCAL_PLAYER__VARS__spcolor; $newhpimg=&$___LOCAL_PLAYER__VARS__newhpimg; $newspimg=&$___LOCAL_PLAYER__VARS__newspimg; $splt=&$___LOCAL_PLAYER__VARS__splt; $hplt=&$___LOCAL_PLAYER__VARS__hplt;  $tpldata=&$___LOCAL_PLAYER__VARS__tpldata; $icon_list=&$___LOCAL_PLAYER__VARS__icon_list; $icon_list_contents_to_frontend=&$___LOCAL_PLAYER__VARS__icon_list_contents_to_frontend; $typeinfo=&$___LOCAL_PLAYER__VARS__typeinfo; $killmsginfo=&$___LOCAL_PLAYER__VARS__killmsginfo; $lwinfo=&$___LOCAL_PLAYER__VARS__lwinfo; $sexinfo=&$___LOCAL_PLAYER__VARS__sexinfo; $equip_list=&$___LOCAL_PLAYER__VARS__equip_list; $battle_equip_list=&$___LOCAL_PLAYER__VARS__battle_equip_list; $pc_icon_range=&$___LOCAL_PLAYER__VARS__pc_icon_range;  $pid=&$___LOCAL_PLAYER__VARS__pid; $type=&$___LOCAL_PLAYER__VARS__type; $name=&$___LOCAL_PLAYER__VARS__name; $pass=&$___LOCAL_PLAYER__VARS__pass; $ip=&$___LOCAL_PLAYER__VARS__ip; $motto=&$___LOCAL_PLAYER__VARS__motto; $killmsg=&$___LOCAL_PLAYER__VARS__killmsg; $lastword=&$___LOCAL_PLAYER__VARS__lastword; $winner_flag=&$___LOCAL_PLAYER__VARS__winner_flag; $player_dead_flag=&$___LOCAL_PLAYER__VARS__player_dead_flag;  $corpse_clear_flag=&$___LOCAL_PLAYER__VARS__corpse_clear_flag; $gd=&$___LOCAL_PLAYER__VARS__gd; $sNo=&$___LOCAL_PLAYER__VARS__sNo; $club=&$___LOCAL_PLAYER__VARS__club; $validtime=&$___LOCAL_PLAYER__VARS__validtime; $endtime=&$___LOCAL_PLAYER__VARS__endtime; $cdsec=&$___LOCAL_PLAYER__VARS__cdsec; $cdmsec=&$___LOCAL_PLAYER__VARS__cdmsec; $cdtime=&$___LOCAL_PLAYER__VARS__cdtime; $action=&$___LOCAL_PLAYER__VARS__action;  $a_actionnum=&$___LOCAL_PLAYER__VARS__a_actionnum; $v_actionnum=&$___LOCAL_PLAYER__VARS__v_actionnum; $hp=&$___LOCAL_PLAYER__VARS__hp; $mhp=&$___LOCAL_PLAYER__VARS__mhp; $sp=&$___LOCAL_PLAYER__VARS__sp; $msp=&$___LOCAL_PLAYER__VARS__msp; $mss=&$___LOCAL_PLAYER__VARS__mss; $att=&$___LOCAL_PLAYER__VARS__att; $def=&$___LOCAL_PLAYER__VARS__def; $pls=&$___LOCAL_PLAYER__VARS__pls;  $lvl=&$___LOCAL_PLAYER__VARS__lvl; $exp=&$___LOCAL_PLAYER__VARS__exp; $money=&$___LOCAL_PLAYER__VARS__money; $rp=&$___LOCAL_PLAYER__VARS__rp; $bid=&$___LOCAL_PLAYER__VARS__bid; $inf=&$___LOCAL_PLAYER__VARS__inf; $rage=&$___LOCAL_PLAYER__VARS__rage; $pose=&$___LOCAL_PLAYER__VARS__pose; $tactic=&$___LOCAL_PLAYER__VARS__tactic; $killnum=&$___LOCAL_PLAYER__VARS__killnum;  $npckillnum=&$___LOCAL_PLAYER__VARS__npckillnum; $state=&$___LOCAL_PLAYER__VARS__state; $skillpoint=&$___LOCAL_PLAYER__VARS__skillpoint; $flare=&$___LOCAL_PLAYER__VARS__flare; $wp=&$___LOCAL_PLAYER__VARS__wp; $wk=&$___LOCAL_PLAYER__VARS__wk; $wg=&$___LOCAL_PLAYER__VARS__wg; $wc=&$___LOCAL_PLAYER__VARS__wc; $wd=&$___LOCAL_PLAYER__VARS__wd; $wf=&$___LOCAL_PLAYER__VARS__wf;  $icon=&$___LOCAL_PLAYER__VARS__icon; $teamID=&$___LOCAL_PLAYER__VARS__teamID; $teamPass=&$___LOCAL_PLAYER__VARS__teamPass; $card=&$___LOCAL_PLAYER__VARS__card; $cardname=&$___LOCAL_PLAYER__VARS__cardname; $wep=&$___LOCAL_PLAYER__VARS__wep; $wepk=&$___LOCAL_PLAYER__VARS__wepk; $wepe=&$___LOCAL_PLAYER__VARS__wepe; $weps=&$___LOCAL_PLAYER__VARS__weps; $wepsk=&$___LOCAL_PLAYER__VARS__wepsk;  $arb=&$___LOCAL_PLAYER__VARS__arb; $arbk=&$___LOCAL_PLAYER__VARS__arbk; $arbe=&$___LOCAL_PLAYER__VARS__arbe; $arbs=&$___LOCAL_PLAYER__VARS__arbs; $arbsk=&$___LOCAL_PLAYER__VARS__arbsk; $arh=&$___LOCAL_PLAYER__VARS__arh; $arhk=&$___LOCAL_PLAYER__VARS__arhk; $arhe=&$___LOCAL_PLAYER__VARS__arhe; $arhs=&$___LOCAL_PLAYER__VARS__arhs; $arhsk=&$___LOCAL_PLAYER__VARS__arhsk;  $ara=&$___LOCAL_PLAYER__VARS__ara; $arak=&$___LOCAL_PLAYER__VARS__arak; $arae=&$___LOCAL_PLAYER__VARS__arae; $aras=&$___LOCAL_PLAYER__VARS__aras; $arask=&$___LOCAL_PLAYER__VARS__arask; $arf=&$___LOCAL_PLAYER__VARS__arf; $arfk=&$___LOCAL_PLAYER__VARS__arfk; $arfe=&$___LOCAL_PLAYER__VARS__arfe; $arfs=&$___LOCAL_PLAYER__VARS__arfs; $arfsk=&$___LOCAL_PLAYER__VARS__arfsk;  $art=&$___LOCAL_PLAYER__VARS__art; $artk=&$___LOCAL_PLAYER__VARS__artk; $arte=&$___LOCAL_PLAYER__VARS__arte; $arts=&$___LOCAL_PLAYER__VARS__arts; $artsk=&$___LOCAL_PLAYER__VARS__artsk; $itm0=&$___LOCAL_PLAYER__VARS__itm0; $itmk0=&$___LOCAL_PLAYER__VARS__itmk0; $itme0=&$___LOCAL_PLAYER__VARS__itme0; $itms0=&$___LOCAL_PLAYER__VARS__itms0; $itmsk0=&$___LOCAL_PLAYER__VARS__itmsk0;  $itm1=&$___LOCAL_PLAYER__VARS__itm1; $itmk1=&$___LOCAL_PLAYER__VARS__itmk1; $itme1=&$___LOCAL_PLAYER__VARS__itme1; $itms1=&$___LOCAL_PLAYER__VARS__itms1; $itmsk1=&$___LOCAL_PLAYER__VARS__itmsk1; $itm2=&$___LOCAL_PLAYER__VARS__itm2; $itmk2=&$___LOCAL_PLAYER__VARS__itmk2; $itme2=&$___LOCAL_PLAYER__VARS__itme2; $itms2=&$___LOCAL_PLAYER__VARS__itms2; $itmsk2=&$___LOCAL_PLAYER__VARS__itmsk2;  $itm3=&$___LOCAL_PLAYER__VARS__itm3; $itmk3=&$___LOCAL_PLAYER__VARS__itmk3; $itme3=&$___LOCAL_PLAYER__VARS__itme3; $itms3=&$___LOCAL_PLAYER__VARS__itms3; $itmsk3=&$___LOCAL_PLAYER__VARS__itmsk3; $itm4=&$___LOCAL_PLAYER__VARS__itm4; $itmk4=&$___LOCAL_PLAYER__VARS__itmk4; $itme4=&$___LOCAL_PLAYER__VARS__itme4; $itms4=&$___LOCAL_PLAYER__VARS__itms4; $itmsk4=&$___LOCAL_PLAYER__VARS__itmsk4;  $itm5=&$___LOCAL_PLAYER__VARS__itm5; $itmk5=&$___LOCAL_PLAYER__VARS__itmk5; $itme5=&$___LOCAL_PLAYER__VARS__itme5; $itms5=&$___LOCAL_PLAYER__VARS__itms5; $itmsk5=&$___LOCAL_PLAYER__VARS__itmsk5; $itm6=&$___LOCAL_PLAYER__VARS__itm6; $itmk6=&$___LOCAL_PLAYER__VARS__itmk6; $itme6=&$___LOCAL_PLAYER__VARS__itme6; $itms6=&$___LOCAL_PLAYER__VARS__itms6; $itmsk6=&$___LOCAL_PLAYER__VARS__itmsk6;  $searchmemory=&$___LOCAL_PLAYER__VARS__searchmemory; $nskill=&$___LOCAL_PLAYER__VARS__nskill; $nskillpara=&$___LOCAL_PLAYER__VARS__nskillpara;   } while (0);
		$ret = Array();
		foreach ($battle_equip_list as $itm)
			foreach (\itemmain\get_itmsk_array($pd[$itm.'sk']) as $key)
				array_push($ret,$key);
				
		$___TMP_MOD_attrbase_FUNC_get_ex_def_array_core_RET =  $ret;
			break; 
		}while(0);
		//======== End of contents from mod attrbase ========

$active = $__VAR_DUMP_MOD_skill89_VARS_active; unset($__VAR_DUMP_MOD_skill89_VARS_active);

		
		$ret = $___TMP_MOD_attrbase_FUNC_get_ex_def_array_core_RET;
		if (\skillbase\skill_query(89, $pd) && \skill89\check_unlocked89 ($pd) && ((int)\skillbase\skill_getvalue(89, 'lvl', $pd) >= 2)) array_push($ret,'^sa1');
		$___TMP_MOD_skill89_FUNC_get_ex_def_array_core_RET =  $ret;
			break; 
		}while(0);
		//======== End of contents from mod skill89 ========

$active = $__VAR_DUMP_MOD_skill96_VARS_active; unset($__VAR_DUMP_MOD_skill96_VARS_active);

		
		$ret = $___TMP_MOD_skill89_FUNC_get_ex_def_array_core_RET;
		if (1 == \bufficons\bufficons_check_buff_state(96, $pd))
		{
			$skill96_type = \skillbase\skill_getvalue(96, 'type', $pd);
			if (!empty($skill96_type))
			{
				if ($skill96_type[0] == '3')
				{
					$skill96_effect = (int)\skillbase\skill_getvalue(96, 'effect', $pd);
					$hu_e = 7 * $skill96_effect - 500;
					array_push($ret,'^hu'.$hu_e);
				}
				if ($skill96_type[1] == '1') array_push($ret,'^sa3');
			}
		}
		$___TMP_MOD_skill96_FUNC_get_ex_def_array_core_RET =  $ret;
			break; 
		}while(0);
		//======== End of contents from mod skill96 ========

$active = $__VAR_DUMP_MOD_skill103_VARS_active; unset($__VAR_DUMP_MOD_skill103_VARS_active);

		
		$ret = $___TMP_MOD_skill96_FUNC_get_ex_def_array_core_RET;
		if (\skillbase\skill_query(103,$pd) && \skill103\check_unlocked103 ($pd))
		{
			$exsk = \skillbase\skill_getvalue(103,'exsk',$pd);
			if (!empty($exsk)) $ret = array_merge($ret,\itemmain\get_itmsk_array($exsk));
		}
		$___TMP_MOD_skill103_FUNC_get_ex_def_array_core_RET =  $ret;
			break; 
		}while(0);
		//======== End of contents from mod skill103 ========

$active = $__VAR_DUMP_MOD_skill93_VARS_active; unset($__VAR_DUMP_MOD_skill93_VARS_active);
		
		$ret = $___TMP_MOD_skill103_FUNC_get_ex_def_array_core_RET;
		if (\skillbase\skill_query(93, $pd) && \skill93\check_unlocked93 ($pd) && ($pd['ss'] <= $pd['mss'] * 0.5)) array_push($ret,'^sa2');
		return $ret;
	
	}
	
}

?>