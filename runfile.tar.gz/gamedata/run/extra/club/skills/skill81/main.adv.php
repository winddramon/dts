<?php

namespace skill81
{
	$skill81rate = 50;
	
	function init() 
	{
		define('MOD_SKILL81_INFO','club;unique;locked;');
		do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;   } while (0);
		$clubskillname[81] = '换装';
	}
	
	function acquire81(&$pa)
	{
		
	}
	
	function lost81(&$pa)
	{
		
	}
	
	function check_unlocked81(&$pa)
	{
		
		return 1;
	}
	
	function check_swapable_items81(&$pa, $swk='W')
	{
		
		$ret = array();
		if(!in_array($swk, array('W','D'))) return $ret;
		
		for($i=1; $i <=6; $i++){
			if($pa['itms'.$i] && strpos($pa['itmk'.$i],$swk)===0) $ret[] = $i;
		}
		return $ret;
	}
	
	
	
	function check_battleswap(&$pa, &$pd, $active, $logflag=0)
	{
		
		$s_arr = check_swapable_items81($pa);
		if(!$s_arr || !$pa['type']) return;
		$r1 = \weapon\get_weapon_range($pa, $active);
		$r2 = \weapon\get_weapon_range($pd, 1-$active);
		if(!$r2) return;
		$flag = 0;
		if($r1 < $r2) $flag = 1;
		
		$del_arr = array();
		$flag = 0;
		foreach($s_arr as $si){
			swapitem81($pa, 'wep', $si);
			$r1 = \weapon\get_weapon_range($pa, $active);
			if(!$active && $r1 < $r2) $del_arr[] = $si;
			swapitem81($pa, 'wep', $si);
		}
		
		$s_arr = array_diff($s_arr, $del_arr);
		
		if(empty($s_arr)) return;
		do { global $___LOCAL_WEAPON__VARS__nowep,$___LOCAL_WEAPON__VARS__nosta,$___LOCAL_WEAPON__VARS__skilltypeinfo,$___LOCAL_WEAPON__VARS__attinfo,$___LOCAL_WEAPON__VARS__attinfo2,$___LOCAL_WEAPON__VARS__skillinfo,$___LOCAL_WEAPON__VARS__wep_equip_list,$___LOCAL_WEAPON__VARS__counter_obbs,$___LOCAL_WEAPON__VARS__rangeinfo,$___LOCAL_WEAPON__VARS__hitrate_obbs, $___LOCAL_WEAPON__VARS__hitrate_max_obbs,$___LOCAL_WEAPON__VARS__hitrate_r,$___LOCAL_WEAPON__VARS__dmg_fluc,$___LOCAL_WEAPON__VARS__skill_dmg,$___LOCAL_WEAPON__VARS__wepimprate,$___LOCAL_WEAPON__VARS__wepdeathstate; $nowep=&$___LOCAL_WEAPON__VARS__nowep; $nosta=&$___LOCAL_WEAPON__VARS__nosta; $skilltypeinfo=&$___LOCAL_WEAPON__VARS__skilltypeinfo; $attinfo=&$___LOCAL_WEAPON__VARS__attinfo; $attinfo2=&$___LOCAL_WEAPON__VARS__attinfo2; $skillinfo=&$___LOCAL_WEAPON__VARS__skillinfo; $wep_equip_list=&$___LOCAL_WEAPON__VARS__wep_equip_list; $counter_obbs=&$___LOCAL_WEAPON__VARS__counter_obbs; $rangeinfo=&$___LOCAL_WEAPON__VARS__rangeinfo; $hitrate_obbs=&$___LOCAL_WEAPON__VARS__hitrate_obbs;  $hitrate_max_obbs=&$___LOCAL_WEAPON__VARS__hitrate_max_obbs; $hitrate_r=&$___LOCAL_WEAPON__VARS__hitrate_r; $dmg_fluc=&$___LOCAL_WEAPON__VARS__dmg_fluc; $skill_dmg=&$___LOCAL_WEAPON__VARS__skill_dmg; $wepimprate=&$___LOCAL_WEAPON__VARS__wepimprate; $wepdeathstate=&$___LOCAL_WEAPON__VARS__wepdeathstate;   } while (0);
		
		$skill_arr = Array('wp' => $pa['wp'], 'wk' => $pa['wk'], 'wg' => $pa['wg'], 'wc' => $pa['wc'], 'wd' => $pa['wd'], 'wf' => $pa['wf']);
		arsort($skill_arr);
		$skill_keys = array_keys($skill_arr);
		$fav0 = $fav1 = '';
		if($skill_arr[$skill_keys[0]] > $skill_arr[$skill_keys[5]]) $fav0 = $skill_keys[0];
		if($skill_arr[$skill_keys[1]] > $skill_arr[$skill_keys[2]]) $fav1 = $skill_keys[1];
		
		$r_arr = array();
		$r_sum = 0;
		
		foreach($s_arr as $si){
			$svar = 100;
			$itm=$pa['itm'.$si];
			$itmk=$pa['itmk'.$si];
			$itme=$pa['itme'.$si];
			$itms=$pa['itms'.$si];
			$itmsk=$pa['itmsk'.$si];
			
			$skind = $skillinfo[substr($itmk,1,1)];
			
			
			if($fav0 == $skind) $svar += 100;
			
			elseif($fav1 == $skind) $svar += 50;
			
			
			foreach(Array('r','n','y') as $val){
				if(\itemmain\check_in_itmsk($val, $itmsk)) $svar += 50;
			}
			
			foreach(Array('N','d','f','k','t','B','b') as $val){
				if(\itemmain\check_in_itmsk($val, $itmsk)) $svar += 15;
			}
			
			$ex_def_array = \attrbase\get_ex_def_array($pa, $pd, $active);
			do { global $___LOCAL_EX_PHY_DEF__VARS__def_kind; $def_kind=&$___LOCAL_EX_PHY_DEF__VARS__def_kind;   } while (0);
			$this_def_kind = $def_kind[substr($itmk,1,1)];
			if(!\attrbase\check_in_itmsk('A', $ex_def_array) && !\attrbase\check_in_itmsk($this_def_kind, $ex_def_array)) $svar += 200;
			
			if($this_def_kind == 'F') $svar += 50;
			
			do { global $___LOCAL_ITEMMAIN__VARS__tmp_itmsk_arr_pool,$___LOCAL_ITEMMAIN__VARS__itemfind_extra_log,$___LOCAL_ITEMMAIN__VARS__item_equip_list,$___LOCAL_ITEMMAIN__VARS__item_hotkey_id_list,$___LOCAL_ITEMMAIN__VARS__itemmain_drophint,$___LOCAL_ITEMMAIN__VARS__item_allow_find_and_use,$___LOCAL_ITEMMAIN__VARS__nosta,$___LOCAL_ITEMMAIN__VARS__nospk,$___LOCAL_ITEMMAIN__VARS__item_obbs,$___LOCAL_ITEMMAIN__VARS__map_noitemdrop_arealist, $___LOCAL_ITEMMAIN__VARS__itemkind_equipable,$___LOCAL_ITEMMAIN__VARS__iteminfo,$___LOCAL_ITEMMAIN__VARS__itemspkinfo,$___LOCAL_ITEMMAIN__VARS__itemspkdesc,$___LOCAL_ITEMMAIN__VARS__itemspkdesc_help,$___LOCAL_ITEMMAIN__VARS__itemspkremark; $tmp_itmsk_arr_pool=&$___LOCAL_ITEMMAIN__VARS__tmp_itmsk_arr_pool; $itemfind_extra_log=&$___LOCAL_ITEMMAIN__VARS__itemfind_extra_log; $item_equip_list=&$___LOCAL_ITEMMAIN__VARS__item_equip_list; $item_hotkey_id_list=&$___LOCAL_ITEMMAIN__VARS__item_hotkey_id_list; $itemmain_drophint=&$___LOCAL_ITEMMAIN__VARS__itemmain_drophint; $item_allow_find_and_use=&$___LOCAL_ITEMMAIN__VARS__item_allow_find_and_use; $nosta=&$___LOCAL_ITEMMAIN__VARS__nosta; $nospk=&$___LOCAL_ITEMMAIN__VARS__nospk; $item_obbs=&$___LOCAL_ITEMMAIN__VARS__item_obbs; $map_noitemdrop_arealist=&$___LOCAL_ITEMMAIN__VARS__map_noitemdrop_arealist;  $itemkind_equipable=&$___LOCAL_ITEMMAIN__VARS__itemkind_equipable; $iteminfo=&$___LOCAL_ITEMMAIN__VARS__iteminfo; $itemspkinfo=&$___LOCAL_ITEMMAIN__VARS__itemspkinfo; $itemspkdesc=&$___LOCAL_ITEMMAIN__VARS__itemspkdesc; $itemspkdesc_help=&$___LOCAL_ITEMMAIN__VARS__itemspkdesc_help; $itemspkremark=&$___LOCAL_ITEMMAIN__VARS__itemspkremark;   } while (0);
			if($itms != $nosta && $itms < 10) $svar -= 1000;
			elseif($itms != $nosta && $itms < 50) $svar -= 200;
			
			
			if($itms == $nosta && (strpos($itmk,'WG')===0 || strpos($itmk,'WJ')===0)) $svar -= 1000;
			if($svar < 0) $svar = 0;
			
			$r_arr[$si] = $svar;
			$r_sum += $svar;
		}
		





		
		if($flag || rand(0,99) < calc_skill81rate($pa, $pd, $active)){
			$dice = rand(0, $r_sum);
			foreach($r_arr as $ri => $rv){
				if($dice < $rv) {
					break;
				}else{
					$dice -= $rv;
				}
			}
			swapitem81($pa, 'wep', $ri, $logflag);
			
			if(strpos($pa['itmk'.$ri] , 'WN') === 0 || !$pa['itms'.$ri])
			{
				$pa['itm'.$ri] = $pa['itmk'.$ri] = $pa['itmsk'.$ri] = '';
				$pa['itme'.$ri] = $pa['itms'.$ri] = 0;
			}
		}
		return;
	}
	
	function calc_skill81rate(&$pa, &$pd, $active){
		
		do { global $___LOCAL_SKILL81__VARS__skill81rate; $skill81rate=&$___LOCAL_SKILL81__VARS__skill81rate;   } while (0);
		return $skill81rate;
	}
	
	
	function swapitem81(&$pa, $ieqp, $in, $logflag=0)
	{
		
		
		if(!$pa || !in_array($ieqp, array('wep','arh','arb','ara','arf','art')) || !in_array($in, range(1,6))) return;
		
		$eqp = &$pa[$ieqp];
		$eqpk = &$pa[$ieqp.'k'];
		$eqpe = &$pa[$ieqp.'e'];
		$eqps = &$pa[$ieqp.'s'];
		$eqpsk = &$pa[$ieqp.'sk'];
		
		$itm=&$pa['itm'.$in];
		$itmk=&$pa['itmk'.$in];
		$itme=&$pa['itme'.$in];
		$itms=&$pa['itms'.$in];
		$itmsk=&$pa['itmsk'.$in];
		
		if (strpos ( $itmk, 'W' ) === 0)
		{
			$noeqp = 'WN';
		}else{
			$noeqp = 'DN';
		}







		
		swap($eqp,$itm);
		swap($eqpk,$itmk);
		swap($eqpe,$itme);
		swap($eqps,$itms);
		swap($eqpsk,$itmsk);
		$pa['wep_kind'] = \weapon\get_attack_method($pa);
		if($logflag) {
			do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
			if (strpos ( $eqpk , $noeqp ) === 0 || !$eqps ) {
				$log .= "{$pa['name']}卸下了<span class=\"yellow b\">$itm</span>。<br>";
			} elseif(strpos ( $itmk , $noeqp ) === 0 || !$itms) {
				$log .= "{$pa['name']}迅速装备了<span class=\"yellow b\">$eqp</span>。<br>";
			} else {
				$log .= "{$pa['name']}迅速将<span class=\"red b\">$itm</span>卸下，装备了<span class=\"yellow b\">$eqp</span>！<br>";
			}
		}
		return;
	}
	
	
	function assault_prepare(&$pa, &$pd, $active)
	{
if(isset($active)) {$__VAR_DUMP_MOD_skill81_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill81_VARS_active = NULL;} 
		//======== Start of contents from mod armor ========
		do{
			$___TMP_MOD_armor_FUNC_assault_prepare_RET = NULL;

		
		if ($active) $pd['armorbreaklog']=''; else $pa['armorbreaklog']='';
if(isset($active)) {$__VAR_DUMP_MOD_armor_VARS_active = $active; } else {$__VAR_DUMP_MOD_armor_VARS_active = NULL;} 
		//======== Start of contents from mod wound ========
		do{
			$___TMP_MOD_wound_FUNC_assault_prepare_RET = NULL;

		
		$pa['original_inf']=$pa['inf'];
		$pd['original_inf']=$pd['inf'];
if(isset($active)) {$__VAR_DUMP_MOD_wound_VARS_active = $active; } else {$__VAR_DUMP_MOD_wound_VARS_active = NULL;} 
		//======== Start of contents from mod battle ========
		do{
			$___TMP_MOD_battle_FUNC_assault_prepare_RET = NULL;

		
		
		if ($active) $pa['user_commanded']=1; else $pa['user_commanded']=0;
		$pd['user_commanded']=0;
		}while(0);
		//======== End of contents from mod battle ========

$active = $__VAR_DUMP_MOD_wound_VARS_active; unset($__VAR_DUMP_MOD_wound_VARS_active);
		$___TMP_MOD_battle_FUNC_assault_prepare_RET;
		}while(0);
		//======== End of contents from mod wound ========

$active = $__VAR_DUMP_MOD_armor_VARS_active; unset($__VAR_DUMP_MOD_armor_VARS_active);
		$___TMP_MOD_wound_FUNC_assault_prepare_RET;
		}while(0);
		//======== End of contents from mod armor ========

$active = $__VAR_DUMP_MOD_skill81_VARS_active; unset($__VAR_DUMP_MOD_skill81_VARS_active);
		
		$___TMP_MOD_armor_FUNC_assault_prepare_RET;
		if (!$active) {
			if(\skillbase\skill_query(81,$pa) && \skill81\check_unlocked81 ($pa)) {
				\skill81\check_battleswap ($pa, $pd, 1-$active);
			}
		}
	
	}
	
	
	function counter_assault_wrapper(&$pa, &$pd, $active)
	{
		
		if ($pa['hp'] > 0 && empty($pa['npc_evolved'])) 
		{
			if(\skillbase\skill_query(81,$pa) && \skill81\check_unlocked81 ($pa)) {
				\skill81\check_battleswap ($pa, $pd, $active, 1);
			}
		}
if(isset($active)) {$__VAR_DUMP_MOD_skill81_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill81_VARS_active = NULL;} 
		//======== Start of contents from mod skill21 ========
		do{
			$___TMP_MOD_skill21_FUNC_counter_assault_wrapper_RET = NULL;

		
		if (isset($pa['npc_evolved']) && $pa['npc_evolved']){ $___TMP_MOD_skill21_FUNC_counter_assault_wrapper_RET = NULL;
			break; }
if(isset($active)) {$__VAR_DUMP_MOD_skill21_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill21_VARS_active = NULL;} 
		//======== Start of contents from mod battle ========
		do{
			$___TMP_MOD_battle_FUNC_counter_assault_wrapper_RET = NULL;

		
		if ($pa['hp']>0 && $pd['hp']>0)
		{
			$pa['is_counter']=1;
			if (\battle\check_can_counter ($pa, $pd,$active)) 
			{
				$pa['counter_assaulted']=1;
				\battle\counter_assault ($pa,$pd,$active);
			}
			else
			{
				$pa['counter_assaulted']=0;
				\battle\cannot_counter ($pa,$pd,$active);
			}
			unset($pa['is_counter'], $pa['out_of_range']);
		}
		}while(0);
		//======== End of contents from mod battle ========

$active = $__VAR_DUMP_MOD_skill21_VARS_active; unset($__VAR_DUMP_MOD_skill21_VARS_active);	
		$___TMP_MOD_battle_FUNC_counter_assault_wrapper_RET;
		}while(0);
		//======== End of contents from mod skill21 ========

$active = $__VAR_DUMP_MOD_skill81_VARS_active; unset($__VAR_DUMP_MOD_skill81_VARS_active);
		$___TMP_MOD_skill21_FUNC_counter_assault_wrapper_RET;
	
	}		
}

?>