<?php

namespace skill42
{
	function init() 
	{
		define('MOD_SKILL42_INFO','club;locked;');
		do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;   } while (0);
		$clubskillname[42] = '恃勇';
	}
	
	function acquire42(&$pa)
	{
		
	}
	
	function lost42(&$pa)
	{
		
		\skillbase\skill_delvalue(42,'u',$pa);
	}
	
	function unlock42(&$pa)
	{
		
		\skillbase\skill_setvalue(42,'u','1',$pa);
	}
	
	function lock42(&$pa)
	{
		
		\skillbase\skill_setvalue(42,'u','0',$pa);
	}
	
	function check_unlocked42(&$pa)
	{
		
		$skill42_u = \skillbase\skill_getvalue(42,'u',$pa);
		if ($skill42_u === '1') return 1;
		elseif ($skill42_u === '0') return 0;
		if (\skillbase\skill_query(43,$pa)) return 0;
		return 1;
	}
	
	
	function get_internal_def(&$pa,&$pd,$active)
	{
		
		if (!\skillbase\skill_query(42,$pd) || !\skill42\check_unlocked42 ($pd)) return \skill445\get_internal_def($pa,$pd,$active);
		return \skill445\get_internal_def($pa,$pd,$active)*1.35;
	
	}
	
	
	function attack_finish(&$pa, &$pd, $active)
	{
		return \skill507\attack_finish($pa,$pd,$active);
	}
	
	
	function player_kill_enemy(&$pa,&$pd,$active)
	{
		return \skill960\player_kill_enemy($pa,$pd,$active);
	}
	
	
	function calculate_active_obbs_multiplier(&$ldata,&$edata)
	{
		return \skill903\calculate_active_obbs_multiplier($ldata,$edata);
	}
	
	
	function skill42_temp_acquire41(&$pa)
	{
		
		$pa['skill42_flag1']=1;
		if (!\skillbase\skill_query(41,$pa))
		{
			
			\skillbase\skill_acquire(41,$pa);
			$pa['skill42_flag2']=1;
		}
		else
		{
			$stat = \skill41\check_unlocked41($pa);
			if ($stat) 
				$pa['skill42_flag2']=3; 
			else
			{
				\skill41\unlock41($pa);
				$pa['skill42_flag2']=2; 
			}
		}
	}
	
	
	function skill42_restore_skill41(&$pa)
	{
		
		if (!isset($pa['skill42_flag1']) || !$pa['skill42_flag1']) return;
		if ($pa['skill42_flag2']==1)
		{
			\skillbase\skill_lost(41,$pa);
		}
		elseif ($pa['skill42_flag2']==2)
		{
			\skill41\lock41($pa);
		}
	}
	
	function battle_prepare(&$pa, &$pd, $active)
	{
		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
		if (\skillbase\skill_query(42,$pa) && \skill42\check_unlocked42 ($pa))
		{
			
			\skill42\skill42_temp_acquire41 ($pd);
		}
		if (\skillbase\skill_query(42,$pd) && \skill42\check_unlocked42 ($pd))
		{
			
			\skill42\skill42_temp_acquire41 ($pa);
		}
if(isset($active)) {$__VAR_DUMP_MOD_skill42_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill42_VARS_active = NULL;} 
		//======== Start of contents from mod skill703 ========
		do{
			$___TMP_MOD_skill703_FUNC_battle_prepare_RET = NULL;

		
		if ((\skillbase\skill_query(703,$pa) && \skill703\check_unlocked703 ($pa)) || (\skillbase\skill_query(703,$pd) && \skill703\check_unlocked703 ($pd)))
		{
			do { global $___LOCAL_SKILL703__VARS__skill703_flag; $skill703_flag=&$___LOCAL_SKILL703__VARS__skill703_flag;   } while (0);
			$skill703_flag = 1;
		}
if(isset($active)) {$__VAR_DUMP_MOD_skill703_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill703_VARS_active = NULL;} 
		//======== Start of contents from mod skill41 ========
		do{
			$___TMP_MOD_skill41_FUNC_battle_prepare_RET = NULL;

		
		if (\skillbase\skill_query(41,$pd) && \skill41\check_unlocked41 ($pd))
		{
			$pd['skill41_proced']=0;
		}
if(isset($active)) {$__VAR_DUMP_MOD_skill41_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill41_VARS_active = NULL;} 
		//======== Start of contents from mod npcchat ========
		do{
			$___TMP_MOD_npcchat_FUNC_battle_prepare_RET = NULL;

		
		if ($pa['type'] && $pa['state']==1) \npcchat\npcchat ($pa, $pd, $active, 'meet');
if(isset($active)) {$__VAR_DUMP_MOD_npcchat_VARS_active = $active; } else {$__VAR_DUMP_MOD_npcchat_VARS_active = NULL;} 
		//======== Start of contents from mod battle ========
		do{
			$___TMP_MOD_battle_FUNC_battle_prepare_RET = NULL;

		
		
		\battle\send_battle_msg ($pa, $pd, $active);
		
		$pa['bid'] = $pd['pid']; $pd['bid'] = $pa['pid'];
		}while(0);
		//======== End of contents from mod battle ========

$active = $__VAR_DUMP_MOD_npcchat_VARS_active; unset($__VAR_DUMP_MOD_npcchat_VARS_active);
		
		$___TMP_MOD_battle_FUNC_battle_prepare_RET;
		}while(0);
		//======== End of contents from mod npcchat ========

$active = $__VAR_DUMP_MOD_skill41_VARS_active; unset($__VAR_DUMP_MOD_skill41_VARS_active);
		$___TMP_MOD_npcchat_FUNC_battle_prepare_RET;
		}while(0);
		//======== End of contents from mod skill41 ========

$active = $__VAR_DUMP_MOD_skill703_VARS_active; unset($__VAR_DUMP_MOD_skill703_VARS_active);
		$___TMP_MOD_skill41_FUNC_battle_prepare_RET;
		}while(0);
		//======== End of contents from mod skill703 ========

$active = $__VAR_DUMP_MOD_skill42_VARS_active; unset($__VAR_DUMP_MOD_skill42_VARS_active);
		$___TMP_MOD_skill703_FUNC_battle_prepare_RET;
	
	}
	
	function battle_finish(&$pa, &$pd, $active)
	{
		return \skill481\battle_finish($pa,$pd,$active);
	}
}

?>
