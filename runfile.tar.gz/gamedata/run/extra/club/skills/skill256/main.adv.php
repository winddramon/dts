<?php

namespace skill256
{
	function init() 
	{
		define('MOD_SKILL256_INFO','club;feature;');
		do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;   } while (0);
		$clubskillname[256] = '拳法';
		$clubdesc_h[19] = $clubdesc_a[19] = '开局获得50点殴系熟练度<br>空手作战时相当于持有殴系熟练度数值的武器';
	}
	
	function acquire256(&$pa)
	{
		
		$pa['wp']+=50;
	}
	
	function lost256(&$pa)
	{
		
	}
	
	function check_unlocked256(&$pa)
	{
		
		return 1;
	}
	
	function get_external_att(&$pa,&$pd,$active)
	{
		$___TEMP_backtrace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 2); 
		array_shift($___TEMP_backtrace);
		if (count($___TEMP_backtrace)==0) $___TEMP_PARENT_NAME=''; else $___TEMP_PARENT_NAME=strtolower($___TEMP_backtrace[0]['function']);
		if ($___TEMP_PARENT_NAME!='wep_g\get_external_att') 
		{
			return \skill507\get_external_att($pa,$pd,$active);
		}
		unset($___TEMP_PARENT_NAME); unset($___TEMP_backtrace); 
	
		
		
		do { global $___LOCAL_WEAPON__VARS__nowep,$___LOCAL_WEAPON__VARS__nosta,$___LOCAL_WEAPON__VARS__skilltypeinfo,$___LOCAL_WEAPON__VARS__attinfo,$___LOCAL_WEAPON__VARS__attinfo2,$___LOCAL_WEAPON__VARS__skillinfo,$___LOCAL_WEAPON__VARS__wep_equip_list,$___LOCAL_WEAPON__VARS__counter_obbs,$___LOCAL_WEAPON__VARS__rangeinfo,$___LOCAL_WEAPON__VARS__hitrate_obbs, $___LOCAL_WEAPON__VARS__hitrate_max_obbs,$___LOCAL_WEAPON__VARS__hitrate_r,$___LOCAL_WEAPON__VARS__dmg_fluc,$___LOCAL_WEAPON__VARS__skill_dmg,$___LOCAL_WEAPON__VARS__wepimprate,$___LOCAL_WEAPON__VARS__wepdeathstate; $nowep=&$___LOCAL_WEAPON__VARS__nowep; $nosta=&$___LOCAL_WEAPON__VARS__nosta; $skilltypeinfo=&$___LOCAL_WEAPON__VARS__skilltypeinfo; $attinfo=&$___LOCAL_WEAPON__VARS__attinfo; $attinfo2=&$___LOCAL_WEAPON__VARS__attinfo2; $skillinfo=&$___LOCAL_WEAPON__VARS__skillinfo; $wep_equip_list=&$___LOCAL_WEAPON__VARS__wep_equip_list; $counter_obbs=&$___LOCAL_WEAPON__VARS__counter_obbs; $rangeinfo=&$___LOCAL_WEAPON__VARS__rangeinfo; $hitrate_obbs=&$___LOCAL_WEAPON__VARS__hitrate_obbs;  $hitrate_max_obbs=&$___LOCAL_WEAPON__VARS__hitrate_max_obbs; $hitrate_r=&$___LOCAL_WEAPON__VARS__hitrate_r; $dmg_fluc=&$___LOCAL_WEAPON__VARS__dmg_fluc; $skill_dmg=&$___LOCAL_WEAPON__VARS__skill_dmg; $wepimprate=&$___LOCAL_WEAPON__VARS__wepimprate; $wepdeathstate=&$___LOCAL_WEAPON__VARS__wepdeathstate;   } while (0);
if(isset($active)) {$__VAR_DUMP_MOD_skill256_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill256_VARS_active = NULL;} 
		//======== Start of contents from mod wep_n ========
		do{
			$___TMP_MOD_wep_n_FUNC_get_external_att_RET = NULL;

		
		
if(isset($active)) {$__VAR_DUMP_MOD_wep_n_VARS_active = $active; } else {$__VAR_DUMP_MOD_wep_n_VARS_active = NULL;} 
		//======== Start of contents from mod weapon ========
		do{
			$___TMP_MOD_weapon_FUNC_get_external_att_RET = NULL;

		
		$___TMP_MOD_weapon_FUNC_get_external_att_RET =  $pa['wepe']*2;
			break; 		
		}while(0);
		//======== End of contents from mod weapon ========

$active = $__VAR_DUMP_MOD_wep_n_VARS_active; unset($__VAR_DUMP_MOD_wep_n_VARS_active);
		$ret = $___TMP_MOD_weapon_FUNC_get_external_att_RET;
		if ($pa['wep_kind']=='N')
			$ret += round($pa[$skillinfo['N']]*2/3);
		$___TMP_MOD_wep_n_FUNC_get_external_att_RET =  $ret;
			break; 
		}while(0);
		//======== End of contents from mod wep_n ========

$active = $__VAR_DUMP_MOD_skill256_VARS_active; unset($__VAR_DUMP_MOD_skill256_VARS_active);
		$ret = $___TMP_MOD_wep_n_FUNC_get_external_att_RET;
		if ($pa['wep_kind']=='N' && \skillbase\skill_query(256,$pa) && \skill256\check_unlocked256 ($pa))
			
			$ret += round($pa[$skillinfo['N']]*4/3);
		return $ret;
	
	}
}

?>