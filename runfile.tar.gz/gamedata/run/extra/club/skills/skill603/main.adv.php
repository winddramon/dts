<?php

namespace skill603
{

	function init() 
	{
		define('MOD_SKILL603_INFO','hidden;debuff;');
		do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;  global $___LOCAL_BUFFICONS__VARS__bufficons_list,$___LOCAL_BUFFICONS__VARS__tmp_totsec,$___LOCAL_BUFFICONS__VARS__tmp_nowsec; $bufficons_list=&$___LOCAL_BUFFICONS__VARS__bufficons_list; $tmp_totsec=&$___LOCAL_BUFFICONS__VARS__tmp_totsec; $tmp_nowsec=&$___LOCAL_BUFFICONS__VARS__tmp_nowsec;   } while (0);
		$clubskillname[603] = '静止';
		$bufficons_list[603] = Array(
			'msec' => 1,
			'hint' => '你的时间被停止了，无法进行任何行动！',
		);
	}
	
	function acquire603(&$pa)
	{
		
	}
	
	function lost603(&$pa)
	{
		return \skill500\lost603($pa);
	}
	
	function check_skill603_state(&$pa = NULL)
	{
		
		return \bufficons\bufficons_check_buff_state(603, $pa);
	}
	
	function set_stun_period603($t, &$pa)	
	{
		
		\bufficons\bufficons_impose_buff(603, $t/1000, 0, $pa, 1, 1);
		$pa['new_stun_flag']=1;
	}

	function check_cooltime_on()
	{
		
		if (1 == \skill603\check_skill603_state ()) return 0;
		//======== Start of contents from mod skill602 ========
		do{
			$___TMP_MOD_skill602_FUNC_check_cooltime_on_RET = NULL;

		
		if (1 == \skill602\check_skill602_state ()){ $___TMP_MOD_skill602_FUNC_check_cooltime_on_RET =  0;
			break; }
		//======== Start of contents from mod cooldown ========
		do{
			$___TMP_MOD_cooldown_FUNC_check_cooltime_on_RET = NULL;

		
		do { global $___LOCAL_COOLDOWN__VARS__coldtimeon,$___LOCAL_COOLDOWN__VARS__showcoldtimer,$___LOCAL_COOLDOWN__VARS__movecoldtime,$___LOCAL_COOLDOWN__VARS__searchcoldtime,$___LOCAL_COOLDOWN__VARS__itemusecoldtime,$___LOCAL_COOLDOWN__VARS__cmdcdtime,$___LOCAL_COOLDOWN__VARS__rmcdtime; $coldtimeon=&$___LOCAL_COOLDOWN__VARS__coldtimeon; $showcoldtimer=&$___LOCAL_COOLDOWN__VARS__showcoldtimer; $movecoldtime=&$___LOCAL_COOLDOWN__VARS__movecoldtime; $searchcoldtime=&$___LOCAL_COOLDOWN__VARS__searchcoldtime; $itemusecoldtime=&$___LOCAL_COOLDOWN__VARS__itemusecoldtime; $cmdcdtime=&$___LOCAL_COOLDOWN__VARS__cmdcdtime; $rmcdtime=&$___LOCAL_COOLDOWN__VARS__rmcdtime;   } while (0);
		$___TMP_MOD_cooldown_FUNC_check_cooltime_on_RET =  $coldtimeon;
			break; 
		}while(0);
		//======== End of contents from mod cooldown ========
	
		$___TMP_MOD_skill602_FUNC_check_cooltime_on_RET =  $___TMP_MOD_cooldown_FUNC_check_cooltime_on_RET;
			break; 
		}while(0);
		//======== End of contents from mod skill602 ========
	
		return $___TMP_MOD_skill602_FUNC_check_cooltime_on_RET;
	
	}
	
	function calculate_active_obbs_change(&$ldata,&$edata,$active_r)	
	{
		
		if (1 == \skill603\check_skill603_state ($ldata)) $change_to = 0;
		if (1 == \skill603\check_skill603_state ($edata)) $change_to = 100;
		if(isset($change_to)){
			$ldata['active_words'] .= '→'.$change_to;
			return $change_to;
		}
if(isset($active_r)) {$__VAR_DUMP_MOD_skill603_VARS_active_r = $active_r; } else {$__VAR_DUMP_MOD_skill603_VARS_active_r = NULL;} if(isset($change_to)) {$__VAR_DUMP_MOD_skill603_VARS_change_to = $change_to; unset($change_to); } else {$__VAR_DUMP_MOD_skill603_VARS_change_to = NULL;} 
		//======== Start of contents from mod skill602 ========
		do{
			$___TMP_MOD_skill602_FUNC_calculate_active_obbs_change_RET = NULL;

		
		if (1 == \skill602\check_skill602_state ($ldata)) $change_to = 0;
		if (1 == \skill602\check_skill602_state ($edata)) $change_to = 100;
		if(isset($change_to)){
			$ldata['active_words'] .= '→'.$change_to;
			$___TMP_MOD_skill602_FUNC_calculate_active_obbs_change_RET =  $change_to;
			break; 
		}
if(isset($active_r)) {$__VAR_DUMP_MOD_skill602_VARS_active_r = $active_r; } else {$__VAR_DUMP_MOD_skill602_VARS_active_r = NULL;} 
		//======== Start of contents from mod enemy ========
		do{
			$___TMP_MOD_enemy_FUNC_calculate_active_obbs_change_RET = NULL;

		
		$___TMP_MOD_enemy_FUNC_calculate_active_obbs_change_RET =  $active_r;
			break; 
		}while(0);
		//======== End of contents from mod enemy ========

$active_r = $__VAR_DUMP_MOD_skill602_VARS_active_r; unset($__VAR_DUMP_MOD_skill602_VARS_active_r);
		$___TMP_MOD_skill602_FUNC_calculate_active_obbs_change_RET =  $___TMP_MOD_enemy_FUNC_calculate_active_obbs_change_RET;
			break; 
		}while(0);
		//======== End of contents from mod skill602 ========

$active_r = $__VAR_DUMP_MOD_skill603_VARS_active_r; unset($__VAR_DUMP_MOD_skill603_VARS_active_r);$change_to = $__VAR_DUMP_MOD_skill603_VARS_change_to; 
		return $___TMP_MOD_skill602_FUNC_calculate_active_obbs_change_RET;
	
	}
	
	
	function check_can_counter(&$pa, &$pd, $active)			
	{
		return \skill36\check_can_counter($pa,$pd,$active);
	}
	
	function pre_act()
	{
		return \instance_quit_button\pre_act();
	}
	
}

?>