<?php

namespace skill27
{
	function init() 
	{
		define('MOD_SKILL27_INFO','club;');
		do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;   } while (0);
		$clubskillname[27] = '流火';
	}
	
	function acquire27(&$pa)
	{
		
	}
	
	function lost27(&$pa)
	{
		
	}
	
	function check_unlocked27(&$pa)
	{
		
		return 1;
		
	}
	
	function armor_break(&$pa, &$pd, $active, $whicharmor)
	{
if(isset($active)) {$__VAR_DUMP_MOD_skill27_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill27_VARS_active = NULL;} if(isset($whicharmor)) {$__VAR_DUMP_MOD_skill27_VARS_whicharmor = $whicharmor; } else {$__VAR_DUMP_MOD_skill27_VARS_whicharmor = NULL;} 
		//======== Start of contents from mod skill505 ========
		do{
			$___TMP_MOD_skill505_FUNC_armor_break_RET = NULL;

		
		if(\skillbase\skill_query(505,$pd) && \skill505\check_unlocked505 ($pd)){
			do { global $___LOCAL_SKILL505__VARS__skill505_keyitm,$___LOCAL_SKILL505__VARS__skill505_plslist; $skill505_keyitm=&$___LOCAL_SKILL505__VARS__skill505_keyitm; $skill505_plslist=&$___LOCAL_SKILL505__VARS__skill505_plslist;   } while (0);
			if($pd[$whicharmor] == $skill505_keyitm) {
				$pd['skill505_fatal'] = 1;
			}
		}
if(isset($active)) {$__VAR_DUMP_MOD_skill505_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill505_VARS_active = NULL;} if(isset($whicharmor)) {$__VAR_DUMP_MOD_skill505_VARS_whicharmor = $whicharmor; } else {$__VAR_DUMP_MOD_skill505_VARS_whicharmor = NULL;} 
		//======== Start of contents from mod ex_residue ========
		do{
			$___TMP_MOD_ex_residue_FUNC_armor_break_RET = NULL;

		
		$rtype = (int)\itemmain\check_in_itmsk('^rtype', $pd[$whicharmor.'sk']);
		if (5 == $rtype)
		{
			$resitem = \ex_residue\get_res_itm ($pd[$whicharmor.'sk']);
			if (!empty($resitem))
			{
				do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
				if ($active)
				{
					$log .= "<span class=\"yellow b\">{$pd['name']}的{$pd[$whicharmor]}在历尽沧桑之后，显现出了真实的样貌！！</span><br>";
					$pd['armorbreaklog'] .= "你的<span class=\"red b\">{$pd[$whicharmor]}</span>变成了<span class=\"red b\">{$resitem['itm']}</span>！<br>";
				}
				else $log .= "<span class=\"yellow b\">你的{$pd[$whicharmor]}在历尽沧桑之后，显现出了真实的样貌！</span><br>";
				$pd[$whicharmor] = $resitem['itm'];
				$pd[$whicharmor.'k'] = $resitem['itmk'];
				$pd[$whicharmor.'e'] = $resitem['itme'];
				$pd[$whicharmor.'s'] = $resitem['itms'];
				$pd[$whicharmor.'sk'] = $resitem['itmsk'];
			}
			else \armor\armor_break($pa,$pd,$active,$whicharmor);
		}
		else \armor\armor_break($pa,$pd,$active,$whicharmor);
		}while(0);
		//======== End of contents from mod ex_residue ========

$active = $__VAR_DUMP_MOD_skill505_VARS_active; unset($__VAR_DUMP_MOD_skill505_VARS_active);$whicharmor = $__VAR_DUMP_MOD_skill505_VARS_whicharmor; unset($__VAR_DUMP_MOD_skill505_VARS_whicharmor);
		$___TMP_MOD_ex_residue_FUNC_armor_break_RET;
		if(!empty($pd['skill505_fatal']) && \skill505\skill505_check_keyitm_exists ($pd)){
			$pd['skill505_fatal'] = 0;
		}
		}while(0);
		//======== End of contents from mod skill505 ========

$active = $__VAR_DUMP_MOD_skill27_VARS_active; unset($__VAR_DUMP_MOD_skill27_VARS_active);$whicharmor = $__VAR_DUMP_MOD_skill27_VARS_whicharmor; unset($__VAR_DUMP_MOD_skill27_VARS_whicharmor);
		
		
		$___TMP_MOD_skill505_FUNC_armor_break_RET;
		
		if (\skillbase\skill_query(27,$pa) && \skill27\check_unlocked27 ($pa))
		{
			do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;  global $___LOCAL_WOUND__VARS__inf_place,$___LOCAL_WOUND__VARS__infinfo,$___LOCAL_WOUND__VARS__infname,$___LOCAL_WOUND__VARS__infskillinfo,$___LOCAL_WOUND__VARS__wep_infatt,$___LOCAL_WOUND__VARS__wep_infobbs,$___LOCAL_WOUND__VARS__inf_recover_sp_cost; $inf_place=&$___LOCAL_WOUND__VARS__inf_place; $infinfo=&$___LOCAL_WOUND__VARS__infinfo; $infname=&$___LOCAL_WOUND__VARS__infname; $infskillinfo=&$___LOCAL_WOUND__VARS__infskillinfo; $wep_infatt=&$___LOCAL_WOUND__VARS__wep_infatt; $wep_infobbs=&$___LOCAL_WOUND__VARS__wep_infobbs; $inf_recover_sp_cost=&$___LOCAL_WOUND__VARS__inf_recover_sp_cost;   } while (0);
			if (!\skillbase\skill_query(6,$pd))
			{
				if ($active)
					$log .= '流火技能'.$infname['u'].'了敌人！';
				else  $log .= '你被敌人的流火技能'.$infname['u'].'了！';
				\wound\get_inf('u',$pd);
			}
		}
	
	}
		
	function strike_finish(&$pa, &$pd, $active)
	{
		
		if (\skillbase\skill_query(27,$pa) && \skill27\check_unlocked27 ($pa) && $pa['is_hit'])
		{
			do {  __MODULE_NULLFUNCTION__(); global $___LOCAL_ARMOR__VARS__nosta,$___LOCAL_ARMOR__VARS__noarb,$___LOCAL_ARMOR__VARS__armor_equip_list,$___LOCAL_ARMOR__VARS__armor_iteminfo; $nosta=&$___LOCAL_ARMOR__VARS__nosta; $noarb=&$___LOCAL_ARMOR__VARS__noarb; $armor_equip_list=&$___LOCAL_ARMOR__VARS__armor_equip_list; $armor_iteminfo=&$___LOCAL_ARMOR__VARS__armor_iteminfo;  global $___LOCAL_WOUND__VARS__inf_place,$___LOCAL_WOUND__VARS__infinfo,$___LOCAL_WOUND__VARS__infname,$___LOCAL_WOUND__VARS__infskillinfo,$___LOCAL_WOUND__VARS__wep_infatt,$___LOCAL_WOUND__VARS__wep_infobbs,$___LOCAL_WOUND__VARS__inf_recover_sp_cost; $inf_place=&$___LOCAL_WOUND__VARS__inf_place; $infinfo=&$___LOCAL_WOUND__VARS__infinfo; $infname=&$___LOCAL_WOUND__VARS__infname; $infskillinfo=&$___LOCAL_WOUND__VARS__infskillinfo; $wep_infatt=&$___LOCAL_WOUND__VARS__wep_infatt; $wep_infobbs=&$___LOCAL_WOUND__VARS__wep_infobbs; $inf_recover_sp_cost=&$___LOCAL_WOUND__VARS__inf_recover_sp_cost;  global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
			if ($pa['bskill']==26)	
			{
				$target = $armor_equip_list;
				if (2==\skillbase\skill_getvalue(26,'lvl',$pa))
					$damage = 3;
				else  $damage = 2; 
			}
			else  
			{
				$target = Array($armor_equip_list[rand(0,count($armor_equip_list)-1)]);
				$damage = 0;
				if (\attrbase\check_in_itmsk('u',\attrbase\get_ex_attack_array($pa, $pd, $active))) $damage+=1;
				if (\attrbase\check_in_itmsk('f',\attrbase\get_ex_attack_array($pa, $pd, $active))) $damage+=2;
			}
			
			if ($damage > 0)
			{
				foreach ($target as $key)
				{
					if (in_array($key,$armor_equip_list) && isset($pd[$key.'e']) && $pd[$key.'e']>0)
					{
						
						$pa['attack_wounded_'.substr($key,2)]+=$damage;
					}
					else
					{
						if (!\skillbase\skill_query(6,$pd))
						{
							if ($active)
								$log .= '流火技能'.$infname['u'].'了敌人！';
							else  $log .= '你被敌人的流火技能'.$infname['u'].'了！';
							\wound\get_inf('u',$pd);
						}
					}
				}
			}
		}
if(isset($active)) {$__VAR_DUMP_MOD_skill27_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill27_VARS_active = NULL;} 
		//======== Start of contents from mod skill26 ========
		do{
			$___TMP_MOD_skill26_FUNC_strike_finish_RET = NULL;

		
		if ($pa['bskill']!=26) {
			\skill722\strike_finish($pa, $pd, $active);
			$___TMP_MOD_skill26_FUNC_strike_finish_RET = NULL;
			break; 
		}
		if ($pa['is_hit'])
		{
			
			$pa['skill26_flag3']=2;
			$attack_type =  \skill26\get_skill26_type ($pa, $pd, $active);
			\ex_dmg_att\check_ex_inf_infliction($pa, $pd, $active, $attack_type);
		}
		unset($pa['skill26_flag1']);
		unset($pa['skill26_flag2']);
		unset($pa['skill26_flag3']);
		unset($pa['skill26_flag4']);
		\skill722\strike_finish($pa, $pd, $active);
		}while(0);
		//======== End of contents from mod skill26 ========

$active = $__VAR_DUMP_MOD_skill27_VARS_active; unset($__VAR_DUMP_MOD_skill27_VARS_active);
		$___TMP_MOD_skill26_FUNC_strike_finish_RET;
	
	}
}

?>
