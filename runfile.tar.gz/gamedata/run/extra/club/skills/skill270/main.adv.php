<?php

namespace skill270
{
	$skill270active = 9;
	$skill270hitrate = 9;
	
	function init() 
	{
		define('MOD_SKILL270_INFO','club;');
		do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;   } while (0);
		$clubskillname[270] = '神影';
	}
	
	function acquire270(&$pa)
	{
		
	}
	
	function lost270(&$pa)
	{
		
	}
	
	function check_unlocked270(&$pa)
	{
		
		return $pa['lvl']>=9;
	}
	
	
	
	function check_skill270_proc(&$pa, &$pd, $active)
	{
		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
		
		foreach(array('pa', 'pd') as $p){
			if(empty($$p['wep_kind'])){
				$$p['wep_kind']=\weapon\get_attack_method($$p);
				$$p['wep_kind_setting'] = 1;
			}
		}

		$o_log = $log;
		$s1 = \weapon\get_skill($pa, $pd, $active);
		$s2 = \weapon\get_skill($pd, $pa, 1-$active);
		$log = $o_log;
		
		
		foreach(array('pa', 'pd') as $p){
			if(isset($$p['wep_kind_setting'])){
				unset($$p['wep_kind'],$$p['wep_kind_setting']);
			}
		}
		
		if ($s1 > $s2) return 1;
		else  return 0;
	}
	
	function get_hitrate_multiplier(&$pa, &$pd, $active)
	{
		return \skill265\get_hitrate_multiplier($pa,$pd,$active);
	}
	
	function calculate_active_obbs_multiplier(&$ldata,&$edata)
	{
		return \skill903\calculate_active_obbs_multiplier($ldata,$edata);
	}
	











	
}

?>