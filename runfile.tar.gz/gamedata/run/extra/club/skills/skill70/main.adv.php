<?php

namespace skill70
{
	function init() 
	{
		define('MOD_SKILL70_INFO','club;feature;');
		do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;   } while (0);
		$clubskillname[70] = '天赋';
		$clubdesc_h[18] = $clubdesc_a[18] = '开局获得5点全系熟练和5点技能点<br>升到偶数级时额外获得1点技能点<br>计算武器熟练度时会额外加上其他各系熟练度的25%';
	}
	
	function acquire70(&$pa)
	{
		
		$pa['skillpoint']+=5;
		do { global $___LOCAL_WEAPON__VARS__nowep,$___LOCAL_WEAPON__VARS__nosta,$___LOCAL_WEAPON__VARS__skilltypeinfo,$___LOCAL_WEAPON__VARS__attinfo,$___LOCAL_WEAPON__VARS__attinfo2,$___LOCAL_WEAPON__VARS__skillinfo,$___LOCAL_WEAPON__VARS__wep_equip_list,$___LOCAL_WEAPON__VARS__counter_obbs,$___LOCAL_WEAPON__VARS__rangeinfo,$___LOCAL_WEAPON__VARS__hitrate_obbs, $___LOCAL_WEAPON__VARS__hitrate_max_obbs,$___LOCAL_WEAPON__VARS__hitrate_r,$___LOCAL_WEAPON__VARS__dmg_fluc,$___LOCAL_WEAPON__VARS__skill_dmg,$___LOCAL_WEAPON__VARS__wepimprate,$___LOCAL_WEAPON__VARS__wepdeathstate; $nowep=&$___LOCAL_WEAPON__VARS__nowep; $nosta=&$___LOCAL_WEAPON__VARS__nosta; $skilltypeinfo=&$___LOCAL_WEAPON__VARS__skilltypeinfo; $attinfo=&$___LOCAL_WEAPON__VARS__attinfo; $attinfo2=&$___LOCAL_WEAPON__VARS__attinfo2; $skillinfo=&$___LOCAL_WEAPON__VARS__skillinfo; $wep_equip_list=&$___LOCAL_WEAPON__VARS__wep_equip_list; $counter_obbs=&$___LOCAL_WEAPON__VARS__counter_obbs; $rangeinfo=&$___LOCAL_WEAPON__VARS__rangeinfo; $hitrate_obbs=&$___LOCAL_WEAPON__VARS__hitrate_obbs;  $hitrate_max_obbs=&$___LOCAL_WEAPON__VARS__hitrate_max_obbs; $hitrate_r=&$___LOCAL_WEAPON__VARS__hitrate_r; $dmg_fluc=&$___LOCAL_WEAPON__VARS__dmg_fluc; $skill_dmg=&$___LOCAL_WEAPON__VARS__skill_dmg; $wepimprate=&$___LOCAL_WEAPON__VARS__wepimprate; $wepdeathstate=&$___LOCAL_WEAPON__VARS__wepdeathstate;   } while (0);
		foreach (array_unique(array_values($skillinfo)) as $key)
			$pa[$key]+=5;
	}
	
	function lost70(&$pa)
	{
		
	}
	
	function check_unlocked70(&$pa)
	{
		
		return 1;
	}
	
	function lvlup(&$pa)
	{
		return \skill87\lvlup($pa);
	}
	
	function get_factor70(&$pa)
	{
		return \skill77\get_factor70($pa);
	}
	
	function get_wskillup70(&$pa,$wep_skillkind)
	{
		
		do { global $___LOCAL_WEAPON__VARS__nowep,$___LOCAL_WEAPON__VARS__nosta,$___LOCAL_WEAPON__VARS__skilltypeinfo,$___LOCAL_WEAPON__VARS__attinfo,$___LOCAL_WEAPON__VARS__attinfo2,$___LOCAL_WEAPON__VARS__skillinfo,$___LOCAL_WEAPON__VARS__wep_equip_list,$___LOCAL_WEAPON__VARS__counter_obbs,$___LOCAL_WEAPON__VARS__rangeinfo,$___LOCAL_WEAPON__VARS__hitrate_obbs, $___LOCAL_WEAPON__VARS__hitrate_max_obbs,$___LOCAL_WEAPON__VARS__hitrate_r,$___LOCAL_WEAPON__VARS__dmg_fluc,$___LOCAL_WEAPON__VARS__skill_dmg,$___LOCAL_WEAPON__VARS__wepimprate,$___LOCAL_WEAPON__VARS__wepdeathstate; $nowep=&$___LOCAL_WEAPON__VARS__nowep; $nosta=&$___LOCAL_WEAPON__VARS__nosta; $skilltypeinfo=&$___LOCAL_WEAPON__VARS__skilltypeinfo; $attinfo=&$___LOCAL_WEAPON__VARS__attinfo; $attinfo2=&$___LOCAL_WEAPON__VARS__attinfo2; $skillinfo=&$___LOCAL_WEAPON__VARS__skillinfo; $wep_equip_list=&$___LOCAL_WEAPON__VARS__wep_equip_list; $counter_obbs=&$___LOCAL_WEAPON__VARS__counter_obbs; $rangeinfo=&$___LOCAL_WEAPON__VARS__rangeinfo; $hitrate_obbs=&$___LOCAL_WEAPON__VARS__hitrate_obbs;  $hitrate_max_obbs=&$___LOCAL_WEAPON__VARS__hitrate_max_obbs; $hitrate_r=&$___LOCAL_WEAPON__VARS__hitrate_r; $dmg_fluc=&$___LOCAL_WEAPON__VARS__dmg_fluc; $skill_dmg=&$___LOCAL_WEAPON__VARS__skill_dmg; $wepimprate=&$___LOCAL_WEAPON__VARS__wepimprate; $wepdeathstate=&$___LOCAL_WEAPON__VARS__wepdeathstate;   } while (0);
		$ret = 0;
		$r70=get_factor70($pa);
		
		foreach (array_unique(array_values($skillinfo)) as $key)
			if ($key!=$wep_skillkind)
				$ret+=$r70*$pa[$key];
		$ret=round($ret);
		return $ret;
	}
	
	function get_skill_by_kind(&$pa, &$pd, $active, $wep_skillkind)
	{
if(isset($active)) {$__VAR_DUMP_MOD_skill70_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill70_VARS_active = NULL;} if(isset($wep_skillkind)) {$__VAR_DUMP_MOD_skill70_VARS_wep_skillkind = $wep_skillkind; } else {$__VAR_DUMP_MOD_skill70_VARS_wep_skillkind = NULL;} 
		//======== Start of contents from mod dualwep ========
		do{
			$___TMP_MOD_dualwep_FUNC_get_skill_by_kind_RET = NULL;

		
		do { global $___LOCAL_WEAPON__VARS__nowep,$___LOCAL_WEAPON__VARS__nosta,$___LOCAL_WEAPON__VARS__skilltypeinfo,$___LOCAL_WEAPON__VARS__attinfo,$___LOCAL_WEAPON__VARS__attinfo2,$___LOCAL_WEAPON__VARS__skillinfo,$___LOCAL_WEAPON__VARS__wep_equip_list,$___LOCAL_WEAPON__VARS__counter_obbs,$___LOCAL_WEAPON__VARS__rangeinfo,$___LOCAL_WEAPON__VARS__hitrate_obbs, $___LOCAL_WEAPON__VARS__hitrate_max_obbs,$___LOCAL_WEAPON__VARS__hitrate_r,$___LOCAL_WEAPON__VARS__dmg_fluc,$___LOCAL_WEAPON__VARS__skill_dmg,$___LOCAL_WEAPON__VARS__wepimprate,$___LOCAL_WEAPON__VARS__wepdeathstate; $nowep=&$___LOCAL_WEAPON__VARS__nowep; $nosta=&$___LOCAL_WEAPON__VARS__nosta; $skilltypeinfo=&$___LOCAL_WEAPON__VARS__skilltypeinfo; $attinfo=&$___LOCAL_WEAPON__VARS__attinfo; $attinfo2=&$___LOCAL_WEAPON__VARS__attinfo2; $skillinfo=&$___LOCAL_WEAPON__VARS__skillinfo; $wep_equip_list=&$___LOCAL_WEAPON__VARS__wep_equip_list; $counter_obbs=&$___LOCAL_WEAPON__VARS__counter_obbs; $rangeinfo=&$___LOCAL_WEAPON__VARS__rangeinfo; $hitrate_obbs=&$___LOCAL_WEAPON__VARS__hitrate_obbs;  $hitrate_max_obbs=&$___LOCAL_WEAPON__VARS__hitrate_max_obbs; $hitrate_r=&$___LOCAL_WEAPON__VARS__hitrate_r; $dmg_fluc=&$___LOCAL_WEAPON__VARS__dmg_fluc; $skill_dmg=&$___LOCAL_WEAPON__VARS__skill_dmg; $wepimprate=&$___LOCAL_WEAPON__VARS__wepimprate; $wepdeathstate=&$___LOCAL_WEAPON__VARS__wepdeathstate;   } while (0);
		$ret = \weapon\get_skill_by_kind($pa,$pd,$active,$wep_skillkind);
		$w2 = \dualwep\get_sec_attack_method ($pa);
		if($w2){
			$wo = \dualwep\get_other_attack_method ($pa, $pa['wep_kind']);
			$reto = \weapon\get_skill_by_kind($pa,$pd,$active,$skillinfo[$wo]);
			if($ret < $reto / 2) $ret = round($reto / 2);
		}
		
		$___TMP_MOD_dualwep_FUNC_get_skill_by_kind_RET =  $ret;
			break; 
		}while(0);
		//======== End of contents from mod dualwep ========

$active = $__VAR_DUMP_MOD_skill70_VARS_active; unset($__VAR_DUMP_MOD_skill70_VARS_active);$wep_skillkind = $__VAR_DUMP_MOD_skill70_VARS_wep_skillkind; unset($__VAR_DUMP_MOD_skill70_VARS_wep_skillkind);
		
		$ret = $___TMP_MOD_dualwep_FUNC_get_skill_by_kind_RET;
		if (\skillbase\skill_query(70,$pa)){
			$ret += \skill70\get_wskillup70 ($pa,$wep_skillkind);
		}
		return $ret;
	
	}
	
}

?>