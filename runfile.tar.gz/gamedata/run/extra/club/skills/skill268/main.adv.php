<?php

namespace skill268
{
	function init() 
	{
		define('MOD_SKILL268_INFO','club;limited;');
		do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;   } while (0);
		$clubskillname[268] = '不屈';
	}
	
	function acquire268(&$pa)
	{
		
		
		\skillbase\skill_setvalue(268,'rmt',2,$pa);
	}

	function lost268(&$pa)
	{
		
		\skillbase\skill_delvalue(268,'rmt',$pa);
	}
	
	function check_unlocked268(&$pa)
	{
		
		return $pa['lvl']>=15;
	}
	
	function apply_total_damage_modifier_insurance(&$pa,&$pd,$active)
	{
		return \skill471\apply_total_damage_modifier_insurance($pa,$pd,$active);
	}
	
	
	function player_damaged_enemy(&$pa, &$pd, $active)
	{
		return \skill379\player_damaged_enemy($pa,$pd,$active);
	}
	
	function parse_news($nid, $news, $hour, $min, $sec, $a, $b, $c, $d, $e, $exarr = array())
	{
		return \skill489\parse_news($nid,$news,$hour,$min,$sec,$a,$b,$c,$d,$e,$exarr);
	}
}

?>