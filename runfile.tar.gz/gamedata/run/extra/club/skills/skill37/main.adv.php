<?php

namespace skill37
{
	function init() 
	{
		define('MOD_SKILL37_INFO','club;');
		do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;   } while (0);
		$clubskillname[37] = '灭气';
	}
	
	function acquire37(&$pa)
	{
		
	}
	
	function lost37(&$pa)
	{
		
	}
	
	function check_unlocked37(&$pa)
	{
		
		return $pa['lvl']>=6;
	}
	
	
	function calculate_attack_rage_gain_base(&$pa, &$pd, $active, $fixed_val=0)
	{
		return \skill410\calculate_attack_rage_gain_base($pa,$pd,$active,$fixed_val);
	}
	
	
	function attack_finish(&$pa, &$pd, $active)
	{
		return \skill507\attack_finish($pa,$pd,$active);
	}
}

?>
