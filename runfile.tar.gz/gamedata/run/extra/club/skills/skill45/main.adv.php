<?php

namespace skill45
{
	
	$ragecost = 20; 
	
	function init() 
	{
		define('MOD_SKILL45_INFO','club;battle;');
		do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;   } while (0);
		$clubskillname[45] = '重拳';
	}
	
	function acquire45(&$pa)
	{
		
	}
	
	function lost45(&$pa)
	{
		
	}
	
	function check_unlocked45(&$pa)
	{
		
		return $pa['lvl']>=3;
	}
	
	function get_rage_cost45(&$pa = NULL)
	{
		
		do { global $___LOCAL_SKILL45__VARS__ragecost; $ragecost=&$___LOCAL_SKILL45__VARS__ragecost;   } while (0);
		return $ragecost;
	}
	
	function strike_prepare(&$pa, &$pd, $active)
	{
		$___TEMP_backtrace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 2); 
		array_shift($___TEMP_backtrace);
		if (count($___TEMP_backtrace)==0) $___TEMP_PARENT_NAME=''; else $___TEMP_PARENT_NAME=strtolower($___TEMP_backtrace[0]['function']);
		if ($___TEMP_PARENT_NAME!='skill46\strike_prepare') 
		{
			return \skill507\strike_prepare($pa,$pd,$active);
		}
		unset($___TEMP_PARENT_NAME); unset($___TEMP_backtrace); 
	
		
		
		if ($pa['bskill']!=45) {
			\skill433\strike_prepare($pa, $pd, $active);
			return;
		}
		if (!\skillbase\skill_query(45,$pa) || !\skill45\check_unlocked45 ($pa))
		{
			do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
			$log .= '你尚未解锁这个技能！';
			$pa['bskill']=0;
		}
		else
		{
			$rcost = \skill45\get_rage_cost45 ($pa);
			if (!\clubbase\check_battle_skill_unactivatable($pa,$pd,45))
			{
				do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
				if ($active)
					$log.="<span class=\"lime b\">你对{$pd['name']}发动了技能「重拳」！</span><br>";
				else  $log.="<span class=\"lime b\">{$pa['name']}对你发动了技能「重拳」！</span><br>";
				$pa['rage']-=$rcost;
				addnews ( 0, 'bskill45', $pa['name'], $pd['name'] );
			}
			else
			{
				if ($active)
				{
					do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
					$log.='怒气不足或其他原因不能发动。<br>';
				}
				$pa['bskill']=0;
			}
		}
		\skill433\strike_prepare($pa, $pd, $active);
	
	}	
	
	function get_physical_dmg_multiplier(&$pa, &$pd, $active)
	{
		return \skill265\get_physical_dmg_multiplier($pa,$pd,$active);
	}
	
	function parse_news($nid, $news, $hour, $min, $sec, $a, $b, $c, $d, $e, $exarr = array())
	{
		return \skill489\parse_news($nid,$news,$hour,$min,$sec,$a,$b,$c,$d,$e,$exarr);
	}
	
}

?>
