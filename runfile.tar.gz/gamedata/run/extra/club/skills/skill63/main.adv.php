<?php

namespace skill63
{
	function init() 
	{
		define('MOD_SKILL63_INFO','club;battle;limited;');
		do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;   } while (0);
		$clubskillname[63] = '噩梦';
	}
	
	function acquire63(&$pa)
	{
		
		
		\skillbase\skill_setvalue(63,'t','1',$pa);
		
		\skillbase\skill_setvalue(63,'p','0',$pa);
		
		\skillbase\skill_setvalue(63,'n','0',$pa);
	}
	
	function lost63(&$pa)
	{
		
		\skillbase\skill_delvalue(63,'t',$pa);
	}
	
	function check_unlocked63(&$pa)
	{
		
		return $pa['lvl']>=21;
	}
	
	function get_remaintime63(&$pa = NULL)
	{
		
		return \skillbase\skill_getvalue(63,'t',$pa);
	}
	
	function strike_prepare(&$pa, &$pd, $active)
	{
		$___TEMP_backtrace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 2); 
		array_shift($___TEMP_backtrace);
		if (count($___TEMP_backtrace)==0) $___TEMP_PARENT_NAME=''; else $___TEMP_PARENT_NAME=strtolower($___TEMP_backtrace[0]['function']);
		if ($___TEMP_PARENT_NAME!='skill74\strike_prepare') 
		{
			return \skill507\strike_prepare($pa,$pd,$active);
		}
		unset($___TEMP_PARENT_NAME); unset($___TEMP_backtrace); 
	
		
		
		if ($pa['bskill']!=63) {
			\skill60\strike_prepare($pa, $pd, $active);
			return;
		}
		if (!\skillbase\skill_query(63,$pa) || !\skill63\check_unlocked63 ($pa))
		{
			do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
			$log .= '你尚未解锁这个技能！';
			$pa['bskill']=0;
		}
		else
		{
			$clv = (int)\skill63\get_remaintime63 ($pa);
			if ( !\clubbase\check_battle_skill_unactivatable($pa,$pd,63) )
			{
				do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
				if ($active)
					$log.="<span class=\"lime b\">你对{$pd['name']}发动了技能「噩梦」！</span><br>";
				else  $log.="<span class=\"lime b\">{$pa['name']}对你发动了技能「噩梦」！</span><br>";
				$clv--; \skillbase\skill_setvalue(63,'t',$clv,$pa);
				\skillbase\skill_setvalue(63,'p',$pd['pid'],$pa);
				\skillbase\skill_setvalue(63,'n',$pd['name'],$pa);
				addnews ( 0, 'bskill63', $pa['name'], $pd['name'] );
			}
			else
			{
				if ($active)
				{
					do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
					$log.='怒气不足或其他原因不能发动。<br>';
				}
				$pa['bskill']=0;
			}
		}
		\skill60\strike_prepare($pa, $pd, $active);
	
	}	
	
	function get_final_dmg_multiplier(&$pa, &$pd, $active)
	{
		return \skill507\get_final_dmg_multiplier($pa,$pd,$active);
	}
	
	function parse_news($nid, $news, $hour, $min, $sec, $a, $b, $c, $d, $e, $exarr = array())
	{
		return \skill489\parse_news($nid,$news,$hour,$min,$sec,$a,$b,$c,$d,$e,$exarr);
	}
	
}

?>
