<?php

namespace skill66
{
	function init() 
	{
		define('MOD_SKILL66_INFO','club;');
		do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;   } while (0);
		$clubskillname[66] = '人杰';
	}
	
	function acquire66(&$pa)
	{
		
	}
	
	function lost66(&$pa)
	{
		
	}
	
	function check_unlocked66(&$pa)
	{
		
		return $pa['lvl']>=19;
	}
	
	function get_skill(&$pa,&$pd,$active)
	{
		$___TEMP_backtrace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 2); 
		array_shift($___TEMP_backtrace);
		if (count($___TEMP_backtrace)==0) $___TEMP_PARENT_NAME=''; else $___TEMP_PARENT_NAME=strtolower($___TEMP_backtrace[0]['function']);
		if ($___TEMP_PARENT_NAME!='skill239\get_skill') 
		{
			return \skill239\get_skill($pa,$pd,$active);
		}
		unset($___TEMP_PARENT_NAME); unset($___TEMP_backtrace); 
	
		
		
		if (!\skillbase\skill_query(66,$pa) || !\skill66\check_unlocked66 ($pa)){
if(isset($active)) {$__VAR_DUMP_MOD_skill66_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill66_VARS_active = NULL;} 
		//======== Start of contents from mod skill253 ========
		do{
			$___TMP_MOD_skill253_FUNC_get_skill_RET = NULL;

		
		if (empty($pa['bskill']) || $pa['bskill']!=253){ $___TMP_MOD_skill253_FUNC_get_skill_RET =  \weapon\get_skill($pa,$pd,$active);
			break; }
		$r = min(220,round($pa['lvl']*($pa['rage']+\skill253\get_rage_cost253 ())/6));
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
		if ($active)
			$log.='<span class="yellow b">「天威」使你的熟练度暂时增加了'.$r.'点！</span><br>';
		else  $log.='<span class="yellow b">「天威」使敌人的熟练度暂时增加了'.$r.'点！</span><br>';
		$___TMP_MOD_skill253_FUNC_get_skill_RET =  \weapon\get_skill($pa,$pd,$active)+$r;
			break; 
		}while(0);
		//======== End of contents from mod skill253 ========

$active = $__VAR_DUMP_MOD_skill66_VARS_active; unset($__VAR_DUMP_MOD_skill66_VARS_active); return $___TMP_MOD_skill253_FUNC_get_skill_RET;}
		do { global $___LOCAL_WEAPON__VARS__nowep,$___LOCAL_WEAPON__VARS__nosta,$___LOCAL_WEAPON__VARS__skilltypeinfo,$___LOCAL_WEAPON__VARS__attinfo,$___LOCAL_WEAPON__VARS__attinfo2,$___LOCAL_WEAPON__VARS__skillinfo,$___LOCAL_WEAPON__VARS__wep_equip_list,$___LOCAL_WEAPON__VARS__counter_obbs,$___LOCAL_WEAPON__VARS__rangeinfo,$___LOCAL_WEAPON__VARS__hitrate_obbs, $___LOCAL_WEAPON__VARS__hitrate_max_obbs,$___LOCAL_WEAPON__VARS__hitrate_r,$___LOCAL_WEAPON__VARS__dmg_fluc,$___LOCAL_WEAPON__VARS__skill_dmg,$___LOCAL_WEAPON__VARS__wepimprate,$___LOCAL_WEAPON__VARS__wepdeathstate; $nowep=&$___LOCAL_WEAPON__VARS__nowep; $nosta=&$___LOCAL_WEAPON__VARS__nosta; $skilltypeinfo=&$___LOCAL_WEAPON__VARS__skilltypeinfo; $attinfo=&$___LOCAL_WEAPON__VARS__attinfo; $attinfo2=&$___LOCAL_WEAPON__VARS__attinfo2; $skillinfo=&$___LOCAL_WEAPON__VARS__skillinfo; $wep_equip_list=&$___LOCAL_WEAPON__VARS__wep_equip_list; $counter_obbs=&$___LOCAL_WEAPON__VARS__counter_obbs; $rangeinfo=&$___LOCAL_WEAPON__VARS__rangeinfo; $hitrate_obbs=&$___LOCAL_WEAPON__VARS__hitrate_obbs;  $hitrate_max_obbs=&$___LOCAL_WEAPON__VARS__hitrate_max_obbs; $hitrate_r=&$___LOCAL_WEAPON__VARS__hitrate_r; $dmg_fluc=&$___LOCAL_WEAPON__VARS__dmg_fluc; $skill_dmg=&$___LOCAL_WEAPON__VARS__skill_dmg; $wepimprate=&$___LOCAL_WEAPON__VARS__wepimprate; $wepdeathstate=&$___LOCAL_WEAPON__VARS__wepdeathstate;   } while (0);
		$max_skill=0;
		foreach (array_unique(array_values($skillinfo)) as $key)
			$max_skill=max($max_skill,\weapon\get_skill_by_kind($pa, $pd, $active, $key));
		return $max_skill;
	
	}
}

?>
