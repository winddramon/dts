<?php

namespace skill80
{
	function init() 
	{
		define('MOD_SKILL80_INFO','club;feature;');
		do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;   } while (0);
		$clubskillname[80] = '脑力';
		
	}
	
	function acquire80(&$pa)
	{
		
	}
	
	function lost80(&$pa)
	{
		
	}
	
	function check_unlocked80(&$pa)
	{
		
		return 1;
	}
	
	
	function calc_memory_recordnum(&$pa=NULL){
		return \skill905\calc_memory_recordnum($pa);
	}
}

?>