<?php

namespace skill272
{
	$skill272_cd = 120;
	$skill272_act_time = 60;
	$skill272_factor = 10;
	$skill272_pos_list = Array('wep','arh','arb','ara','arf','art','itm1','itm2','itm3','itm4','itm5','itm6');
	
	$skill272_itmsk_cube = array(
		'c'=>'黄色方块', 'l'=>'X方块', 'g'=>'Y方块',
		'P'=>'红色方块', 'K'=>'绿色方块', 'G'=>'蓝色方块', 'C'=>'金色方块', 'D'=>'黄色方块', 'F'=>'银色方块',
		'p'=>'绿色方块', 'q'=>'绿色方块', 'u'=>'红色方块', 'U'=>'红色方块', 'i'=>'蓝色方块', 'I'=>'蓝色方块', 'e'=>'金色方块', 'E'=>'金色方块', 'w'=>'银色方块', 'W'=>'银色方块'
	);
	
	function init() 
	{
		define('MOD_SKILL272_INFO','club;locked;buffer;');
		do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;  global $___LOCAL_BUFFICONS__VARS__bufficons_list,$___LOCAL_BUFFICONS__VARS__tmp_totsec,$___LOCAL_BUFFICONS__VARS__tmp_nowsec; $bufficons_list=&$___LOCAL_BUFFICONS__VARS__bufficons_list; $tmp_totsec=&$___LOCAL_BUFFICONS__VARS__tmp_totsec; $tmp_nowsec=&$___LOCAL_BUFFICONS__VARS__tmp_nowsec;   } while (0);
		$clubskillname[272] = '吸光';
		$bufficons_list[272] = Array(
			'disappear' => 0,
			'clickable' => 1,
		);
	}
	
	function acquire272(&$pa)
	{
		
		\skillbase\skill_setvalue(272,'end_ts',1,$pa);
		\skillbase\skill_setvalue(272,'cd_ts',0,$pa);
		\skillbase\skill_setvalue(272,'unlockcount',0,$pa);
		\skillbase\skill_setvalue(272,'lvl',0,$pa);
		\skillbase\skill_setvalue(272,'num',0,$pa);
	}
	
	function lost272(&$pa)
	{
		
		\skillbase\skill_delvalue(272,'unlockcount',$pa);
		\skillbase\skill_delvalue(272,'lvl',$pa);
		\skillbase\skill_delvalue(272,'num',$pa);
	}
	
	function check_unlocked272(&$pa)
	{
		
		return $pa['lvl']>=3;
	}
	
	function skill272_command()
	{
		
		do { global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;  global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;  global $___LOCAL_PLAYER__VARS__ss,$___LOCAL_PLAYER__VARS__db_player_structure,$___LOCAL_PLAYER__VARS__db_player_structure_types,$___LOCAL_PLAYER__VARS__gamedata,$___LOCAL_PLAYER__VARS__cmd,$___LOCAL_PLAYER__VARS__main,$___LOCAL_PLAYER__VARS__sdata,$___LOCAL_PLAYER__VARS__fog,$___LOCAL_PLAYER__VARS__upexp,$___LOCAL_PLAYER__VARS__lvlupexp, $___LOCAL_PLAYER__VARS__iconImg,$___LOCAL_PLAYER__VARS__iconImgB,$___LOCAL_PLAYER__VARS__iconImgBwidth,$___LOCAL_PLAYER__VARS__ardef,$___LOCAL_PLAYER__VARS__hpcolor,$___LOCAL_PLAYER__VARS__spcolor,$___LOCAL_PLAYER__VARS__newhpimg,$___LOCAL_PLAYER__VARS__newspimg,$___LOCAL_PLAYER__VARS__splt,$___LOCAL_PLAYER__VARS__hplt, $___LOCAL_PLAYER__VARS__tpldata,$___LOCAL_PLAYER__VARS__icon_list,$___LOCAL_PLAYER__VARS__icon_list_contents_to_frontend,$___LOCAL_PLAYER__VARS__typeinfo,$___LOCAL_PLAYER__VARS__killmsginfo,$___LOCAL_PLAYER__VARS__lwinfo,$___LOCAL_PLAYER__VARS__sexinfo,$___LOCAL_PLAYER__VARS__equip_list,$___LOCAL_PLAYER__VARS__battle_equip_list,$___LOCAL_PLAYER__VARS__pc_icon_range, $___LOCAL_PLAYER__VARS__pid,$___LOCAL_PLAYER__VARS__type,$___LOCAL_PLAYER__VARS__name,$___LOCAL_PLAYER__VARS__pass,$___LOCAL_PLAYER__VARS__ip,$___LOCAL_PLAYER__VARS__motto,$___LOCAL_PLAYER__VARS__killmsg,$___LOCAL_PLAYER__VARS__lastword,$___LOCAL_PLAYER__VARS__winner_flag,$___LOCAL_PLAYER__VARS__player_dead_flag, $___LOCAL_PLAYER__VARS__corpse_clear_flag,$___LOCAL_PLAYER__VARS__gd,$___LOCAL_PLAYER__VARS__sNo,$___LOCAL_PLAYER__VARS__club,$___LOCAL_PLAYER__VARS__validtime,$___LOCAL_PLAYER__VARS__endtime,$___LOCAL_PLAYER__VARS__cdsec,$___LOCAL_PLAYER__VARS__cdmsec,$___LOCAL_PLAYER__VARS__cdtime,$___LOCAL_PLAYER__VARS__action, $___LOCAL_PLAYER__VARS__a_actionnum,$___LOCAL_PLAYER__VARS__v_actionnum,$___LOCAL_PLAYER__VARS__hp,$___LOCAL_PLAYER__VARS__mhp,$___LOCAL_PLAYER__VARS__sp,$___LOCAL_PLAYER__VARS__msp,$___LOCAL_PLAYER__VARS__mss,$___LOCAL_PLAYER__VARS__att,$___LOCAL_PLAYER__VARS__def,$___LOCAL_PLAYER__VARS__pls, $___LOCAL_PLAYER__VARS__lvl,$___LOCAL_PLAYER__VARS__exp,$___LOCAL_PLAYER__VARS__money,$___LOCAL_PLAYER__VARS__rp,$___LOCAL_PLAYER__VARS__bid,$___LOCAL_PLAYER__VARS__inf,$___LOCAL_PLAYER__VARS__rage,$___LOCAL_PLAYER__VARS__pose,$___LOCAL_PLAYER__VARS__tactic,$___LOCAL_PLAYER__VARS__killnum, $___LOCAL_PLAYER__VARS__npckillnum,$___LOCAL_PLAYER__VARS__state,$___LOCAL_PLAYER__VARS__skillpoint,$___LOCAL_PLAYER__VARS__flare,$___LOCAL_PLAYER__VARS__wp,$___LOCAL_PLAYER__VARS__wk,$___LOCAL_PLAYER__VARS__wg,$___LOCAL_PLAYER__VARS__wc,$___LOCAL_PLAYER__VARS__wd,$___LOCAL_PLAYER__VARS__wf, $___LOCAL_PLAYER__VARS__icon,$___LOCAL_PLAYER__VARS__teamID,$___LOCAL_PLAYER__VARS__teamPass,$___LOCAL_PLAYER__VARS__card,$___LOCAL_PLAYER__VARS__cardname,$___LOCAL_PLAYER__VARS__wep,$___LOCAL_PLAYER__VARS__wepk,$___LOCAL_PLAYER__VARS__wepe,$___LOCAL_PLAYER__VARS__weps,$___LOCAL_PLAYER__VARS__wepsk, $___LOCAL_PLAYER__VARS__arb,$___LOCAL_PLAYER__VARS__arbk,$___LOCAL_PLAYER__VARS__arbe,$___LOCAL_PLAYER__VARS__arbs,$___LOCAL_PLAYER__VARS__arbsk,$___LOCAL_PLAYER__VARS__arh,$___LOCAL_PLAYER__VARS__arhk,$___LOCAL_PLAYER__VARS__arhe,$___LOCAL_PLAYER__VARS__arhs,$___LOCAL_PLAYER__VARS__arhsk, $___LOCAL_PLAYER__VARS__ara,$___LOCAL_PLAYER__VARS__arak,$___LOCAL_PLAYER__VARS__arae,$___LOCAL_PLAYER__VARS__aras,$___LOCAL_PLAYER__VARS__arask,$___LOCAL_PLAYER__VARS__arf,$___LOCAL_PLAYER__VARS__arfk,$___LOCAL_PLAYER__VARS__arfe,$___LOCAL_PLAYER__VARS__arfs,$___LOCAL_PLAYER__VARS__arfsk, $___LOCAL_PLAYER__VARS__art,$___LOCAL_PLAYER__VARS__artk,$___LOCAL_PLAYER__VARS__arte,$___LOCAL_PLAYER__VARS__arts,$___LOCAL_PLAYER__VARS__artsk,$___LOCAL_PLAYER__VARS__itm0,$___LOCAL_PLAYER__VARS__itmk0,$___LOCAL_PLAYER__VARS__itme0,$___LOCAL_PLAYER__VARS__itms0,$___LOCAL_PLAYER__VARS__itmsk0, $___LOCAL_PLAYER__VARS__itm1,$___LOCAL_PLAYER__VARS__itmk1,$___LOCAL_PLAYER__VARS__itme1,$___LOCAL_PLAYER__VARS__itms1,$___LOCAL_PLAYER__VARS__itmsk1,$___LOCAL_PLAYER__VARS__itm2,$___LOCAL_PLAYER__VARS__itmk2,$___LOCAL_PLAYER__VARS__itme2,$___LOCAL_PLAYER__VARS__itms2,$___LOCAL_PLAYER__VARS__itmsk2, $___LOCAL_PLAYER__VARS__itm3,$___LOCAL_PLAYER__VARS__itmk3,$___LOCAL_PLAYER__VARS__itme3,$___LOCAL_PLAYER__VARS__itms3,$___LOCAL_PLAYER__VARS__itmsk3,$___LOCAL_PLAYER__VARS__itm4,$___LOCAL_PLAYER__VARS__itmk4,$___LOCAL_PLAYER__VARS__itme4,$___LOCAL_PLAYER__VARS__itms4,$___LOCAL_PLAYER__VARS__itmsk4, $___LOCAL_PLAYER__VARS__itm5,$___LOCAL_PLAYER__VARS__itmk5,$___LOCAL_PLAYER__VARS__itme5,$___LOCAL_PLAYER__VARS__itms5,$___LOCAL_PLAYER__VARS__itmsk5,$___LOCAL_PLAYER__VARS__itm6,$___LOCAL_PLAYER__VARS__itmk6,$___LOCAL_PLAYER__VARS__itme6,$___LOCAL_PLAYER__VARS__itms6,$___LOCAL_PLAYER__VARS__itmsk6, $___LOCAL_PLAYER__VARS__searchmemory,$___LOCAL_PLAYER__VARS__nskill,$___LOCAL_PLAYER__VARS__nskillpara; $ss=&$___LOCAL_PLAYER__VARS__ss; $db_player_structure=&$___LOCAL_PLAYER__VARS__db_player_structure; $db_player_structure_types=&$___LOCAL_PLAYER__VARS__db_player_structure_types; $gamedata=&$___LOCAL_PLAYER__VARS__gamedata; $cmd=&$___LOCAL_PLAYER__VARS__cmd; $main=&$___LOCAL_PLAYER__VARS__main; $sdata=&$___LOCAL_PLAYER__VARS__sdata; $fog=&$___LOCAL_PLAYER__VARS__fog; $upexp=&$___LOCAL_PLAYER__VARS__upexp; $lvlupexp=&$___LOCAL_PLAYER__VARS__lvlupexp;  $iconImg=&$___LOCAL_PLAYER__VARS__iconImg; $iconImgB=&$___LOCAL_PLAYER__VARS__iconImgB; $iconImgBwidth=&$___LOCAL_PLAYER__VARS__iconImgBwidth; $ardef=&$___LOCAL_PLAYER__VARS__ardef; $hpcolor=&$___LOCAL_PLAYER__VARS__hpcolor; $spcolor=&$___LOCAL_PLAYER__VARS__spcolor; $newhpimg=&$___LOCAL_PLAYER__VARS__newhpimg; $newspimg=&$___LOCAL_PLAYER__VARS__newspimg; $splt=&$___LOCAL_PLAYER__VARS__splt; $hplt=&$___LOCAL_PLAYER__VARS__hplt;  $tpldata=&$___LOCAL_PLAYER__VARS__tpldata; $icon_list=&$___LOCAL_PLAYER__VARS__icon_list; $icon_list_contents_to_frontend=&$___LOCAL_PLAYER__VARS__icon_list_contents_to_frontend; $typeinfo=&$___LOCAL_PLAYER__VARS__typeinfo; $killmsginfo=&$___LOCAL_PLAYER__VARS__killmsginfo; $lwinfo=&$___LOCAL_PLAYER__VARS__lwinfo; $sexinfo=&$___LOCAL_PLAYER__VARS__sexinfo; $equip_list=&$___LOCAL_PLAYER__VARS__equip_list; $battle_equip_list=&$___LOCAL_PLAYER__VARS__battle_equip_list; $pc_icon_range=&$___LOCAL_PLAYER__VARS__pc_icon_range;  $pid=&$___LOCAL_PLAYER__VARS__pid; $type=&$___LOCAL_PLAYER__VARS__type; $name=&$___LOCAL_PLAYER__VARS__name; $pass=&$___LOCAL_PLAYER__VARS__pass; $ip=&$___LOCAL_PLAYER__VARS__ip; $motto=&$___LOCAL_PLAYER__VARS__motto; $killmsg=&$___LOCAL_PLAYER__VARS__killmsg; $lastword=&$___LOCAL_PLAYER__VARS__lastword; $winner_flag=&$___LOCAL_PLAYER__VARS__winner_flag; $player_dead_flag=&$___LOCAL_PLAYER__VARS__player_dead_flag;  $corpse_clear_flag=&$___LOCAL_PLAYER__VARS__corpse_clear_flag; $gd=&$___LOCAL_PLAYER__VARS__gd; $sNo=&$___LOCAL_PLAYER__VARS__sNo; $club=&$___LOCAL_PLAYER__VARS__club; $validtime=&$___LOCAL_PLAYER__VARS__validtime; $endtime=&$___LOCAL_PLAYER__VARS__endtime; $cdsec=&$___LOCAL_PLAYER__VARS__cdsec; $cdmsec=&$___LOCAL_PLAYER__VARS__cdmsec; $cdtime=&$___LOCAL_PLAYER__VARS__cdtime; $action=&$___LOCAL_PLAYER__VARS__action;  $a_actionnum=&$___LOCAL_PLAYER__VARS__a_actionnum; $v_actionnum=&$___LOCAL_PLAYER__VARS__v_actionnum; $hp=&$___LOCAL_PLAYER__VARS__hp; $mhp=&$___LOCAL_PLAYER__VARS__mhp; $sp=&$___LOCAL_PLAYER__VARS__sp; $msp=&$___LOCAL_PLAYER__VARS__msp; $mss=&$___LOCAL_PLAYER__VARS__mss; $att=&$___LOCAL_PLAYER__VARS__att; $def=&$___LOCAL_PLAYER__VARS__def; $pls=&$___LOCAL_PLAYER__VARS__pls;  $lvl=&$___LOCAL_PLAYER__VARS__lvl; $exp=&$___LOCAL_PLAYER__VARS__exp; $money=&$___LOCAL_PLAYER__VARS__money; $rp=&$___LOCAL_PLAYER__VARS__rp; $bid=&$___LOCAL_PLAYER__VARS__bid; $inf=&$___LOCAL_PLAYER__VARS__inf; $rage=&$___LOCAL_PLAYER__VARS__rage; $pose=&$___LOCAL_PLAYER__VARS__pose; $tactic=&$___LOCAL_PLAYER__VARS__tactic; $killnum=&$___LOCAL_PLAYER__VARS__killnum;  $npckillnum=&$___LOCAL_PLAYER__VARS__npckillnum; $state=&$___LOCAL_PLAYER__VARS__state; $skillpoint=&$___LOCAL_PLAYER__VARS__skillpoint; $flare=&$___LOCAL_PLAYER__VARS__flare; $wp=&$___LOCAL_PLAYER__VARS__wp; $wk=&$___LOCAL_PLAYER__VARS__wk; $wg=&$___LOCAL_PLAYER__VARS__wg; $wc=&$___LOCAL_PLAYER__VARS__wc; $wd=&$___LOCAL_PLAYER__VARS__wd; $wf=&$___LOCAL_PLAYER__VARS__wf;  $icon=&$___LOCAL_PLAYER__VARS__icon; $teamID=&$___LOCAL_PLAYER__VARS__teamID; $teamPass=&$___LOCAL_PLAYER__VARS__teamPass; $card=&$___LOCAL_PLAYER__VARS__card; $cardname=&$___LOCAL_PLAYER__VARS__cardname; $wep=&$___LOCAL_PLAYER__VARS__wep; $wepk=&$___LOCAL_PLAYER__VARS__wepk; $wepe=&$___LOCAL_PLAYER__VARS__wepe; $weps=&$___LOCAL_PLAYER__VARS__weps; $wepsk=&$___LOCAL_PLAYER__VARS__wepsk;  $arb=&$___LOCAL_PLAYER__VARS__arb; $arbk=&$___LOCAL_PLAYER__VARS__arbk; $arbe=&$___LOCAL_PLAYER__VARS__arbe; $arbs=&$___LOCAL_PLAYER__VARS__arbs; $arbsk=&$___LOCAL_PLAYER__VARS__arbsk; $arh=&$___LOCAL_PLAYER__VARS__arh; $arhk=&$___LOCAL_PLAYER__VARS__arhk; $arhe=&$___LOCAL_PLAYER__VARS__arhe; $arhs=&$___LOCAL_PLAYER__VARS__arhs; $arhsk=&$___LOCAL_PLAYER__VARS__arhsk;  $ara=&$___LOCAL_PLAYER__VARS__ara; $arak=&$___LOCAL_PLAYER__VARS__arak; $arae=&$___LOCAL_PLAYER__VARS__arae; $aras=&$___LOCAL_PLAYER__VARS__aras; $arask=&$___LOCAL_PLAYER__VARS__arask; $arf=&$___LOCAL_PLAYER__VARS__arf; $arfk=&$___LOCAL_PLAYER__VARS__arfk; $arfe=&$___LOCAL_PLAYER__VARS__arfe; $arfs=&$___LOCAL_PLAYER__VARS__arfs; $arfsk=&$___LOCAL_PLAYER__VARS__arfsk;  $art=&$___LOCAL_PLAYER__VARS__art; $artk=&$___LOCAL_PLAYER__VARS__artk; $arte=&$___LOCAL_PLAYER__VARS__arte; $arts=&$___LOCAL_PLAYER__VARS__arts; $artsk=&$___LOCAL_PLAYER__VARS__artsk; $itm0=&$___LOCAL_PLAYER__VARS__itm0; $itmk0=&$___LOCAL_PLAYER__VARS__itmk0; $itme0=&$___LOCAL_PLAYER__VARS__itme0; $itms0=&$___LOCAL_PLAYER__VARS__itms0; $itmsk0=&$___LOCAL_PLAYER__VARS__itmsk0;  $itm1=&$___LOCAL_PLAYER__VARS__itm1; $itmk1=&$___LOCAL_PLAYER__VARS__itmk1; $itme1=&$___LOCAL_PLAYER__VARS__itme1; $itms1=&$___LOCAL_PLAYER__VARS__itms1; $itmsk1=&$___LOCAL_PLAYER__VARS__itmsk1; $itm2=&$___LOCAL_PLAYER__VARS__itm2; $itmk2=&$___LOCAL_PLAYER__VARS__itmk2; $itme2=&$___LOCAL_PLAYER__VARS__itme2; $itms2=&$___LOCAL_PLAYER__VARS__itms2; $itmsk2=&$___LOCAL_PLAYER__VARS__itmsk2;  $itm3=&$___LOCAL_PLAYER__VARS__itm3; $itmk3=&$___LOCAL_PLAYER__VARS__itmk3; $itme3=&$___LOCAL_PLAYER__VARS__itme3; $itms3=&$___LOCAL_PLAYER__VARS__itms3; $itmsk3=&$___LOCAL_PLAYER__VARS__itmsk3; $itm4=&$___LOCAL_PLAYER__VARS__itm4; $itmk4=&$___LOCAL_PLAYER__VARS__itmk4; $itme4=&$___LOCAL_PLAYER__VARS__itme4; $itms4=&$___LOCAL_PLAYER__VARS__itms4; $itmsk4=&$___LOCAL_PLAYER__VARS__itmsk4;  $itm5=&$___LOCAL_PLAYER__VARS__itm5; $itmk5=&$___LOCAL_PLAYER__VARS__itmk5; $itme5=&$___LOCAL_PLAYER__VARS__itme5; $itms5=&$___LOCAL_PLAYER__VARS__itms5; $itmsk5=&$___LOCAL_PLAYER__VARS__itmsk5; $itm6=&$___LOCAL_PLAYER__VARS__itm6; $itmk6=&$___LOCAL_PLAYER__VARS__itmk6; $itme6=&$___LOCAL_PLAYER__VARS__itme6; $itms6=&$___LOCAL_PLAYER__VARS__itms6; $itmsk6=&$___LOCAL_PLAYER__VARS__itmsk6;  $searchmemory=&$___LOCAL_PLAYER__VARS__searchmemory; $nskill=&$___LOCAL_PLAYER__VARS__nskill; $nskillpara=&$___LOCAL_PLAYER__VARS__nskillpara;  global $___LOCAL_SKILL272__VARS__skill272_cd,$___LOCAL_SKILL272__VARS__skill272_act_time,$___LOCAL_SKILL272__VARS__skill272_factor,$___LOCAL_SKILL272__VARS__skill272_pos_list,$___LOCAL_SKILL272__VARS__skill272_itmsk_cube; $skill272_cd=&$___LOCAL_SKILL272__VARS__skill272_cd; $skill272_act_time=&$___LOCAL_SKILL272__VARS__skill272_act_time; $skill272_factor=&$___LOCAL_SKILL272__VARS__skill272_factor; $skill272_pos_list=&$___LOCAL_SKILL272__VARS__skill272_pos_list; $skill272_itmsk_cube=&$___LOCAL_SKILL272__VARS__skill272_itmsk_cube;   } while (0);
		if (!\skillbase\skill_query(272) || !check_unlocked272($sdata)) 
		{
			$log.='你没有这个技能。';
			$mode='command';
			return;
		}
		$subcmd = get_var_input('subcmd');
		$skill272_ipos = get_var_input('skill272_ipos');
		if ('activate'==$subcmd && !empty($skill272_ipos))
		{
			activate272($skill272_ipos);
			return;
		}
		$flag = 0;
		$effect_list = create_effect_list272();
		foreach ($skill272_pos_list as $val){
			if(check_valid_single272($val, 1, $effect_list)) $flag = 1;
		}
		if(!$flag) {
			$log.='你身上的装备道具全都不符合要求！';
			$mode='command';
			return;
		}
		include template(MOD_SKILL272_SKILL272_COMMAND);
		$cmd=ob_get_contents();
		ob_clean();
	}
	
	
	function check_valid_single272($ipos, $check_only=0, $effect_list=NULL){
		
		if(!$effect_list) $effect_list = create_effect_list272();
		do { global $___LOCAL_SKILL272__VARS__skill272_cd,$___LOCAL_SKILL272__VARS__skill272_act_time,$___LOCAL_SKILL272__VARS__skill272_factor,$___LOCAL_SKILL272__VARS__skill272_pos_list,$___LOCAL_SKILL272__VARS__skill272_itmsk_cube; $skill272_cd=&$___LOCAL_SKILL272__VARS__skill272_cd; $skill272_act_time=&$___LOCAL_SKILL272__VARS__skill272_act_time; $skill272_factor=&$___LOCAL_SKILL272__VARS__skill272_factor; $skill272_pos_list=&$___LOCAL_SKILL272__VARS__skill272_pos_list; $skill272_itmsk_cube=&$___LOCAL_SKILL272__VARS__skill272_itmsk_cube;  global $___LOCAL_PLAYER__VARS__ss,$___LOCAL_PLAYER__VARS__db_player_structure,$___LOCAL_PLAYER__VARS__db_player_structure_types,$___LOCAL_PLAYER__VARS__gamedata,$___LOCAL_PLAYER__VARS__cmd,$___LOCAL_PLAYER__VARS__main,$___LOCAL_PLAYER__VARS__sdata,$___LOCAL_PLAYER__VARS__fog,$___LOCAL_PLAYER__VARS__upexp,$___LOCAL_PLAYER__VARS__lvlupexp, $___LOCAL_PLAYER__VARS__iconImg,$___LOCAL_PLAYER__VARS__iconImgB,$___LOCAL_PLAYER__VARS__iconImgBwidth,$___LOCAL_PLAYER__VARS__ardef,$___LOCAL_PLAYER__VARS__hpcolor,$___LOCAL_PLAYER__VARS__spcolor,$___LOCAL_PLAYER__VARS__newhpimg,$___LOCAL_PLAYER__VARS__newspimg,$___LOCAL_PLAYER__VARS__splt,$___LOCAL_PLAYER__VARS__hplt, $___LOCAL_PLAYER__VARS__tpldata,$___LOCAL_PLAYER__VARS__icon_list,$___LOCAL_PLAYER__VARS__icon_list_contents_to_frontend,$___LOCAL_PLAYER__VARS__typeinfo,$___LOCAL_PLAYER__VARS__killmsginfo,$___LOCAL_PLAYER__VARS__lwinfo,$___LOCAL_PLAYER__VARS__sexinfo,$___LOCAL_PLAYER__VARS__equip_list,$___LOCAL_PLAYER__VARS__battle_equip_list,$___LOCAL_PLAYER__VARS__pc_icon_range, $___LOCAL_PLAYER__VARS__pid,$___LOCAL_PLAYER__VARS__type,$___LOCAL_PLAYER__VARS__name,$___LOCAL_PLAYER__VARS__pass,$___LOCAL_PLAYER__VARS__ip,$___LOCAL_PLAYER__VARS__motto,$___LOCAL_PLAYER__VARS__killmsg,$___LOCAL_PLAYER__VARS__lastword,$___LOCAL_PLAYER__VARS__winner_flag,$___LOCAL_PLAYER__VARS__player_dead_flag, $___LOCAL_PLAYER__VARS__corpse_clear_flag,$___LOCAL_PLAYER__VARS__gd,$___LOCAL_PLAYER__VARS__sNo,$___LOCAL_PLAYER__VARS__club,$___LOCAL_PLAYER__VARS__validtime,$___LOCAL_PLAYER__VARS__endtime,$___LOCAL_PLAYER__VARS__cdsec,$___LOCAL_PLAYER__VARS__cdmsec,$___LOCAL_PLAYER__VARS__cdtime,$___LOCAL_PLAYER__VARS__action, $___LOCAL_PLAYER__VARS__a_actionnum,$___LOCAL_PLAYER__VARS__v_actionnum,$___LOCAL_PLAYER__VARS__hp,$___LOCAL_PLAYER__VARS__mhp,$___LOCAL_PLAYER__VARS__sp,$___LOCAL_PLAYER__VARS__msp,$___LOCAL_PLAYER__VARS__mss,$___LOCAL_PLAYER__VARS__att,$___LOCAL_PLAYER__VARS__def,$___LOCAL_PLAYER__VARS__pls, $___LOCAL_PLAYER__VARS__lvl,$___LOCAL_PLAYER__VARS__exp,$___LOCAL_PLAYER__VARS__money,$___LOCAL_PLAYER__VARS__rp,$___LOCAL_PLAYER__VARS__bid,$___LOCAL_PLAYER__VARS__inf,$___LOCAL_PLAYER__VARS__rage,$___LOCAL_PLAYER__VARS__pose,$___LOCAL_PLAYER__VARS__tactic,$___LOCAL_PLAYER__VARS__killnum, $___LOCAL_PLAYER__VARS__npckillnum,$___LOCAL_PLAYER__VARS__state,$___LOCAL_PLAYER__VARS__skillpoint,$___LOCAL_PLAYER__VARS__flare,$___LOCAL_PLAYER__VARS__wp,$___LOCAL_PLAYER__VARS__wk,$___LOCAL_PLAYER__VARS__wg,$___LOCAL_PLAYER__VARS__wc,$___LOCAL_PLAYER__VARS__wd,$___LOCAL_PLAYER__VARS__wf, $___LOCAL_PLAYER__VARS__icon,$___LOCAL_PLAYER__VARS__teamID,$___LOCAL_PLAYER__VARS__teamPass,$___LOCAL_PLAYER__VARS__card,$___LOCAL_PLAYER__VARS__cardname,$___LOCAL_PLAYER__VARS__wep,$___LOCAL_PLAYER__VARS__wepk,$___LOCAL_PLAYER__VARS__wepe,$___LOCAL_PLAYER__VARS__weps,$___LOCAL_PLAYER__VARS__wepsk, $___LOCAL_PLAYER__VARS__arb,$___LOCAL_PLAYER__VARS__arbk,$___LOCAL_PLAYER__VARS__arbe,$___LOCAL_PLAYER__VARS__arbs,$___LOCAL_PLAYER__VARS__arbsk,$___LOCAL_PLAYER__VARS__arh,$___LOCAL_PLAYER__VARS__arhk,$___LOCAL_PLAYER__VARS__arhe,$___LOCAL_PLAYER__VARS__arhs,$___LOCAL_PLAYER__VARS__arhsk, $___LOCAL_PLAYER__VARS__ara,$___LOCAL_PLAYER__VARS__arak,$___LOCAL_PLAYER__VARS__arae,$___LOCAL_PLAYER__VARS__aras,$___LOCAL_PLAYER__VARS__arask,$___LOCAL_PLAYER__VARS__arf,$___LOCAL_PLAYER__VARS__arfk,$___LOCAL_PLAYER__VARS__arfe,$___LOCAL_PLAYER__VARS__arfs,$___LOCAL_PLAYER__VARS__arfsk, $___LOCAL_PLAYER__VARS__art,$___LOCAL_PLAYER__VARS__artk,$___LOCAL_PLAYER__VARS__arte,$___LOCAL_PLAYER__VARS__arts,$___LOCAL_PLAYER__VARS__artsk,$___LOCAL_PLAYER__VARS__itm0,$___LOCAL_PLAYER__VARS__itmk0,$___LOCAL_PLAYER__VARS__itme0,$___LOCAL_PLAYER__VARS__itms0,$___LOCAL_PLAYER__VARS__itmsk0, $___LOCAL_PLAYER__VARS__itm1,$___LOCAL_PLAYER__VARS__itmk1,$___LOCAL_PLAYER__VARS__itme1,$___LOCAL_PLAYER__VARS__itms1,$___LOCAL_PLAYER__VARS__itmsk1,$___LOCAL_PLAYER__VARS__itm2,$___LOCAL_PLAYER__VARS__itmk2,$___LOCAL_PLAYER__VARS__itme2,$___LOCAL_PLAYER__VARS__itms2,$___LOCAL_PLAYER__VARS__itmsk2, $___LOCAL_PLAYER__VARS__itm3,$___LOCAL_PLAYER__VARS__itmk3,$___LOCAL_PLAYER__VARS__itme3,$___LOCAL_PLAYER__VARS__itms3,$___LOCAL_PLAYER__VARS__itmsk3,$___LOCAL_PLAYER__VARS__itm4,$___LOCAL_PLAYER__VARS__itmk4,$___LOCAL_PLAYER__VARS__itme4,$___LOCAL_PLAYER__VARS__itms4,$___LOCAL_PLAYER__VARS__itmsk4, $___LOCAL_PLAYER__VARS__itm5,$___LOCAL_PLAYER__VARS__itmk5,$___LOCAL_PLAYER__VARS__itme5,$___LOCAL_PLAYER__VARS__itms5,$___LOCAL_PLAYER__VARS__itmsk5,$___LOCAL_PLAYER__VARS__itm6,$___LOCAL_PLAYER__VARS__itmk6,$___LOCAL_PLAYER__VARS__itme6,$___LOCAL_PLAYER__VARS__itms6,$___LOCAL_PLAYER__VARS__itmsk6, $___LOCAL_PLAYER__VARS__searchmemory,$___LOCAL_PLAYER__VARS__nskill,$___LOCAL_PLAYER__VARS__nskillpara; $ss=&$___LOCAL_PLAYER__VARS__ss; $db_player_structure=&$___LOCAL_PLAYER__VARS__db_player_structure; $db_player_structure_types=&$___LOCAL_PLAYER__VARS__db_player_structure_types; $gamedata=&$___LOCAL_PLAYER__VARS__gamedata; $cmd=&$___LOCAL_PLAYER__VARS__cmd; $main=&$___LOCAL_PLAYER__VARS__main; $sdata=&$___LOCAL_PLAYER__VARS__sdata; $fog=&$___LOCAL_PLAYER__VARS__fog; $upexp=&$___LOCAL_PLAYER__VARS__upexp; $lvlupexp=&$___LOCAL_PLAYER__VARS__lvlupexp;  $iconImg=&$___LOCAL_PLAYER__VARS__iconImg; $iconImgB=&$___LOCAL_PLAYER__VARS__iconImgB; $iconImgBwidth=&$___LOCAL_PLAYER__VARS__iconImgBwidth; $ardef=&$___LOCAL_PLAYER__VARS__ardef; $hpcolor=&$___LOCAL_PLAYER__VARS__hpcolor; $spcolor=&$___LOCAL_PLAYER__VARS__spcolor; $newhpimg=&$___LOCAL_PLAYER__VARS__newhpimg; $newspimg=&$___LOCAL_PLAYER__VARS__newspimg; $splt=&$___LOCAL_PLAYER__VARS__splt; $hplt=&$___LOCAL_PLAYER__VARS__hplt;  $tpldata=&$___LOCAL_PLAYER__VARS__tpldata; $icon_list=&$___LOCAL_PLAYER__VARS__icon_list; $icon_list_contents_to_frontend=&$___LOCAL_PLAYER__VARS__icon_list_contents_to_frontend; $typeinfo=&$___LOCAL_PLAYER__VARS__typeinfo; $killmsginfo=&$___LOCAL_PLAYER__VARS__killmsginfo; $lwinfo=&$___LOCAL_PLAYER__VARS__lwinfo; $sexinfo=&$___LOCAL_PLAYER__VARS__sexinfo; $equip_list=&$___LOCAL_PLAYER__VARS__equip_list; $battle_equip_list=&$___LOCAL_PLAYER__VARS__battle_equip_list; $pc_icon_range=&$___LOCAL_PLAYER__VARS__pc_icon_range;  $pid=&$___LOCAL_PLAYER__VARS__pid; $type=&$___LOCAL_PLAYER__VARS__type; $name=&$___LOCAL_PLAYER__VARS__name; $pass=&$___LOCAL_PLAYER__VARS__pass; $ip=&$___LOCAL_PLAYER__VARS__ip; $motto=&$___LOCAL_PLAYER__VARS__motto; $killmsg=&$___LOCAL_PLAYER__VARS__killmsg; $lastword=&$___LOCAL_PLAYER__VARS__lastword; $winner_flag=&$___LOCAL_PLAYER__VARS__winner_flag; $player_dead_flag=&$___LOCAL_PLAYER__VARS__player_dead_flag;  $corpse_clear_flag=&$___LOCAL_PLAYER__VARS__corpse_clear_flag; $gd=&$___LOCAL_PLAYER__VARS__gd; $sNo=&$___LOCAL_PLAYER__VARS__sNo; $club=&$___LOCAL_PLAYER__VARS__club; $validtime=&$___LOCAL_PLAYER__VARS__validtime; $endtime=&$___LOCAL_PLAYER__VARS__endtime; $cdsec=&$___LOCAL_PLAYER__VARS__cdsec; $cdmsec=&$___LOCAL_PLAYER__VARS__cdmsec; $cdtime=&$___LOCAL_PLAYER__VARS__cdtime; $action=&$___LOCAL_PLAYER__VARS__action;  $a_actionnum=&$___LOCAL_PLAYER__VARS__a_actionnum; $v_actionnum=&$___LOCAL_PLAYER__VARS__v_actionnum; $hp=&$___LOCAL_PLAYER__VARS__hp; $mhp=&$___LOCAL_PLAYER__VARS__mhp; $sp=&$___LOCAL_PLAYER__VARS__sp; $msp=&$___LOCAL_PLAYER__VARS__msp; $mss=&$___LOCAL_PLAYER__VARS__mss; $att=&$___LOCAL_PLAYER__VARS__att; $def=&$___LOCAL_PLAYER__VARS__def; $pls=&$___LOCAL_PLAYER__VARS__pls;  $lvl=&$___LOCAL_PLAYER__VARS__lvl; $exp=&$___LOCAL_PLAYER__VARS__exp; $money=&$___LOCAL_PLAYER__VARS__money; $rp=&$___LOCAL_PLAYER__VARS__rp; $bid=&$___LOCAL_PLAYER__VARS__bid; $inf=&$___LOCAL_PLAYER__VARS__inf; $rage=&$___LOCAL_PLAYER__VARS__rage; $pose=&$___LOCAL_PLAYER__VARS__pose; $tactic=&$___LOCAL_PLAYER__VARS__tactic; $killnum=&$___LOCAL_PLAYER__VARS__killnum;  $npckillnum=&$___LOCAL_PLAYER__VARS__npckillnum; $state=&$___LOCAL_PLAYER__VARS__state; $skillpoint=&$___LOCAL_PLAYER__VARS__skillpoint; $flare=&$___LOCAL_PLAYER__VARS__flare; $wp=&$___LOCAL_PLAYER__VARS__wp; $wk=&$___LOCAL_PLAYER__VARS__wk; $wg=&$___LOCAL_PLAYER__VARS__wg; $wc=&$___LOCAL_PLAYER__VARS__wc; $wd=&$___LOCAL_PLAYER__VARS__wd; $wf=&$___LOCAL_PLAYER__VARS__wf;  $icon=&$___LOCAL_PLAYER__VARS__icon; $teamID=&$___LOCAL_PLAYER__VARS__teamID; $teamPass=&$___LOCAL_PLAYER__VARS__teamPass; $card=&$___LOCAL_PLAYER__VARS__card; $cardname=&$___LOCAL_PLAYER__VARS__cardname; $wep=&$___LOCAL_PLAYER__VARS__wep; $wepk=&$___LOCAL_PLAYER__VARS__wepk; $wepe=&$___LOCAL_PLAYER__VARS__wepe; $weps=&$___LOCAL_PLAYER__VARS__weps; $wepsk=&$___LOCAL_PLAYER__VARS__wepsk;  $arb=&$___LOCAL_PLAYER__VARS__arb; $arbk=&$___LOCAL_PLAYER__VARS__arbk; $arbe=&$___LOCAL_PLAYER__VARS__arbe; $arbs=&$___LOCAL_PLAYER__VARS__arbs; $arbsk=&$___LOCAL_PLAYER__VARS__arbsk; $arh=&$___LOCAL_PLAYER__VARS__arh; $arhk=&$___LOCAL_PLAYER__VARS__arhk; $arhe=&$___LOCAL_PLAYER__VARS__arhe; $arhs=&$___LOCAL_PLAYER__VARS__arhs; $arhsk=&$___LOCAL_PLAYER__VARS__arhsk;  $ara=&$___LOCAL_PLAYER__VARS__ara; $arak=&$___LOCAL_PLAYER__VARS__arak; $arae=&$___LOCAL_PLAYER__VARS__arae; $aras=&$___LOCAL_PLAYER__VARS__aras; $arask=&$___LOCAL_PLAYER__VARS__arask; $arf=&$___LOCAL_PLAYER__VARS__arf; $arfk=&$___LOCAL_PLAYER__VARS__arfk; $arfe=&$___LOCAL_PLAYER__VARS__arfe; $arfs=&$___LOCAL_PLAYER__VARS__arfs; $arfsk=&$___LOCAL_PLAYER__VARS__arfsk;  $art=&$___LOCAL_PLAYER__VARS__art; $artk=&$___LOCAL_PLAYER__VARS__artk; $arte=&$___LOCAL_PLAYER__VARS__arte; $arts=&$___LOCAL_PLAYER__VARS__arts; $artsk=&$___LOCAL_PLAYER__VARS__artsk; $itm0=&$___LOCAL_PLAYER__VARS__itm0; $itmk0=&$___LOCAL_PLAYER__VARS__itmk0; $itme0=&$___LOCAL_PLAYER__VARS__itme0; $itms0=&$___LOCAL_PLAYER__VARS__itms0; $itmsk0=&$___LOCAL_PLAYER__VARS__itmsk0;  $itm1=&$___LOCAL_PLAYER__VARS__itm1; $itmk1=&$___LOCAL_PLAYER__VARS__itmk1; $itme1=&$___LOCAL_PLAYER__VARS__itme1; $itms1=&$___LOCAL_PLAYER__VARS__itms1; $itmsk1=&$___LOCAL_PLAYER__VARS__itmsk1; $itm2=&$___LOCAL_PLAYER__VARS__itm2; $itmk2=&$___LOCAL_PLAYER__VARS__itmk2; $itme2=&$___LOCAL_PLAYER__VARS__itme2; $itms2=&$___LOCAL_PLAYER__VARS__itms2; $itmsk2=&$___LOCAL_PLAYER__VARS__itmsk2;  $itm3=&$___LOCAL_PLAYER__VARS__itm3; $itmk3=&$___LOCAL_PLAYER__VARS__itmk3; $itme3=&$___LOCAL_PLAYER__VARS__itme3; $itms3=&$___LOCAL_PLAYER__VARS__itms3; $itmsk3=&$___LOCAL_PLAYER__VARS__itmsk3; $itm4=&$___LOCAL_PLAYER__VARS__itm4; $itmk4=&$___LOCAL_PLAYER__VARS__itmk4; $itme4=&$___LOCAL_PLAYER__VARS__itme4; $itms4=&$___LOCAL_PLAYER__VARS__itms4; $itmsk4=&$___LOCAL_PLAYER__VARS__itmsk4;  $itm5=&$___LOCAL_PLAYER__VARS__itm5; $itmk5=&$___LOCAL_PLAYER__VARS__itmk5; $itme5=&$___LOCAL_PLAYER__VARS__itme5; $itms5=&$___LOCAL_PLAYER__VARS__itms5; $itmsk5=&$___LOCAL_PLAYER__VARS__itmsk5; $itm6=&$___LOCAL_PLAYER__VARS__itm6; $itmk6=&$___LOCAL_PLAYER__VARS__itmk6; $itme6=&$___LOCAL_PLAYER__VARS__itme6; $itms6=&$___LOCAL_PLAYER__VARS__itms6; $itmsk6=&$___LOCAL_PLAYER__VARS__itmsk6;  $searchmemory=&$___LOCAL_PLAYER__VARS__searchmemory; $nskill=&$___LOCAL_PLAYER__VARS__nskill; $nskillpara=&$___LOCAL_PLAYER__VARS__nskillpara;  global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;  global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
		$alert = '';
		$flag = 1;
		if (!in_array($ipos, $skill272_pos_list))
		{
			$alert.='你选择的道具无效，请重新选择。<br>';
			$flag = 0;
		}
		if(strpos($ipos, 'itm')===0) {
			$itm=&${$ipos};
			$itmk=&${'itmk'.substr($ipos,3,1)};
			$itme=&${'itme'.substr($ipos,3,1)};
			$itms=&${'itms'.substr($ipos,3,1)};
			$itmsk=&${'itmsk'.substr($ipos,3,1)};
		}else{
			$itm=&${$ipos};
			$itmk=&${$ipos.'k'};
			$itme=&${$ipos.'e'};
			$itms=&${$ipos.'s'};
			$itmsk=&${$ipos.'sk'};
		}
		if ($itmk=='WN')
		{
			$alert.='你不能吸收你自己的拳头。<br>';
			$flag = 0;
		}elseif ($itms <= 0 && $itms != $nosta) 
		{
			$alert.='道具不存在，请重新选择。<br>';
			$flag = 0;
		}elseif (!$itmsk || is_numeric($itmsk)) 
		{
			$alert.='该道具无属性，请重新选择。<br>';
			$flag = 0;
		}
		list($effect_num, $itmsk_after) = check_skill272num_single($itmsk, $effect_list);
		if(!$effect_num) 
		{
			$alert.='该道具没有可以吸收的属性，请重新选择。<br>';
			$flag = 0;
		}
		if(!$check_only && !$flag){
			$log .= $alert;
		}
		return $flag;
	}
	
	
	function create_effect_list272(){
		
		
		
		$effect_list = Array('c','l','g');
		do { global $___LOCAL_EX_PHY_DEF__VARS__def_kind; $def_kind=&$___LOCAL_EX_PHY_DEF__VARS__def_kind;   } while (0);
		foreach($def_kind as $dv){
			$effect_list[] = $dv;
		}
		do { global $___LOCAL_EX_DMG_DEF__VARS__def_kind; $def_kind=&$___LOCAL_EX_DMG_DEF__VARS__def_kind;   } while (0);
		foreach($def_kind as $dk => $dv){
			$effect_list[] = $dk;
			$effect_list[] = $dv;
		}
		$effect_list = array_diff($effect_list,array('d'));
		$effect_list = array_unique($effect_list);
		return $effect_list;
	}
	
	function check_skill272num_single( $itmsk, $effect_list=NULL){
		
		if(!$effect_list) $effect_list = create_effect_list272();
		$effect_num = 0;
		$itmsk_after = $itmsk;
		$affected_arr = array();
		
		if(!empty($itmsk)) {
			
			$itmsk_arr = \itemmain\get_itmsk_array($itmsk,1);
			foreach($itmsk_arr as &$isk){
				if(in_array($isk, $effect_list)){
					$effect_num ++ ;
					$affected_arr[] = $isk;
					$isk = '';
				}
			}
			$itmsk_after = implode('', $itmsk_arr);
			
		}
		
		return array($effect_num, $itmsk_after, $affected_arr);
	}
	
	function activate272($ipos)
	{
		
		do { global $___LOCAL_PLAYER__VARS__ss,$___LOCAL_PLAYER__VARS__db_player_structure,$___LOCAL_PLAYER__VARS__db_player_structure_types,$___LOCAL_PLAYER__VARS__gamedata,$___LOCAL_PLAYER__VARS__cmd,$___LOCAL_PLAYER__VARS__main,$___LOCAL_PLAYER__VARS__sdata,$___LOCAL_PLAYER__VARS__fog,$___LOCAL_PLAYER__VARS__upexp,$___LOCAL_PLAYER__VARS__lvlupexp, $___LOCAL_PLAYER__VARS__iconImg,$___LOCAL_PLAYER__VARS__iconImgB,$___LOCAL_PLAYER__VARS__iconImgBwidth,$___LOCAL_PLAYER__VARS__ardef,$___LOCAL_PLAYER__VARS__hpcolor,$___LOCAL_PLAYER__VARS__spcolor,$___LOCAL_PLAYER__VARS__newhpimg,$___LOCAL_PLAYER__VARS__newspimg,$___LOCAL_PLAYER__VARS__splt,$___LOCAL_PLAYER__VARS__hplt, $___LOCAL_PLAYER__VARS__tpldata,$___LOCAL_PLAYER__VARS__icon_list,$___LOCAL_PLAYER__VARS__icon_list_contents_to_frontend,$___LOCAL_PLAYER__VARS__typeinfo,$___LOCAL_PLAYER__VARS__killmsginfo,$___LOCAL_PLAYER__VARS__lwinfo,$___LOCAL_PLAYER__VARS__sexinfo,$___LOCAL_PLAYER__VARS__equip_list,$___LOCAL_PLAYER__VARS__battle_equip_list,$___LOCAL_PLAYER__VARS__pc_icon_range, $___LOCAL_PLAYER__VARS__pid,$___LOCAL_PLAYER__VARS__type,$___LOCAL_PLAYER__VARS__name,$___LOCAL_PLAYER__VARS__pass,$___LOCAL_PLAYER__VARS__ip,$___LOCAL_PLAYER__VARS__motto,$___LOCAL_PLAYER__VARS__killmsg,$___LOCAL_PLAYER__VARS__lastword,$___LOCAL_PLAYER__VARS__winner_flag,$___LOCAL_PLAYER__VARS__player_dead_flag, $___LOCAL_PLAYER__VARS__corpse_clear_flag,$___LOCAL_PLAYER__VARS__gd,$___LOCAL_PLAYER__VARS__sNo,$___LOCAL_PLAYER__VARS__club,$___LOCAL_PLAYER__VARS__validtime,$___LOCAL_PLAYER__VARS__endtime,$___LOCAL_PLAYER__VARS__cdsec,$___LOCAL_PLAYER__VARS__cdmsec,$___LOCAL_PLAYER__VARS__cdtime,$___LOCAL_PLAYER__VARS__action, $___LOCAL_PLAYER__VARS__a_actionnum,$___LOCAL_PLAYER__VARS__v_actionnum,$___LOCAL_PLAYER__VARS__hp,$___LOCAL_PLAYER__VARS__mhp,$___LOCAL_PLAYER__VARS__sp,$___LOCAL_PLAYER__VARS__msp,$___LOCAL_PLAYER__VARS__mss,$___LOCAL_PLAYER__VARS__att,$___LOCAL_PLAYER__VARS__def,$___LOCAL_PLAYER__VARS__pls, $___LOCAL_PLAYER__VARS__lvl,$___LOCAL_PLAYER__VARS__exp,$___LOCAL_PLAYER__VARS__money,$___LOCAL_PLAYER__VARS__rp,$___LOCAL_PLAYER__VARS__bid,$___LOCAL_PLAYER__VARS__inf,$___LOCAL_PLAYER__VARS__rage,$___LOCAL_PLAYER__VARS__pose,$___LOCAL_PLAYER__VARS__tactic,$___LOCAL_PLAYER__VARS__killnum, $___LOCAL_PLAYER__VARS__npckillnum,$___LOCAL_PLAYER__VARS__state,$___LOCAL_PLAYER__VARS__skillpoint,$___LOCAL_PLAYER__VARS__flare,$___LOCAL_PLAYER__VARS__wp,$___LOCAL_PLAYER__VARS__wk,$___LOCAL_PLAYER__VARS__wg,$___LOCAL_PLAYER__VARS__wc,$___LOCAL_PLAYER__VARS__wd,$___LOCAL_PLAYER__VARS__wf, $___LOCAL_PLAYER__VARS__icon,$___LOCAL_PLAYER__VARS__teamID,$___LOCAL_PLAYER__VARS__teamPass,$___LOCAL_PLAYER__VARS__card,$___LOCAL_PLAYER__VARS__cardname,$___LOCAL_PLAYER__VARS__wep,$___LOCAL_PLAYER__VARS__wepk,$___LOCAL_PLAYER__VARS__wepe,$___LOCAL_PLAYER__VARS__weps,$___LOCAL_PLAYER__VARS__wepsk, $___LOCAL_PLAYER__VARS__arb,$___LOCAL_PLAYER__VARS__arbk,$___LOCAL_PLAYER__VARS__arbe,$___LOCAL_PLAYER__VARS__arbs,$___LOCAL_PLAYER__VARS__arbsk,$___LOCAL_PLAYER__VARS__arh,$___LOCAL_PLAYER__VARS__arhk,$___LOCAL_PLAYER__VARS__arhe,$___LOCAL_PLAYER__VARS__arhs,$___LOCAL_PLAYER__VARS__arhsk, $___LOCAL_PLAYER__VARS__ara,$___LOCAL_PLAYER__VARS__arak,$___LOCAL_PLAYER__VARS__arae,$___LOCAL_PLAYER__VARS__aras,$___LOCAL_PLAYER__VARS__arask,$___LOCAL_PLAYER__VARS__arf,$___LOCAL_PLAYER__VARS__arfk,$___LOCAL_PLAYER__VARS__arfe,$___LOCAL_PLAYER__VARS__arfs,$___LOCAL_PLAYER__VARS__arfsk, $___LOCAL_PLAYER__VARS__art,$___LOCAL_PLAYER__VARS__artk,$___LOCAL_PLAYER__VARS__arte,$___LOCAL_PLAYER__VARS__arts,$___LOCAL_PLAYER__VARS__artsk,$___LOCAL_PLAYER__VARS__itm0,$___LOCAL_PLAYER__VARS__itmk0,$___LOCAL_PLAYER__VARS__itme0,$___LOCAL_PLAYER__VARS__itms0,$___LOCAL_PLAYER__VARS__itmsk0, $___LOCAL_PLAYER__VARS__itm1,$___LOCAL_PLAYER__VARS__itmk1,$___LOCAL_PLAYER__VARS__itme1,$___LOCAL_PLAYER__VARS__itms1,$___LOCAL_PLAYER__VARS__itmsk1,$___LOCAL_PLAYER__VARS__itm2,$___LOCAL_PLAYER__VARS__itmk2,$___LOCAL_PLAYER__VARS__itme2,$___LOCAL_PLAYER__VARS__itms2,$___LOCAL_PLAYER__VARS__itmsk2, $___LOCAL_PLAYER__VARS__itm3,$___LOCAL_PLAYER__VARS__itmk3,$___LOCAL_PLAYER__VARS__itme3,$___LOCAL_PLAYER__VARS__itms3,$___LOCAL_PLAYER__VARS__itmsk3,$___LOCAL_PLAYER__VARS__itm4,$___LOCAL_PLAYER__VARS__itmk4,$___LOCAL_PLAYER__VARS__itme4,$___LOCAL_PLAYER__VARS__itms4,$___LOCAL_PLAYER__VARS__itmsk4, $___LOCAL_PLAYER__VARS__itm5,$___LOCAL_PLAYER__VARS__itmk5,$___LOCAL_PLAYER__VARS__itme5,$___LOCAL_PLAYER__VARS__itms5,$___LOCAL_PLAYER__VARS__itmsk5,$___LOCAL_PLAYER__VARS__itm6,$___LOCAL_PLAYER__VARS__itmk6,$___LOCAL_PLAYER__VARS__itme6,$___LOCAL_PLAYER__VARS__itms6,$___LOCAL_PLAYER__VARS__itmsk6, $___LOCAL_PLAYER__VARS__searchmemory,$___LOCAL_PLAYER__VARS__nskill,$___LOCAL_PLAYER__VARS__nskillpara; $ss=&$___LOCAL_PLAYER__VARS__ss; $db_player_structure=&$___LOCAL_PLAYER__VARS__db_player_structure; $db_player_structure_types=&$___LOCAL_PLAYER__VARS__db_player_structure_types; $gamedata=&$___LOCAL_PLAYER__VARS__gamedata; $cmd=&$___LOCAL_PLAYER__VARS__cmd; $main=&$___LOCAL_PLAYER__VARS__main; $sdata=&$___LOCAL_PLAYER__VARS__sdata; $fog=&$___LOCAL_PLAYER__VARS__fog; $upexp=&$___LOCAL_PLAYER__VARS__upexp; $lvlupexp=&$___LOCAL_PLAYER__VARS__lvlupexp;  $iconImg=&$___LOCAL_PLAYER__VARS__iconImg; $iconImgB=&$___LOCAL_PLAYER__VARS__iconImgB; $iconImgBwidth=&$___LOCAL_PLAYER__VARS__iconImgBwidth; $ardef=&$___LOCAL_PLAYER__VARS__ardef; $hpcolor=&$___LOCAL_PLAYER__VARS__hpcolor; $spcolor=&$___LOCAL_PLAYER__VARS__spcolor; $newhpimg=&$___LOCAL_PLAYER__VARS__newhpimg; $newspimg=&$___LOCAL_PLAYER__VARS__newspimg; $splt=&$___LOCAL_PLAYER__VARS__splt; $hplt=&$___LOCAL_PLAYER__VARS__hplt;  $tpldata=&$___LOCAL_PLAYER__VARS__tpldata; $icon_list=&$___LOCAL_PLAYER__VARS__icon_list; $icon_list_contents_to_frontend=&$___LOCAL_PLAYER__VARS__icon_list_contents_to_frontend; $typeinfo=&$___LOCAL_PLAYER__VARS__typeinfo; $killmsginfo=&$___LOCAL_PLAYER__VARS__killmsginfo; $lwinfo=&$___LOCAL_PLAYER__VARS__lwinfo; $sexinfo=&$___LOCAL_PLAYER__VARS__sexinfo; $equip_list=&$___LOCAL_PLAYER__VARS__equip_list; $battle_equip_list=&$___LOCAL_PLAYER__VARS__battle_equip_list; $pc_icon_range=&$___LOCAL_PLAYER__VARS__pc_icon_range;  $pid=&$___LOCAL_PLAYER__VARS__pid; $type=&$___LOCAL_PLAYER__VARS__type; $name=&$___LOCAL_PLAYER__VARS__name; $pass=&$___LOCAL_PLAYER__VARS__pass; $ip=&$___LOCAL_PLAYER__VARS__ip; $motto=&$___LOCAL_PLAYER__VARS__motto; $killmsg=&$___LOCAL_PLAYER__VARS__killmsg; $lastword=&$___LOCAL_PLAYER__VARS__lastword; $winner_flag=&$___LOCAL_PLAYER__VARS__winner_flag; $player_dead_flag=&$___LOCAL_PLAYER__VARS__player_dead_flag;  $corpse_clear_flag=&$___LOCAL_PLAYER__VARS__corpse_clear_flag; $gd=&$___LOCAL_PLAYER__VARS__gd; $sNo=&$___LOCAL_PLAYER__VARS__sNo; $club=&$___LOCAL_PLAYER__VARS__club; $validtime=&$___LOCAL_PLAYER__VARS__validtime; $endtime=&$___LOCAL_PLAYER__VARS__endtime; $cdsec=&$___LOCAL_PLAYER__VARS__cdsec; $cdmsec=&$___LOCAL_PLAYER__VARS__cdmsec; $cdtime=&$___LOCAL_PLAYER__VARS__cdtime; $action=&$___LOCAL_PLAYER__VARS__action;  $a_actionnum=&$___LOCAL_PLAYER__VARS__a_actionnum; $v_actionnum=&$___LOCAL_PLAYER__VARS__v_actionnum; $hp=&$___LOCAL_PLAYER__VARS__hp; $mhp=&$___LOCAL_PLAYER__VARS__mhp; $sp=&$___LOCAL_PLAYER__VARS__sp; $msp=&$___LOCAL_PLAYER__VARS__msp; $mss=&$___LOCAL_PLAYER__VARS__mss; $att=&$___LOCAL_PLAYER__VARS__att; $def=&$___LOCAL_PLAYER__VARS__def; $pls=&$___LOCAL_PLAYER__VARS__pls;  $lvl=&$___LOCAL_PLAYER__VARS__lvl; $exp=&$___LOCAL_PLAYER__VARS__exp; $money=&$___LOCAL_PLAYER__VARS__money; $rp=&$___LOCAL_PLAYER__VARS__rp; $bid=&$___LOCAL_PLAYER__VARS__bid; $inf=&$___LOCAL_PLAYER__VARS__inf; $rage=&$___LOCAL_PLAYER__VARS__rage; $pose=&$___LOCAL_PLAYER__VARS__pose; $tactic=&$___LOCAL_PLAYER__VARS__tactic; $killnum=&$___LOCAL_PLAYER__VARS__killnum;  $npckillnum=&$___LOCAL_PLAYER__VARS__npckillnum; $state=&$___LOCAL_PLAYER__VARS__state; $skillpoint=&$___LOCAL_PLAYER__VARS__skillpoint; $flare=&$___LOCAL_PLAYER__VARS__flare; $wp=&$___LOCAL_PLAYER__VARS__wp; $wk=&$___LOCAL_PLAYER__VARS__wk; $wg=&$___LOCAL_PLAYER__VARS__wg; $wc=&$___LOCAL_PLAYER__VARS__wc; $wd=&$___LOCAL_PLAYER__VARS__wd; $wf=&$___LOCAL_PLAYER__VARS__wf;  $icon=&$___LOCAL_PLAYER__VARS__icon; $teamID=&$___LOCAL_PLAYER__VARS__teamID; $teamPass=&$___LOCAL_PLAYER__VARS__teamPass; $card=&$___LOCAL_PLAYER__VARS__card; $cardname=&$___LOCAL_PLAYER__VARS__cardname; $wep=&$___LOCAL_PLAYER__VARS__wep; $wepk=&$___LOCAL_PLAYER__VARS__wepk; $wepe=&$___LOCAL_PLAYER__VARS__wepe; $weps=&$___LOCAL_PLAYER__VARS__weps; $wepsk=&$___LOCAL_PLAYER__VARS__wepsk;  $arb=&$___LOCAL_PLAYER__VARS__arb; $arbk=&$___LOCAL_PLAYER__VARS__arbk; $arbe=&$___LOCAL_PLAYER__VARS__arbe; $arbs=&$___LOCAL_PLAYER__VARS__arbs; $arbsk=&$___LOCAL_PLAYER__VARS__arbsk; $arh=&$___LOCAL_PLAYER__VARS__arh; $arhk=&$___LOCAL_PLAYER__VARS__arhk; $arhe=&$___LOCAL_PLAYER__VARS__arhe; $arhs=&$___LOCAL_PLAYER__VARS__arhs; $arhsk=&$___LOCAL_PLAYER__VARS__arhsk;  $ara=&$___LOCAL_PLAYER__VARS__ara; $arak=&$___LOCAL_PLAYER__VARS__arak; $arae=&$___LOCAL_PLAYER__VARS__arae; $aras=&$___LOCAL_PLAYER__VARS__aras; $arask=&$___LOCAL_PLAYER__VARS__arask; $arf=&$___LOCAL_PLAYER__VARS__arf; $arfk=&$___LOCAL_PLAYER__VARS__arfk; $arfe=&$___LOCAL_PLAYER__VARS__arfe; $arfs=&$___LOCAL_PLAYER__VARS__arfs; $arfsk=&$___LOCAL_PLAYER__VARS__arfsk;  $art=&$___LOCAL_PLAYER__VARS__art; $artk=&$___LOCAL_PLAYER__VARS__artk; $arte=&$___LOCAL_PLAYER__VARS__arte; $arts=&$___LOCAL_PLAYER__VARS__arts; $artsk=&$___LOCAL_PLAYER__VARS__artsk; $itm0=&$___LOCAL_PLAYER__VARS__itm0; $itmk0=&$___LOCAL_PLAYER__VARS__itmk0; $itme0=&$___LOCAL_PLAYER__VARS__itme0; $itms0=&$___LOCAL_PLAYER__VARS__itms0; $itmsk0=&$___LOCAL_PLAYER__VARS__itmsk0;  $itm1=&$___LOCAL_PLAYER__VARS__itm1; $itmk1=&$___LOCAL_PLAYER__VARS__itmk1; $itme1=&$___LOCAL_PLAYER__VARS__itme1; $itms1=&$___LOCAL_PLAYER__VARS__itms1; $itmsk1=&$___LOCAL_PLAYER__VARS__itmsk1; $itm2=&$___LOCAL_PLAYER__VARS__itm2; $itmk2=&$___LOCAL_PLAYER__VARS__itmk2; $itme2=&$___LOCAL_PLAYER__VARS__itme2; $itms2=&$___LOCAL_PLAYER__VARS__itms2; $itmsk2=&$___LOCAL_PLAYER__VARS__itmsk2;  $itm3=&$___LOCAL_PLAYER__VARS__itm3; $itmk3=&$___LOCAL_PLAYER__VARS__itmk3; $itme3=&$___LOCAL_PLAYER__VARS__itme3; $itms3=&$___LOCAL_PLAYER__VARS__itms3; $itmsk3=&$___LOCAL_PLAYER__VARS__itmsk3; $itm4=&$___LOCAL_PLAYER__VARS__itm4; $itmk4=&$___LOCAL_PLAYER__VARS__itmk4; $itme4=&$___LOCAL_PLAYER__VARS__itme4; $itms4=&$___LOCAL_PLAYER__VARS__itms4; $itmsk4=&$___LOCAL_PLAYER__VARS__itmsk4;  $itm5=&$___LOCAL_PLAYER__VARS__itm5; $itmk5=&$___LOCAL_PLAYER__VARS__itmk5; $itme5=&$___LOCAL_PLAYER__VARS__itme5; $itms5=&$___LOCAL_PLAYER__VARS__itms5; $itmsk5=&$___LOCAL_PLAYER__VARS__itmsk5; $itm6=&$___LOCAL_PLAYER__VARS__itm6; $itmk6=&$___LOCAL_PLAYER__VARS__itmk6; $itme6=&$___LOCAL_PLAYER__VARS__itme6; $itms6=&$___LOCAL_PLAYER__VARS__itms6; $itmsk6=&$___LOCAL_PLAYER__VARS__itmsk6;  $searchmemory=&$___LOCAL_PLAYER__VARS__searchmemory; $nskill=&$___LOCAL_PLAYER__VARS__nskill; $nskillpara=&$___LOCAL_PLAYER__VARS__nskillpara;  global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;  global $___LOCAL_SYS__VARS__url,$___LOCAL_SYS__VARS__gameover_plist,$___LOCAL_SYS__VARS__gameover_ulist,$___LOCAL_SYS__VARS__mode,$___LOCAL_SYS__VARS__command,$___LOCAL_SYS__VARS__db,$___LOCAL_SYS__VARS__plock,$___LOCAL_SYS__VARS__uip,$___LOCAL_SYS__VARS__cudata,$___LOCAL_SYS__VARS__disable_access, $___LOCAL_SYS__VARS__pdata_pool,$___LOCAL_SYS__VARS__pdata_origin_pool,$___LOCAL_SYS__VARS__pdata_lock_pool,$___LOCAL_SYS__VARS__udata_lock_pool,$___LOCAL_SYS__VARS__server_address,$___LOCAL_SYS__VARS__gameurl,$___LOCAL_SYS__VARS__database,$___LOCAL_SYS__VARS__dbcharset,$___LOCAL_SYS__VARS__dbhost,$___LOCAL_SYS__VARS__dbuser, $___LOCAL_SYS__VARS__dbpw,$___LOCAL_SYS__VARS__dbname,$___LOCAL_SYS__VARS__dbreport,$___LOCAL_SYS__VARS__cookiedomain,$___LOCAL_SYS__VARS__cookiepath,$___LOCAL_SYS__VARS__headercharset,$___LOCAL_SYS__VARS__onlinehold,$___LOCAL_SYS__VARS__pconnect,$___LOCAL_SYS__VARS__gamefounder,$___LOCAL_SYS__VARS__moveut, $___LOCAL_SYS__VARS__moveutmin,$___LOCAL_SYS__VARS__gtablepre,$___LOCAL_SYS__VARS__authkey,$___LOCAL_SYS__VARS__charset,$___LOCAL_SYS__VARS__tplrefresh,$___LOCAL_SYS__VARS__bbsurl,$___LOCAL_SYS__VARS__homepage,$___LOCAL_SYS__VARS__gtitle,$___LOCAL_SYS__VARS__nowep,$___LOCAL_SYS__VARS__noarb, $___LOCAL_SYS__VARS__noitm,$___LOCAL_SYS__VARS__nosta,$___LOCAL_SYS__VARS__nospk,$___LOCAL_SYS__VARS__mltwk,$___LOCAL_SYS__VARS__gstate,$___LOCAL_SYS__VARS__gwin,$___LOCAL_SYS__VARS__gtinfo,$___LOCAL_SYS__VARS__gtdesc,$___LOCAL_SYS__VARS__week,$___LOCAL_SYS__VARS__gamevarsinfo, $___LOCAL_SYS__VARS__stateinfo,$___LOCAL_SYS__VARS__dinfo,$___LOCAL_SYS__VARS__sexinfo,$___LOCAL_SYS__VARS__chatinfo,$___LOCAL_SYS__VARS__chatclass,$___LOCAL_SYS__VARS__emoticon_list,$___LOCAL_SYS__VARS__on_premise_chat,$___LOCAL_SYS__VARS___INFO,$___LOCAL_SYS__VARS___ERROR,$___LOCAL_SYS__VARS__disable_event, $___LOCAL_SYS__VARS__disable_newgame,$___LOCAL_SYS__VARS__disable_newroom,$___LOCAL_SYS__VARS__startmode,$___LOCAL_SYS__VARS__starthour,$___LOCAL_SYS__VARS__startmin,$___LOCAL_SYS__VARS__readymin,$___LOCAL_SYS__VARS__iplimit,$___LOCAL_SYS__VARS__iconlimit,$___LOCAL_SYS__VARS__newslimit,$___LOCAL_SYS__VARS__alivelimit, $___LOCAL_SYS__VARS__ranklimit,$___LOCAL_SYS__VARS__winlimit,$___LOCAL_SYS__VARS__winratemingames,$___LOCAL_SYS__VARS__chatlimit,$___LOCAL_SYS__VARS__chatrefresh,$___LOCAL_SYS__VARS__chatinnews,$___LOCAL_SYS__VARS__validlimit,$___LOCAL_SYS__VARS__splimit,$___LOCAL_SYS__VARS__hplimit,$___LOCAL_SYS__VARS__hack_obbs, $___LOCAL_SYS__VARS__checkstr,$___LOCAL_SYS__VARS__oldpswdcmp,$___LOCAL_SYS__VARS__allowcsscache,$___LOCAL_SYS__VARS__hnewsstorage,$___LOCAL_SYS__VARS__gamecfg,$___LOCAL_SYS__VARS__userdb_remote_storage,$___LOCAL_SYS__VARS__userdb_remote_storage_sign,$___LOCAL_SYS__VARS__userdb_remote_storage_pass,$___LOCAL_SYS__VARS__userdb_receive_list,$___LOCAL_SYS__VARS__replay_remote_storage, $___LOCAL_SYS__VARS__replay_remote_send,$___LOCAL_SYS__VARS__replay_remote_storage_sign,$___LOCAL_SYS__VARS__replay_remote_storage_key,$___LOCAL_SYS__VARS__replay_receive_list,$___LOCAL_SYS__VARS__room_mode,$___LOCAL_SYS__VARS__teamwin_mode,$___LOCAL_SYS__VARS__qiegao_ignore_mode,$___LOCAL_SYS__VARS__elorated_mode,$___LOCAL_SYS__VARS__pve_ignore_mode,$___LOCAL_SYS__VARS__replay_ignore_mode, $___LOCAL_SYS__VARS__gameversion,$___LOCAL_SYS__VARS__gamecredits,$___LOCAL_SYS__VARS__tablepre,$___LOCAL_SYS__VARS__wtablepre,$___LOCAL_SYS__VARS__ctablepre,$___LOCAL_SYS__VARS__room_prefix,$___LOCAL_SYS__VARS__room_id,$___LOCAL_SYS__VARS__u_templateid,$___LOCAL_SYS__VARS__new_messages,$___LOCAL_SYS__VARS__acbra2_user, $___LOCAL_SYS__VARS__acbra2_pass,$___LOCAL_SYS__VARS__error,$___LOCAL_SYS__VARS__now,$___LOCAL_SYS__VARS__sec,$___LOCAL_SYS__VARS__min,$___LOCAL_SYS__VARS__hour,$___LOCAL_SYS__VARS__day,$___LOCAL_SYS__VARS__month,$___LOCAL_SYS__VARS__year,$___LOCAL_SYS__VARS__wday, $___LOCAL_SYS__VARS__userdb_forced_local,$___LOCAL_SYS__VARS__userdb_forced_key,$___LOCAL_SYS__VARS__gameinfo,$___LOCAL_SYS__VARS__gamenum,$___LOCAL_SYS__VARS__gametype,$___LOCAL_SYS__VARS__gamestate,$___LOCAL_SYS__VARS__groomid,$___LOCAL_SYS__VARS__groomtype,$___LOCAL_SYS__VARS__groomstatus,$___LOCAL_SYS__VARS__starttime, $___LOCAL_SYS__VARS__afktime,$___LOCAL_SYS__VARS__validnum,$___LOCAL_SYS__VARS__alivenum,$___LOCAL_SYS__VARS__deathnum,$___LOCAL_SYS__VARS__combonum,$___LOCAL_SYS__VARS__weather,$___LOCAL_SYS__VARS__hack,$___LOCAL_SYS__VARS__hdamage,$___LOCAL_SYS__VARS__hplayer,$___LOCAL_SYS__VARS__winmode, $___LOCAL_SYS__VARS__winner,$___LOCAL_SYS__VARS__areanum,$___LOCAL_SYS__VARS__areatime,$___LOCAL_SYS__VARS__areawarn,$___LOCAL_SYS__VARS__arealist,$___LOCAL_SYS__VARS__noisevars,$___LOCAL_SYS__VARS__roomvars,$___LOCAL_SYS__VARS__gamevars,$___LOCAL_SYS__VARS__cuser,$___LOCAL_SYS__VARS__cpass, $___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode,$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command; $url=&$___LOCAL_SYS__VARS__url; $gameover_plist=&$___LOCAL_SYS__VARS__gameover_plist; $gameover_ulist=&$___LOCAL_SYS__VARS__gameover_ulist; $mode=&$___LOCAL_SYS__VARS__mode; $command=&$___LOCAL_SYS__VARS__command; $db=&$___LOCAL_SYS__VARS__db; $plock=&$___LOCAL_SYS__VARS__plock; $uip=&$___LOCAL_SYS__VARS__uip; $cudata=&$___LOCAL_SYS__VARS__cudata; $disable_access=&$___LOCAL_SYS__VARS__disable_access;  $pdata_pool=&$___LOCAL_SYS__VARS__pdata_pool; $pdata_origin_pool=&$___LOCAL_SYS__VARS__pdata_origin_pool; $pdata_lock_pool=&$___LOCAL_SYS__VARS__pdata_lock_pool; $udata_lock_pool=&$___LOCAL_SYS__VARS__udata_lock_pool; $server_address=&$___LOCAL_SYS__VARS__server_address; $gameurl=&$___LOCAL_SYS__VARS__gameurl; $database=&$___LOCAL_SYS__VARS__database; $dbcharset=&$___LOCAL_SYS__VARS__dbcharset; $dbhost=&$___LOCAL_SYS__VARS__dbhost; $dbuser=&$___LOCAL_SYS__VARS__dbuser;  $dbpw=&$___LOCAL_SYS__VARS__dbpw; $dbname=&$___LOCAL_SYS__VARS__dbname; $dbreport=&$___LOCAL_SYS__VARS__dbreport; $cookiedomain=&$___LOCAL_SYS__VARS__cookiedomain; $cookiepath=&$___LOCAL_SYS__VARS__cookiepath; $headercharset=&$___LOCAL_SYS__VARS__headercharset; $onlinehold=&$___LOCAL_SYS__VARS__onlinehold; $pconnect=&$___LOCAL_SYS__VARS__pconnect; $gamefounder=&$___LOCAL_SYS__VARS__gamefounder; $moveut=&$___LOCAL_SYS__VARS__moveut;  $moveutmin=&$___LOCAL_SYS__VARS__moveutmin; $gtablepre=&$___LOCAL_SYS__VARS__gtablepre; $authkey=&$___LOCAL_SYS__VARS__authkey; $charset=&$___LOCAL_SYS__VARS__charset; $tplrefresh=&$___LOCAL_SYS__VARS__tplrefresh; $bbsurl=&$___LOCAL_SYS__VARS__bbsurl; $homepage=&$___LOCAL_SYS__VARS__homepage; $gtitle=&$___LOCAL_SYS__VARS__gtitle; $nowep=&$___LOCAL_SYS__VARS__nowep; $noarb=&$___LOCAL_SYS__VARS__noarb;  $noitm=&$___LOCAL_SYS__VARS__noitm; $nosta=&$___LOCAL_SYS__VARS__nosta; $nospk=&$___LOCAL_SYS__VARS__nospk; $mltwk=&$___LOCAL_SYS__VARS__mltwk; $gstate=&$___LOCAL_SYS__VARS__gstate; $gwin=&$___LOCAL_SYS__VARS__gwin; $gtinfo=&$___LOCAL_SYS__VARS__gtinfo; $gtdesc=&$___LOCAL_SYS__VARS__gtdesc; $week=&$___LOCAL_SYS__VARS__week; $gamevarsinfo=&$___LOCAL_SYS__VARS__gamevarsinfo;  $stateinfo=&$___LOCAL_SYS__VARS__stateinfo; $dinfo=&$___LOCAL_SYS__VARS__dinfo; $sexinfo=&$___LOCAL_SYS__VARS__sexinfo; $chatinfo=&$___LOCAL_SYS__VARS__chatinfo; $chatclass=&$___LOCAL_SYS__VARS__chatclass; $emoticon_list=&$___LOCAL_SYS__VARS__emoticon_list; $on_premise_chat=&$___LOCAL_SYS__VARS__on_premise_chat; $_INFO=&$___LOCAL_SYS__VARS___INFO; $_ERROR=&$___LOCAL_SYS__VARS___ERROR; $disable_event=&$___LOCAL_SYS__VARS__disable_event;  $disable_newgame=&$___LOCAL_SYS__VARS__disable_newgame; $disable_newroom=&$___LOCAL_SYS__VARS__disable_newroom; $startmode=&$___LOCAL_SYS__VARS__startmode; $starthour=&$___LOCAL_SYS__VARS__starthour; $startmin=&$___LOCAL_SYS__VARS__startmin; $readymin=&$___LOCAL_SYS__VARS__readymin; $iplimit=&$___LOCAL_SYS__VARS__iplimit; $iconlimit=&$___LOCAL_SYS__VARS__iconlimit; $newslimit=&$___LOCAL_SYS__VARS__newslimit; $alivelimit=&$___LOCAL_SYS__VARS__alivelimit;  $ranklimit=&$___LOCAL_SYS__VARS__ranklimit; $winlimit=&$___LOCAL_SYS__VARS__winlimit; $winratemingames=&$___LOCAL_SYS__VARS__winratemingames; $chatlimit=&$___LOCAL_SYS__VARS__chatlimit; $chatrefresh=&$___LOCAL_SYS__VARS__chatrefresh; $chatinnews=&$___LOCAL_SYS__VARS__chatinnews; $validlimit=&$___LOCAL_SYS__VARS__validlimit; $splimit=&$___LOCAL_SYS__VARS__splimit; $hplimit=&$___LOCAL_SYS__VARS__hplimit; $hack_obbs=&$___LOCAL_SYS__VARS__hack_obbs;  $checkstr=&$___LOCAL_SYS__VARS__checkstr; $oldpswdcmp=&$___LOCAL_SYS__VARS__oldpswdcmp; $allowcsscache=&$___LOCAL_SYS__VARS__allowcsscache; $hnewsstorage=&$___LOCAL_SYS__VARS__hnewsstorage; $gamecfg=&$___LOCAL_SYS__VARS__gamecfg; $userdb_remote_storage=&$___LOCAL_SYS__VARS__userdb_remote_storage; $userdb_remote_storage_sign=&$___LOCAL_SYS__VARS__userdb_remote_storage_sign; $userdb_remote_storage_pass=&$___LOCAL_SYS__VARS__userdb_remote_storage_pass; $userdb_receive_list=&$___LOCAL_SYS__VARS__userdb_receive_list; $replay_remote_storage=&$___LOCAL_SYS__VARS__replay_remote_storage;  $replay_remote_send=&$___LOCAL_SYS__VARS__replay_remote_send; $replay_remote_storage_sign=&$___LOCAL_SYS__VARS__replay_remote_storage_sign; $replay_remote_storage_key=&$___LOCAL_SYS__VARS__replay_remote_storage_key; $replay_receive_list=&$___LOCAL_SYS__VARS__replay_receive_list; $room_mode=&$___LOCAL_SYS__VARS__room_mode; $teamwin_mode=&$___LOCAL_SYS__VARS__teamwin_mode; $qiegao_ignore_mode=&$___LOCAL_SYS__VARS__qiegao_ignore_mode; $elorated_mode=&$___LOCAL_SYS__VARS__elorated_mode; $pve_ignore_mode=&$___LOCAL_SYS__VARS__pve_ignore_mode; $replay_ignore_mode=&$___LOCAL_SYS__VARS__replay_ignore_mode;  $gameversion=&$___LOCAL_SYS__VARS__gameversion; $gamecredits=&$___LOCAL_SYS__VARS__gamecredits; $tablepre=&$___LOCAL_SYS__VARS__tablepre; $wtablepre=&$___LOCAL_SYS__VARS__wtablepre; $ctablepre=&$___LOCAL_SYS__VARS__ctablepre; $room_prefix=&$___LOCAL_SYS__VARS__room_prefix; $room_id=&$___LOCAL_SYS__VARS__room_id; $u_templateid=&$___LOCAL_SYS__VARS__u_templateid; $new_messages=&$___LOCAL_SYS__VARS__new_messages; $acbra2_user=&$___LOCAL_SYS__VARS__acbra2_user;  $acbra2_pass=&$___LOCAL_SYS__VARS__acbra2_pass; $error=&$___LOCAL_SYS__VARS__error; $now=&$___LOCAL_SYS__VARS__now; $sec=&$___LOCAL_SYS__VARS__sec; $min=&$___LOCAL_SYS__VARS__min; $hour=&$___LOCAL_SYS__VARS__hour; $day=&$___LOCAL_SYS__VARS__day; $month=&$___LOCAL_SYS__VARS__month; $year=&$___LOCAL_SYS__VARS__year; $wday=&$___LOCAL_SYS__VARS__wday;  $userdb_forced_local=&$___LOCAL_SYS__VARS__userdb_forced_local; $userdb_forced_key=&$___LOCAL_SYS__VARS__userdb_forced_key; $gameinfo=&$___LOCAL_SYS__VARS__gameinfo; $gamenum=&$___LOCAL_SYS__VARS__gamenum; $gametype=&$___LOCAL_SYS__VARS__gametype; $gamestate=&$___LOCAL_SYS__VARS__gamestate; $groomid=&$___LOCAL_SYS__VARS__groomid; $groomtype=&$___LOCAL_SYS__VARS__groomtype; $groomstatus=&$___LOCAL_SYS__VARS__groomstatus; $starttime=&$___LOCAL_SYS__VARS__starttime;  $afktime=&$___LOCAL_SYS__VARS__afktime; $validnum=&$___LOCAL_SYS__VARS__validnum; $alivenum=&$___LOCAL_SYS__VARS__alivenum; $deathnum=&$___LOCAL_SYS__VARS__deathnum; $combonum=&$___LOCAL_SYS__VARS__combonum; $weather=&$___LOCAL_SYS__VARS__weather; $hack=&$___LOCAL_SYS__VARS__hack; $hdamage=&$___LOCAL_SYS__VARS__hdamage; $hplayer=&$___LOCAL_SYS__VARS__hplayer; $winmode=&$___LOCAL_SYS__VARS__winmode;  $winner=&$___LOCAL_SYS__VARS__winner; $areanum=&$___LOCAL_SYS__VARS__areanum; $areatime=&$___LOCAL_SYS__VARS__areatime; $areawarn=&$___LOCAL_SYS__VARS__areawarn; $arealist=&$___LOCAL_SYS__VARS__arealist; $noisevars=&$___LOCAL_SYS__VARS__noisevars; $roomvars=&$___LOCAL_SYS__VARS__roomvars; $gamevars=&$___LOCAL_SYS__VARS__gamevars; $cuser=&$___LOCAL_SYS__VARS__cuser; $cpass=&$___LOCAL_SYS__VARS__cpass;  $___LOCAL_INPUT__VARS__mode=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__mode; $___LOCAL_INPUT__VARS__command=&$___LOCAL_SYS__VARS_____LOCAL_INPUT__VARS__command;  global $___LOCAL_SKILL272__VARS__skill272_cd,$___LOCAL_SKILL272__VARS__skill272_act_time,$___LOCAL_SKILL272__VARS__skill272_factor,$___LOCAL_SKILL272__VARS__skill272_pos_list,$___LOCAL_SKILL272__VARS__skill272_itmsk_cube; $skill272_cd=&$___LOCAL_SKILL272__VARS__skill272_cd; $skill272_act_time=&$___LOCAL_SKILL272__VARS__skill272_act_time; $skill272_factor=&$___LOCAL_SKILL272__VARS__skill272_factor; $skill272_pos_list=&$___LOCAL_SKILL272__VARS__skill272_pos_list; $skill272_itmsk_cube=&$___LOCAL_SKILL272__VARS__skill272_itmsk_cube;   } while (0);
		\player\update_sdata();

		
		list($can_activate, $fail_hint) = \bufficons\bufficons_check_buff_state_shell(272);
		if(!$can_activate) {
			$log .= $fail_hint;
			return;
		}
		
		$effect_list = create_effect_list272();
		
		if(!check_valid_single272($ipos, 0, $effect_list)){
			$mode = 'command';
			return;
		}
		$itm = &${$ipos};
		if(strpos($ipos, 'itm')===0) {
			$itmsk=&${'itmsk'.substr($ipos,3,1)};
		}else{
			$itmsk=&${$ipos.'sk'};
		}
		
		list($effect_num, $itmsk_after, $affected_arr) = check_skill272num_single($itmsk, $effect_list);
		if(!$effect_num) {
			$log.='该道具没有任何可以吸收的属性。<br>';
			$mode = 'command';
			return;
		}
		$itmsk = $itmsk_after;
		$skill272_real_cd = \skillbase\skill_getvalue(272,'lvl') ? 0 : $skill272_cd;
		$flag = \bufficons\bufficons_set_timestamp(272, $skill272_act_time, $skill272_real_cd);
		if(!$flag) {
			$log.='发动失败！<br>';
			return;
		}
		\skillbase\skill_setvalue(272,'num',$effect_num);
		addnews ( 0, 'bskill272', $name );
		do { global $___LOCAL_SKILL272__VARS__skill272_cd,$___LOCAL_SKILL272__VARS__skill272_act_time,$___LOCAL_SKILL272__VARS__skill272_factor,$___LOCAL_SKILL272__VARS__skill272_pos_list,$___LOCAL_SKILL272__VARS__skill272_itmsk_cube; $skill272_cd=&$___LOCAL_SKILL272__VARS__skill272_cd; $skill272_act_time=&$___LOCAL_SKILL272__VARS__skill272_act_time; $skill272_factor=&$___LOCAL_SKILL272__VARS__skill272_factor; $skill272_pos_list=&$___LOCAL_SKILL272__VARS__skill272_pos_list; $skill272_itmsk_cube=&$___LOCAL_SKILL272__VARS__skill272_itmsk_cube;  global $___LOCAL_ITEMMAIN__VARS__tmp_itmsk_arr_pool,$___LOCAL_ITEMMAIN__VARS__itemfind_extra_log,$___LOCAL_ITEMMAIN__VARS__item_equip_list,$___LOCAL_ITEMMAIN__VARS__item_hotkey_id_list,$___LOCAL_ITEMMAIN__VARS__itemmain_drophint,$___LOCAL_ITEMMAIN__VARS__item_allow_find_and_use,$___LOCAL_ITEMMAIN__VARS__nosta,$___LOCAL_ITEMMAIN__VARS__nospk,$___LOCAL_ITEMMAIN__VARS__item_obbs,$___LOCAL_ITEMMAIN__VARS__map_noitemdrop_arealist, $___LOCAL_ITEMMAIN__VARS__itemkind_equipable,$___LOCAL_ITEMMAIN__VARS__iteminfo,$___LOCAL_ITEMMAIN__VARS__itemspkinfo,$___LOCAL_ITEMMAIN__VARS__itemspkdesc,$___LOCAL_ITEMMAIN__VARS__itemspkdesc_help,$___LOCAL_ITEMMAIN__VARS__itemspkremark; $tmp_itmsk_arr_pool=&$___LOCAL_ITEMMAIN__VARS__tmp_itmsk_arr_pool; $itemfind_extra_log=&$___LOCAL_ITEMMAIN__VARS__itemfind_extra_log; $item_equip_list=&$___LOCAL_ITEMMAIN__VARS__item_equip_list; $item_hotkey_id_list=&$___LOCAL_ITEMMAIN__VARS__item_hotkey_id_list; $itemmain_drophint=&$___LOCAL_ITEMMAIN__VARS__itemmain_drophint; $item_allow_find_and_use=&$___LOCAL_ITEMMAIN__VARS__item_allow_find_and_use; $nosta=&$___LOCAL_ITEMMAIN__VARS__nosta; $nospk=&$___LOCAL_ITEMMAIN__VARS__nospk; $item_obbs=&$___LOCAL_ITEMMAIN__VARS__item_obbs; $map_noitemdrop_arealist=&$___LOCAL_ITEMMAIN__VARS__map_noitemdrop_arealist;  $itemkind_equipable=&$___LOCAL_ITEMMAIN__VARS__itemkind_equipable; $iteminfo=&$___LOCAL_ITEMMAIN__VARS__iteminfo; $itemspkinfo=&$___LOCAL_ITEMMAIN__VARS__itemspkinfo; $itemspkdesc=&$___LOCAL_ITEMMAIN__VARS__itemspkdesc; $itemspkdesc_help=&$___LOCAL_ITEMMAIN__VARS__itemspkdesc_help; $itemspkremark=&$___LOCAL_ITEMMAIN__VARS__itemspkremark;   } while (0);
		$tmp_list='';
		$cubes = array();
		foreach($affected_arr as $eval){
			$tmp_list.=$itemspkinfo[$eval].'+';
			
			if (rand(0,99) < 30)
			{
				$citm = $skill272_itmsk_cube[$eval];
				$cubes[] = $citm;
				$dropid = \itemmain\itemdrop_query($citm, 'X', 1, 1, '', $pls);
				$amarr = array('iid' => $dropid, 'itm' => $citm, 'pls' => $pls, 'unseen' => 0);
				\skill1006\add_beacon($amarr, $sdata);
			}
		}
		$clv = (int)\skillbase\skill_getvalue(272,'lvl',$sdata);
		if (!$clv)
		{
			$ucount = (int)\skillbase\skill_getvalue(272,'unlockcount',$sdata);
			$ucount += count($affected_arr);
			if ($ucount >= 12)
			{
				$log .= "<span class=\"yellow b\">你可以更熟练地使用「吸光」了。</span><br><br>";
				\skillbase\skill_setvalue(272,'lvl',1,$sdata);
			}
			else \skillbase\skill_setvalue(272,'unlockcount',$ucount,$sdata);
		}
		$extrac_rate = $clv ? 20 : 5;
		if (rand(0,99) < $extrac_rate)
		{
			$citm = array_randompick(array('X方块','X方块','Y方块','Y方块','黄鸡方块'));
			$cubes[] = $citm;
			$dropid = \itemmain\itemdrop_query($citm, 'X', 1, 1, '', $pls);
			$amarr = array('iid' => $dropid, 'itm' => $citm, 'pls' => $pls, 'unseen' => 0);
			\skill1006\add_beacon($amarr, $sdata);
		}
		if(!empty($tmp_list)) $tmp_list = str_replace('+','、',substr($tmp_list,0,-1));
		
		$log.='<span class="lime b">技能「吸光」发动成功。</span><br>你将'.$itm.'上的'.$tmp_list.'属性化为了自己的力量！<br>效果时间内，你的属性伤害将<span class="cyan b">增加'.($skill272_factor*$effect_num).'%</span>。<br>';
		if(!empty($cubes)) {
			$cube_count = count($cubes);
			if ($cube_count > 1) $cube_txt = implode('、', array_slice($cubes, 0, $cube_count - 1)).'和'.end($cubes);
			else $cube_txt = $cubes[0];
			$log .= "<span class=\"yellow b\">$cube_txt</span>在光芒中凝结而成，掉在了你的身旁。<br>";
		}
		$mode = 'command';
		return;
	}
	
	
	function check_skill272_state(&$pa){
		
		return \bufficons\bufficons_check_buff_state(272,$pa);
	}
	
	function calculate_ex_attack_dmg_multiplier(&$pa, &$pd, $active)
	{
		
		$r=Array();
		if (1==\skill272\check_skill272_state ($pa))
		{
			do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;  global $___LOCAL_SKILL272__VARS__skill272_cd,$___LOCAL_SKILL272__VARS__skill272_act_time,$___LOCAL_SKILL272__VARS__skill272_factor,$___LOCAL_SKILL272__VARS__skill272_pos_list,$___LOCAL_SKILL272__VARS__skill272_itmsk_cube; $skill272_cd=&$___LOCAL_SKILL272__VARS__skill272_cd; $skill272_act_time=&$___LOCAL_SKILL272__VARS__skill272_act_time; $skill272_factor=&$___LOCAL_SKILL272__VARS__skill272_factor; $skill272_pos_list=&$___LOCAL_SKILL272__VARS__skill272_pos_list; $skill272_itmsk_cube=&$___LOCAL_SKILL272__VARS__skill272_itmsk_cube;   } while (0);
			$effect = $skill272_factor * \skillbase\skill_getvalue(272,'num',$pa);
			if(empty($pa['skill272_log'])){
				$log .= \battle\battlelog_parser($pa, $pd, $active, '<span class="yellow b">「吸光」使<:pa_name:>的属性伤害增强了'.$effect.'%！</span><br>');
				$pa['skill272_log'] = 1;
			}
			$r[] = 1 + $effect / 100;
		}
if(isset($active)) {$__VAR_DUMP_MOD_skill272_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill272_VARS_active = NULL;} if(isset($r)) {$__VAR_DUMP_MOD_skill272_VARS_r = $r; unset($r); } else {$__VAR_DUMP_MOD_skill272_VARS_r = NULL;} 
		//======== Start of contents from mod skill90 ========
		do{
			$___TMP_MOD_skill90_FUNC_calculate_ex_attack_dmg_multiplier_RET = NULL;

		
		$r = array();
		if ($pa['bskill']==90)
		{
			do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
			$skill90_exdmggain = \skill90\get_skill90_extra_dmg_gain ($pa, $pd, $active);
			if ($active)
				$log .= "<span class=\"lime b\">「安魂」使你造成的属性伤害增加了{$skill90_exdmggain}%！</span><br>";
			else  $log .= "<span class=\"lime b\">「安魂」使敌人造成的属性伤害增加了{$skill90_exdmggain}%！</span><br>";
			$r[] = 1 + $skill90_exdmggain / 100;
		}
if(isset($active)) {$__VAR_DUMP_MOD_skill90_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill90_VARS_active = NULL;} if(isset($r)) {$__VAR_DUMP_MOD_skill90_VARS_r = $r; unset($r); } else {$__VAR_DUMP_MOD_skill90_VARS_r = NULL;} 
		//======== Start of contents from mod skill524 ========
		do{
			$___TMP_MOD_skill524_FUNC_calculate_ex_attack_dmg_multiplier_RET = NULL;

		

		$r=Array();
		if (\skillbase\skill_query(524,$pd) && \skill524\check_unlocked524 ($pd) && (( strstr($pa['wepsk'], 'i') != '') || strstr($pa['wepsk'], 'k'))){
			$r = Array(4);
		}
if(isset($active)) {$__VAR_DUMP_MOD_skill524_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill524_VARS_active = NULL;} if(isset($r)) {$__VAR_DUMP_MOD_skill524_VARS_r = $r; unset($r); } else {$__VAR_DUMP_MOD_skill524_VARS_r = NULL;} 
		//======== Start of contents from mod skill523 ========
		do{
			$___TMP_MOD_skill523_FUNC_calculate_ex_attack_dmg_multiplier_RET = NULL;

		

		$r=Array();
		if (\skillbase\skill_query(523,$pd) && \skill523\check_unlocked523 ($pd) &&(( strstr($pa['wepsk'], 'u') != '') || strstr($pa['wepsk'], 'f'))){
			$r = Array(4);
		}
if(isset($active)) {$__VAR_DUMP_MOD_skill523_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill523_VARS_active = NULL;} if(isset($r)) {$__VAR_DUMP_MOD_skill523_VARS_r = $r; unset($r); } else {$__VAR_DUMP_MOD_skill523_VARS_r = NULL;} 
		//======== Start of contents from mod skill522 ========
		do{
			$___TMP_MOD_skill522_FUNC_calculate_ex_attack_dmg_multiplier_RET = NULL;

		

		$r=Array();
		if (\skillbase\skill_query(522,$pd) && \skill522\check_unlocked522 ($pd) &&( strstr($pa['wepsk'], 'e') != '')){
			$r = Array(4);
		}
if(isset($active)) {$__VAR_DUMP_MOD_skill522_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill522_VARS_active = NULL;} if(isset($r)) {$__VAR_DUMP_MOD_skill522_VARS_r = $r; unset($r); } else {$__VAR_DUMP_MOD_skill522_VARS_r = NULL;} 
		//======== Start of contents from mod skill521 ========
		do{
			$___TMP_MOD_skill521_FUNC_calculate_ex_attack_dmg_multiplier_RET = NULL;

		

		$r=Array();
		if (\skillbase\skill_query(521,$pd) && \skill521\check_unlocked521 ($pd) &&( strstr($pa['wepsk'], 'p') != '')){
			$r = Array(12);
		}
if(isset($active)) {$__VAR_DUMP_MOD_skill521_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill521_VARS_active = NULL;} if(isset($r)) {$__VAR_DUMP_MOD_skill521_VARS_r = $r; unset($r); } else {$__VAR_DUMP_MOD_skill521_VARS_r = NULL;} 
		//======== Start of contents from mod skill205 ========
		do{
			$___TMP_MOD_skill205_FUNC_calculate_ex_attack_dmg_multiplier_RET = NULL;

		
		$r = Array();
		if ($pa['bskill']==205) 
		{
			$r[] = 1.8;
		}
if(isset($active)) {$__VAR_DUMP_MOD_skill205_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill205_VARS_active = NULL;} if(isset($r)) {$__VAR_DUMP_MOD_skill205_VARS_r = $r; unset($r); } else {$__VAR_DUMP_MOD_skill205_VARS_r = NULL;} 
		//======== Start of contents from mod skill54 ========
		do{
			$___TMP_MOD_skill54_FUNC_calculate_ex_attack_dmg_multiplier_RET = NULL;

		
		$r=Array();
		if (\skillbase\skill_query(54,$pd) && \skill54\check_unlocked54 ($pd)) 
		{
			do { global $___LOCAL_SKILL54__VARS__upgradecost,$___LOCAL_SKILL54__VARS__dmgreduction; $upgradecost=&$___LOCAL_SKILL54__VARS__upgradecost; $dmgreduction=&$___LOCAL_SKILL54__VARS__dmgreduction;   } while (0);
			$clv = \skillbase\skill_getvalue(54,'lvl',$pd);
			$clv = (int)$clv;
			$r=Array(1-$dmgreduction[$clv]/100);
		}
if(isset($active)) {$__VAR_DUMP_MOD_skill54_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill54_VARS_active = NULL;} if(isset($r)) {$__VAR_DUMP_MOD_skill54_VARS_r = $r; unset($r); } else {$__VAR_DUMP_MOD_skill54_VARS_r = NULL;} 
		//======== Start of contents from mod skill25 ========
		do{
			$___TMP_MOD_skill25_FUNC_calculate_ex_attack_dmg_multiplier_RET = NULL;

		
		$r=Array();
		if (\skillbase\skill_query(25,$pa) && \skill25\check_unlocked25 ($pa))
		{
			$r=Array(1.25);
		}
if(isset($active)) {$__VAR_DUMP_MOD_skill25_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill25_VARS_active = NULL;} if(isset($r)) {$__VAR_DUMP_MOD_skill25_VARS_r = $r; unset($r); } else {$__VAR_DUMP_MOD_skill25_VARS_r = NULL;} 
		//======== Start of contents from mod skill217 ========
		do{
			$___TMP_MOD_skill217_FUNC_calculate_ex_attack_dmg_multiplier_RET = NULL;

		
		$r = Array();
		if (\skillbase\skill_query(217,$pa) && \skill217\check_unlocked217 ($pa))
		{
			$r[] = \skill217\get_skill217_extra_dmg_gain ($pa, $pd, $active);
		}
if(isset($active)) {$__VAR_DUMP_MOD_skill217_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill217_VARS_active = NULL;} 
		//======== Start of contents from mod ex_dmg_att ========
		do{
			$___TMP_MOD_ex_dmg_att_FUNC_calculate_ex_attack_dmg_multiplier_RET = NULL;

		
		$___TMP_MOD_ex_dmg_att_FUNC_calculate_ex_attack_dmg_multiplier_RET =  Array();
			break; 
		}while(0);
		//======== End of contents from mod ex_dmg_att ========

$active = $__VAR_DUMP_MOD_skill217_VARS_active; unset($__VAR_DUMP_MOD_skill217_VARS_active);
		$___TMP_MOD_skill217_FUNC_calculate_ex_attack_dmg_multiplier_RET =  array_merge($r,$___TMP_MOD_ex_dmg_att_FUNC_calculate_ex_attack_dmg_multiplier_RET);
			break; 
		}while(0);
		//======== End of contents from mod skill217 ========

$active = $__VAR_DUMP_MOD_skill25_VARS_active; unset($__VAR_DUMP_MOD_skill25_VARS_active);$r = $__VAR_DUMP_MOD_skill25_VARS_r; 
		$___TMP_MOD_skill25_FUNC_calculate_ex_attack_dmg_multiplier_RET =  array_merge($r,$___TMP_MOD_skill217_FUNC_calculate_ex_attack_dmg_multiplier_RET);
			break; 
		}while(0);
		//======== End of contents from mod skill25 ========

$active = $__VAR_DUMP_MOD_skill54_VARS_active; unset($__VAR_DUMP_MOD_skill54_VARS_active);$r = $__VAR_DUMP_MOD_skill54_VARS_r; 
		$___TMP_MOD_skill54_FUNC_calculate_ex_attack_dmg_multiplier_RET =  array_merge($r,$___TMP_MOD_skill25_FUNC_calculate_ex_attack_dmg_multiplier_RET);
			break; 
		}while(0);
		//======== End of contents from mod skill54 ========

$active = $__VAR_DUMP_MOD_skill205_VARS_active; unset($__VAR_DUMP_MOD_skill205_VARS_active);$r = $__VAR_DUMP_MOD_skill205_VARS_r; 
		$___TMP_MOD_skill205_FUNC_calculate_ex_attack_dmg_multiplier_RET =  array_merge($r,$___TMP_MOD_skill54_FUNC_calculate_ex_attack_dmg_multiplier_RET);
			break; 
		}while(0);
		//======== End of contents from mod skill205 ========

$active = $__VAR_DUMP_MOD_skill521_VARS_active; unset($__VAR_DUMP_MOD_skill521_VARS_active);$r = $__VAR_DUMP_MOD_skill521_VARS_r; 

		$___TMP_MOD_skill521_FUNC_calculate_ex_attack_dmg_multiplier_RET =  array_merge($r,$___TMP_MOD_skill205_FUNC_calculate_ex_attack_dmg_multiplier_RET);
			break; 
		}while(0);
		//======== End of contents from mod skill521 ========

$active = $__VAR_DUMP_MOD_skill522_VARS_active; unset($__VAR_DUMP_MOD_skill522_VARS_active);$r = $__VAR_DUMP_MOD_skill522_VARS_r; 

		$___TMP_MOD_skill522_FUNC_calculate_ex_attack_dmg_multiplier_RET =  array_merge($r,$___TMP_MOD_skill521_FUNC_calculate_ex_attack_dmg_multiplier_RET);
			break; 
		}while(0);
		//======== End of contents from mod skill522 ========

$active = $__VAR_DUMP_MOD_skill523_VARS_active; unset($__VAR_DUMP_MOD_skill523_VARS_active);$r = $__VAR_DUMP_MOD_skill523_VARS_r; 

		$___TMP_MOD_skill523_FUNC_calculate_ex_attack_dmg_multiplier_RET =  array_merge($r,$___TMP_MOD_skill522_FUNC_calculate_ex_attack_dmg_multiplier_RET);
			break; 
		}while(0);
		//======== End of contents from mod skill523 ========

$active = $__VAR_DUMP_MOD_skill524_VARS_active; unset($__VAR_DUMP_MOD_skill524_VARS_active);$r = $__VAR_DUMP_MOD_skill524_VARS_r; 

		$___TMP_MOD_skill524_FUNC_calculate_ex_attack_dmg_multiplier_RET =  array_merge($r,$___TMP_MOD_skill523_FUNC_calculate_ex_attack_dmg_multiplier_RET);
			break; 
		}while(0);
		//======== End of contents from mod skill524 ========

$active = $__VAR_DUMP_MOD_skill90_VARS_active; unset($__VAR_DUMP_MOD_skill90_VARS_active);$r = $__VAR_DUMP_MOD_skill90_VARS_r; 
		$___TMP_MOD_skill90_FUNC_calculate_ex_attack_dmg_multiplier_RET =  array_merge($r,$___TMP_MOD_skill524_FUNC_calculate_ex_attack_dmg_multiplier_RET);
			break; 
		}while(0);
		//======== End of contents from mod skill90 ========

$active = $__VAR_DUMP_MOD_skill272_VARS_active; unset($__VAR_DUMP_MOD_skill272_VARS_active);$r = $__VAR_DUMP_MOD_skill272_VARS_r; 
		return array_merge($r,$___TMP_MOD_skill90_FUNC_calculate_ex_attack_dmg_multiplier_RET);
	
	}
	
	function act()
	{
		return \skill962\act();
	}
	
	function parse_news($nid, $news, $hour, $min, $sec, $a, $b, $c, $d, $e, $exarr = array())
	{
		return \skill489\parse_news($nid,$news,$hour,$min,$sec,$a,$b,$c,$d,$e,$exarr);
	}
}

?>