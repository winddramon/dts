<?php

namespace skill271
{
	$skill271deno = 300;
	
	function init() 
	{
		define('MOD_SKILL271_INFO','club;');
		do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;   } while (0);
		$clubskillname[271] = '神裁';
	}
	
	function acquire271(&$pa)
	{
		
	}
	
	function lost271(&$pa)
	{
		
	}
	
	function check_unlocked271(&$pa)
	{
		
		return $pa['lvl']>=13;
	}
	
	function get_skill271_times(&$pa, &$pd, $active)
	{
		
		do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;  global $___LOCAL_SKILL271__VARS__skill271deno; $skill271deno=&$___LOCAL_SKILL271__VARS__skill271deno;   } while (0);
		
		$o_log = $log;
		$s1 = \weapon\get_skill($pa, $pd, $active);
		$s2 = \weapon\get_skill($pd, $pa, 1-$active);
		$log = $o_log;
		
		
		
		$t = 0;
		if ($s1 > $s2) {
			$t = floor(($s1-$s2)/$skill271deno);
		}
		
		return $t;
	}
	
	function get_all_attr271()
	{
		
		do { global $___LOCAL_EX_PHY_DEF__VARS__def_kind; $def_kind=&$___LOCAL_EX_PHY_DEF__VARS__def_kind;   } while (0);
		$arr = $def_kind;
		do { global $___LOCAL_EX_DMG_DEF__VARS__def_kind; $def_kind=&$___LOCAL_EX_DMG_DEF__VARS__def_kind;   } while (0);
		$arr = array_merge($arr,$def_kind);
		$arr['r'] = 'R';
		return $arr;
	}
	
	function get_avaliable_attr271(&$pa, &$pd, $active)
	{
		
		$all_arr = get_all_attr271();
		$a_arr = \attrbase\get_ex_attack_array($pa, $pd, $active);
		$a_arr = array_diff($a_arr,array('P','K','G','C','D','F'));
		$a_arr[] = $pa['wep_kind'];
		$ad_arr = array();
		foreach($a_arr as $ak){
			if(isset($all_arr[$ak]))	$ad_arr[] = $all_arr[$ak];
		}
		
		if(!$ad_arr) return array();
		$arr = \attrbase\get_ex_def_array($pa, $pd, $active);		
		if(\attrbase\check_in_itmsk('A', $arr)) {
			do { global $___LOCAL_EX_PHY_DEF__VARS__def_kind; $def_kind=&$___LOCAL_EX_PHY_DEF__VARS__def_kind;   } while (0);
			$arr = array_diff(array_merge($arr, array_values($def_kind)), array('A'));
		}
		if(\attrbase\check_in_itmsk('a', $arr)) {
			do { global $___LOCAL_EX_DMG_DEF__VARS__def_kind; $def_kind=&$___LOCAL_EX_DMG_DEF__VARS__def_kind;   } while (0);
			$arr = array_diff(array_merge($arr, array_values($def_kind)), array('a'));
		}
		
		$arr = array_unique(array_intersect($arr, $ad_arr));
		return $arr;
	}
	
	
	function strike_prepare(&$pa, &$pd, $active)
	{
		$___TEMP_backtrace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 2); 
		array_shift($___TEMP_backtrace);
		if (count($___TEMP_backtrace)==0) $___TEMP_PARENT_NAME=''; else $___TEMP_PARENT_NAME=strtolower($___TEMP_backtrace[0]['function']);
		if ($___TEMP_PARENT_NAME!='skill112\strike_prepare') 
		{
			return \skill507\strike_prepare($pa,$pd,$active);
		}
		unset($___TEMP_PARENT_NAME); unset($___TEMP_backtrace); 
	
		
if(isset($active)) {$__VAR_DUMP_MOD_skill271_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill271_VARS_active = NULL;} 
		//======== Start of contents from mod skill215 ========
		do{
			$___TMP_MOD_skill215_FUNC_strike_prepare_RET = NULL;

		
		if ($pa['bskill']!=215) {
			\skill208\strike_prepare($pa, $pd, $active);
			$___TMP_MOD_skill215_FUNC_strike_prepare_RET = NULL;
			break; 
		}
		if (!\skillbase\skill_query(215,$pa) || !\skill215\check_unlocked215 ($pa))
		{
			do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
			$log .= '你尚未解锁这个技能！';
			$pa['bskill']=0;
		}
		else
		{
			$rcost = \skill215\get_rage_cost215 ($pa);
			if (!\clubbase\check_battle_skill_unactivatable($pa,$pd,215))
			{
				do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
				if ($active)
					$log.="<span class=\"lime b\">你对{$pd['name']}发动了技能「高能」！</span><br>";
				else  $log.="<span class=\"lime b\">{$pa['name']}对你发动了技能「高能」！</span><br>";
				$pa['rage']-=$rcost;
				addnews ( 0, 'bskill215', $pa['name'], $pd['name'] );
			}
			else
			{
				if ($active)
				{
					do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;   } while (0);
					$log.='怒气不足或其他原因不能发动。<br>';
				}
				$pa['bskill']=0;
			}
		}
		\skill208\strike_prepare($pa, $pd, $active);
		}while(0);
		//======== End of contents from mod skill215 ========

$active = $__VAR_DUMP_MOD_skill271_VARS_active; unset($__VAR_DUMP_MOD_skill271_VARS_active);
		
		$___TMP_MOD_skill215_FUNC_strike_prepare_RET;
		if(\skillbase\skill_query(271, $pa) && \skill271\check_unlocked271 ($pa)){
			$t = \skill271\get_skill271_times ($pa, $pd, $active);
			if($t > 0){
				$pd_def_arr = \skill271\get_avaliable_attr271 ($pa, $pd, $active);
				
				if($pd_def_arr){
					shuffle($pd_def_arr);
					$pa['skill271_list'] = array_slice($pd_def_arr, 0, $t);
					do { global $___LOCAL_LOGGER__VARS__log; $log=&$___LOCAL_LOGGER__VARS__log;  global $___LOCAL_ITEMMAIN__VARS__tmp_itmsk_arr_pool,$___LOCAL_ITEMMAIN__VARS__itemfind_extra_log,$___LOCAL_ITEMMAIN__VARS__item_equip_list,$___LOCAL_ITEMMAIN__VARS__item_hotkey_id_list,$___LOCAL_ITEMMAIN__VARS__itemmain_drophint,$___LOCAL_ITEMMAIN__VARS__item_allow_find_and_use,$___LOCAL_ITEMMAIN__VARS__nosta,$___LOCAL_ITEMMAIN__VARS__nospk,$___LOCAL_ITEMMAIN__VARS__item_obbs,$___LOCAL_ITEMMAIN__VARS__map_noitemdrop_arealist, $___LOCAL_ITEMMAIN__VARS__itemkind_equipable,$___LOCAL_ITEMMAIN__VARS__iteminfo,$___LOCAL_ITEMMAIN__VARS__itemspkinfo,$___LOCAL_ITEMMAIN__VARS__itemspkdesc,$___LOCAL_ITEMMAIN__VARS__itemspkdesc_help,$___LOCAL_ITEMMAIN__VARS__itemspkremark; $tmp_itmsk_arr_pool=&$___LOCAL_ITEMMAIN__VARS__tmp_itmsk_arr_pool; $itemfind_extra_log=&$___LOCAL_ITEMMAIN__VARS__itemfind_extra_log; $item_equip_list=&$___LOCAL_ITEMMAIN__VARS__item_equip_list; $item_hotkey_id_list=&$___LOCAL_ITEMMAIN__VARS__item_hotkey_id_list; $itemmain_drophint=&$___LOCAL_ITEMMAIN__VARS__itemmain_drophint; $item_allow_find_and_use=&$___LOCAL_ITEMMAIN__VARS__item_allow_find_and_use; $nosta=&$___LOCAL_ITEMMAIN__VARS__nosta; $nospk=&$___LOCAL_ITEMMAIN__VARS__nospk; $item_obbs=&$___LOCAL_ITEMMAIN__VARS__item_obbs; $map_noitemdrop_arealist=&$___LOCAL_ITEMMAIN__VARS__map_noitemdrop_arealist;  $itemkind_equipable=&$___LOCAL_ITEMMAIN__VARS__itemkind_equipable; $iteminfo=&$___LOCAL_ITEMMAIN__VARS__iteminfo; $itemspkinfo=&$___LOCAL_ITEMMAIN__VARS__itemspkinfo; $itemspkdesc=&$___LOCAL_ITEMMAIN__VARS__itemspkdesc; $itemspkdesc_help=&$___LOCAL_ITEMMAIN__VARS__itemspkdesc_help; $itemspkremark=&$___LOCAL_ITEMMAIN__VARS__itemspkremark;   } while (0);
					$words = array();
					foreach($pa['skill271_list'] as $val){
						$words[] = $itemspkinfo[$val];
					}
					$words = implode('、',$words);
					$log .= \battle\battlelog_parser($pa, $pd, $active, '<:pa_name:>的「神裁」技能使<:pa_name:>无视了<:pd_name:>的'.$words.'属性！<br>');
				}
			}
			
		}
	
	}
	










	
	function check_ex_phy_def_proc(&$pa, &$pd, $active)
	{
if(isset($active)) {$__VAR_DUMP_MOD_skill271_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill271_VARS_active = NULL;} 
		//======== Start of contents from mod skill243 ========
		do{
			$___TMP_MOD_skill243_FUNC_check_ex_phy_def_proc_RET = NULL;

		
		if (!\skillbase\skill_query(243,$pa) || !\skill243\check_unlocked243 ($pa)){ $___TMP_MOD_skill243_FUNC_check_ex_phy_def_proc_RET =  \ex_phy_def\check_ex_phy_def_proc($pa,$pd,$active);
			break; } 
		$z=\ex_phy_def\check_ex_phy_def_proc($pa, $pd, $active);
		if (!$z)	
		{
			do { global $___LOCAL_EX_PHY_DEF__VARS__def_kind; $def_kind=&$___LOCAL_EX_PHY_DEF__VARS__def_kind;   } while (0);
			$s=\skillbase\skill_getvalue(243,'l',$pa);
			if (strpos($s,$def_kind[$pa['wep_kind']])===false)
			{
				$s.=$def_kind[$pa['wep_kind']];
				\skillbase\skill_setvalue(243,'l',$s,$pa);
			}
		}
		$___TMP_MOD_skill243_FUNC_check_ex_phy_def_proc_RET =  $z;
			break; 
		}while(0);
		//======== End of contents from mod skill243 ========

$active = $__VAR_DUMP_MOD_skill271_VARS_active; unset($__VAR_DUMP_MOD_skill271_VARS_active);
		
		$ret = $___TMP_MOD_skill243_FUNC_check_ex_phy_def_proc_RET;
		do { global $___LOCAL_EX_PHY_DEF__VARS__def_kind; $def_kind=&$___LOCAL_EX_PHY_DEF__VARS__def_kind;   } while (0);
		if(!empty($pa['skill271_list']) && in_array($def_kind[$pa['wep_kind']], $pa['skill271_list'])){
			$ret = 0;
			
		}
		return $ret;
	
	}
	
	
	function check_ex_dmg_def_proc(&$pa, &$pd, $active, $key)
	{
if(isset($active)) {$__VAR_DUMP_MOD_skill271_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill271_VARS_active = NULL;} if(isset($key)) {$__VAR_DUMP_MOD_skill271_VARS_key = $key; } else {$__VAR_DUMP_MOD_skill271_VARS_key = NULL;} 
		//======== Start of contents from mod skill243 ========
		do{
			$___TMP_MOD_skill243_FUNC_check_ex_dmg_def_proc_RET = NULL;

		
		if (!\skillbase\skill_query(243,$pa) || !\skill243\check_unlocked243 ($pa)){ $___TMP_MOD_skill243_FUNC_check_ex_dmg_def_proc_RET =  \ex_dmg_def\check_ex_dmg_def_proc($pa,$pd,$active,$key);
			break; } 
		$z=\ex_dmg_def\check_ex_dmg_def_proc($pa, $pd, $active, $key);
		if (!$z)	
		{
			do { global $___LOCAL_EX_DMG_DEF__VARS__def_kind; $def_kind=&$___LOCAL_EX_DMG_DEF__VARS__def_kind;   } while (0);
			$s=\skillbase\skill_getvalue(243,'l',$pa);
			if (strpos($s,$def_kind[$key])===false)
			{
				$s.=$def_kind[$key];
				\skillbase\skill_setvalue(243,'l',$s,$pa);
			}
		}
		$___TMP_MOD_skill243_FUNC_check_ex_dmg_def_proc_RET =  $z;
			break; 
		}while(0);
		//======== End of contents from mod skill243 ========

$active = $__VAR_DUMP_MOD_skill271_VARS_active; unset($__VAR_DUMP_MOD_skill271_VARS_active);$key = $__VAR_DUMP_MOD_skill271_VARS_key; unset($__VAR_DUMP_MOD_skill271_VARS_key);
		
		$ret = $___TMP_MOD_skill243_FUNC_check_ex_dmg_def_proc_RET;
		do { global $___LOCAL_EX_DMG_DEF__VARS__def_kind; $def_kind=&$___LOCAL_EX_DMG_DEF__VARS__def_kind;   } while (0);
		if(!empty($pa['skill271_list']) && in_array($def_kind[$key], $pa['skill271_list'])){
			$ret = 0;
		}
		return $ret;
	
	}
	
	
	function check_ex_rapid_def_proc(&$pa, &$pd, $active)
	{
if(isset($active)) {$__VAR_DUMP_MOD_skill271_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill271_VARS_active = NULL;} 
		//======== Start of contents from mod skill243 ========
		do{
			$___TMP_MOD_skill243_FUNC_check_ex_rapid_def_proc_RET = NULL;
if(isset($active)) {$__VAR_DUMP_MOD_skill243_VARS_active = $active; } else {$__VAR_DUMP_MOD_skill243_VARS_active = NULL;} 
		//======== Start of contents from mod ex_rapid_def ========
		do{
			$___TMP_MOD_ex_rapid_def_FUNC_check_ex_rapid_def_proc_RET = NULL;

		
		$proc_rate = \ex_rapid_def\get_ex_rapid_def_proc_rate ($pa, $pd, $active);
		$dice = rand(0,99);
		$___TMP_MOD_ex_rapid_def_FUNC_check_ex_rapid_def_proc_RET =  $dice < $proc_rate;
			break; 
		}while(0);
		//======== End of contents from mod ex_rapid_def ========

$active = $__VAR_DUMP_MOD_skill243_VARS_active; unset($__VAR_DUMP_MOD_skill243_VARS_active);

		
		$z=$___TMP_MOD_ex_rapid_def_FUNC_check_ex_rapid_def_proc_RET;
		if (!$z && \skillbase\skill_query(243,$pa) && \skill243\check_unlocked243 ($pa)){
			$s=\skillbase\skill_getvalue(243,'l',$pa);
			if (strpos($s,'R')===false)
			{
				$s.='R';
				\skillbase\skill_setvalue(243,'l',$s,$pa);
			}
		}
		$___TMP_MOD_skill243_FUNC_check_ex_rapid_def_proc_RET =  $z;
			break; 
		}while(0);
		//======== End of contents from mod skill243 ========

$active = $__VAR_DUMP_MOD_skill271_VARS_active; unset($__VAR_DUMP_MOD_skill271_VARS_active);
		
		$ret = $___TMP_MOD_skill243_FUNC_check_ex_rapid_def_proc_RET;
		if(!empty($pa['skill271_list']) && in_array('R', $pa['skill271_list'])){
			$ret = 0;
		}
		return $ret;
	
	}
}

?>