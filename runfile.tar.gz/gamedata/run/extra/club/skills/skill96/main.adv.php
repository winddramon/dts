<?php

namespace skill96
{
	function init()
	{
		define('MOD_SKILL96_INFO','club;buffer;');
		do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;  global $___LOCAL_BUFFICONS__VARS__bufficons_list,$___LOCAL_BUFFICONS__VARS__tmp_totsec,$___LOCAL_BUFFICONS__VARS__tmp_nowsec; $bufficons_list=&$___LOCAL_BUFFICONS__VARS__bufficons_list; $tmp_totsec=&$___LOCAL_BUFFICONS__VARS__tmp_totsec; $tmp_nowsec=&$___LOCAL_BUFFICONS__VARS__tmp_nowsec;   } while (0);
		$clubskillname[96] = '魂音';
		$bufficons_list[96] = Array(
			'disappear' => 1,
			'clickable' => 0,
			'hint' => '状态「魂音」：歌曲使你获得了强化！',
		);
	}
	
	function acquire96(&$pa)
	{
		
	}
	
	function lost96(&$pa)
	{
		
	}
	
	function check_unlocked96(&$pa)
	{
		
		return 1;
	}
	
	
	function get_final_dmg_multiplier(&$pa, &$pd, $active)
	{
		return \skill507\get_final_dmg_multiplier($pa,$pd,$active);
	}
	
	
	function calculate_active_obbs_multiplier(&$ldata,&$edata)
	{
		return \skill903\calculate_active_obbs_multiplier($ldata,$edata);
	}
	
	
	function get_ex_def_array_core(&$pa, &$pd, $active)
	{
		return \skill34\get_ex_def_array_core($pa,$pd,$active);
	}
	
	
	function get_ex_attack_array_core(&$pa, &$pd, $active)
	{
		return \skill507\get_ex_attack_array_core($pa,$pd,$active);
	}
	
}

?>