<?php

namespace skill58
{
	function init() 
	{
		define('MOD_SKILL58_INFO','club;feature;');
		do { global $___LOCAL_CLUBBASE__VARS__max_club_choice_num,$___LOCAL_CLUBBASE__VARS__clublist,$___LOCAL_CLUBBASE__VARS__clubinfo,$___LOCAL_CLUBBASE__VARS__clubdesc_a,$___LOCAL_CLUBBASE__VARS__clubdesc_h,$___LOCAL_CLUBBASE__VARS__clubskillname; $max_club_choice_num=&$___LOCAL_CLUBBASE__VARS__max_club_choice_num; $clublist=&$___LOCAL_CLUBBASE__VARS__clublist; $clubinfo=&$___LOCAL_CLUBBASE__VARS__clubinfo; $clubdesc_a=&$___LOCAL_CLUBBASE__VARS__clubdesc_a; $clubdesc_h=&$___LOCAL_CLUBBASE__VARS__clubdesc_h; $clubskillname=&$___LOCAL_CLUBBASE__VARS__clubskillname;   } while (0);
		$clubskillname[58] = '复活';
		$clubdesc_h[24] = $clubdesc_a[24] = '你被战斗/陷阱杀死时会立即复活。1局游戏只能复活1次。';
	}
	
	function acquire58(&$pa)
	{
		
		
		\skillbase\skill_setvalue(58,'r','0',$pa);
	}

	function lost58(&$pa)
	{
		
		\skillbase\skill_delvalue(58,'r',$pa);
	}
	
	function check_unlocked58(&$pa)
	{
		
		return 1;
	}
	
	
	function set_revive_sequence(&$pa, &$pd)
	{
		return \skill538\set_revive_sequence($pa,$pd);
	}	

	
	function revive_check(&$pa, &$pd, $rkey)
	{
		return \skill538\revive_check($pa,$pd,$rkey);
	}
	
	
	function post_revive_events(&$pa, &$pd, $rkey)
	{
		return \skill538\post_revive_events($pa,$pd,$rkey);
	}
	
	function kill(&$pa, &$pd)
	{
		return \skill576\kill($pa,$pd);
	}
	
	function player_kill_enemy(&$pa,&$pd,$active)
	{
		return \skill960\player_kill_enemy($pa,$pd,$active);
	}
	
	function parse_news($nid, $news, $hour, $min, $sec, $a, $b, $c, $d, $e, $exarr = array())
	{
		return \skill489\parse_news($nid,$news,$hour,$min,$sec,$a,$b,$c,$d,$e,$exarr);
	}
	
}

?>