<?php

namespace skill57
{
	function init() 
	{
		define('MOD_SKILL57_INFO','club;hidden;');
	}
	
	function acquire57(&$pa)
	{
		
		
		\skillbase\skill_setvalue(57,'p','0',$pa);
		
		\skillbase\skill_setvalue(57,'l','0',$pa);
	}
	
	function skill57_set_hpid($hpid,&$pa)
	{
		
		\skillbase\skill_setvalue(57,'p',$hpid,$pa);
	}
	
	function skill57_set_label($z,&$pa)
	{
		
		\skillbase\skill_setvalue(57,'l',$z,$pa);
	}
	
	function lost57(&$pa)
	{
		
	}
	
	function skill_onload_event(&$pa)
	{
		return \skill182\skill_onload_event($pa);
	}
}

?>
